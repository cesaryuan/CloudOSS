(()=>{
    var e = {
        802: (e,t,n)=>{
            self.window = self;
            const r = n(200).N
              , o = n(400);
            function s(e, t, n, o) {
                const s = h.readStringField(e, 0)
                  , i = h.readInt32Field(e, 4)
                  , a = h.readStringField(e, 8)
                  , c = h.readUint64Field(e, 20);
                if (null !== a) {
                    const t = h.readUint64Field(e, 12);
                    if (0 !== t)
                        return r.jsCallDispatcher.beginInvokeJSFromDotNet(t, s, a, i, c),
                        0;
                    {
                        const e = r.jsCallDispatcher.invokeJSFromDotNet(s, a, i, c);
                        return null === e ? 0 : BINDING.js_string_to_mono_string(e)
                    }
                }
                {
                    const e = r.jsCallDispatcher.findJSFunction(s, c).call(null, t, n, o);
                    switch (i) {
                    case r.JSCallResultType.Default:
                        return e;
                    case r.JSCallResultType.JSObjectReference:
                        return r.createJSObjectReference(e).__jsObjectId;
                    case r.JSCallResultType.JSStreamReference:
                        {
                            const t = r.createJSStreamReference(e)
                              , n = JSON.stringify(t);
                            return BINDING.js_string_to_mono_string(n)
                        }
                    case r.JSCallResultType.JSVoidResult:
                        return null;
                    default:
                        throw new Error(`Invalid JS call result type '${i}'.`)
                    }
                }
            }
            function i(e, t, n) {
                const o = BINDING.conv_string(e)
                  , s = 0 !== t
                  , i = BINDING.conv_string(n);
                r.jsCallDispatcher.endInvokeDotNetFromJS(o, s, i)
            }
            const a = Math.pow(2, 32)
              , c = Math.pow(2, 21) - 1;
            let l = null;
            function u(e) {
                return MONO.getI32(e)
            }
            function f(e) {
                return e + 12
            }
            function d() {
                if (l)
                    throw new Error("Assertion failed - heap is currently locked")
            }
            const h = {
                toUint8Array: function(e) {
                    const t = f(e)
                      , n = u(t)
                      , r = new Uint8Array(n);
                    return r.set(Module.HEAPU8.subarray(t + 4, t + 4 + n)),
                    r
                },
                getArrayLength: function(e) {
                    return u(f(e))
                },
                getArrayEntryPtr: function(e, t, n) {
                    return f(e) + 4 + t * n
                },
                getObjectFieldsBaseAddress: function(e) {
                    return e + 8
                },
                readInt16Field: function(e, t) {
                    return n = e + (t || 0),
                    MONO.getI16(n);
                    var n
                },
                readInt32Field: function(e, t) {
                    return u(e + (t || 0))
                },
                readUint64Field: function(e, t) {
                    return function(e) {
                        const t = e >> 2
                          , n = Module.HEAPU32[t + 1];
                        if (n > c)
                            throw new Error(`Cannot read uint64 with high order part ${n}, because the result would exceed Number.MAX_SAFE_INTEGER.`);
                        return n * a + Module.HEAPU32[t]
                    }(e + (t || 0))
                },
                readFloatField: function(e, t) {
                    return n = e + (t || 0),
                    MONO.getF32(n);
                    var n
                },
                readObjectField: function(e, t) {
                    return u(e + (t || 0))
                },
                readStringField: function(e, t, n) {
                    const r = u(e + (t || 0));
                    if (0 === r)
                        return null;
                    if (n) {
                        const e = BINDING.unbox_mono_obj(r);
                        return "boolean" == typeof e ? e ? "" : null : e
                    }
                    let o;
                    return l ? (o = l.stringCache.get(r),
                    void 0 === o && (o = BINDING.conv_string(r),
                    l.stringCache.set(r, o))) : o = BINDING.conv_string(r),
                    o
                },
                readStructField: function(e, t) {
                    return e + (t || 0)
                },
                beginHeapLock: function() {
                    return d(),
                    l = new m,
                    l
                },
                invokeWhenHeapUnlocked: function(e) {
                    l ? l.enqueuePostReleaseAction(e) : e()
                }
            };
            class m {
                constructor() {
                    this.stringCache = new Map,
                    this.postReleaseActions = void 0
                }
                enqueuePostReleaseAction(e) {
                    this.postReleaseActions || (this.postReleaseActions = []),
                    this.postReleaseActions.push(e)
                }
                release() {
                    if (l !== this)
                        throw new Error("Trying to release a lock which isn't current");
                    for (l = null; null !== (e = this.postReleaseActions) && void 0 !== e && e.length; ) {
                        var e;
                        this.postReleaseActions.shift()(),
                        d()
                    }
                }
            }
            (async()=>{
                const e = JSON.parse(o)
                  , t = e.resources
                  , n = t.assembly
                  , r = t.runtime
                  , a = e.entryAssembly
                  , c = Object.keys(r).find((e=>e.startsWith("dotnet.") && e.endsWith(".js")));
                importScripts(`/static/${c}`),
                await self.createDotnetRuntime((async e=>{
                    const t = e.MONO
                      , n = e.BINDING
                      , r = e.Module;
                    return self.Module = r,
                    self.BINDING = n,
                    self.MONO = t,
                    {
                        disableDotnet6Compatibility: !1
                    }
                }
                )),
                await Promise.all(Object.keys(n).map((e=>async function(e, t) {
                    const n = `blazor:${e.name}`;
                    Module.addRunDependency(n);
                    try {
                        const n = await fetch(`/static/${e}`)
                          , r = await n.arrayBuffer()
                          , o = new Uint8Array(r)
                          , s = Module._malloc(o.length);
                        new Uint8Array(Module.HEAPU8.buffer,s,o.length).set(o),
                        MONO.mono_wasm_add_assembly(t, s, o.length),
                        MONO.loaded_files.push(e.url)
                    } catch (e) {
                        return void console.error(e)
                    }
                    Module.removeRunDependency(n)
                }(e, function(e, t) {
                    const n = e.lastIndexOf(".");
                    if (n < 0)
                        throw new Error(`No extension to replace in '${e}'`);
                    return e.substr(0, n) + ".dll"
                }(e))))),
                MONO.mono_wasm_load_runtime("appBinDir", 0),
                MONO.mono_wasm_runtime_ready(),
                self.Blazor = {
                    _internal: {
                        invokeJSFromDotNet: s,
                        endInvokeDotNetFromJS: i
                    }
                },
                await BINDING.call_assembly_entry_point(a, [[]], "m")
            }
            )(),
            self.bindStaticMethod = (e,t)=>{
                const n = `[Regex101] Regex101.${e}:${t}`;
                return BINDING.bind_static_method(n)
            }
        }
        ,
        400: e=>{
            "use strict";
            e.exports = '{\r\n  "cacheBootResources": true,\r\n  "config": [ ],\r\n  "debugBuild": false,\r\n  "entryAssembly": "Regex101",\r\n  "icuDataMode": 2,\r\n  "linkerEnabled": true,\r\n  "resources": {\r\n    "assembly": {\r\n      "Microsoft.JSInterop.WebAssembly.dll": "sha256-6NTHrsP9YxveChFq0Y2IfOBHRjJvsq4v3Al\\/\\/DUJcEI=",\r\n      "Regex101.dll": "sha256-RZ3l7x2LVPYyaEoIZIG7SXh0oSC4BbukgoNvqKCE754=",\r\n      "System.Collections.Concurrent.dll": "sha256-CeVRyHv99fAUoex4nb0CWmYYnlBZ1L1WqxE0sFna6MI=",\r\n      "System.Collections.dll": "sha256-vluyRBYl+N+IWKMQtKfDOrpH3yOIpbrcH+ohtwi1B6Y=",\r\n      "System.Private.CoreLib.dll": "sha256-J4tmqFG65Q0fx3d5mzDjPw9S8FgFrXzTAy3kUpvHY50=",\r\n      "System.Private.Runtime.InteropServices.JavaScript.dll": "sha256-FttJUOjKRld1eqprqI0312NxWuFTsT2uG+afr3qwOxs=",\r\n      "System.Private.Uri.dll": "sha256-YRiHJSbuGxbtYO2DaP46xJGz3VdGHxMiz0Ie0sy0XRY=",\r\n      "System.Runtime.CompilerServices.Unsafe.dll": "sha256-WyGW3gZcJVrhwgtDTXzYd5Igi0uaZT8G4Z4w30QBwhI=",\r\n      "System.Runtime.dll": "sha256-dg5TfMDmwOxYTXCiGYgmSZL2UIwelnD7X9BMhAtHZO4=",\r\n      "System.Text.RegularExpressions.dll": "sha256-qZdpiEkYAlOSbT74eNmn6fRGcnHIgCm8F5c+e0j+lmI="\r\n    },\r\n    "extensions": null,\r\n    "lazyAssembly": null,\r\n    "libraryInitializers": null,\r\n    "pdb": null,\r\n    "runtime": {\r\n      "dotnet.7.0.0-preview.1.22076.8.dmvubuk7mh.js": "sha256-vw+OrEwuXe7Uq3+YxuntTP175vixizEEwtvqLpSlJsk=",\r\n      "dotnet.wasm": "sha256-gzBhYUhWrTwQtIOhzHyYigKQlok8nIIpx6tmGh8\\/S0Q="\r\n    },\r\n    "satelliteResources": null\r\n  }\r\n}'
        }
        ,
        200: (e,t,n)=>{
            "use strict";
            var r;
            n.d(t, {
                N: ()=>r
            }),
            function(e) {
                window.DotNet = e;
                const t = []
                  , n = new Map
                  , r = new Map
                  , o = "__jsObjectId"
                  , s = "__byte[]";
                class i {
                    constructor(e) {
                        this._jsObject = e,
                        this._cachedFunctions = new Map
                    }
                    findFunction(e) {
                        const t = this._cachedFunctions.get(e);
                        if (t)
                            return t;
                        let n, r = this._jsObject;
                        if (e.split(".").forEach((t=>{
                            if (!(t in r))
                                throw new Error(`Could not find '${e}' ('${t}' was undefined).`);
                            n = r,
                            r = r[t]
                        }
                        )),
                        r instanceof Function)
                            return r = r.bind(n),
                            this._cachedFunctions.set(e, r),
                            r;
                        throw new Error(`The value '${e}' is not a function.`)
                    }
                    getWrappedObject() {
                        return this._jsObject
                    }
                }
                const a = {}
                  , c = {
                    0: new i(window)
                };
                c[0]._cachedFunctions.set("import", (e=>("string" == typeof e && e.startsWith("./") && (e = document.baseURI + e.substr(2)),
                import(e))));
                let l, u = 1, f = 1, d = null;
                function h(e) {
                    t.push(e)
                }
                function m(e) {
                    if (e && "object" == typeof e) {
                        c[f] = new i(e);
                        const t = {
                            [o]: f
                        };
                        return f++,
                        t
                    }
                    throw new Error(`Cannot create a JSObjectReference from the value '${e}'.`)
                }
                function p(e) {
                    let t = -1;
                    if (e instanceof ArrayBuffer && (e = new Uint8Array(e)),
                    e instanceof Blob)
                        t = e.size;
                    else {
                        if (!(e.buffer instanceof ArrayBuffer))
                            throw new Error("Supplied value is not a typed array or blob.");
                        if (void 0 === e.byteLength)
                            throw new Error(`Cannot create a JSStreamReference from the value '${e}' as it doesn't have a byteLength.`);
                        t = e.byteLength
                    }
                    const n = {
                        __jsStreamReferenceLength: t
                    };
                    try {
                        const t = m(e);
                        n.__jsObjectId = t.__jsObjectId
                    } catch {
                        throw new Error(`Cannot create a JSStreamReference from the value '${e}'.`)
                    }
                    return n
                }
                function y(e) {
                    return e ? JSON.parse(e, ((e,n)=>t.reduce(((t,n)=>n(e, t)), n))) : null
                }
                function w(e, t, n, r) {
                    const o = S();
                    if (o.invokeDotNetFromJS) {
                        const s = D(r)
                          , i = o.invokeDotNetFromJS(e, t, n, s);
                        return i ? y(i) : null
                    }
                    throw new Error("The current dispatcher does not support synchronous calls from JS to .NET. Use invokeMethodAsync instead.")
                }
                function b(e, t, n, r) {
                    if (e && n)
                        throw new Error(`For instance method calls, assemblyName should be null. Received '${e}'.`);
                    const o = u++
                      , s = new Promise(((e,t)=>{
                        a[o] = {
                            resolve: e,
                            reject: t
                        }
                    }
                    ));
                    try {
                        const s = D(r);
                        S().beginInvokeDotNetFromJS(o, e, t, n, s)
                    } catch (e) {
                        g(o, !1, e)
                    }
                    return s
                }
                function S() {
                    if (null !== d)
                        return d;
                    throw new Error("No .NET call dispatcher has been set.")
                }
                function g(e, t, n) {
                    if (!a.hasOwnProperty(e))
                        throw new Error(`There is no pending async call with ID ${e}.`);
                    const r = a[e];
                    delete a[e],
                    t ? r.resolve(n) : r.reject(n)
                }
                function v(e) {
                    return e instanceof Error ? `${e.message}\n${e.stack}` : e ? e.toString() : "null"
                }
                function _(e, t) {
                    let n = c[t];
                    if (n)
                        return n.findFunction(e);
                    throw new Error(`JS object instance with ID ${t} does not exist (has it been disposed?).`)
                }
                function I(e) {
                    delete c[e]
                }
                e.attachDispatcher = function(e) {
                    d = e
                }
                ,
                e.attachReviver = h,
                e.invokeMethod = function(e, t, ...n) {
                    return w(e, t, null, n)
                }
                ,
                e.invokeMethodAsync = function(e, t, ...n) {
                    return b(e, t, null, n)
                }
                ,
                e.createJSObjectReference = m,
                e.createJSStreamReference = p,
                e.disposeJSObjectReference = function(e) {
                    const t = e && e.__jsObjectId;
                    "number" == typeof t && I(t)
                }
                ,
                function(e) {
                    e[e.Default = 0] = "Default",
                    e[e.JSObjectReference = 1] = "JSObjectReference",
                    e[e.JSStreamReference = 2] = "JSStreamReference",
                    e[e.JSVoidResult = 3] = "JSVoidResult"
                }(l = e.JSCallResultType || (e.JSCallResultType = {})),
                e.jsCallDispatcher = {
                    findJSFunction: _,
                    disposeJSObjectReferenceById: I,
                    invokeJSFromDotNet: (e,t,n,r)=>{
                        const o = j(_(e, r).apply(null, y(t)), n);
                        return null == o ? null : D(o)
                    }
                    ,
                    beginInvokeJSFromDotNet: (e,t,n,r,o)=>{
                        const s = new Promise((e=>{
                            e(_(t, o).apply(null, y(n)))
                        }
                        ));
                        e && s.then((t=>S().endInvokeJSFromDotNet(e, !0, D([e, !0, j(t, r)]))), (t=>S().endInvokeJSFromDotNet(e, !1, JSON.stringify([e, !1, v(t)]))))
                    }
                    ,
                    endInvokeDotNetFromJS: (e,t,n)=>{
                        const r = t ? y(n) : new Error(n);
                        g(parseInt(e), t, r)
                    }
                    ,
                    receiveByteArray: (e,t)=>{
                        n.set(e, t)
                    }
                    ,
                    supplyDotNetStream: (e,t)=>{
                        if (r.has(e)) {
                            const n = r.get(e);
                            r.delete(e),
                            n.resolve(t)
                        } else {
                            const n = new R;
                            n.resolve(t),
                            r.set(e, n)
                        }
                    }
                };
                class O {
                    constructor(e) {
                        this._id = e
                    }
                    invokeMethod(e, ...t) {
                        return w(null, e, this._id, t)
                    }
                    invokeMethodAsync(e, ...t) {
                        return b(null, e, this._id, t)
                    }
                    dispose() {
                        b(null, "__Dispose", this._id, null).catch((e=>console.error(e)))
                    }
                    serializeAsArg() {
                        return {
                            __dotNetObject: this._id
                        }
                    }
                }
                e.DotNetObject = O,
                h((function(e, t) {
                    if (t && "object" == typeof t) {
                        if (t.hasOwnProperty("__dotNetObject"))
                            return new O(t.__dotNetObject);
                        if (t.hasOwnProperty(o)) {
                            const e = t.__jsObjectId
                              , n = c[e];
                            if (n)
                                return n.getWrappedObject();
                            throw new Error(`JS object instance with Id '${e}' does not exist. It may have been disposed.`)
                        }
                        if (t.hasOwnProperty(s)) {
                            const e = t["__byte[]"]
                              , r = n.get(e);
                            if (void 0 === r)
                                throw new Error(`Byte array index '${e}' does not exist.`);
                            return n.delete(e),
                            r
                        }
                        if (t.hasOwnProperty("__dotNetStream"))
                            return new N(t.__dotNetStream)
                    }
                    return t
                }
                ));
                class N {
                    constructor(e) {
                        var t;
                        if (r.has(e))
                            this._streamPromise = null === (t = r.get(e)) || void 0 === t ? void 0 : t.streamPromise,
                            r.delete(e);
                        else {
                            const t = new R;
                            r.set(e, t),
                            this._streamPromise = t.streamPromise
                        }
                    }
                    stream() {
                        return this._streamPromise
                    }
                    async arrayBuffer() {
                        return new Response(await this.stream()).arrayBuffer()
                    }
                }
                class R {
                    constructor() {
                        this.streamPromise = new Promise(((e,t)=>{
                            this.resolve = e,
                            this.reject = t
                        }
                        ))
                    }
                }
                function j(e, t) {
                    switch (t) {
                    case l.Default:
                        return e;
                    case l.JSObjectReference:
                        return m(e);
                    case l.JSStreamReference:
                        return p(e);
                    case l.JSVoidResult:
                        return null;
                    default:
                        throw new Error(`Invalid JS call result type '${t}'.`)
                    }
                }
                let J = 0;
                function D(e) {
                    return J = 0,
                    JSON.stringify(e, M)
                }
                function M(e, t) {
                    if (t instanceof O)
                        return t.serializeAsArg();
                    if (t instanceof Uint8Array) {
                        d.sendByteArray(J, t);
                        const e = {
                            [s]: J
                        };
                        return J++,
                        e
                    }
                    return t
                }
            }(r || (r = {}))
        }
    }
      , t = {};
    function n(r) {
        var o = t[r];
        if (void 0 !== o)
            return o.exports;
        var s = t[r] = {
            exports: {}
        };
        return e[r](s, s.exports, n),
        s.exports
    }
    n.d = (e,t)=>{
        for (var r in t)
            n.o(t, r) && !n.o(e, r) && Object.defineProperty(e, r, {
                enumerable: !0,
                get: t[r]
            })
    }
    ,
    n.o = (e,t)=>Object.prototype.hasOwnProperty.call(e, t),
    (()=>{
        "use strict";
        function e(e, t) {
            (null == t || t > e.length) && (t = e.length);
            for (var n = 0, r = new Array(t); n < t; n++)
                r[n] = e[n];
            return r
        }
        function t(t, n) {
            return function(e) {
                if (Array.isArray(e))
                    return e
            }(t) || function(e, t) {
                var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                if (null != n) {
                    var r, o, s = [], i = !0, a = !1;
                    try {
                        for (n = n.call(e); !(i = (r = n.next()).done) && (s.push(r.value),
                        !t || s.length !== t); i = !0)
                            ;
                    } catch (e) {
                        a = !0,
                        o = e
                    } finally {
                        try {
                            i || null == n.return || n.return()
                        } finally {
                            if (a)
                                throw o
                        }
                    }
                    return s
                }
            }(t, n) || function(t, n) {
                if (t) {
                    if ("string" == typeof t)
                        return e(t, n);
                    var r = Object.prototype.toString.call(t).slice(8, -1);
                    return "Object" === r && t.constructor && (r = t.constructor.name),
                    "Map" === r || "Set" === r ? Array.from(t) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? e(t, n) : void 0
                }
            }(t, n) || function() {
                throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }()
        }
        n(802);
        const r = e=>{
            const n = {};
            for (let r = 0; r < e.length; r++) {
                const s = e[r];
                for (let e = 0; e < s.length; e++) {
                    const r = s[e]
                      , i = t(o(r), 2)
                      , a = i[0]
                      , c = i[1];
                    if (!(a < 0))
                        if (a === c)
                            n[a] = [...n[a] || [], r];
                        else
                            for (let e = a; e < c; e++)
                                n[e] = [...n[e] || [], r]
                }
            }
            return n
        }
          , o = e=>[Math.min(e.start, e.end), Math.max(e.start, e.end)];
        var s;
        null == (s = self).performance && (s.performance = {}),
        null == s.performance.now && (s.performance.now = ()=>Date.now()),
        self.onmessage = function(e) {
            try {
                const t = performance.now()
                  , {regex: n, testString: o, flags: s} = e.data
                  , i = (s.includes("g") ? self.RegexMatches : self.RegexMatch)(n, o, function(e) {
                    return e.split("").reduce(((e,t)=>{
                        switch (t) {
                        case "n":
                            return 4 | e;
                        case "i":
                            return 1 | e;
                        case "x":
                            return 32 | e;
                        case "m":
                            return 2 | e;
                        case "s":
                            return 16 | e;
                        case "R":
                            return 64 | e;
                        case "g":
                            return e;
                        default:
                            throw new Error(`Unknown flag '${t}'`)
                        }
                    }
                    ), 0)
                }(s))
                  , a = JSON.parse(i)
                  , c = {
                    matchResult: a,
                    matchMap: r(a),
                    time: performance.now() - t
                };
                self.postMessage(c)
            } catch (e) {
                console.error(e),
                self.postMessage({
                    error: e.message
                })
            }
        }
        ,
        self.engineInit = ()=>{
            self.RegexMatches = bindStaticMethod("Helpers", "RegexMatches"),
            self.RegexMatch = bindStaticMethod("Helpers", "RegexMatch"),
            self.postMessage("onload")
        }
    }
    )()
}
)();
