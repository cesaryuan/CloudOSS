(() => {
  var e,
    t,
    r,
    s,
    n,
    a,
    i,
    o = {
      14850: (e, t, r) => {
        "use strict";
        r.d(t, {
          CJ: () => b,
          MX: () => de,
          K_: () => v,
          jb: () => X,
          jJ: () => w,
          s1: () => le,
          v0: () => je,
          xv: () => Oe,
          Of: () => L,
          zp: () => M,
          sk: () => Le,
          Ak: () => _e,
          ew: () => j,
          xz: () => xe,
          by: () => J,
          Ot: () => a,
          hK: () => g,
          IU: () => Ne,
          Ky: () => Q,
          Dk: () => re,
          tP: () => ve,
          bL: () => ye,
          kB: () => we,
          ak: () => q,
          Ub: () => se,
          Bq: () => H,
          zO: () => ee,
          uf: () => E,
          G6: () => I,
          QF: () => N,
          Ez: () => ue,
          dL: () => A.Z,
          o6: () => T,
          fU: () => pe,
          JO: () => he,
          rS: () => R,
          ML: () => me,
          _1: () => fe,
          Gj: () => m,
          I2: () => n,
          ZI: () => D,
          E0: () => C,
          Jh: () => _,
          UZ: () => y,
          vn: () => B,
          Iu: () => G,
          ux: () => U,
          rI: () => F,
          h5: () => O,
          dM: () => o,
          UF: () => i,
          NS: () => Ae,
          Tr: () => Ce,
          SD: () => d,
          BF: () => p,
          ZD: () => Ze,
          og: () => V,
          $9: () => De,
          _v: () => Ee,
        });
        var s = r(34963);
        const n = function (e) {
            return { type: s.jo, value: e };
          },
          a = function () {
            return { type: s.rx };
          },
          i = function () {
            return { type: s.fB };
          },
          o = function (e) {
            return { type: s.sk, value: e };
          };
        var c = r(31807),
          l = r.n(c),
          u = r(48211),
          h = r(53808);
        function p(e, t = !0) {
          if (!l()) return;
          const s = u[e] || u.ENGLISH;
          return () =>
            fetch(s.file)
              .then((e) => e.json())
              .then(h.a)
              .then(() => {
                t && r(6817).P();
              });
        }
        const d = function (e) {
            return { type: s.ro, value: { subsection: e } };
          },
          g = function (e) {
            return { type: s.WV, value: e };
          },
          m = function (e) {
            return { type: s.CJ, value: e };
          };
        var f = r(14824),
          x = r(89441);
        const b = function (e) {
            return {
              type: s.lA,
              value: e || {
                description: null,
                testString: "",
                compareString: "",
                target: x.m,
                criteria: f.FS,
              },
            };
          },
          v = function (e) {
            return { type: s.rT, value: e };
          },
          j = function (e, t) {
            return { type: s.mo, value: { oldIndex: e, newIndex: t } };
          },
          y = function (e, t, r, n) {
            return {
              type: s.ES,
              value: { testKey: e, error: t, steps: r, time: n },
            };
          },
          O = function () {
            return { type: s.p2 };
          },
          w = function () {
            return { type: s.lZ };
          },
          C = function (e) {
            return { type: s.Jb, value: e };
          },
          E = function (e) {
            return { type: s.a0, value: e };
          };
        var Z = r(4844),
          S = r(34768);
        const k = [
            S.Y8,
            S.D9,
            S.ik,
            S.VE,
            S.ek,
            S.Rp,
            S.Fo,
            S.ed,
            S.wm,
            S.Vu,
            S.e0,
            S.UA,
            S.Gv,
          ].map((e) => ("" + e).toLowerCase().trim()),
          P = [
            "recursive call could loop indefinitely",
            "regular expression is too large",
            "too much recursion",
          ],
          N = function (e) {
            const t = ("" + e).toLowerCase().trim();
            if (e && !k.includes(t) && !P.some((e) => t.includes(e))) {
              const t = new Error(
                "Unhandled error while matching regex. Code: " + e
              );
              Z.O7(t);
            }
            return { type: s.Nl, value: e };
          },
          _ = function (e) {
            return { type: s.Cy, value: e };
          },
          T = function (e) {
            return { type: s.hl, value: e };
          };
        var A = r(61898);
        const I = function (e) {
          return { type: s.Sr, value: e };
        };
        function R(e) {
          return { type: s.KE, value: e };
        }
        const D = function (e) {
          return { type: s.u8, value: e };
        };
        function L(e, t) {
          return (r, s) => {
            if (!e) return Promise.resolve();
            const n = s().general.cookie;
            return fetch(`/api/regex/${e}/${t}`, {
              method: "GET",
              credentials: "same-origin",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                cookie: n,
              },
            })
              .then((e) => e.json())
              .then((s) => {
                const n = s.regex,
                  a = s.testString,
                  i = void 0 === a ? "" : a,
                  o = s.flavor,
                  c = s.delimiter,
                  l = s.flags,
                  u = s.substitution,
                  h = void 0 === u ? "" : u,
                  p = s.listSubstitution,
                  d = void 0 === p ? "" : p,
                  g = s.unitTests,
                  m = s.isFavorite,
                  f = s.isLibraryEntry,
                  x = s.title,
                  v = s.tags,
                  j = s.libraryTitle,
                  y = s.libraryDescription,
                  O = s.libraryAuthor,
                  w = s.isEditable,
                  C = s.isOwner;
                r(E(n)),
                  r(_(i)),
                  r(T(o)),
                  r(I(c)),
                  r(A.Z("", l, o)),
                  null != h
                    ? (r(U()), r(D(h)))
                    : null != d && (r(B()), r(q(d))),
                  g.forEach((e) => r(b(e))),
                  null == d && null == h && "" === i && g.length > 0 && r(F()),
                  r(we(j, y, O)),
                  r(H(e, t, null, f, x || j, v, C)),
                  r(X(m)),
                  r(ee(w));
              });
          };
        }
        function M(e) {
          return (t) =>
            fetch("/api/regex/" + e, {
              method: "GET",
              credentials: "same-origin",
            })
              .then((e) => e.json())
              .then(({ versions: e }) =>
                t(
                  (function (e) {
                    return { type: s.r0, value: e };
                  })(e)
                )
              );
        }
        const U = function () {
            return { type: s.T_ };
          },
          F = function () {
            return { type: s.YW };
          },
          G = function () {
            return { type: s.RS };
          };
        function V(e) {
          return { type: s.NJ, value: e };
        }
        const B = function () {
          return { type: s.R8 };
        };
        function q(e) {
          return { type: s.r$, value: e };
        }
        const H = function (e, t, r, n, a = "", i = [], o) {
          return (
            (t = parseInt(t, 10) || null),
            {
              type: s.nU,
              value: {
                permalinkFragment: e,
                version: t,
                deleteCode: r,
                isLibraryEntry: n,
                title: a,
                tags: i,
                isOwner: o,
              },
            }
          );
        };
        var $ = r(4942),
          z = r(25968),
          W = r(94500);
        function Y(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function K(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Y(Object(r), !0).forEach(function (t) {
                  (0, $.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Y(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        function J(e = !1) {
          return (t, r) => {
            z.ZP.emit(z.P);
            const s = r(),
              n = s.unitTests.tests.map((e) => ({
                criteria: e.criteria,
                description: e.description,
                target: e.target,
                testString: e.testString,
                compareString: e.compareString,
              })),
              a = s.regexEditor;
            let i = {
              regex: a.regex,
              testString: a.testString,
              flags: a.flags,
              delimiter: a.delimiter,
              flavor: a.flavor,
              unitTests: n,
            };
            e && (i.permalinkFragment = s.general.permalinkFragment);
            const o = s.regexEditor,
              c = o.showSubstitutionArea,
              l = o.substString,
              u = o.showListSubstitutionArea,
              h = o.listSubstString;
            let p, d;
            return (
              c
                ? (i = K(K({}, i), {}, { substitution: l || "" }))
                : u && (i = K(K({}, i), {}, { listSubstitution: h || "" })),
              e && ((p = s.general.title), (d = s.general.tags)),
              fetch("/api/regex/", {
                method: "POST",
                credentials: "same-origin",
                headers: {
                  Accept: "application/json",
                  "Content-Type": "application/json",
                },
                body: JSON.stringify(i),
              })
                .then((e) => e.json())
                .then((r) => {
                  const s = r.permalinkFragment,
                    n = r.version,
                    a = r.isLibraryEntry;
                  let o = r.deleteCode;
                  return (
                    i.permalinkFragment && !o && (o = void 0),
                    null != o && (0, W.SW)(s, o),
                    t(H(s, n, o, a, p, d, !e || void 0)),
                    { permalinkFragment: s, version: n, deleteCode: o }
                  );
                })
            );
          };
        }
        const X = function (e) {
            return { type: s.yF, value: e };
          },
          Q = function (e) {
            return { type: s.yB, value: e };
          },
          ee = function (e) {
            return { type: s._, value: e };
          };
        var te = r(34595);
        const re = function (e) {
            return { type: s.ol, value: e || te.DEFAULT_PAGE_TITLE };
          },
          se = function (e) {
            return { type: s.lK, value: e || te.DEFAULT_META_DESCRIPTION };
          };
        var ne = r(17563),
          ae = r(7504),
          ie = r.n(ae);
        function oe(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function ce(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? oe(Object(r), !0).forEach(function (t) {
                  (0, $.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : oe(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        function le(e = ie().ALL, t = 1, r = []) {
          return (n, a) => {
            const i = a().general.cookie;
            return fetch(
              `/api/user/history/${e}/${t}/?${ne.stringify({ filterTags: r })}`,
              {
                method: "GET",
                credentials: "same-origin",
                headers: { cookie: i },
              }
            )
              .then((e) => e.json())
              .then((e) =>
                n(
                  (function (e, t = !1) {
                    return {
                      type: s.sH,
                      value: ce(ce({}, e), {}, { staleData: t }),
                    };
                  })(e)
                )
              );
          };
        }
        function ue(e, t, r) {
          return (n) =>
            fetch(`/api/user/favorite/${e}`, {
              method: "PUT",
              credentials: "same-origin",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
              },
              body: JSON.stringify({ isFavorite: r }),
            }).then(() => {
              null != t &&
                n({ type: s.Ht, value: { itemIndex: t, isFavorite: r } });
            });
        }
        function he(e, t, r) {
          return (n) =>
            fetch(`/api/user/history/${e}/private`, {
              method: "PUT",
              credentials: "same-origin",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
              },
              body: JSON.stringify({ isPrivate: r }),
            }).then(() =>
              n({ type: s.Ht, value: { itemIndex: t, isPrivate: r } })
            );
        }
        function pe(e, t, r) {
          return (n) =>
            fetch(`/api/user/history/${e}/lock`, {
              method: "PUT",
              credentials: "same-origin",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
              },
              body: JSON.stringify({ isLocked: r }),
            }).then(() =>
              n({ type: s.Ht, value: { itemIndex: t, isLocked: r } })
            );
        }
        function de(e, t) {
          return () =>
            fetch("/api/regex", {
              method: "DELETE",
              credentials: "same-origin",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
              },
              body: JSON.stringify({ deleteCode: t }),
            }).then(() => (0, W.rP)(e));
        }
        var ge = r(60370);
        function me(e, t, r) {
          const n = (0, ge.Z)(e);
          return (a, i) =>
            fetch(`/api/user/history/${r}/tags`, {
              method: "PUT",
              credentials: "same-origin",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
              },
              body: JSON.stringify({ tags: n }),
            }).then(() => {
              null != t &&
                a(
                  (function (e, t) {
                    return { type: s.Xm, value: { tags: e, itemIndex: t } };
                  })(e, t)
                );
              const o = i().general.permalinkFragment;
              null != o && r === o && a({ type: s.CN, value: n });
            });
        }
        function fe(e, t, r) {
          return (n, a) =>
            fetch(`/api/user/history/${r}/title`, {
              method: "PUT",
              credentials: "same-origin",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
              },
              body: JSON.stringify({ title: e }),
            }).then(() => {
              null != t && n({ type: s.Ht, value: { itemIndex: t, title: e } });
              const i = a().general.permalinkFragment;
              null != i && r === i && n({ type: s.se, value: e });
            });
        }
        function xe() {
          return { type: s.go };
        }
        var be = r(35896);
        const ve = function (e, t = 0) {
          return { type: s.b9, value: { libraryData: e, pages: t } };
        };
        function je(e = 1, t = "", r = be.MOST_RECENT, s = []) {
          const n = ne.stringify({ search: t, orderBy: r, filterFlavors: s });
          return (t, r) => {
            const s = r().general.cookie;
            return fetch(`/api/library/${e}/?${n}`, {
              method: "GET",
              credentials: "same-origin",
              headers: { cookie: s },
            })
              .then((e) => e.json())
              .then((e) => t(ve(e.data, e.pages)));
          };
        }
        const ye = function (e) {
          return { type: s.mX, value: e };
        };
        function Oe(e) {
          return (t, r) => {
            const s = r().general.cookie;
            return fetch(`/api/library/details/${e}`, {
              method: "GET",
              credentials: "same-origin",
              headers: { cookie: s },
            })
              .then((e) => e.json())
              .then((e) => t(ye(e)));
          };
        }
        const we = function (e, t, r) {
          return { type: s.DE, value: { title: e, description: t, author: r } };
        };
        function Ce(e, t, r) {
          return (s, n) => {
            z.ZP.emit(z.P);
            const a = n(),
              i = a.unitTests.tests.map((e) => ({
                criteria: e.criteria,
                description: e.description,
                target: e.target,
                testString: e.testString,
                compareString: e.compareString,
              })),
              o = a.regexEditor,
              c = o.regex,
              l = o.testString,
              u = o.flags,
              h = o.delimiter,
              p = o.flavor,
              d = o.showSubstitutionArea,
              g = o.substString;
            return fetch("/api/library/", {
              method: "POST",
              credentials: "same-origin",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                regex: c,
                testString: l,
                flags: u,
                delimiter: h,
                flavor: p,
                unitTests: i,
                author: r,
                description: t,
                title: e,
                substitution: d ? g || "" : null,
              }),
            })
              .then((e) => e.json())
              .then(({ permalinkFragment: n }) => (s(we(e, t, r)), n));
          };
        }
        function Ee(e, t) {
          return (r) =>
            fetch(`/api/library/${e}/vote`, {
              method: "POST",
              credentials: "same-origin",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
              },
              body: JSON.stringify({ vote: t }),
            }).then(() =>
              r(
                (function (e, t) {
                  return {
                    type: s.BS,
                    value: { permalinkFragment: t, vote: e },
                  };
                })(t, e)
              )
            );
        }
        function Ze(e, t, r) {
          return (s, n) => {
            const a = n();
            return fetch("/api/library/", {
              method: "PUT",
              credentials: "same-origin",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                permalinkFragment: a.general.permalinkFragment,
                author: r,
                description: t,
                title: e,
              }),
            })
              .then((e) => e.json())
              .then(
                ({ permalinkFragment: n, version: a }) => (
                  s(we(e, t, r)), { permalinkFragment: n, version: a }
                )
              );
          };
        }
        var Se = r(58317);
        function ke(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Pe(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? ke(Object(r), !0).forEach(function (t) {
                  (0, $.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : ke(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Ne = function (e, t) {
          if (!t) return { type: s.qI, value: {} };
          const r = Pe(
            {
              firstSeen: new Date(),
              lastSeen: new Date(),
              allTimeCount: 0,
              todayCount: 0,
            },
            (e && e[t.bannerid]) || {}
          );
          r.allTimeCount++, r.todayCount++;
          const n = Pe(Pe({}, e), {}, { [t.bannerid]: r });
          return Se.Z.save("regex101-sponsor", n), { type: s.qI, value: t };
        };
        function _e() {
          return (e, t) => {
            const r = t().general.cookie;
            return fetch("/api/quiz/tasks", {
              method: "GET",
              credentials: "same-origin",
              headers: { cookie: r },
            })
              .then((e) => e.json())
              .then((t) => e(Te(t)));
          };
        }
        function Te(e) {
          return { type: s.te, value: e };
        }
        function Ae(e, t) {
          return (r) => {
            const n = {
              regex: t.regex,
              flags: t.flags,
              delimiter: t.delimiter,
              substitution: t.substitution,
            };
            return fetch(`/api/quiz/verify/${e}`, {
              method: "POST",
              credentials: "same-origin",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
              },
              body: JSON.stringify(n),
            })
              .then((e) => e.json())
              .then((t) => {
                if (t.errorMessage)
                  r(
                    (function (e, t) {
                      const r = t.errorMessage,
                        n = t.totalTests,
                        a = t.testNumber;
                      return {
                        type: s.nA,
                        value: {
                          taskNumber: e,
                          errorMessage: r,
                          totalTests: n,
                          testNumber: a,
                        },
                      };
                    })(e - 1, t)
                  );
                else {
                  const n = t.successMessage,
                    a = t.tasks;
                  r(
                    (function (e, t) {
                      return {
                        type: s.Sb,
                        value: { taskNumber: e, successMessage: t },
                      };
                    })(e - 1, n)
                  ),
                    r(Te(a));
                }
              });
          };
        }
        function Ie(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Re(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Ie(Object(r), !0).forEach(function (t) {
                  (0, $.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Ie(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        function De(e, t) {
          return { type: s.F, value: Re({ taskIdx: e }, t) };
        }
        function Le(e, t) {
          return (r, n) => {
            const a = n().general.cookie;
            return fetch("/api/quiz/statistics/" + t, {
              method: "GET",
              credentials: "same-origin",
              headers: { cookie: a },
            })
              .then((e) => e.json())
              .then((t) =>
                r(
                  (function (e, t) {
                    return { type: s.$Z, value: { taskIdx: e, stats: t } };
                  })(e, t)
                )
              );
          };
        }
      },
      34963: (e, t, r) => {
        "use strict";
        r.d(t, {
          nU: () => s,
          RT: () => n,
          yF: () => a,
          th: () => i,
          yB: () => o,
          se: () => c,
          CN: () => l,
          qI: () => u,
          yM: () => h,
          _: () => p,
          ol: () => d,
          lK: () => g,
          sH: () => m,
          Ht: () => f,
          Xm: () => x,
          go: () => b,
          jo: () => v,
          rx: () => j,
          fB: () => y,
          sk: () => O,
          xw: () => w,
          hl: () => C,
          ro: () => E,
          WV: () => Z,
          CJ: () => S,
          T_: () => k,
          YW: () => P,
          RS: () => N,
          DA: () => _,
          Sr: () => T,
          KE: () => A,
          Nl: () => I,
          u8: () => R,
          Cy: () => D,
          a0: () => L,
          tc: () => M,
          r0: () => U,
          NJ: () => F,
          R8: () => G,
          r$: () => V,
          lA: () => B,
          rT: () => q,
          LM: () => H,
          mo: () => $,
          ES: () => z,
          p2: () => W,
          lZ: () => Y,
          Jb: () => K,
          b9: () => J,
          BS: () => X,
          mX: () => Q,
          DE: () => ee,
          te: () => te,
          nA: () => re,
          Sb: () => se,
          F: () => ne,
          $Z: () => ae,
        });
        const s = "SET_PERMALINK_FRAGMENT",
          n = "SET_USER_DATA",
          a = "FAVORITE_CURRENT_REGEX",
          i = "SET_COOKIE",
          o = "SET_DELETE_CODE",
          c = "SET_GENERAL_TITLE",
          l = "SET_GENERAL_TAGS",
          u = "SET_CARBON_SPONSOR",
          h = "SET_CURRENT_THEME",
          p = "SET_PERMALINK_EDITABLE",
          d = "SET_DOCUMENT_TITLE",
          g = "SET_META_DESCRIPTION",
          m = "SET_USER_HISTORY",
          f = "UPDATE_ACCOUNT_DATA",
          x = "SET_REGEX_TAGS",
          b = "RESET_USER_HISTORY",
          v = "SET_SETTINGS",
          j = "SAVE_STORAGE",
          y = "STORAGE_SAVED",
          O = "STORAGE_LOADED",
          w = "SAVE_REGEX_EDITOR_STATE",
          C = "SET_REGEX_FLAVOR",
          E = "TOGGLE_RIGHT_SIDEBAR_SUBSECTION",
          Z = "SET_ACTIVE_SUBSECTION",
          S = "SET_RIGHT_SIDEBAR_WIDTH",
          k = "SHOW_SUBSTITUTION_AREA",
          P = "SHOW_UNIT_TEST_AREA",
          N = "SHOW_MATCH_AREA",
          _ = "SET_REGEX_FLAGS",
          T = "SET_REGEX_DELIMITER",
          A = "SET_REGEX_RESULT",
          I = "SET_REGEX_ERROR",
          R = "SET_SUBSTITUTION",
          D = "SET_TEST_STRING",
          L = "SET_REGEX",
          M = "SET_UNIT_TESTS_ACTIVE",
          U = "SET_REGEX_VERSIONS",
          F = "UPDATE_REGEX_AREA_PARSER",
          G = "SHOW_LIST_SUBSTITUTION_AREA",
          V = "SET_LIST_SUBSTITUTION",
          B = "ADD_UNIT_TEST",
          q = "DELETE_UNIT_TEST",
          H = "EDIT_UNIT_TEST",
          $ = "MOVE_UNIT_TEST",
          z = "SET_UNIT_TEST_STATUS",
          W = "START_UNIT_TESTING",
          Y = "FINISH_UNIT_TESTING",
          K = "SET_UNIT_TEST_FILTER",
          J = "SET_LIBRARY_DATA",
          X = "VOTE_LIBRARY_ENTRY",
          Q = "SET_LIBRARY_DETAILS",
          ee = "SET_LIBRARY_ENTRY_METADATA",
          te = "SET_QUIZ_TASKS",
          re = "SET_QUIZ_TASK_ERROR",
          se = "SET_QUIZ_TASK_DONE",
          ne = "UPDATE_QUIZ_TASK_ENTRY",
          ae = "SET_QUIZ_STATISTICS";
      },
      61898: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => l, e: () => u });
        var s = r(60370),
          n = r(34963),
          a = r(76493),
          i = r.n(a),
          o = r(81370),
          c = r.n(o);
        const l = function (e, t, r) {
          let s = t;
          (r !== c().PCRE && r !== c().PCRE2) || !e.includes("y")
            ? r === c().JAVASCRIPT &&
              e.includes("A") &&
              (s = s.replace("A", "y"))
            : (s = s.replace("y", "A"));
          let a = u(s, r);
          if (r === c().PYTHON) {
            const t = a.includes("u"),
              r = a.includes("a");
            e.includes("a") && t
              ? (a = a.replace("a", ""))
              : ((e.includes("u") && r) || (t && r)) &&
                (a = a.replace("u", ""));
          }
          return { type: n.DA, value: a };
        };
        function u(e, t) {
          return (0, s.Z)(e.replace(new RegExp(`[^${i()[t]}]`, "g"), "")).join(
            ""
          );
        }
      },
      9599: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => n });
        var s = r(34963);
        function n(e) {
          return { type: s.yM, value: e };
        }
      },
      90732: (e, t, r) => {
        "use strict";
        r.d(t, {
          aQ: () => a,
          tZ: () => i,
          OH: () => o,
          sh: () => c,
          tp: () => l,
          dg: () => u,
          Go: () => h,
          bU: () => p,
          uZ: () => d,
          SX: () => g,
          Bt: () => m,
          uv: () => f,
          vI: () => x,
          Wr: () => b,
        });
        var s = r(81370),
          n = r.n(s);
        const a = "javascript",
          i = "php",
          o = "python",
          c = "csharp",
          l = "java",
          u = "ruby",
          h = "rust",
          p = "golang",
          d = "perl",
          g = "autoit",
          m = "SED",
          f = "swift5_2",
          x = [
            {
              value: a,
              string: "JavaScript",
              referencePage:
                "https://developer.mozilla.org/en/docs/Web/JavaScript/Guide/Regular_Expressions",
            },
            {
              value: i,
              string: "PHP",
              referencePage: "http://php.net/manual/en/ref.pcre.php",
            },
            {
              value: o,
              string: "Python",
              referencePage: "https://docs.python.org/3/library/re.html",
            },
            {
              value: c,
              string: "C#",
              referencePage:
                "https://msdn.microsoft.com/en-us/library/system.text.regularexpressions.regex(v=vs.110).aspx",
            },
            {
              value: l,
              string: "Java",
              referencePage:
                "https://docs.oracle.com/javase/7/docs/api/java/util/regex/Pattern.html",
            },
            {
              value: u,
              string: "Ruby",
              referencePage: "http://ruby-doc.org/core-2.2.0/Regexp.html",
            },
            {
              value: h,
              string: "Rust",
              referencePage: "https://docs.rs/regex/latest/regex/",
            },
            {
              value: p,
              string: "Golang",
              referencePage: "https://golang.org/pkg/regexp/",
            },
            {
              value: d,
              string: "Perl",
              referencePage: "http://perldoc.perl.org/perlre.html",
            },
            {
              value: g,
              string: "AutoIt",
              referencePage:
                "https://www.autoitscript.com/autoit3/docs/functions/StringRegExp.htm",
            },
            {
              value: m,
              string: "SED",
              referencePage:
                "https://www.gnu.org/software/sed/manual/html_node/The-_0022s_0022-Command.html",
            },
            {
              value: f,
              string: "Swift 5.2",
              referencePage:
                "https://developer.apple.com/documentation/foundation/nsregularexpression",
            },
          ].sort((e, t) => e.string.localeCompare(t.string));
        function b(e) {
          switch (e) {
            case n().PCRE2:
            case n().PCRE:
              return i;
            case n().GOLANG:
              return p;
            case n().JAVASCRIPT:
              return a;
            case n().PYTHON:
              return o;
            case n().JAVA:
              return l;
            case n().DOTNET:
              return c;
            default:
              return a;
          }
        }
      },
      33086: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => n });
        const s = {
          name: "showWhitespace",
          flattenSpans: !1,
          token(e) {
            let t = e.peek();
            if (" " === t) return e.next(), "space";
            for (; !e.eol() && " " !== t; ) e.next(), (t = e.peek());
            return null;
          },
        };
        function n(e) {
          e.defineOption("showWhitespace", !1, (t, r, n) => {
            n === e.Init && (n = !1),
              n && !r
                ? t.removeOverlay("showWhitespace")
                : !n && r && t.addOverlay(s);
          });
        }
      },
      86135: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => b });
        var s = r(4942),
          n = r(45987),
          a = r(67294),
          i = r(94184),
          o = r.n(i),
          c = r(85893);
        const l = ["className", "children"];
        function u(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function h(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? u(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : u(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const p = (e) => {
            let t = e.className,
              r = e.children,
              s = (0, n.Z)(e, l);
            return (0, c.jsx)(
              "div",
              h(
                h({ className: o()("WLU1r", "BcuOd", t) }, s),
                {},
                { children: r }
              )
            );
          },
          d = (0, a.memo)(p),
          g = ["icon", "children"];
        function m(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function f(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? m(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : m(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const x = (e) => {
            let t = e.icon,
              r = e.children,
              s = (0, n.Z)(e, g);
            return (0, c.jsxs)(
              d,
              f(
                f({}, s),
                {},
                {
                  children: [
                    t && (0, c.jsx)(t, { size: 14, className: "FvZHv" }),
                    r,
                  ],
                }
              )
            );
          },
          b = (0, a.memo)(x);
      },
      87740: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => g });
        var s = r(4942),
          n = r(45987),
          a = r(67294),
          i = r(94184),
          o = r.n(i),
          c = r(79352),
          l = r(85893);
        const u = ["isActive", "className", "children"];
        function h(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function p(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? h(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : h(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const d = (e) => {
            let t = e.isActive,
              r = e.className,
              s = e.children,
              a = (0, n.Z)(e, u);
            return (0, l.jsxs)(
              "div",
              p(
                p({ className: o()("rocdx", t && "wxNpu", r) }, a),
                {},
                {
                  children: [
                    (0, l.jsx)("div", { className: "u_Q0A", children: s }),
                    t && (0, l.jsx)(c.xuy, { size: 16, className: "zxc_j" }),
                  ],
                }
              )
            );
          },
          g = (0, a.memo)(d);
      },
      87287: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => d });
        var s = r(4942),
          n = r(45987),
          a = r(67294),
          i = r(35383),
          o = r(86135),
          c = r(85893);
        const l = ["icon", "children", "className"];
        function u(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function h(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? u(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : u(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const p = (e) => {
            let t = e.icon,
              r = e.children,
              s = e.className,
              a = (0, n.Z)(e, l);
            return (0, c.jsx)(
              i.Z,
              h(
                h({}, a),
                {},
                {
                  children: (0, c.jsx)(o.Z, {
                    icon: t,
                    children: r,
                    className: s,
                  }),
                }
              )
            );
          },
          d = (0, a.memo)(p);
      },
      35383: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => g });
        var s = r(4942),
          n = r(45987),
          a = r(67294),
          i = r(94184),
          o = r.n(i),
          c = r(63101),
          l = r(85893);
        const u = ["isDisabled", "className", "children", "onClick"];
        function h(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function p(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? h(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : h(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const d = (e) => {
            let t = e.isDisabled,
              r = e.className,
              s = e.children,
              a = e.onClick,
              i = (0, n.Z)(e, u);
            const h = o()("tu7rF", r, t && "QTYb3");
            return null != a
              ? (0, l.jsx)(
                  c.Yd,
                  p(
                    p({ tag: "li", disabled: t, className: h, onClick: a }, i),
                    {},
                    { children: s }
                  )
                )
              : (0, l.jsx)(
                  "li",
                  p(p({ className: h }, i), {}, { children: s })
                );
          },
          g = (0, a.memo)(d);
      },
      54430: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => p });
        var s = r(4942),
          n = r(45987),
          a = r(67294),
          i = r(63101),
          o = r(85893);
        const c = ["className", "children", "header", "headerChildren"];
        function l(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function u(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? l(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : l(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const h = (e) => {
            let t = e.className,
              r = e.children,
              s = e.header,
              a = e.headerChildren,
              l = (0, n.Z)(e, c);
            return (0, o.jsxs)(
              "div",
              u(
                u({ className: t }, l),
                {},
                {
                  children: [
                    !!s &&
                      (0, o.jsx)(i.__, {
                        text: s,
                        className: "bjLBV",
                        children: a,
                      }),
                    (0, o.jsx)("ul", { className: "yEXrR", children: r }),
                  ],
                }
              )
            );
          },
          p = (0, a.memo)(h);
      },
      27582: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => g });
        var s = r(4942),
          n = r(45987),
          a = r(67294),
          i = r(94184),
          o = r.n(i),
          c = r(87287),
          l = r(85893);
        const u = ["children", "className", "rightElement", "monospace"];
        function h(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function p(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? h(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : h(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const d = (e) => {
            let t = e.children,
              r = e.className,
              s = e.rightElement,
              a = e.monospace,
              i = void 0 === a || a,
              h = (0, n.Z)(e, u);
            return (0, l.jsxs)(
              c.Z,
              p(
                p({ className: o()("VZGjx", r) }, h),
                {},
                {
                  children: [
                    (0, l.jsx)("div", { className: "Lta24", children: t }),
                    (0, l.jsx)("div", {
                      className: o()("IVPLo", i && "i8N8D"),
                      children: s,
                    }),
                  ],
                }
              )
            );
          },
          g = (0, a.memo)(d);
      },
      43406: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => d });
        var s = r(4942),
          n = r(45987),
          a = r(67294),
          i = r(87287),
          o = r(87740),
          c = r(85893);
        const l = ["isActive", "children"];
        function u(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function h(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? u(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : u(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const p = (e) => {
            let t = e.isActive,
              r = e.children,
              s = (0, n.Z)(e, l);
            return (0, c.jsx)(
              i.Z,
              h(
                h({}, s),
                {},
                { children: (0, c.jsx)(o.Z, { children: r, isActive: t }) }
              )
            );
          },
          d = (0, a.memo)(p);
      },
      3262: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => x });
        var s = r(67294),
          n = r(94184),
          a = r.n(n),
          i = r(79352),
          o = r(25968),
          c = r(53808),
          l = r(70872),
          u = r(74387),
          h = r(63101);
        const p = "UGBuq",
          d = "Mveik";
        var g = r(85893);
        const m = (0, l.Z)(u.E2),
          f = {
            appear: p,
            appearActive: d,
            enter: p,
            enterActive: d,
            exit: "T8Z3r",
            exitActive: "sAd7O",
          },
          x = ({
            children: e,
            isOpen: t,
            className: r,
            isLoading: n,
            onModalClose: l,
          }) => {
            const u = (0, s.useCallback)(
                (e) => {
                  n || (e.stopPropagation(), l());
                },
                [l, n]
              ),
              p = (0, s.useCallback)((e) => e.stopPropagation(), []);
            return (
              (0, s.useEffect)(
                () => (
                  t && o.ZP.on("key:escape", u), () => o.ZP.off("key:escape", u)
                ),
                [t, u]
              ),
              (0, g.jsx)(h.h_, {
                isOpen: t,
                closeTimeout: m,
                children: (0, g.jsx)(h.uT, {
                  className: "CL1DJ",
                  classNames: f,
                  timeout: m,
                  in: t,
                  children: (0, g.jsx)(h.iQ, {
                    children: (0, g.jsx)("div", {
                      className: "Uj2uD",
                      role: "dialog",
                      onClick: u,
                      children: (0, g.jsxs)("div", {
                        className: a()("pvMZe", r),
                        onClick: p,
                        children: [
                          (0, g.jsx)(h.Yd, {
                            className: a()("o1E1z", n && "dIKNo"),
                            onClick: u,
                            "aria-label": (0, c.Z)("Close"),
                            children: (0, g.jsx)(i.eSQ, {
                              size: 24,
                              className: "ghZGL",
                            }),
                          }),
                          e,
                        ],
                      }),
                    }),
                  }),
                }),
              })
            );
          };
      },
      58461: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => h });
        var s = r(4942),
          n = r(45987),
          a = r(94184),
          i = r.n(a),
          o = r(85893);
        const c = ["children", "className"];
        function l(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function u(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? l(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : l(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const h = (e) => {
          let t = e.children,
            r = e.className,
            s = (0, n.Z)(e, c);
          return (0, o.jsx)(
            "div",
            u(u({ className: i()("qC93k", r) }, s), {}, { children: t })
          );
        };
      },
      95712: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => l });
        var s = r(4942),
          n = r(45987),
          a = r(85893);
        const i = ["children"];
        function o(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function c(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? o(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : o(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const l = (e) => {
          let t = e.children,
            r = (0, n.Z)(e, i);
          return (0, a.jsx)(
            "div",
            c(c({ className: "xJ9FN" }, r), {}, { children: t })
          );
        };
      },
      91536: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => h });
        var s = r(4942),
          n = r(45987),
          a = r(94184),
          i = r.n(a),
          o = r(85893);
        const c = ["children", "className"];
        function l(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function u(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? l(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : l(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const h = (e) => {
          let t = e.children,
            r = e.className,
            s = (0, n.Z)(e, c);
          return (0, o.jsx)(
            "h3",
            u(u({ className: i()("pIQMq", r) }, s), {}, { children: t })
          );
        };
      },
      8342: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => p });
        var s = r(67294),
          n = r(53808),
          a = r(63101),
          i = r(23543),
          o = r(3262),
          c = r(91536),
          l = r(58461),
          u = r(95712),
          h = r(85893);
        const p = ({ shortcuts: e, onModalClose: t, isOpen: r }) =>
          (0, h.jsxs)(o.Z, {
            onModalClose: t,
            isOpen: r,
            className: "Lc3cW",
            children: [
              (0, h.jsx)(c.Z, { children: (0, n.Z)("Keyboard Shortcuts") }),
              (0, h.jsx)(l.Z, {
                children: (0, h.jsxs)("table", {
                  className: "Ooj_l",
                  children: [
                    (0, h.jsx)("thead", {
                      children: (0, h.jsxs)("tr", {
                        children: [
                          (0, h.jsx)("th", {
                            className: "P07mv",
                            children: (0, n.Z)("Shortcut"),
                          }),
                          (0, h.jsx)("th", {
                            className: "iXeHu",
                            children: (0, n.Z)("Description"),
                          }),
                        ],
                      }),
                    }),
                    (0, h.jsx)("tbody", {
                      children: e.map(({ description: e, shortcuts: t }, r) =>
                        (0, h.jsxs)(
                          "tr",
                          {
                            className: "tt9uJ",
                            children: [
                              (0, h.jsx)("td", {
                                className: "wE5nz",
                                children: t.map((e, r) =>
                                  (0, h.jsxs)(
                                    s.Fragment,
                                    {
                                      children: [
                                        (0, h.jsx)("div", {
                                          className: "cGBV0",
                                          children: (0, h.jsx)(a.aX, {
                                            shortcut: e,
                                          }),
                                        }),
                                        r !== t.length - 1 &&
                                          ` ${(0, n.Z)("or")} `,
                                      ],
                                    },
                                    `shortcut-${e}-${r}`
                                  )
                                ),
                              }),
                              (0, h.jsx)("td", { children: e }),
                            ],
                          },
                          `shortcut-${r}`
                        )
                      ),
                    }),
                  ],
                }),
              }),
              (0, h.jsx)(u.Z, {
                children: (0, h.jsx)(a.zx, {
                  text: (0, n.Z)("Close"),
                  onClick: t,
                  type: i.V5.n1,
                }),
              }),
            ],
          });
      },
      14824: (e, t, r) => {
        "use strict";
        r.d(t, {
          FS: () => i,
          Xg: () => o,
          u0: () => c,
          wU: () => l,
          DC: () => u,
          xz: () => h,
          GU: () => p,
          VO: () => d,
        });
        var s = r(53808),
          n = r(63101),
          a = r(85893);
        const i = "DOES_MATCH",
          o = "DOES_NOT_MATCH",
          c = "STARTS_WITH",
          l = "ENDS_WITH",
          u = "CONTAINS",
          h = "EQUALS",
          p = "IS_NULL",
          d = {
            [i]: (0, s.Z)("does match"),
            [o]: (0, a.jsx)(n.vV, {
              text: "does {1} match",
              ph1: (0, a.jsx)("em", {
                style: { textDecoration: "underline" },
                children: (0, s.Z)("not"),
              }),
            }),
            [c]: (0, s.Z)("starts with"),
            [l]: (0, s.Z)("ends with"),
            [u]: (0, s.Z)("contains"),
            [h]: (0, s.Z)("equals"),
            [p]: (0, s.Z)("is null"),
          };
      },
      89441: (e, t, r) => {
        "use strict";
        r.d(t, { m: () => n, H: () => a });
        var s = r(53808);
        const n = "REGEX";
        function a(e, t) {
          if (e === n) return (0, s.Z)("regex");
          if (0 === (e = parseInt(e, 10))) return (0, s.Z)("full match");
          let r = e;
          return (
            null != t[e] && e !== t[e] && (r += ` (${t[e]})`),
            (0, s.Z)("capture group {1}", r)
          );
        }
      },
      50836: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => o });
        var s = r(93942),
          n = r(63101),
          a = r(39781),
          i = r(85893);
        const o = ({ className: e, children: t, to: r = "debugger" }) => {
          const o = (0, s.v9)((e) => e.regexEditor.flavor);
          return (0, a.G)(o)
            ? (0, i.jsx)(n.rU, { to: r, className: e, children: t })
            : null;
        };
      },
      23584: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => f });
        var s = r(4942),
          n = r(45987),
          a = r(67294),
          i = r(94184),
          o = r.n(i),
          c = r(63101),
          l = r(23543),
          u = r(70657),
          h = r(85893);
        const p = [
          "tooltip",
          "tooltipDirection",
          "children",
          "size",
          "className",
          "style",
        ];
        function d(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function g(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? d(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : d(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const m = (e) => {
            let t = e.tooltip,
              r = e.tooltipDirection,
              s = void 0 === r ? l.qF.N : r,
              i = e.children,
              d = e.size,
              m = void 0 === d ? 22 : d,
              f = e.className,
              x = e.style,
              b = void 0 === x ? {} : x,
              v = (0, n.Z)(e, p);
            return !i || i.length > 1
              ? null
              : (0, h.jsx)(c.lx, {
                  text: t,
                  direction: s,
                  children: (0, h.jsxs)(
                    c.rU,
                    g(
                      g(
                        {
                          className: o()(u.Z.iconButton, f),
                          style: g(g({}, b), {}, { width: m, height: m }),
                        },
                        v
                      ),
                      {},
                      {
                        children: [
                          (0, h.jsx)(c._G, { children: t }),
                          (0, a.cloneElement)(
                            i,
                            g(
                              g({}, i.props),
                              {},
                              { className: o()(i.props.className, u.Z.icon) }
                            )
                          ),
                        ],
                      }
                    )
                  ),
                });
          },
          f = (0, a.memo)(m);
      },
      20411: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => u });
        var s = r(45987),
          n = r(67294),
          a = r(53808),
          i = r(85893);
        const o = ["text", "tag", "className", "style"],
          c = /{[1-9]\d*}/g,
          l = (e) => {
            let t = e.text,
              r = e.tag,
              l = void 0 === r ? "span" : r,
              u = e.className,
              h = e.style,
              p = (0, s.Z)(e, o);
            const d = t.match(c);
            if (!d)
              return (0, i.jsx)(l, {
                className: u,
                style: h,
                children: (0, a.Z)(t, ...Object.values(p)),
              });
            const g = t.split(c);
            return (0, i.jsx)(l, {
              className: u,
              style: h,
              children: g.reduce((e, t, r) => {
                if (!d[r]) return [...e, t];
                const s = d[r].slice(1, -1),
                  a = p[`ph${s}`];
                return [
                  ...e,
                  t,
                  (0, i.jsx)(n.Fragment, { children: a }, t + r),
                ];
              }, []),
            });
          },
          u = (0, n.memo)(l);
      },
      20400: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => f });
        var s = r(98152),
          n = r(4942),
          a = r(45987),
          i = r(67294),
          o = r(94184),
          c = r.n(o),
          l = r(93942),
          u = r(39912),
          h = r(85893);
        const p = ["text", "removeNewlines", "className", "markerClassName"];
        function d(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function g(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? d(Object(r), !0).forEach(function (t) {
                  (0, n.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : d(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const m = (e) => {
            let t = e.text,
              r = e.removeNewlines,
              n = e.className,
              i = e.markerClassName,
              o = (0, a.Z)(e, p);
            const d = (0, l.v9)((e) => e.settings.displayWhitespace);
            if (!d && !r)
              return (0, h.jsx)(
                "span",
                g(g({ className: n }, o), {}, { children: t })
              );
            const m =
                !d && r
                  ? /(?:\r\n?|\n)/g
                  : /(?:\r\n?|\n)|[ \t\f\v\u0000-\u001f\u007f-\u009f\u00ad\u061c\u200b-\u200f\u2028\u2029\ufeff\ufff9-\ufffc]/g,
              f = t.split(m);
            if (f.length <= 1)
              return (0, h.jsx)(
                "span",
                g(g({ className: n }, o), {}, { children: t })
              );
            const x = t.match(m);
            return f.reduce((e, t, a) => {
              if (!x[a]) return [...e, t];
              const o = (function (e) {
                  if (/[\r\n]/.test(e)) return [u.Z.whitespace, "\u21b5"];
                  if (e.length > 1)
                    throw new Error(
                      `Marker length greater than 1, string: "${e}"`
                    );
                  return " " === e
                    ? [u.Z.whitespace, "\u2022"]
                    : "\t" === e
                    ? [u.Z.tab, " "]
                    : [
                        u.Z.specialChar,
                        `U+${(
                          "0000" + e.codePointAt(0).toString(16).toUpperCase()
                        ).slice(-4)}`,
                      ];
                })(x[a]),
                l = (0, s.Z)(o, 2),
                p = l[0],
                d = l[1],
                g =
                  r && "\n" === x[a]
                    ? (0, h.jsx)(
                        "span",
                        {
                          className: c()(n, i, p, u.Z.removeNewlines),
                          children: d,
                        },
                        `special-char-${a}`
                      )
                    : (0, h.jsx)(
                        "span",
                        {
                          className: c()(n, i, p, u.Z.addBeforeElement),
                          "data-content": d,
                          children: x[a],
                        },
                        `special-char-${a}`
                      );
              return [...e, t, g];
            }, []);
          },
          f = (0, i.memo)(m);
      },
      63101: (e, t, r) => {
        "use strict";
        r.d(t, {
          Yd: () => M,
          zx: () => q,
          FX: () => Be,
          gx: () => ze,
          qi: () => et,
          Yi: () => st.Z,
          SV: () => ot,
          Tv: () => tt,
          iQ: () => ut,
          aX: () => wt,
          hU: () => Ie,
          x6: () => ht.Z,
          CP: () => vt,
          __: () => d,
          rU: () => ue,
          Po: () => Me,
          A5: () => rt,
          qX: () => j,
          h_: () => $,
          l_: () => gt,
          _G: () => at,
          I2: () => ct,
          $j: () => me,
          vV: () => T.Z,
          Yv: () => ke,
          oi: () => se,
          lx: () => _,
          uT: () => je,
          K: () => nt.Z,
        });
        var s = r(4942),
          n = r(45987),
          a = r(94184),
          i = r.n(a),
          o = r(23543);
        const c = {
          root: "dYInr",
          small: "z2wCE",
          medium: "yBUBH",
          large: "m46EU",
          overflow: "JOzNE",
          required: "uJMuU",
        };
        var l = r(85893);
        const u = [
          "size",
          "text",
          "className",
          "children",
          "allowOverflow",
          "required",
        ];
        function h(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function p(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? h(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : h(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const d = (e) => {
          let t = e.size,
            r = void 0 === t ? o.J7.HC : t,
            s = e.text,
            a = e.className,
            h = e.children,
            d = e.allowOverflow,
            g = e.required,
            m = (0, n.Z)(e, u);
          return (0, l.jsxs)(
            "h2",
            p(
              p({ className: i()(c.root, !d && c.overflow, c[r], a) }, m),
              {},
              {
                children: [
                  (0, l.jsx)("span", {
                    className: i()(!d && c.overflow),
                    children: s,
                  }),
                  g &&
                    (0, l.jsx)("span", {
                      className: c.required,
                      children: " *",
                    }),
                  h,
                ],
              }
            )
          );
        };
        var g = r(67294);
        const m = {
            error: "zyVia",
            warn: "wxY97",
            info: "ZHUJ9",
            margin: "_2SqQ",
          },
          f = ["type", "children", "className", "noMargin"];
        function x(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function b(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? x(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : x(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const v = (e) => {
            let t = e.type,
              r = void 0 === t ? o.gr.H_ : t,
              s = e.children,
              a = e.className,
              c = e.noMargin,
              u = (0, n.Z)(e, f);
            return (
              r === o.gr.pn && ((u.role = u.role || "alert"), (c = !0)),
              (0, l.jsx)(
                "div",
                b(
                  b({ className: i()(m[r], !c && m.margin, a) }, u),
                  {},
                  { children: s }
                )
              )
            );
          },
          j = (0, g.memo)(v);
        var y = r(98152),
          O = r(31807),
          w = r.n(O),
          C = r(424),
          E = r(70872),
          Z = r(74387);
        const S = {
            portal: "B5ZQm",
            animation: "W1cZe",
            tooltipped: "VkxC6",
            "tooltipped-s": "tpO8n",
            "tooltipped-se": "rRIcU",
            "tooltipped-sw": "rxR8J",
            "tooltipped-n": "HEiJb",
            "tooltipped-ne": "C8D6d",
            "tooltipped-nw": "_LdAA",
            "tooltipped-w": "ItfZm",
            "tooltipped-e": "G0Q1B",
            multiline: "IE41R",
            "tooltipped-sticky": "prZOI",
            enter: "_e9G1",
            enterActive: "cSwfV",
            leave: "y9o0V",
            leaveActive: "UuK9m",
          },
          k =
            w() &&
            ("ontouchstart" in window ||
              navigator.maxTouchPoints > 0 ||
              navigator.msMaxTouchPoints > 0),
          P = (0, E.Z)(Z.DP),
          N = {
            appear: S.enter,
            appearActive: S.enterActive,
            enter: S.enter,
            enterActive: S.enterActive,
            exit: S.leave,
            exitActive: S.leaveActive,
          },
          _ = ({
            direction: e = o.qF.S,
            text: t,
            children: r,
            disableTooltip: s,
            multiline: n,
          }) => {
            const a = (0, g.useRef)({}),
              c = (0, g.useState)(!1),
              u = (0, y.Z)(c, 2),
              h = u[0],
              p = u[1],
              d = (0, g.useRef)(null),
              m = g.Children.only(r),
              f = m.ref || d,
              x = (0, C.Sf)(() => p(!0), 175, "cancel");
            if (
              ((0, g.useEffect)(() => {
                const e = f.current,
                  t = () => {
                    var e, t;
                    null !== (e = document) &&
                      void 0 !== e &&
                      null !== (t = e.body) &&
                      void 0 !== t &&
                      t.classList.contains("using-keyboard") &&
                      p(!0);
                  },
                  r = () => {
                    var e, t;
                    x.cancel(),
                      null !== (e = document) &&
                        void 0 !== e &&
                        null !== (t = e.body) &&
                        void 0 !== t &&
                        t.classList.contains("using-keyboard") &&
                        p(!1);
                  },
                  s = () => {
                    x.cancel(), p(!1);
                  },
                  n = (t) => {
                    (null != e && e.contains(t.target)) ||
                      e === t.target ||
                      s();
                  };
                return (
                  e.addEventListener("focus", t, { passive: !0 }),
                  e.addEventListener("blur", r, { passive: !0 }),
                  e.addEventListener("mouseenter", x, { passive: !0 }),
                  e.addEventListener("mouseleave", s, { passive: !0 }),
                  document.body.addEventListener("click", n, { passive: !0 }),
                  () => {
                    x.cancel(),
                      e.removeEventListener("focus", t, { passive: !0 }),
                      e.removeEventListener("blur", r, { passive: !0 }),
                      e.removeEventListener("mouseenter", x, { passive: !0 }),
                      e.removeEventListener("mouseleave", s, { passive: !0 }),
                      document.body.removeEventListener("click", n, {
                        passive: !0,
                      });
                  }
                );
              }, [f, x]),
              (0, g.useEffect)(() => {
                (m.props.disabled || m.props.isDisabled) && (x.cancel(), p(!1));
              }, [m.props.disabled, m.props.isDisabled, x]),
              f.current && h)
            ) {
              const t = f.current.getBoundingClientRect();
              let r, s;
              switch (
                ((a.current = {
                  position: "absolute",
                  height: t.height,
                  width: t.width,
                }),
                e)
              ) {
                case o.qF.SE:
                case o.qF.SW:
                case o.qF.S:
                  (r = t.top + t.height), (s = t.left);
                  break;
                case o.qF.NW:
                case o.qF.NE:
                case o.qF.N:
                  (r = t.top), (s = t.left);
                  break;
                case o.qF.W:
                case o.qF.E:
                  (r = t.top + t.height / 2), (s = t.left);
                  break;
                default:
                  throw new Error(`Unhandled tooltip direction ${e}`);
              }
              (a.current.top = Math.round(r)), (a.current.left = Math.round(s));
            }
            const b = !s && !k && h;
            return (0, l.jsxs)(l.Fragment, {
              children: [
                (0, g.cloneElement)(m, {
                  ref: f,
                  "aria-label": m.props["aria-label"] || t,
                }),
                (0, l.jsx)($, {
                  isOpen: b,
                  closeTimeout: P,
                  className: S.portal,
                  children: (0, l.jsx)(je, {
                    className: S.animation,
                    classNames: N,
                    timeout: P,
                    style: a.current,
                    in: b,
                    children: (0, l.jsx)("div", {
                      className: i()(
                        S.tooltipped,
                        n && S.multiline,
                        S[`tooltipped-${e}`]
                      ),
                      role: "tooltip",
                      children: (0, l.jsx)("span", { children: t }),
                    }),
                  }),
                }),
              ],
            });
          };
        var T = r(20411),
          A = r(45697),
          I = r.n(A);
        const R = ["tag", "className", "onClick", "disabled"];
        function D(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        const L = (0, g.forwardRef)((e, t) => {
            let r = e.tag,
              a = void 0 === r ? "button" : r,
              o = e.className,
              c = e.onClick,
              u = e.disabled,
              h = (0, n.Z)(e, R);
            const p = (0, g.useCallback)(
              (e) => {
                ("Enter" !== e.key && " " !== e.key) ||
                  (e.preventDefault(), c(e));
              },
              [c]
            );
            return (
              "button" !== a &&
                ((h.role = h.role || "button"),
                (h.tabIndex = h.tabIndex || 0),
                u || (h.onKeyUp = p)),
              u && ((h.tabIndex = -1), (h.disabled = !0)),
              "button" === a && (h.type = "button"),
              (0, l.jsx)(
                a,
                (function (e) {
                  for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2
                      ? D(Object(r), !0).forEach(function (t) {
                          (0, s.Z)(e, t, r[t]);
                        })
                      : Object.getOwnPropertyDescriptors
                      ? Object.defineProperties(
                          e,
                          Object.getOwnPropertyDescriptors(r)
                        )
                      : D(Object(r)).forEach(function (t) {
                          Object.defineProperty(
                            e,
                            t,
                            Object.getOwnPropertyDescriptor(r, t)
                          );
                        });
                  }
                  return e;
                })(
                  {
                    className: i()("b0Wk4", u && "KOowz", o),
                    onClick: u ? void 0 : c,
                    ref: t,
                    "aria-disabled": u,
                  },
                  h
                )
              )
            );
          }),
          M = (0, g.memo)(L),
          U = {
            okButton: "KlLjA",
            cancelButton: "o0XbU",
            dangerButton: "LHBOD",
            disabled: "TzGX0",
          },
          F = ["text", "type", "className", "disabled"];
        function G(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function V(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? G(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : G(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const B = (0, g.forwardRef)((e, t) => {
          let r = e.text,
            s = e.type,
            a = void 0 === s ? o.V5.OK : s,
            c = e.className,
            u = e.disabled,
            h = (0, n.Z)(e, F);
          return (0, l.jsx)(
            M,
            V(
              V(
                {
                  className: i()(U[a], c, u && U.disabled),
                  "aria-label": r,
                  disabled: u,
                  ref: t,
                },
                h
              ),
              {},
              { children: r }
            )
          );
        });
        B.propTypes = {
          text: I().string.isRequired,
          type: I().oneOf(o.V5.$6),
          className: I().string,
          disabled: I().bool,
        };
        const q = (0, g.memo)(B);
        var H = r(73935);
        const $ = ({
          className: e,
          children: t,
          onPortalRef: r,
          isOpen: s = !0,
          closeTimeout: n = 0,
          portalTarget: a,
        }) => {
          const i = null == a && w() ? document.body : a,
            o = (0, g.useState)(!1),
            c = (0, y.Z)(o, 2),
            u = c[0],
            h = c[1],
            p = (0, g.useRef)(),
            d = (0, g.useRef)();
          (0, g.useEffect)(
            () => (
              s &&
                (clearTimeout(d.current),
                null == p.current &&
                  ((p.current = document.createElement("div")),
                  i.appendChild(p.current),
                  null == r || r(p.current)),
                h(!0)),
              () => {
                null != p.current &&
                  (clearTimeout(d.current),
                  (d.current = setTimeout(() => {
                    var e;
                    null === (e = p.current) || void 0 === e || e.remove(),
                      (p.current = null),
                      h(!1),
                      null == r || r(null);
                  }, n)));
              }
            ),
            [s, i, n, r]
          ),
            (0, g.useEffect)(() => {
              null != p.current && null != e && (p.current.className = e);
            }, [s, e]),
            (0, g.useEffect)(
              () => () => {
                var e;
                clearTimeout(d.current),
                  null === (e = p.current) || void 0 === e || e.remove(),
                  (p.current = null),
                  null == r || r(null);
              },
              [r]
            );
          const m = g.Children.only(t);
          return w()
            ? u
              ? H.createPortal(m, p.current)
              : null
            : (0, l.jsx)("div", { style: { display: "none" }, children: m });
        };
        var z = r(79352),
          W = r(25968),
          Y = r(53808),
          K = r(12037);
        const J = ({ maxLength: e, currentLength: t = 0, multiline: r }) => {
            const s = i()("MaQ5e", !r && "kRYUB");
            return e
              ? (0, l.jsx)("div", { className: s, children: `${t}/${e}` })
              : (0, l.jsx)("div", { className: s, children: t });
          },
          X = (0, g.memo)(J),
          Q = [
            "onChange",
            "className",
            "codeInput",
            "value",
            "defaultValue",
            "multiline",
            "readOnly",
            "maxlength",
            "validation",
            "showLengthCounter",
            "selectOnMount",
            "selectOnFocus",
            "focusOnMount",
            "wrappedClassName",
            "copyButton",
            "clearButton",
          ];
        function ee(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function te(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? ee(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : ee(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const re = (0, g.forwardRef)((e, t) => {
            let r = e.onChange,
              s = e.className,
              a = e.codeInput,
              c = e.value,
              u = e.defaultValue,
              h = e.multiline,
              p = void 0 !== h && h,
              d = e.readOnly,
              m = e.maxlength,
              f = e.validation,
              x = e.showLengthCounter,
              b = e.selectOnMount,
              v = e.selectOnFocus,
              j = e.focusOnMount,
              O = e.wrappedClassName,
              w = e.copyButton,
              C = e.clearButton,
              E = (0, n.Z)(e, Q);
            const Z = (0, g.useState)(""),
              S = (0, y.Z)(Z, 2),
              k = S[0],
              P = S[1],
              N = (0, g.useState)(!1),
              T = (0, y.Z)(N, 2),
              A = T[0],
              I = T[1],
              R = (0, g.useState)(!1),
              D = (0, y.Z)(R, 2),
              L = D[0],
              U = D[1],
              F = (0, g.useRef)(null),
              G = t || F;
            (0, g.useEffect)(() => {
              let e = null;
              return (
                A && (e = setTimeout(() => I(!1), 400)),
                () => {
                  clearTimeout(e);
                }
              );
            }, [A]),
              (0, g.useEffect)(() => {
                null != c && P(c);
              }, [c]);
            const V = (0, g.useCallback)(() => {
                W.ZP.emit(W.B3, K.LEFT_ARROW),
                  W.ZP.emit(W.B3, K.RIGHT_ARROW),
                  W.ZP.emit(W.B3, K.SHIFT_LEFT_ARROW),
                  W.ZP.emit(W.B3, K.SHIFT_RIGHT_ARROW),
                  U(!0);
              }, []),
              B = (0, g.useCallback)(() => {
                W.ZP.emit(W.LG, K.LEFT_ARROW),
                  W.ZP.emit(W.LG, K.RIGHT_ARROW),
                  W.ZP.emit(W.LG, K.SHIFT_LEFT_ARROW),
                  W.ZP.emit(W.LG, K.SHIFT_RIGHT_ARROW),
                  U(!1);
              }, []),
              q = (0, g.useCallback)(
                (e) => {
                  if (d) return;
                  const t = e.target.value;
                  (f && !f.test(t)) || (m && m < t.length)
                    ? (I(!0), null == r || r(k))
                    : (I(!1), P(t), null == r || r(t));
                },
                [k, m, f, r, d]
              ),
              H = (0, g.useCallback)(() => {
                I(!1), P(""), null == r || r("");
              }, [r]);
            (0, g.useEffect)(() => {
              null != u && P(u);
            }, [u]),
              (0, g.useEffect)(() => {
                (b || j) &&
                  setTimeout(() => {
                    var e;
                    return null === (e = G.current) || void 0 === e
                      ? void 0
                      : e.focus();
                  });
              }, []),
              (0, g.useEffect)(() => {
                L && v && G.current.select();
              }, [G, v, L]);
            const $ = p ? "textarea" : "input",
              J = C && !d && !p && !m && !x && k.length > 0;
            return (0, l.jsxs)("div", {
              className: i()(
                "OSM2Q",
                A && "YUotv",
                L && "E646T",
                d && "qPEQx",
                O
              ),
              children: [
                (0, l.jsx)(
                  $,
                  te(
                    te({}, E),
                    {},
                    {
                      className: i()(
                        "vNcES",
                        a && "zLfBM",
                        w && "L6fuH",
                        J && "svJgY",
                        (m || x) && !p && "Nih6H",
                        s
                      ),
                      onChange: q,
                      onFocus: V,
                      onBlur: B,
                      value: k,
                      ref: G,
                    }
                  )
                ),
                J &&
                  (0, l.jsx)(_, {
                    text: (0, Y.Z)("Clear"),
                    direction: o.qF.NW,
                    children: (0, l.jsx)(M, {
                      onClick: H,
                      className: "e8Fwv",
                      children: (0, l.jsx)(z.eSQ, { size: 20 }),
                    }),
                  }),
                (m || x) &&
                  (0, l.jsx)(X, {
                    maxLength: m,
                    currentLength: k.length,
                    multiline: p,
                  }),
                w &&
                  (0, l.jsx)(et, {
                    className: "mha2w",
                    copyText: k,
                    basic: !0,
                  }),
              ],
            });
          }),
          se = (0, g.memo)(re);
        var ne = r(39711),
          ae = r(96974);
        const ie = [
          "to",
          "absolute",
          "children",
          "noTheme",
          "className",
          "activeClassName",
          "activeRegex",
        ];
        function oe(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function ce(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? oe(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : oe(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const le = (0, g.forwardRef)((e, t) => {
            let r = e.to,
              s = e.absolute,
              a = void 0 !== s && s,
              o = e.children,
              c = e.noTheme,
              u = void 0 !== c && c,
              h = e.className,
              p = e.activeClassName,
              d = e.activeRegex,
              g = (0, n.Z)(e, ie);
            const m = (0, ae.TH)().pathname,
              f = null != d && d.test(m),
              x = i()("HnB3F", !u && "kKIV1", f && p, h);
            return a
              ? (0, l.jsx)(
                  "a",
                  ce(
                    ce({ href: r, className: x, rel: "noopener", ref: t }, g),
                    {},
                    { children: o }
                  )
                )
              : (0, l.jsx)(
                  ne.rU,
                  ce(
                    ce({ to: r, className: x, ref: t }, g),
                    {},
                    { children: o }
                  )
                );
          }),
          ue = (0, g.memo)(le),
          he = {
            loading: "Pv6NV",
            large: "K5n25",
            medium: "uo2S1",
            small: "LbYg5",
            tiny: "u06aC",
          },
          pe = ["className", "size"];
        function de(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        const ge = (e) => {
            let t = e.className,
              r = e.size,
              a = void 0 === r ? o.J7.M2 : r,
              c = (0, n.Z)(e, pe);
            return (0, l.jsx)(
              "div",
              (function (e) {
                for (var t = 1; t < arguments.length; t++) {
                  var r = null != arguments[t] ? arguments[t] : {};
                  t % 2
                    ? de(Object(r), !0).forEach(function (t) {
                        (0, s.Z)(e, t, r[t]);
                      })
                    : Object.getOwnPropertyDescriptors
                    ? Object.defineProperties(
                        e,
                        Object.getOwnPropertyDescriptors(r)
                      )
                    : de(Object(r)).forEach(function (t) {
                        Object.defineProperty(
                          e,
                          t,
                          Object.getOwnPropertyDescriptor(r, t)
                        );
                      });
                }
                return e;
              })(
                {
                  className: i()(he.loading, t, he[a]),
                  "aria-label": (0, Y.Z)("Loading..."),
                },
                c
              )
            );
          },
          me = (0, g.memo)(ge);
        var fe = r(17159);
        const xe = [
          "children",
          "className",
          "component",
          "appear",
          "enter",
          "exit",
          "unmountOnExit",
          "mountOnEnter",
          "timeout",
          "classNames",
          "style",
          "in",
        ];
        function be(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function ve(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? be(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : be(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const je = (0, g.forwardRef)((e, t) => {
          let r = e.children,
            s = e.className,
            a = e.component,
            i = void 0 === a ? "div" : a,
            o = e.appear,
            c = void 0 === o || o,
            u = e.enter,
            h = void 0 === u || u,
            p = e.exit,
            d = void 0 === p || p,
            m = e.unmountOnExit,
            f = void 0 === m || m,
            x = e.mountOnEnter,
            b = void 0 === x || x,
            v = e.timeout,
            j = e.classNames,
            y = e.style,
            O = e.in,
            C = (0, n.Z)(e, xe);
          const E = (0, g.useRef)(null),
            Z = (0, l.jsx)(i, {
              className: s,
              style: y,
              ref: t || E,
              children: r,
            });
          return w()
            ? "visible" === document.visibilityState ||
              !1 === document.hidden ||
              document.hasFocus()
              ? (0, l.jsx)(
                  fe.Z,
                  ve(
                    ve(
                      {
                        classNames: j,
                        timeout: v,
                        appear: c,
                        enter: h,
                        exit: d,
                        mountOnEnter: b,
                        unmountOnExit: f,
                        in: O,
                        nodeRef: t || E,
                      },
                      C
                    ),
                    {},
                    { children: Z }
                  )
                )
              : (0, l.jsx)(
                  fe.Z,
                  ve(
                    ve(
                      {
                        className: s,
                        classNames: j,
                        timeout: v,
                        appear: !1,
                        enter: !1,
                        exit: d,
                        mountOnEnter: b,
                        unmountOnExit: f,
                        in: O,
                        nodeRef: t || E,
                      },
                      C
                    ),
                    {},
                    { children: Z }
                  )
                )
            : Z;
        });
        var ye = r(37731),
          Oe = r(25913),
          we = r(12541);
        const Ce = ["target", "placement"];
        function Ee(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Ze(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Ee(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Ee(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Se = {
            name: "applyMaxSize",
            enabled: !0,
            phase: "beforeWrite",
            requires: ["maxSize"],
            fn({ state: e }) {
              const t = e.modifiersData.maxSize.height;
              e.styles.popper.maxHeight = `${t}px`;
            },
          },
          ke = (e) => {
            let t = e.target,
              r = e.placement,
              s = (0, n.Z)(e, Ce);
            const a = (0, g.useRef)(null);
            (0, g.useEffect)(
              () => () => {
                var e;
                return null === (e = a.current) || void 0 === e
                  ? void 0
                  : e.destroy();
              },
              []
            );
            const i = (0, g.useCallback)(
              (e) => {
                var s;
                e
                  ? (a.current = (0, ye.fi)(t, e, {
                      placement: r,
                      modifiers: [
                        Ze(Ze({}, we.Z), {}, { options: { padding: 10 } }),
                        Se,
                        Oe.Z,
                      ],
                      rootBoundary: "viewport",
                    }))
                  : null === (s = a.current) || void 0 === s || s.destroy();
              },
              [t, r]
            );
            return (0, l.jsx)($, Ze(Ze({}, s), {}, { onPortalRef: i }));
          };
        var Pe = r(70657);
        const Ne = [
          "tooltip",
          "tooltipDirection",
          "className",
          "children",
          "disabled",
          "size",
          "isLoading",
        ];
        function _e(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Te(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? _e(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : _e(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Ae = (0, g.forwardRef)((e, t) => {
            let r = e.tooltip,
              s = e.tooltipDirection,
              a = void 0 === s ? o.qF.N : s,
              c = e.className,
              u = e.children,
              h = e.disabled,
              p = e.size,
              d = void 0 === p ? 22 : p,
              m = e.isLoading,
              f = void 0 !== m && m,
              x = (0, n.Z)(e, Ne);
            return !u || u.length > 1
              ? null
              : (0, l.jsx)(_, {
                  text: r,
                  direction: a,
                  children: (0, l.jsxs)(
                    M,
                    Te(
                      Te(
                        {
                          className: i()(
                            Pe.Z.iconButton,
                            h && Pe.Z.disabled,
                            c
                          ),
                          disabled: h,
                        },
                        x
                      ),
                      {},
                      {
                        style: { width: d, height: d },
                        ref: t,
                        children: [
                          (0, g.cloneElement)(
                            u,
                            Te(
                              Te({}, u.props),
                              {},
                              { className: i()(u.props.className, Pe.Z.icon) }
                            )
                          ),
                          f &&
                            (0, l.jsx)("div", {
                              className: Pe.Z.spinner,
                              children: (0, l.jsx)(me, {
                                style: { width: d - 12, height: d - 12 },
                                size: o.J7.HC,
                              }),
                            }),
                        ],
                      }
                    )
                  ),
                });
          }),
          Ie = (0, g.memo)(Ae),
          Re = ["children", "className"];
        function De(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Le(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? De(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : De(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Me = (e) => {
            let t = e.children,
              r = e.className,
              s = (0, n.Z)(e, Re);
            return (0, l.jsx)(
              d,
              Le(
                Le({ className: i()("icHQ0", r) }, s),
                {},
                {
                  children: (0, l.jsx)("div", {
                    className: "hwtOd",
                    children: t,
                  }),
                }
              )
            );
          },
          Ue = ["collapsed", "className", "onClick"];
        function Fe(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Ge(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Fe(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Fe(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Ve = (e) => {
            let t = e.collapsed,
              r = e.className,
              s = e.onClick,
              a = (0, n.Z)(e, Ue);
            return (0, l.jsx)(M, {
              onClick: s,
              children: (0, l.jsx)(
                d,
                Ge(
                  Ge({ className: i()("MudcX", r) }, a),
                  {},
                  {
                    children: (0, l.jsx)("div", {
                      className: "YTTWs",
                      children: t
                        ? (0, l.jsx)(z.gcy, {})
                        : (0, l.jsx)(z.ZXJ, {}),
                    }),
                  }
                )
              ),
            });
          },
          Be = (0, g.memo)(Ve),
          qe = [
            "header",
            "children",
            "className",
            "contentClassName",
            "isVisible",
          ];
        function He(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function $e(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? He(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : He(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const ze = (e) => {
          let t = e.header,
            r = e.children,
            s = e.className,
            a = e.contentClassName,
            o = e.isVisible,
            c = void 0 === o || o,
            u = (0, n.Z)(e, qe);
          return (0, l.jsxs)(
            "div",
            $e(
              $e({ className: i()("gUc_7", s) }, u),
              {},
              {
                children: [
                  (0, g.cloneElement)(t, {
                    className: i()("BrhQI", t.props.className),
                  }),
                  c &&
                    (0, l.jsx)("div", {
                      className: i()("D57o9", a),
                      children: (0, g.cloneElement)(r, {
                        className: i()(r.props.className, "KjF06"),
                      }),
                    }),
                ],
              }
            )
          );
        };
        var We = r(84665);
        const Ye = ["className", "basic", "getCopyComponent", "copyText"];
        function Ke(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Je(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Ke(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Ke(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        let Xe;
        w() && (Xe = r(42152));
        const Qe = (e) => {
            let t = e.className,
              r = e.basic,
              s = e.getCopyComponent,
              a = e.copyText,
              c = (0, n.Z)(e, Ye);
            const u = (0, g.useRef)(null),
              h = (0, g.useState)(null),
              p = (0, y.Z)(h, 2),
              d = p[0],
              m = p[1];
            return (
              (0, g.useEffect)(() => {
                const e = new Xe(u.current, {
                  container: u.current,
                  text() {
                    if (null == s) return a;
                    const e = s();
                    return e.textContent || e.value || "";
                  },
                });
                let t;
                const r = (e) => {
                    var r;
                    e.clearSelection(),
                      m((0, Y.Z)("Copied!")),
                      null === (r = u.current) || void 0 === r || r.focus(),
                      clearTimeout(t),
                      (t = setTimeout(() => m(null), 1e3));
                  },
                  n = () => {
                    m((0, Y.Z)("Press {1} to copy", (0, We.W5)("c"))),
                      clearTimeout(t),
                      (t = setTimeout(() => m(null), 1e3));
                  };
                return (
                  e.on("success", r),
                  e.on("error", n),
                  () => {
                    clearTimeout(t),
                      e.off("success", r),
                      e.off("error", n),
                      e.destroy();
                  }
                );
              }, [s, a]),
              r
                ? (0, l.jsx)(_, {
                    direction: o.qF.NW,
                    text: d || (0, Y.Z)("Copy to clipboard"),
                    children: (0, l.jsx)(
                      M,
                      Je(
                        Je(
                          {
                            className: i()("EOaQm", t),
                            onMouseOut: () => m(null),
                            ref: u,
                          },
                          c
                        ),
                        {},
                        { children: (0, l.jsx)(z.qA2, { size: 16 }) }
                      )
                    ),
                  })
                : (0, l.jsx)(
                    Ie,
                    Je(
                      Je(
                        {
                          tooltip: d || (0, Y.Z)("Copy to clipboard"),
                          tooltipDirection: o.qF.NW,
                          onMouseOut: () => m(null),
                          size: 28,
                          ref: u,
                          className: t,
                        },
                        c
                      ),
                      {},
                      { children: (0, l.jsx)(z.qA2, { size: 14 }) }
                    )
                  )
            );
          },
          et = (0, g.memo)(Qe),
          tt = ({
            className: e,
            topPadding: t = 0,
            rightPos: r = 0,
            children: s,
          }) => {
            const n = (0, g.useRef)(null);
            return (
              (0, g.useEffect)(() => {
                var e;
                let s;
                const a =
                    null === (e = n.current) || void 0 === e
                      ? void 0
                      : e.parentNode,
                  i = () => {
                    n.current &&
                      ((n.current.style.opacity = 0.01),
                      clearTimeout(s),
                      (s = setTimeout(() => {
                        if (!a || !n.current) return;
                        const e = a.scrollTop,
                          s = a.scrollLeft;
                        (n.current.style.opacity = 1),
                          (n.current.style.top = t + e + "px"),
                          (n.current.style.left = `calc(100% + ${s - r}px)`);
                      }, 250)));
                  };
                return (
                  a.addEventListener("scroll", i, { capture: !1, passive: !0 }),
                  () => {
                    clearTimeout(s),
                      a.removeEventListener("scroll", i, {
                        capture: !1,
                        passive: !0,
                      });
                  }
                );
              }, [t, r]),
              (0, l.jsx)("div", {
                className: i()("WRRyg", e),
                ref: n,
                style: { top: t, left: `calc(100% - ${r}px)` },
                children: s,
              })
            );
          };
        function rt() {
          return (0, l.jsx)("noscript", {
            children: (0, l.jsx)(ue, {
              to: "https://enable-javascript.com/",
              absolute: !0,
              children: (0, Y.Z)(
                "Please enable JavaScript to use this web application."
              ),
            }),
          });
        }
        var st = r(50836),
          nt = r(20400);
        const at = ({ children: e }) =>
          (0, l.jsx)("span", { className: "M__Pz", children: e });
        class it extends g.Component {
          constructor(...e) {
            super(...e), (this.state = { hasError: !1 });
          }
          static getDerivedStateFromError(e) {
            return { hasError: !0 };
          }
          componentDidCatch(e, t) {}
          render() {
            const e = this.props,
              t = e.fallback,
              r = e.children,
              s = e.className;
            return this.state.hasError
              ? void 0 === t
                ? (0, l.jsx)(j, {
                    type: o.gr.pn,
                    className: s,
                    children: (0, Y.Z)(
                      "An error occurred while fetching the resource"
                    ),
                  })
                : t
              : r;
          }
        }
        const ot = it,
          ct = ({
            fallback: e,
            errorClassName: t,
            children: r,
            errorFallback: s,
          }) =>
            w()
              ? (0, l.jsx)(ot, {
                  className: t,
                  fallback: s,
                  children: (0, l.jsx)(g.Suspense, {
                    fallback: e,
                    children: r,
                  }),
                })
              : e;
        var lt = r(44291);
        const ut = ({ children: e }) => {
          const t = g.Children.only(e),
            r = (0, g.useRef)(null),
            s = t.ref || r;
          return (
            (0, g.useEffect)(() => {
              let e;
              return (
                s.current &&
                  ((e = (0, lt.v)(s.current, {
                    returnFocusOnDeactivate: !0,
                    allowOutsideClick: !0,
                  })),
                  e.activate()),
                () => {
                  var t;
                  clearTimeout(void 0),
                    null === (t = e) || void 0 === t || t.deactivate();
                }
              );
            }, [s]),
            (0, g.cloneElement)(t, { ref: s })
          );
        };
        var ht = r(23584),
          pt = r(58830);
        function dt(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        const gt = (e) => (
            (0, g.useContext)(pt.U),
            (0, l.jsx)(
              ae.Fg,
              (function (e) {
                for (var t = 1; t < arguments.length; t++) {
                  var r = null != arguments[t] ? arguments[t] : {};
                  t % 2
                    ? dt(Object(r), !0).forEach(function (t) {
                        (0, s.Z)(e, t, r[t]);
                      })
                    : Object.getOwnPropertyDescriptors
                    ? Object.defineProperties(
                        e,
                        Object.getOwnPropertyDescriptors(r)
                      )
                    : dt(Object(r)).forEach(function (t) {
                        Object.defineProperty(
                          e,
                          t,
                          Object.getOwnPropertyDescriptor(r, t)
                        );
                      });
                }
                return e;
              })({}, e)
            )
          ),
          mt = ["className", "children"];
        function ft(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function xt(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? ft(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : ft(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const bt = (0, g.forwardRef)((e, t) => {
          let r = e.className,
            s = e.children,
            a = (0, n.Z)(e, mt);
          return (0, l.jsxs)(
            M,
            xt(
              xt({ className: i()("WtMVB", r), ref: t }, a),
              {},
              { children: [s, (0, l.jsx)(z.ZXJ, {})] }
            )
          );
        });
        bt.propTypes = { className: I().string, children: I().node };
        const vt = bt;
        var jt = r(93942),
          yt = r(49061);
        const Ot = ({ shortcut: e }) => {
          if ((0, jt.v9)((e) => e.settings.disableKeyboardShortcuts))
            return null;
          const t = [];
          e.metaKey &&
            (We.yg && We.yg !== yt.B
              ? We.yg === yt.v && t.push("\u2318")
              : t.push("ctrl")),
            e.shiftKey && t.push("\u21e7"),
            e.altKey && t.push("\u2325");
          let r = null;
          switch (e.key) {
            case "ArrowLeft":
              r = "\u2190";
              break;
            case "ArrowUp":
              r = "\u2191";
              break;
            case "ArrowRight":
              r = "\u2192";
              break;
            case "ArrowDown":
              r = "\u2193";
              break;
            case "PageDown":
              r = "PgDn";
              break;
            case "PageUp":
              r = "PgUp";
              break;
            case "Enter":
              r = "enter";
              break;
            default:
              r = e.key;
          }
          return t.push(r), t.join("+");
        };
        Ot.propTypes = { shortcut: I().object.isRequired };
        const wt = (0, g.memo)(Ot);
      },
      23543: (e, t, r) => {
        "use strict";
        r.d(t, { qF: () => n, gr: () => l, J7: () => s, V5: () => a });
        var s = {};
        r.r(s), r.d(s, { M2: () => i, HC: () => o, TC: () => c });
        var n = {};
        r.r(n),
          r.d(n, {
            E: () => f,
            N: () => m,
            NE: () => d,
            NW: () => g,
            S: () => p,
            SE: () => u,
            SW: () => h,
            W: () => x,
          });
        var a = {};
        r.r(a), r.d(a, { n1: () => b, T: () => j, OK: () => v, $6: () => y });
        const i = "medium",
          o = "small",
          c = "tiny";
        var l = r(43154);
        const u = "se",
          h = "sw",
          p = "s",
          d = "ne",
          g = "nw",
          m = "n",
          f = "e",
          x = "w",
          b = "cancelButton",
          v = "okButton",
          j = "dangerButton",
          y = [v, b, j];
      },
      43154: (e, t, r) => {
        "use strict";
        r.d(t, { pn: () => s, u_: () => n, H_: () => a });
        const s = "error",
          n = "warn",
          a = "info";
      },
      34595: (e) => {
        e.exports = {
          ROOT_ELEMENT: "#regex-app",
          UPDATE_RESULT_DELAY: 500,
          DONATION_LINK:
            "https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=firas%2edib%40gmail%2ecom&lc=US&item_name=Regex101&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donate_SM%2egif%3aNonHostedGuest",
          WEBCHAT_LINK: "https://web.libera.chat/?nick=<NICKNAME>&chan=#regex",
          GROUP_COUNT: 6,
          DELETE_CODES: "regex101-delete-codes",
          CACHE_NAME: "regex101-cache",
          SPONSOR_LINK: "https://github.com/sponsors/firasdib",
          STATE_STORAGE_KEY: "regex101-state",
          STATE_TEMP_REGEX_EDITOR_KEY: "regex101-temp",
          DEFAULT_PAGE_TITLE: "build, test, and debug regex",
          DEFAULT_META_DESCRIPTION:
            "Regular expression tester with syntax highlighting, explanation, cheat sheet for PHP/PCRE, Python, GO, JavaScript, Java, C#/.NET.",
          LIBRARY_META_DESCRIPTION:
            "Search, filter and view user submitted regular expressions in the regex library. Over 20,000 entries, and counting!",
          QUIZ_META_DESCRIPTION:
            "Learn regex and challenge yourself in a unique regex quiz: play progressively harder levels and compete with orders in creating the shortest solutions.",
          SETTINGS_META_DESCRIPTION:
            "Customize your regex101 experience to suit your needs. Extensive options available: themes, default flavor, site language, and much more.",
          ACCOUNT_META_DESCRIPTION:
            "Manage all your regular expressions using your personal account. Add favorites, organize entries with titles and tags, make entries private, and more!",
        };
      },
      78850: (e, t, r) => {
        const s = r(81370),
          n = ["/", "~", "@", ";", "%", "`", "#"];
        e.exports = {
          [s.PCRE2]: n,
          [s.PCRE]: n,
          [s.PYTHON]: ['"', "'", '"""', "'''"],
          [s.JAVASCRIPT]: ["/", "`", '"', "'"],
          [s.GOLANG]: ["`"],
          [s.JAVA]: ['"'],
          [s.DOTNET]: ['"'],
        };
      },
      81370: (e) => {
        const t = "pcre",
          r = "pcre2",
          s = "javascript",
          n = "python",
          a = "golang",
          i = "java",
          o = "dotnet",
          c = [t, r, s, n, a, i, o];
        e.exports = {
          PCRE2: r,
          PCRE: t,
          PYTHON: n,
          JAVASCRIPT: s,
          GOLANG: a,
          JAVA: i,
          DOTNET: o,
          all: c,
        };
      },
      12037: (e, t, r) => {
        "use strict";
        r.r(t),
          r.d(t, {
            ESC: () => s,
            UPDATE_REGEX: () => n,
            SAVE_REGEX: () => a,
            LEFT_ARROW: () => i,
            RIGHT_ARROW: () => o,
            SHIFT_LEFT_ARROW: () => c,
            SHIFT_RIGHT_ARROW: () => l,
            COMMA: () => u,
            DOT: () => h,
            META_LEFT_ARROW: () => p,
            META_RIGHT_ARROW: () => d,
            PLUS: () => g,
            MINUS: () => m,
            HOME: () => f,
            END: () => x,
            PAGE_UP: () => b,
            PAGE_DOWN: () => v,
            RUN_UNIT_TESTS: () => j,
            SHOW_SHORTCUTS: () => y,
            SWITCH_TO_MATCH: () => O,
            SWITCH_TO_SUBST: () => w,
            SWITCH_TO_LIST: () => C,
            SWITCH_TO_UNIT_TESTS: () => E,
            SHOW_DEBUGGER: () => Z,
            SHOW_CODE_GEN: () => S,
          });
        const s = {
            name: "escape",
            keyCode: [27],
            key: "Escape",
            overrideInput: !0,
          },
          n = {
            name: "updateRegex",
            key: "s",
            keyCode: [83],
            shiftKey: !0,
            metaKey: !0,
            alwaysConsume: !0,
            overrideInput: !0,
          },
          a = {
            name: "saveRegex",
            key: "s",
            keyCode: [83],
            metaKey: !0,
            alwaysConsume: !0,
            overrideInput: !0,
          },
          i = {
            name: "leftArrow",
            key: "ArrowLeft",
            keyCode: [37],
            overrideInput: !1,
          },
          o = {
            name: "rightArrow",
            key: "ArrowRight",
            keyCode: [39],
            overrideInput: !1,
          },
          c = {
            name: "shiftLeftArrow",
            key: "ArrowLeft",
            keyCode: [37],
            shiftKey: !0,
            overrideInput: !1,
          },
          l = {
            name: "shiftRightArrow",
            key: "ArrowRight",
            keyCode: [39],
            shiftKey: !0,
            overrideInput: !1,
          },
          u = { name: "comma", key: ",", keyCode: [44], overrideInput: !1 },
          h = { name: "dot", key: ".", keyCode: [46], overrideInput: !1 },
          p = {
            name: "metaArrowLeft",
            key: "ArrowLeft",
            keyCode: [37],
            metaKey: !0,
            overrideInput: !1,
          },
          d = {
            name: "metaArrowRight",
            key: "ArrowRight",
            keyCode: [39],
            metaKey: !0,
            overrideInput: !1,
          },
          g = {
            name: "plus",
            key: "+",
            keyCode: [107, 171],
            overrideInput: !1,
          },
          m = {
            name: "minus",
            key: "-",
            keyCode: [109, 173],
            overrideInput: !1,
          },
          f = { name: "home", key: "Home", keyCode: [36], overrideInput: !1 },
          x = { name: "end", key: "End", keyCode: [35], overrideInput: !1 },
          b = {
            name: "pageUp",
            key: "PageUp",
            keyCode: [33],
            overrideInput: !1,
          },
          v = {
            name: "pageDown",
            key: "PageDown",
            keyCode: [34],
            overrideInput: !1,
          },
          j = {
            name: "ctrlEnter",
            key: "Enter",
            keyCode: [13],
            metaKey: !0,
            overrideInput: !0,
          },
          y = {
            name: "question",
            key: "?",
            keyCode: [171],
            shiftKey: !0,
            overrideInput: !1,
          },
          O = {
            name: "ctrl1",
            key: "1",
            keyCode: [49],
            metaKey: !0,
            overrideInput: !0,
          },
          w = {
            name: "ctrl2",
            key: "2",
            keyCode: [50],
            metaKey: !0,
            overrideInput: !0,
          },
          C = {
            name: "ctrl3",
            key: "3",
            keyCode: [51],
            metaKey: !0,
            overrideInput: !0,
          },
          E = {
            name: "ctrl4",
            key: "4",
            keyCode: [52],
            metaKey: !0,
            overrideInput: !0,
          },
          Z = {
            name: "ctrlB",
            key: "b",
            keyCode: [66],
            metaKey: !0,
            overrideInput: !0,
          },
          S = {
            name: "ctrlG",
            key: "g",
            keyCode: [71],
            metaKey: !0,
            overrideInput: !0,
          };
      },
      48211: (e, t, r) => {
        "use strict";
        r.r(t),
          r.d(t, {
            CHINESE: () => b,
            DUTCH: () => m,
            ENGLISH: () => g,
            FRENCH: () => f,
            GERMAN: () => x,
            ITALIAN: () => C,
            PORTOGUESE: () => y,
            ROMANIAN: () => w,
            RUSSIAN: () => O,
            SPANISH: () => j,
            SWEDISH: () => v,
          });
        const s = r.p + "assets/english.80ab70a1.json",
          n = r.p + "assets/dutch.ba1b436c.json",
          a = r.p + "assets/french.e5a4f309.json",
          i = r.p + "assets/german.ae26d277.json",
          o = r.p + "assets/zh.7eab4195.json",
          c = r.p + "assets/sv.92024469.json",
          l = r.p + "assets/spanish.1f438d32.json",
          u = r.p + "assets/pt_BR.6686befb.json",
          h = r.p + "assets/ru.3769d051.json",
          p = r.p + "assets/ro.3fae4d40.json",
          d = r.p + "assets/it.0a2090a1.json",
          g = { text: "English", file: s },
          m = { text: "Dutch", file: n },
          f = { text: "French", file: a },
          x = { text: "German", file: i },
          b = { text: "Chinese", file: o },
          v = { text: "Swedish", file: c },
          j = { text: "Spanish", file: l },
          y = { text: "Portogueze (Brazil)", file: u },
          O = { text: "Russian", file: h },
          w = { text: "Romanian", file: p },
          C = { text: "Italian", file: d };
      },
      35896: (e) => {
        const t = "MOST_RECENT",
          r = "MOST_POINTS",
          s = "LEAST_POINTS",
          n = "RELEVANCE",
          a = [t, r, s, n];
        e.exports = {
          MOST_RECENT: t,
          MOST_POINTS: r,
          LEAST_POINTS: s,
          RELEVANCE: n,
          all: a,
        };
      },
      34768: (e, t, r) => {
        "use strict";
        r.d(t, {
          D9: () => s,
          ik: () => n,
          Y8: () => a,
          Hg: () => i,
          VE: () => o,
          ek: () => c,
          Rp: () => l,
          e0: () => u,
          ed: () => h,
          Fo: () => p,
          wm: () => d,
          Vu: () => g,
          UA: () => m,
          Gv: () => f,
        });
        const s = "PATTERN_ERROR",
          n = "TIMEOUT_ERROR",
          a = "FAILED_TO_INITIALIZE_ENGINE",
          i = -1,
          o = -8,
          c = -11,
          l = -21,
          u = -26,
          h = -33,
          p = -36,
          d = -47,
          g = -52,
          m = -53,
          f = "JAVA_STACK_ERROR";
      },
      49061: (e, t, r) => {
        "use strict";
        r.d(t, { v: () => s, B: () => n });
        const s = "OSX",
          n = "WINDOWS";
      },
      67664: (e, t, r) => {
        "use strict";
        r.d(t, {
          f0: () => s,
          CL: () => n,
          Xu: () => a,
          wi: () => i,
          kU: () => o,
          cs: () => c,
          bk: () => l,
          eB: () => u,
          jV: () => h,
          wn: () => p,
          Gz: () => d,
          gN: () => g,
          As: () => m,
          Bj: () => f,
          RY: () => x,
          Hh: () => b,
          Cc: () => v,
          Vt: () => j,
          IA: () => y,
          sw: () => O,
          i0: () => w,
          BC: () => C,
          fA: () => E,
          VM: () => Z,
          d3: () => S,
          Y4: () => k,
          $H: () => P,
          Af: () => N,
          RH: () => _,
          zX: () => T,
          t0: () => A,
          Jf: () => I,
          O3: () => R,
          K0: () => D,
          Yo: () => L,
          y1: () => M,
          oH: () => U,
          Rf: () => F,
          YY: () => G,
          xi: () => V,
          Iu: () => B,
          mi: () => q,
          jb: () => H,
          XD: () => $,
          Ey: () => z,
          M3: () => W,
          mB: () => Y,
          wW: () => K,
          Qc: () => J,
          of: () => X,
          rs: () => Q,
          xX: () => ee,
          jz: () => te,
          sb: () => re,
          Oy: () => se,
          KE: () => ne,
          bb: () => ae,
        });
        const s = "UNMATCHED_PARENTHESIS",
          n = "INCOMPLETE_GROUP",
          a = "INVALID_CONDITION",
          i = "DUPLICATE_SUBPATTERN_NAME",
          o = "BAD_SUBPATTERN_NAME",
          c = "TOO_MANY_ALTERNATIVES",
          l = "TOO_LONG_SUBPATTERN_NAME",
          u = "LOOKBEHIND_VARIABLE_WIDTH",
          h = "TOKEN_NOT_ALLOWED_IN_LOOKBEHIND",
          p = "DUPLICATE_SUBPATTERN_BAD_INDEX",
          d = "INVALID_HYPHEN_INLINE_MODIFIERS",
          g = "UNKNOWN_VERB",
          m = "VERB_NOT_AT_START",
          f = "INVALID_REFERENCE",
          x = "NOT_QUANTIFIABLE",
          b = "QUANTIFIER_OUT_OF_ORDER",
          v = "QUANTIFIER_LOOKBEHIND_DISALLOWED",
          j = "QUANTIFIER_TOO_LARGE",
          y = "LONE_BRACKET",
          O = "INCOMPLETE_CHARCLASS",
          w = "CHARCLASS_RANGE_OUT_OF_ORDER",
          C = "INVALID_CHARCLASS_RANGE_META",
          E = "POSIX_OUTSIDE_CHARCLASS",
          Z = "UNKNOWN_POSIX_CLASS",
          S = "INVALID_CHARCLASS_RANGE_PCRE_BUG",
          k = "CHARCLASS_RANGE_INVALID",
          P = "INVALID_POSIX_WORD_BOUNDARY",
          N = "BAD_CHARCLASS_RANGE_SURROGATES",
          _ = "UNSUPPORTED_ESCAPE_SEQUENCE",
          T = "TRAILING_BACKSLASH",
          A = "UNESCAPED_DELIMITER",
          I = "TOO_LARGE_NUMBER",
          R = "NULL_BYTE_NOT_ALLOWED",
          D = "INVALID_UNICODE_ESCAPE",
          L = "INCOMPLETE_HEX_TOKEN",
          M = "HEX_VALUE_TOO_LARGE",
          U = "HEX_SURROGATES",
          F = "OCTAL_VALUE_TOO_LARGE",
          G = "INCOMPLETE_TOKEN",
          V = "UNKNOWN_UNICODE_SCRIPT",
          B = "INVALID_CONTROL_CHAR",
          q = "INVALID_ESCAPE_SEQUENCE",
          H = "BACKSPACE_NOT_SUPPORTED",
          $ = "EMPTY_QUOTE",
          z = "LONELY_END_QUOTE_ERROR",
          W = "PYTHON_INLINE_MODIFIERS_BAD_POS",
          Y = "PYTHON_CONFLICTING_FLAGS_A_U",
          K = "PYTHON_BOGUS_ESCAPE",
          J = "GOLANG_INVALID_ESCAPE_BACKTICK",
          X = "JS_NOT_ALLOWED_IN_STRICT_MODE",
          Q = "UNMATCHED_BRACKET",
          ee = "TOO_MANY_CONDITIONALS",
          te = "INVALID_CHARCLASS_INTERSECTION",
          re = "JAVA_BACKREF_PREMATURE_USE",
          se = "BACKREFERENCE_IN_CHAR_CLASS",
          ne = "DOTNET_RANGE_BRACKET",
          ae = "INVALID_CHARCLASS_SUBTRACTION";
      },
      76493: (e, t, r) => {
        const s = r(31807),
          n = r(81370);
        let a = "gmi";
        s || (a += "syud"),
          (e.exports = {
            [n.PCRE2]: "gmixsuUAJD",
            [n.PCRE]: "gmixXsuUAJD",
            [n.JAVASCRIPT]: a,
            [n.PYTHON]: "gmixsua",
            [n.GOLANG]: "gmisU",
            [n.JAVA]: "gmisxuU",
            [n.DOTNET]: "gimsnxR",
            extendFlags(t, r) {
              e.exports[t] += r;
            },
          });
      },
      1277: (e, t, r) => {
        "use strict";
        r.d(t, {
          MW: () => s,
          hs: () => n,
          Wj: () => a,
          t0: () => i,
          $U: () => o,
          Qp: () => c,
          dz: () => l,
          Pg: () => u,
          L3: () => h,
          Yb: () => p,
          RW: () => d,
          cF: () => g,
          lA: () => m,
          Eb: () => f,
          Tf: () => x,
          bO: () => b,
          _w: () => v,
          O3: () => j,
          hb: () => y,
          bJ: () => O,
          eq: () => w,
          WE: () => C,
          ZH: () => E,
          HI: () => Z,
          U6: () => S,
          jt: () => k,
          be: () => P,
          jl: () => N,
          XR: () => _,
          qi: () => T,
          xT: () => A,
          Ws: () => I,
          oK: () => R,
          Yz: () => D,
          df: () => L,
          sS: () => M,
          no: () => U,
          Jy: () => F,
          t: () => G,
          jf: () => V,
          vU: () => B,
          Ty: () => q,
          Gs: () => H,
          up: () => $,
          PG: () => z,
          fy: () => W,
          qh: () => Y,
          zl: () => K,
          Xq: () => J,
          aM: () => X,
          py: () => Q,
          w_: () => ee,
          Cz: () => te,
          tI: () => re,
          hL: () => se,
          Ud: () => ne,
          ul: () => ae,
          sr: () => ie,
          ET: () => oe,
          Ao: () => ce,
          zB: () => le,
          tK: () => ue,
          Az: () => he,
          Bx: () => pe,
        });
        const s = "META",
          n = "ALTERNATOR",
          a = "QUANTIFIER",
          i = "ESCAPED_LITERAL",
          o = "QUOTED_LITERALS",
          c = "LONELY_END_QUOTE",
          l = "UNICODE_PROPERTY",
          u = "OCTAL",
          h = "HEX",
          p = "UNICODE_ESCAPE",
          d = "INLINE_MODIFIERS",
          g = "DELIMITER",
          m = "CONTROL_SEQUENCE",
          f = "GLOBAL_FLAGS",
          x = "VERTICAL_TAB",
          b = "SURROGATE_PAIR",
          v = "SUBPATTERN_REFERENCE_GROUP",
          j = "NAMED_BACKREFERENCE",
          y = "BACKREFERENCE_G",
          O = "BACKREFERENCE_K",
          w = "SUBPATTERN_REFERENCE_G",
          C = "NUMERIC_BACKREFERENCE",
          E = "BACKSPACE",
          Z = "OPEN_CHARCLASS",
          S = "CLOSE_CHARCLASS",
          k = "CHARCLASS_RANGE",
          P = "POSIX",
          N = "EMPTY_CHARCLASS",
          _ = "POSIX_WORD_BOUNDARY",
          T = "LINE_COMMENT",
          A = "GROUP",
          I = "DEFINE",
          R = "CONDITIONAL",
          D = "CONDITIONAL_CONDITION",
          L = "MODIFIER_GROUP",
          M = "NAMED_GROUP",
          U = "BRANCH_RESET_GROUP",
          F = "ATOMIC_GROUP",
          G = "CAPTURING_GROUP",
          V = "GROUP_COMMENT",
          B = "VERB",
          q = "NEGATIVE_LOOKBEHIND",
          H = "POSITIVE_LOOKBEHIND",
          $ = "NEGATIVE_LOOKAHEAD",
          z = "POSITIVE_LOOKAHEAD",
          W = "NON_ATOMIC_POSITIVE_LOOKAHEAD",
          Y = "NON_ATOMIC_POSITIVE_LOOKBEHIND",
          K = "PLAIN_TEXT",
          J = "ERROR_TOKEN",
          X = "START_CASE_MODIFIER",
          Q = "END_CASE_MODIFIER",
          ee = "SUBST_CONDITIONAL",
          te = "INSERT_PRECEDES_MATCH",
          re = "INSERT_FOLLOWS_MATCH",
          se = "INSERT_FULL_MATCH",
          ne = "INSERT_INPUT_STRING",
          ae = "INSERT_LAST_GROUP",
          ie = "NAMED_BALANCING_GROUP",
          oe = "BALANCING_GROUP",
          ce = "CHARCLASS_SUBTRACTION",
          le = "CHARCLASS_INTERSECTION";
        function ue(e) {
          return [A, I, R, L, M, U, F, G, ie, oe].includes(e) || he(e);
        }
        function he(e) {
          return [q, H, $, z, W, Y].includes(e);
        }
        function pe(e) {
          return [Z, n, le, ce].includes(e) || ue(e);
        }
      },
      13201: (e) => {
        e.exports = { GOOGLE: "google", TWITTER: "twitter", GITHUB: "github" };
      },
      7551: (e, t, r) => {
        "use strict";
        r.d(t, { rp: () => s, Py: () => n, B7: () => a });
        const s = "light",
          n = "dark",
          a = "AUTO";
      },
      7504: (e) => {
        e.exports = {
          MINE: "mine",
          FAVORITES: "favorites",
          LIBRARY: "library",
        };
      },
      11162: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => m });
        var s = r(4942),
          n = r(45987),
          a = r(67294),
          i = r(45697),
          o = r.n(i),
          c = r(94184),
          l = r.n(c),
          u = r(85893);
        const h = ["children", "className"];
        function p(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function d(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? p(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : p(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const g = (0, a.forwardRef)((e, t) => {
          let r = e.children,
            s = e.className,
            a = (0, n.Z)(e, h);
          return (0, u.jsx)(
            "div",
            d(d({ className: l()("ueGQi", s), ref: t }, a), {}, { children: r })
          );
        });
        g.propTypes = { children: o().node, className: o().string };
        const m = g;
      },
      94500: (e, t, r) => {
        "use strict";
        r.d(t, { SW: () => i, rP: () => o, $Z: () => c });
        var s = r(23765),
          n = r(58317),
          a = r(34595);
        function i(e, t) {
          const r = { permalinkFragment: e, deleteCode: t },
            i = n.Z.get(a.DELETE_CODES) || [];
          i.find((t) => t.permalinkFragment === e)
            ? s.Z.info(`Delete code for '${e}' already stored`)
            : (i.push(r),
              n.Z.save(a.DELETE_CODES, i),
              s.Z.info("Saved new delete code", r));
        }
        function o(e) {
          try {
            const t = n.Z.get(a.DELETE_CODES, !1) || [],
              r = t.find((t) => t.permalinkFragment === e),
              i = r ? t.indexOf(r) : -1;
            if (-1 !== i) {
              const r = t.slice();
              return (
                r.splice(i, 1),
                s.Z.info("Removed delete code for permalink fragment", e),
                n.Z.save(a.DELETE_CODES, r, !1)
              );
            }
            throw new Error();
          } catch (t) {
            s.Z.warn(
              "Unable to remove delete code for permalink fragment",
              e,
              t
            );
          }
        }
        function c(e) {
          try {
            const t = (n.Z.get(a.DELETE_CODES, !1) || []).find(
              (t) => t.permalinkFragment === e
            );
            if (t)
              return (
                s.Z.info("Retrieved delete code for permalink fragment", e),
                t.deleteCode
              );
            s.Z.warn(
              "Unable to retrieve delete code for permalink fragment",
              e
            );
          } catch (t) {
            s.Z.error(
              `Unable to retrieve delete code for permalink fragment "${e}"`,
              t
            );
          }
        }
      },
      64023: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => o });
        var s = r(4942),
          n = r(34768);
        function a(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function i(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? a(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : a(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const o = class {
          constructor() {
            (this.tokens = []),
              (this._positionToTokenMap = null),
              (this._initialState = null),
              (this._patternError = null),
              (this.tokens = []),
              (this._positionToTokenMap = []),
              (this._initialState = {});
          }
          getStatus() {
            return this._patternError ? n.D9 : null;
          }
          static copyState(e) {
            const t = {};
            for (let r = 0, s = Object.keys(e); r < s.length; r++) {
              const n = s[r],
                a = e[n];
              Array.isArray(a)
                ? (t[n] = a.slice())
                : (t[n] = null != a && "object" == typeof a ? i({}, a) : a);
            }
            return t;
          }
          getTokenAtPos(e) {
            if (null == e || e < 0) return null;
            let t = 0,
              r = this.tokens.length - 1;
            for (; t <= r; ) {
              const s = (t + r) >> 1;
              let n = this.tokens[s];
              n.invisible && s > 0 && (n = this.tokens[s - 1]);
              const a = n.position,
                i = a.start,
                o = a.end;
              if (e >= i && e < o) return n;
              e < i ? (r = s - 1) : (t = s + 1);
            }
            return null;
          }
          _token(e, t, r) {
            const s = this._getTokenizers(e);
            for (let e = 0, n = s.length; e < n; e++) {
              const n = s[e].call(this, t, t.peek(), r);
              if (null != n) return n;
            }
            throw new Error(
              `There was no tokenizer that could parse the regex '${t.current}'`
            );
          }
          _getTokenizers() {
            throw new Error("Tokenizer function not implemented");
          }
        };
      },
      26681: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => s });
        const s = new (r(35425).ZP)();
      },
      35425: (e, t, r) => {
        "use strict";
        r.d(t, {
          ZP: () => Gt,
          wx: () => Vt,
          fg: () => Bt,
          IP: () => qt,
          nn: () => Ht,
          x3: () => $t,
          XG: () => zt,
        });
        var s = r(98152),
          n = r(4942),
          a = r(64023),
          i = r(75659),
          o = r(1277),
          c = r(81370),
          l = r.n(c),
          u = r(43307);
        class h extends u.Z {
          constructor(e) {
            super(e, o.hs),
              (this.string = ""),
              (this.alternativeNumber = 0),
              (this.position = { start: -1, end: -1 }),
              (this.invisible = !0);
          }
          _getNextState(e) {
            return (
              e.parents.push(this),
              (e.previousToken = this.state.previousToken),
              e
            );
          }
        }
        const p = h;
        var d = r(4844),
          g = r(67664),
          m = r(4458);
        class f extends u.Z {
          constructor(e) {
            super(e, o.$U), this.setStyle(m.Z.quote);
          }
          parseComplete() {
            if ("\\Q\\E" === this.string) this.setError(g.XD);
            else {
              const e = this.string.length - 3;
              (this.charCode = this.string.charCodeAt(e)),
                (this.codePoint = this.string.codePointAt(e));
            }
            this.length = this.string.length - 4;
          }
        }
        const x = f;
        class b extends u.Z {
          constructor(e) {
            super(e, o.be), (this.posixClass = null), this.setStyle(m.Z.meta);
          }
          parseComplete() {
            const e =
              this.state.flavor === l().PCRE || this.state.flavor === l().PCRE2;
            (this.posixClass = this.string.replace(/^\[:\^?|:\]$/g, "")),
              this.state.inCharClass
                ? e && /^[<>]$/.test(this.posixClass)
                  ? this.setError(g.$H)
                  : /^(?:alnum|ascii|alpha|word|blank|cntrl|digit|graph|lower|print|punct|space|upper|xdigit)$/.test(
                      this.posixClass
                    ) || this.setError(g.VM)
                : this.setError(g.fA);
          }
        }
        const v = b;
        var j = r(53996);
        class y extends j.Z {
          constructor(e) {
            super(e, o._w), this.setStyle(m.Z.subpattern_reference);
          }
          _revalidate(e) {
            if ("(?0)" === this.string || "(?R)" === this.string)
              return void (this.reference = null);
            const t = this.string.replace(/^(?:\\g|\(\?P>)|[^\w\-+]/g, "");
            let r;
            if (t)
              if ("+" === t.charAt(0)) {
                const s = parseInt(t.slice(1), 10);
                (r = this.state.captureGroupCount + s),
                  (0 === s ||
                    this.state.captureGroupCount + s > e.captureGroupCount) &&
                    this.setError(g.Bj);
              } else if ("-" === t.charAt(0)) {
                const e = parseInt(t.slice(1), 10);
                (r = this.state.captureGroupCount - e + 1),
                  (0 === e || this.state.captureGroupCount - e < 0) &&
                    this.setError(g.Bj);
              } else
                isNaN(t) ||
                "&" === this.string.charAt(2) ||
                "(?P>" === this.string.slice(0, 4)
                  ? e.subpatterns.includes(t) || this.setError(g.Bj)
                  : ((r = parseInt(t, 10)),
                    e.captureGroupCount < r && this.setError(g.Bj));
            else this.setError(g.YY);
            return (this.reference = r || t), !!this.error;
          }
        }
        const O = y;
        var w = r(86700),
          C = r(4427),
          E = r(38645),
          Z = r(99520);
        const S =
            /^(?:ACCEPT|F(?:AIL)?|COMMIT|PRUNE(?::\w+)?|SKIP(?::\w+)?|MARK:\w+|THEN(?::\w+)?|:\w+)$/,
          k =
            /^(?:LIMIT_MATCH=\d{1,9}|LIMIT_RECURSION=\d{1,9}|NO_AUTO_POSSESS|NO_START_OPT|CR|LF|CRLF|ANYCRLF|ANY|BSR_ANYCRLF|BSR_UNICODE|UTF16|UCP)$/,
          P =
            /^(?:LIMIT_DEPTH=\d{1,9}|LIMIT_HEAP=\d{1,9}|NOTEMPTY|NOTEMPTY_ATSTART|NO_DOTSTAR_ANCHOR|NUL|NO_JIT)$/;
        class N extends u.Z {
          constructor(e) {
            super(e, o.vU),
              (this.verb = null),
              (this.startVerb = !1),
              this.setStyle(m.Z.verb);
          }
          parseComplete() {
            const e = this.state.flavor === l().PCRE2;
            (this.verb = this.string.slice(2, -1)),
              (this.quantifiable = e && "ACCEPT" === this.verb);
            const t = (e ? P : k).test(this.verb);
            if (((this.startVerb = t), t || S.test(this.verb))) {
              const e = this.state.actualPreviousToken;
              !t ||
                0 === this.position.start ||
                (null != e &&
                  null == e.error &&
                  e.type === o.vU &&
                  e.startVerb) ||
                this.setError(g.As);
            } else this.setError(g.gN);
          }
          _getNextState(e) {
            return (
              "CR" === this.verb
                ? (e.lineTerminators = ["\\r"])
                : "LF" === this.verb
                ? (e.lineTerminators = ["\\n"])
                : "CRLF" === this.verb
                ? (e.lineTerminators = ["\\r\\n"])
                : "ANYCRLF" === this.verb
                ? (e.lineTerminators = ["\\n", "\\r", "\\r\\n"])
                : "ANY" === this.verb &&
                  (e.lineTerminators = [
                    "\\n",
                    "\\r",
                    "\\r\\n",
                    "\\f",
                    "\\v",
                    "\\x85",
                    "\\u2028",
                    "\\u2029",
                  ]),
              e
            );
          }
        }
        const _ = N;
        var T = r(16770),
          A = r(93210),
          I = r(87263);
        class R extends I.Z {
          constructor(e, t) {
            super(e, o.Ws);
          }
          _getNextState(e) {
            return (e.inDEFINE = !0), I.Z.prototype._getNextState.call(this, e);
          }
        }
        const D = R;
        var L = r(29328),
          M = r(75262),
          U = r(6975),
          F = r(43276),
          G = r(53980),
          V = r(23550),
          B = r(23049),
          q = r(85877);
        class H extends q.Z {
          constructor(e, t) {
            super(e, o.fy, t);
          }
        }
        const $ = H;
        var z = r(50594);
        class W extends z.Z {
          constructor(e, t) {
            super(e, o.qh, t);
          }
        }
        const Y = W;
        var K = r(60370);
        function J(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function X(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? J(Object(r), !0).forEach(function (t) {
                  (0, n.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : J(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        class Q extends I.Z {
          constructor(e) {
            super(e, o.no, !0),
              (this.captureGroupMap = {}),
              (this.subpatterns = []),
              (this.finalCaptureGroupCount = 0);
          }
          setBaseline(e) {
            (this.finalCaptureGroupCount = Math.max(
              this.finalCaptureGroupCount,
              e.captureGroupCount
            )),
              (this.captureGroupMap = X(
                X({}, this.captureGroupMap),
                e.captureGroupMap
              )),
              (this.subpatterns = (0, K.Z)(
                this.subpatterns.concat(e.subpatterns)
              ));
          }
          getBaseline() {
            return {
              captureGroupCount: this.state.captureGroupCount,
              captureGroupMap:
                this.captureGroupMap || this.state.captureGroupMap,
              subpatterns: this.subpatterns || this.state.subpatterns,
            };
          }
          _getNextState(e) {
            return (
              (e.inDuplicateSubpatternGroup = !0),
              I.Z.prototype._getNextState.call(this, e)
            );
          }
        }
        const ee = Q;
        var te = r(78338),
          re = r(61923),
          se = r(4462);
        class ne extends E.Z {
          parseComplete() {
            E.Z.prototype.parseComplete.call(this),
              "}" !== this.string.slice(-1)
                ? this.setError(g.YY)
                : ((!this.state.unicodeEnabled && this.charCode > 65535) ||
                    (this.state.unicodeEnabled &&
                      this.charCode > parseInt("0x10FFFF", 16))) &&
                  this.setError(g.Rf);
          }
        }
        const ae = ne;
        var ie = r(64375);
        class oe extends u.Z {
          constructor(e) {
            super(e, o.Qp), this.setError(g.Ey);
          }
        }
        const ce = oe;
        var le = r(22028);
        const ue = [
          "Arabic",
          "Armenian",
          "Avestan",
          "Balinese",
          "Bamum",
          "Bassa_Vah",
          "Batak",
          "Bengali",
          "Bopomofo",
          "Brahmi",
          "Braille",
          "Buginese",
          "Buhid",
          "Canadian_Aboriginal",
          "Car-ian",
          "Caucasian_Albanian",
          "Chakma",
          "Cham",
          "Cherokee",
          "Common",
          "Coptic",
          "Cunei-form",
          "Cypriot",
          "Cyrillic",
          "Deseret",
          "Devanagari",
          "Duployan",
          "Egyptian_Hiero-glyphs",
          "Elbasan",
          "Ethiopic",
          "Georgian",
          "Glagolitic",
          "Gothic",
          "Grantha",
          "Greek",
          "Gujarati",
          "Gurmukhi",
          "Han",
          "Hangul",
          "Hanunoo",
          "Hebrew",
          "Hiragana",
          "Imperial_Aramaic",
          "Inherited",
          "Inscriptional_Pahlavi",
          "Inscrip-tional_Parthian",
          "Javanese",
          "Kaithi",
          "Kannada",
          "Katakana",
          "Kayah_Li",
          "Kharoshthi",
          "Khmer",
          "Khojki",
          "Khudawadi",
          "Lao",
          "Latin",
          "Lepcha",
          "Limbu",
          "Lin-ear_A",
          "Linear_B",
          "Lisu",
          "Lycian",
          "Lydian",
          "Mahajani",
          "Malayalam",
          "Mandaic",
          "Manichaean",
          "Meetei_Mayek",
          "Mende_Kikakui",
          "Meroitic_Cursive",
          "Meroitic_Hieroglyphs",
          "Miao",
          "Modi",
          "Mongolian",
          "Mro",
          "Myanmar",
          "Nabataean",
          "New_Tai_Lue",
          "Nko",
          "Ogham",
          "Ol_Chiki",
          "Old_Italic",
          "Old_North_Arabian",
          "Old_Permic",
          "Old_Persian",
          "Old_South_Arabian",
          "Old_Turkic",
          "Oriya",
          "Osmanya",
          "Pahawh_Hmong",
          "Palmyrene",
          "Pau_Cin_Hau",
          "Phags_Pa",
          "Phoenician",
          "Psalter_Pahlavi",
          "Rejang",
          "Runic",
          "Samaritan",
          "Saurashtra",
          "Sharada",
          "Sha-vian",
          "Siddham",
          "Sinhala",
          "Sora_Sompeng",
          "Sundanese",
          "Syloti_Nagri",
          "Syriac",
          "Tagalog",
          "Tagbanwa",
          "Tai_Le",
          "Tai_Tham",
          "Tai_Viet",
          "Takri",
          "Tamil",
          "Telugu",
          "Thaana",
          "Thai",
          "Tibetan",
          "Tifinagh",
          "Tirhuta",
          "Ugaritic",
          "Vai",
          "Warang_Citi",
          "Yi",
          "C",
          "Cc",
          "Cf",
          "Cn",
          "Co",
          "Cs",
          "L",
          "Ll",
          "Lm",
          "Lo",
          "Lt",
          "Lu",
          "L&",
          "M",
          "Mc",
          "Me",
          "Mn",
          "N",
          "Nd",
          "Nl",
          "No",
          "P",
          "Pc",
          "Pd",
          "Pe",
          "Pf",
          "Pi",
          "Po",
          "Ps",
          "S",
          "Sc",
          "Sk",
          "Sm",
          "So",
          "Z",
          "Zl",
          "Zp",
          "Zs",
        ];
        class he extends le.Z {
          parseComplete() {
            le.Z.prototype.parseComplete.call(this),
              ue.includes(this.script)
                ? "{" === this.string.charAt(2) &&
                  "}" !== this.string.slice(-1) &&
                  this.setError(g.YY)
                : this.setError(g.xi);
          }
        }
        const pe = he;
        var de = r(72655);
        class ge extends de.Z {
          _revalidate(e, t) {
            return t && /^\\[a-z]/i.test(t.string) && t.type === o.t0
              ? (this.setError(g.d3), !0)
              : this.state.flavor === l().PCRE && null == e.charCode
              ? (this._convertToPlainText(), !1)
              : de.Z.prototype._revalidate.apply(this, arguments);
          }
        }
        const me = ge;
        var fe = r(97027);
        class xe extends fe.Z {
          parseComplete() {
            fe.Z.prototype.parseComplete.call(this),
              (this.state.flavor === l().PCRE2 ||
                this.state.flags.includes("X")) &&
                /^\\[a-z]/i.test(this.string) &&
                this.setError(g.mi);
          }
        }
        const be = xe;
        var ve = r(53467);
        class je extends ve.Z {
          parseComplete() {
            ve.Z.prototype.parseComplete.call(this),
              (this.from > 65535 || (this.to !== 1 / 0 && this.to > 65535)) &&
                this.setError(g.Vt);
          }
          _validateQuantifier(e) {
            "+" === e
              ? (this.possessive = !0)
              : ve.Z.prototype._validateQuantifier.apply(this, arguments);
          }
        }
        const ye = je;
        class Oe extends I.Z {
          constructor(e, t) {
            super(e, o.oK, !0),
              (this.expectCondition = !1),
              (this.condition = null),
              (this.lookaround = !1),
              (this.backreference = !1),
              (this.subroutine = !1),
              (this.reference = null),
              (this.expectCondition = t);
          }
          setCondition(e) {
            (this.lookaround = !0), (this.condition = e);
          }
          parseComplete() {
            I.Z.prototype.parseComplete.call(this),
              this.expectCondition ||
                (this.condition = this.string.slice(3, -1));
          }
          _getNextState(e) {
            return (
              e.conditionals.push(this),
              this.expectCondition && (e.expectingCondition = !0),
              I.Z.prototype._getNextState.call(this, e)
            );
          }
          _revalidate(e) {
            if (!this.condition || !this.closeGroup)
              return this.setError(g.CL), !!this.error;
            if ("string" != typeof this.condition) return !1;
            if (/^R?\d+$/.test(this.condition))
              (this.reference = parseInt(
                this.condition.replace(/\D/g, ""),
                10
              )),
                this.reference > e.captureGroupCount && this.setError(g.Bj),
                "R" === this.condition.charAt(0)
                  ? (this.subroutine = !0)
                  : ((this.backreference = !0),
                    0 === this.reference && this.setError(g.Bj));
            else if ("R" !== this.condition || e.subpatterns.includes("R")) {
              if (/^(?:<\w+>|'\w+'|\w+)$/.test(this.condition))
                (this.backreference = !0),
                  (this.reference = this.condition.replace(/\W/g, "")),
                  e.subpatterns.includes(this.reference) || this.setError(g.Bj);
              else if (/^R&/.test(this.condition))
                (this.reference = this.condition.slice(2)),
                  (this.subroutine = !0),
                  e.subpatterns.includes(this.reference) || this.setError(g.Bj);
              else if (this.condition.includes("+")) {
                const t = parseInt(this.condition.slice(1), 10);
                (this.reference = this.state.captureGroupCount + t),
                  (this.backreference = !0),
                  (0 === t || this.reference > e.captureGroupCount) &&
                    this.setError(g.Bj);
              } else if (this.condition.includes("-")) {
                const e = parseInt(this.condition.slice(1), 10);
                (this.reference = this.state.captureGroupCount - e + 1),
                  (this.backreference = !0),
                  (0 === e || this.reference < 1) && this.setError(g.Bj);
              }
            } else (this.reference = null), (this.subroutine = !0);
            return !!this.error;
          }
        }
        const we = Oe;
        class Ce extends u.Z {
          constructor(e) {
            super(e, o.XR),
              this.setStyle([m.Z.charclass, m.Z.meta]),
              (this.quantifiable = !1),
              (this.length = 0);
          }
        }
        const Ee = Ce;
        var Ze = r(51402),
          Se = r(32774);
        const ke = (e, t, r) => {
            if ("\\" === t && e.matchString("\\E")) return new ce(r);
          },
          Pe = (e, t, r) => {
            if ("\\" === t && e.match(/^\\Q(?:(?!\\E).)*(?:\\E)?/s))
              return new x(r);
          },
          Ne = (e, t, r) => {
            if ("[" === t && !r.inCharClass && e.match(/^\[\[:[<>]:]]/))
              return new Ee(r);
          },
          _e = (e, t, r) => {
            if (
              "[" === t &&
              e.match(/^\[:(?:(?!\[:[a-z]+:])(?:\\[\s\S]|[^\\\]]))*?\\?:]/)
            )
              return new v(r);
          },
          Te = (e, t, r) => {
            if ("[" === t && e.match(/^\[([.=])(?:\\[\s\S]|[^\]\\])*?\\?\1]/))
              return new ie.Z(r);
          },
          Ae = (e, t, r) => {
            if (r.inCharClass && e.eat("-")) return new me(r);
          },
          Ie = (e, t, r) => {
            if (
              !r.inCharClass &&
              "(" === t &&
              e.match(/^\(\?(?:[0R]|[+-]?[1-9]+\d*|P>\w+|&\w+)\)/)
            )
              return new O(r);
          },
          Re = (e, t, r) => {
            if (!r.inCharClass && "(" === t && e.match(/^\(\?P=(\w+)\)/))
              return new w.Z(r);
          },
          De = (e, t, r) => {
            let s;
            if (
              !r.inCharClass &&
              "(" === t &&
              (s = e.match(/^\(\*[A-Z\d_:]+(?:=\d+)?\)/))
            ) {
              const e = s[0];
              return (
                e.includes("UTF")
                  ? (r.unicodeEnabled = !0)
                  : e.includes("UCP") && (r.ucpVerb = !0),
                new _(r)
              );
            }
          },
          Le = (e, t, r) => {
            if (!r.inCharClass && "(" === t && e.match(/^\(\?C\d*\)/))
              return new ie.Z(r);
          },
          Me = (e, t, r) => {
            if (!r.inCharClass && e.match(/^(?:[*+?]|{\d+,?\d*})/))
              return new ye(r);
          },
          Ue = (e, t, r) => {
            if ("\\" === t && e.match(/^\\[pP]([CLMNPSZ]|{\^?(?:L&|\w+)}?)?/))
              return new pe(r);
          },
          Fe = (e, t, r) => {
            if (
              !r.inCharClass &&
              "\\" === t &&
              e.match(/^(?:\\g{\w+}|\\k(?:'\w+'|<\w+>|{\w+})?)/)
            )
              return new w.Z(r);
          },
          Ge = (e, t, r) => {
            if (
              !r.inCharClass &&
              "\\" === t &&
              e.match(/^\\g(?:<\w+>|'\w+'|'[+-]\d+'|<[+-]\d+>)?/)
            )
              return new O(r);
          },
          Ve = (e, t, r) => {
            if (
              "\\" === t &&
              e.match(/^\\x(?:{[0-9A-Fa-f]*}?|[0-9A-Fa-f]{0,2})/)
            )
              return new se.Z(r);
          },
          Be = (e, t, r) => {
            if ("\\" === t && e.match(/^\\o(?:{([0-7]+)}?)?/)) return new ae(r);
          },
          qe = (e, t, r) => {
            let s;
            if ("\\" === t && (s = e.match(Se.i)))
              return /^\\[lu]/i.test(s[0]) ||
                ("\\N" === s[0].slice(0, 2) &&
                  (s[0].length > 2 || r.inCharClass))
                ? new ie.Z(r)
                : r.inCharClass
                ? "\\b" === s[0]
                  ? new re.Z(r)
                  : /^\\[trnfaedDhHpPsSvVwWN]/.test(s[0])
                  ? new te.Z(r)
                  : new be(r)
                : new te.Z(r);
          },
          He = (e) => (t, r, s) => {
            let n;
            if (!s.inCharClass && "(" === r && (n = t.match(e))) {
              const e = n[0],
                r = n[0].replace(/\w+/g, "");
              if ("(" === n[0])
                return s.flags.includes("n") ? new G.Z(s) : new T.Z(s);
              if ("(?:" === n[0]) return new G.Z(s);
              if ("(?>" === n[0]) return new A.Z(s);
              if ("(?|" === n[0]) return new ee(s);
              if ("(?<>" === r || "(?''" === r) return new M.Z(s);
              if (/^\(\?[\^a-z-]+:/i.test(n[0])) return new L.Z(s);
              if (
                "(?=" === r ||
                "(*pla:" === e ||
                "(*positive_lookahead:" === e
              )
                return new V.Z(s);
              if (
                "(?!" === r ||
                "(*nla:" === e ||
                "(*negative_lookahead:" === e
              )
                return new U.Z(s);
              if (
                "(?<=" === r ||
                "(*plb:" === e ||
                "(*positive_lookbehind:" === e
              )
                return new B.Z(s);
              if (
                "(?<!" === r ||
                "(*nlb:" === e ||
                "(*negative_lookbehind:" === e
              )
                return new F.Z(s);
              if (
                "(?*" === r ||
                "(*napla:" === e ||
                "(*non_atomic_positive_lookahead:" === e
              )
                return new $(s);
              if (
                "(?<*" === r ||
                "(*naplb:" === e ||
                "(*non_atomic_positive_lookbehind:" === e
              )
                return new Y(s);
              if ("(?" === r) {
                const e = t.match(
                  /^\((?:R(?:&\w+)?|R?\d+|[+-]?\d+|\w+|'\w+'|<\w+>)\)/
                );
                if (
                  e &&
                  "(DEFINE)" === e[0] &&
                  !s.subpatterns.includes("DEFINE")
                )
                  return new D(s);
                const r =
                  !e &&
                  !!t.match(
                    /^\((?:\?<?[=!]|\*(?:[pn]l[ab]|(?:positive|negative)_lookahead|(?:positive|negative)_lookbehind):)/,
                    !1
                  );
                return new we(s, r);
              }
              d.O7(new Error(`Unknown group structure '${r}'`));
            }
          },
          $e = [
            ke,
            Pe,
            Te,
            Ne,
            _e,
            Ze.iT,
            Ze.q1,
            Ae,
            Ie,
            Re,
            (0, Ze.UB)(2147483639),
            (e, t, r) => {
              let s;
              if ("\\" === t && (s = e.match(/^\\(\d{1,3})/))) {
                const t = parseInt(s[1], 10);
                if (
                  !r.inCharClass &&
                  t > 0 &&
                  "0" !== s[1].charAt(0) &&
                  ((t < 10 && 1 === s[1].length) || t <= r.captureGroupCount)
                )
                  return new C.Z(r);
                const n = s[1].match(/^[0-7]{1,3}/);
                let a = 0;
                return n
                  ? ((a = s[1].length - n[0].length),
                    a > 0 && e.backUp(a),
                    new E.Z(r))
                  : (s[0].length > 2 && e.backUp(s[0].length - 2), new be(r));
              }
            },
            (e, t, r) => {
              if (!r.inCharClass && "(" === t && e.match(/^\(\?[mixXsUJ-]*\)/))
                return new Z.Z(r);
            },
            De,
            Ze.mw,
            Le,
            He(/^\((?:\?(?:[mixXsUJ-]*:|[>!=|]|<[=!]|'\w+'|P?<\w+>)?)?/),
            Ze.fF,
            Ze.MH,
            Me,
            Ue,
            (e, t, r) => {
              if (
                !r.inCharClass &&
                "\\" === t &&
                e.match(/^\\g(?:\d+|{-?\d+})/)
              )
                return new C.Z(r);
            },
            Fe,
            Ge,
            Ve,
            Be,
            Ze.oY,
            Ze.Nk,
            qe,
            (0, Ze.eb)(be),
            Ze.tP,
            Ze.k_,
            Ze.sN,
            Ze.NY,
          ];
        var ze = r(52011);
        const We = [
          ke,
          Pe,
          Te,
          Ne,
          _e,
          Ze.iT,
          Ze.q1,
          Ae,
          Ie,
          Re,
          (e, t, r) => {
            let s;
            if ("\\" === t && (s = e.match(/^\\(\d{1,3})/))) {
              const t = parseInt(s[1], 10);
              if (!r.inCharClass && t > 0 && "0" !== s[1].charAt(0)) {
                if ((t < 10 && 1 === s[1].length) || t <= r.captureGroupCount)
                  return new C.Z(r);
                if (/^\\[89]\d/.test(s[0]))
                  return e.backUp(s[0].length - 3), new C.Z(r);
              }
              const n = s[1].match(/^[0-7]{1,3}/);
              let a = 0;
              return n
                ? ((a = s[1].length - n[0].length),
                  a > 0 && e.backUp(a),
                  new E.Z(r))
                : (s[0].length > 2 && e.backUp(s[0].length - 2), new be(r));
            }
          },
          (e, t, r) => {
            if (
              !r.inCharClass &&
              "(" === t &&
              e.match(/^\(\?(?:\^[mixsUJn]*|[nmixsUJ-]*)\)/)
            )
              return new Z.Z(r);
          },
          De,
          Ze.mw,
          Le,
          He(
            /^\((?:\?(?:\^?[mixsUJn-]*:|[>!=|]|<[=!]|'\w+'|P?<\w+>|<?\*)?|\*(?:napl[ab]|[pn]l[ab]|(?:positive|negative)_lookahead|(?:positive|negative)_lookbehind|non_atomic_positive_(?:lookbehind|lookahead)):)?/
          ),
          Ze.fF,
          Ze.MH,
          Me,
          Ue,
          (e, t, r) => {
            if (
              !r.inCharClass &&
              "\\" === t &&
              e.match(/^\\g(?:\d+|{[+-]?\d+})/)
            )
              return new C.Z(r);
          },
          Fe,
          Ge,
          Ve,
          Be,
          (e, t, r) => {
            if ("\\" === t && e.match(/^\\c[\x20-\x7f]?/)) return new ze.Z(r);
          },
          Ze.Nk,
          qe,
          (0, Ze.eb)(be),
          Ze.tP,
          Ze.k_,
          Ze.sN,
          Ze.NY,
        ];
        var Ye = r(92880);
        const Ke = [
          "Ahom",
          "Anatolian_Hieroglyphs",
          "Arabic",
          "Armenian",
          "Avestan",
          "Balinese",
          "Bamum",
          "Bassa_Vah",
          "Batak",
          "Bengali",
          "Bopomofo",
          "Brahmi",
          "Braille",
          "Buginese",
          "Buhid",
          "Canadian_Aboriginal",
          "Carian",
          "Caucasian_Albanian",
          "Chakma",
          "Cham",
          "Cherokee",
          "Common",
          "Coptic",
          "Cuneiform",
          "Cypriot",
          "Cyrillic",
          "Deseret",
          "Devanagari",
          "Duployan",
          "Egyptian_Hieroglyphs",
          "Elbasan",
          "Ethiopic",
          "Georgian",
          "Glagolitic",
          "Gothic",
          "Grantha",
          "Greek",
          "Gujarati",
          "Gurmukhi",
          "Han",
          "Hangul",
          "Hanunoo",
          "Hatran",
          "Hebrew",
          "Hiragana",
          "Imperial_Aramaic",
          "Inherited",
          "Inscriptional_Pahlavi",
          "Inscriptional_Parthian",
          "Javanese",
          "Kaithi",
          "Kannada",
          "Katakana",
          "Kayah_Li",
          "Kharoshthi",
          "Khmer",
          "Khojki",
          "Khudawadi",
          "Lao",
          "Latin",
          "Lepcha",
          "Limbu",
          "Linear_A",
          "Linear_B",
          "Lisu",
          "Lycian",
          "Lydian",
          "Mahajani",
          "Malayalam",
          "Mandaic",
          "Manichaean",
          "Meetei_Mayek",
          "Mende_Kikakui",
          "Meroitic_Cursive",
          "Meroitic_Hieroglyphs",
          "Miao",
          "Modi",
          "Mongolian",
          "Mro",
          "Multani",
          "Myanmar",
          "Nabataean",
          "New_Tai_Lue",
          "Nko",
          "Ogham",
          "Ol_Chiki",
          "Old_Hungarian",
          "Old_Italic",
          "Old_North_Arabian",
          "Old_Permic",
          "Old_Persian",
          "Old_South_Arabian",
          "Old_Turkic",
          "Oriya",
          "Osmanya",
          "Pahawh_Hmong",
          "Palmyrene",
          "Pau_Cin_Hau",
          "Phags_Pa",
          "Phoenician",
          "Psalter_Pahlavi",
          "Rejang",
          "Runic",
          "Samaritan",
          "Saurashtra",
          "Sharada",
          "Shavian",
          "Siddham",
          "SignWriting",
          "Sinhala",
          "Sora_Sompeng",
          "Sundanese",
          "Syloti_Nagri",
          "Syriac",
          "Tagalog",
          "Tagbanwa",
          "Tai_Le",
          "Tai_Tham",
          "Tai_Viet",
          "Takri",
          "Tamil",
          "Telugu",
          "Thaana",
          "Thai",
          "Tibetan",
          "Tifinagh",
          "Tirhuta",
          "Ugaritic",
          "Vai",
          "Warang_Citi",
          "Yi",
          "C",
          "Cc",
          "Cf",
          "Co",
          "Cs",
          "L",
          "Ll",
          "Lm",
          "Lo",
          "Lt",
          "Lu",
          "M",
          "Mc",
          "Me",
          "Mn",
          "N",
          "Nd",
          "Nl",
          "No",
          "P",
          "Pc",
          "Pd",
          "Pe",
          "Pf",
          "Pi",
          "Po",
          "Ps",
          "S",
          "Sc",
          "Sk",
          "Sm",
          "So",
          "Z",
          "Zl",
          "Zp",
          "Zs",
        ];
        class Je extends le.Z {
          parseComplete() {
            le.Z.prototype.parseComplete.call(this),
              Ke.includes(this.script) || this.setError(g.xi);
          }
        }
        const Xe = Je;
        var Qe = r(32973),
          et = r(66476),
          tt = r(49116);
        class rt extends ve.Z {
          parseComplete() {
            ve.Z.prototype.parseComplete.call(this),
              (this.from > 1e3 || (this.to !== 1 / 0 && this.to > 1e3)) &&
                this.setError(g.Vt);
          }
        }
        const st = rt;
        class nt extends de.Z {
          _revalidate(e, t) {
            return null == e.charCode
              ? (this._convertToPlainText(), !1)
              : de.Z.prototype._revalidate.apply(this, arguments);
          }
        }
        const at = nt,
          it = (e, t, r) => {
            if ("\\" === t && e.match(/^\\x(?:[0-9A-Fa-f]{2}|{[0-9A-Fa-f]+}?)/))
              return new et.Z(r);
          },
          ot = [
            Pe,
            Ze.iT,
            Ze.q1,
            (e, t, r) => {
              if ("[" === t && e.match(/^\[:\^?([^:]*):]/)) return new v(r);
            },
            (e, t, r) => {
              if (r.inCharClass && e.eat("-")) return new at(r);
            },
            (e, t, r) => {
              if ("\\" === t && e.match(/^\\(?:[1-7][0-7]{1,2}|[0-7]{2,3})/))
                return new E.Z(r);
            },
            (e, t, r) => {
              if (
                !r.inCharClass &&
                "(" === t &&
                e.match(/^\(\?[imsU]*(?:-[imsU]+)?\)/)
              )
                return new Z.Z(r);
            },
            (e, t, r) => {
              let s;
              if (
                !r.inCharClass &&
                "(" === t &&
                (s = e.match(/^\((?:\?(?:[imsU-]*:|P<\w+>))?/))
              ) {
                const e = s[0].replace(/\w+/g, "");
                if ("(" === s[0]) return new T.Z(r);
                if ("(?:" === s[0]) return new G.Z(r);
                if ("(?|" === s[0]) return new ee(r);
                if ("(?<>" === e) return new M.Z(r);
                if (/^\(\?[imsU-]+:/.test(s[0])) return new L.Z(r);
                d.O7(new Error(`Unknown group structure '${e}'`));
              }
            },
            Ze.fF,
            Ze.MH,
            (e, t, r) => {
              if (!r.inCharClass && e.match(/^(?:[*+?]|{\d+,?\d*})/))
                return new st(r);
            },
            (e, t, r) => {
              if (
                "\\" === t &&
                e.match(
                  /^\\[pP](?:C[cfos]?|L[lmotu]?|M[cen]?|N[dlo]?|P[cdefios]?|S[ckmo]?|Z[lps]?|{\^?\w*}?)?/
                )
              )
                return new Xe(r);
            },
            it,
            Ze.Nk,
            (e, t, r) => {
              let s;
              if ("\\" === t && (s = e.match(/^\\[WwDdSspPABbzaftnrv]/)))
                return "\\v" === s[0]
                  ? new Qe.Z(r)
                  : r.inCharClass
                  ? /^\\[trnfaedDpPsSvwW]/.test(s[0])
                    ? new te.Z(r)
                    : new tt.Z(r)
                  : new te.Z(r);
            },
            (0, Ze.eb)(tt.Z),
            Ze.k_,
            Ze.sN,
            Ze.NY,
          ];
        var ct = r(50439);
        class lt extends C.Z {
          constructor(e) {
            super(e), e.inCharClass && this.setError(g.Oy);
          }
        }
        const ut = lt;
        var ht = r(54602),
          pt = r(68120),
          dt = r(4727),
          gt = r(65315),
          mt = r(25287);
        const ft = [
            "LD",
            "Lower",
            "Upper",
            "ASCII",
            "Alpha",
            "Digit",
            "Alnum",
            "Punct",
            "Graph",
            "Print",
            "Blank",
            "Cntrl",
            "XDigit",
            "Space",
            "javaLowerCase",
            "javaUpperCase",
            "javaAlphabetic",
            "javaIdeographic",
            "javaTitleCase",
            "javaDigit",
            "javaDefined",
            "javaLetter",
            "javaLetterOrDigit",
            "javaJavaIdentifierStart",
            "javaJavaIdentifierPart",
            "javaUnicodeIdentifierStart",
            "javaUnicodeIdentifierPart",
            "javaIdentifierIgnorable",
            "javaSpaceChar",
            "javaWhitespace",
            "javaISOControl",
            "javaMirrored",
            "IsAlphabetic",
            "IsIdeographic",
            "IsLetter",
            "IsLowercase",
            "IsUppercase",
            "IsTitlecase",
            "IsPunctuation",
            "IsControl",
            "IsWhite_Space",
            "IsDigit",
            "IsHex_Digit",
            "IsNoncharacter_Code_Point",
            "IsAssigned",
          ],
          xt = [
            "Mc",
            "Pc",
            "Cc",
            "Sc",
            "Pd",
            "Nd",
            "L",
            "S",
            "Me",
            "Pe",
            "Pf",
            "Cf",
            "Pi",
            "Nl",
            "Zl",
            "Ll",
            "Sm",
            "Lm",
            "Sk",
            "Mn",
            "Lo",
            "No",
            "Po",
            "So",
            "Zp",
            "Co",
            "Zs",
            "Ps",
            "Cs",
            "Lt",
            "Cn",
            "Lu",
          ],
          bt = [
            "Arabic",
            "Armenian",
            "Avestan",
            "Balinese",
            "Bamum",
            "Batak",
            "Bengali",
            "Bopomofo",
            "Brahmi",
            "Braille",
            "Buginese",
            "Buhid",
            "Canadian_Aboriginal",
            "Carian",
            "Cham",
            "Cherokee",
            "Common",
            "Coptic",
            "Cuneiform",
            "Cypriot",
            "Cyrillic",
            "Deseret",
            "Devanagari",
            "Egyptian_Hieroglyphs",
            "Ethiopic",
            "Georgian",
            "Glagolitic",
            "Gothic",
            "Greek",
            "Gujarati",
            "Gurmukhi",
            "Han",
            "Hangul",
            "Hanunoo",
            "Hebrew",
            "Hiragana",
            "Imperial_Aramaic",
            "Inherited",
            "Inscriptional_Pahlavi",
            "Inscriptional_Parthian",
            "Javanese",
            "Kaithi",
            "Kannada",
            "Katakana",
            "Kayah_Li",
            "Kharoshthi",
            "Khmer",
            "Lao",
            "Latin",
            "Lepcha",
            "Limbu",
            "Linear_B",
            "Lisu",
            "Lycian",
            "Lydian",
            "Malayalam",
            "Mandaic",
            "Meetei_Mayek",
            "Mongolian",
            "Myanmar",
            "New_Tai_Lue",
            "Nko",
            "Ogham",
            "Ol_Chiki",
            "Old_Italic",
            "Old_Persian",
            "Old_South_Arabian",
            "Old_Turkic",
            "Oriya",
            "Osmanya",
            "Phags_Pa",
            "Phoenician",
            "Rejang",
            "Runic",
            "Samaritan",
            "Saurashtra",
            "Shavian",
            "Sinhala",
            "Sundanese",
            "Syloti_Nagri",
            "Syriac",
            "Tagalog",
            "Tagbanwa",
            "Tai_Le",
            "Tai_Tham",
            "Tai_Viet",
            "Tamil",
            "Telugu",
            "Thaana",
            "Thai",
            "Tibetan",
            "Tifinagh",
            "Ugaritic",
            "Unknown",
            "Vai",
            "Yi",
          ],
          vt = [
            "Aegean_Numbers",
            "Alchemical_Symbols",
            "Alphabetic_Presentation_Forms",
            "Ancient_Greek_Musical_Notation",
            "Ancient_Greek_Numbers",
            "Ancient_Symbols",
            "Arabic",
            "Arabic_Presentation_Forms_A",
            "Arabic_Presentation_Forms_B",
            "Arabic_Supplement",
            "Armenian",
            "Arrows",
            "Avestan",
            "Balinese",
            "Bamum",
            "Bamum_Supplement",
            "Basic_Latin",
            "Batak",
            "Bengali",
            "Block_Elements",
            "Bopomofo",
            "Bopomofo_Extended",
            "Box_Drawing",
            "Brahmi",
            "Braille_Patterns",
            "Buginese",
            "Buhid",
            "Byzantine_Musical_Symbols",
            "Carian",
            "Cham",
            "Cherokee",
            "CJK_Compatibility",
            "CJK_Compatibility_Forms",
            "CJK_Compatibility_Ideographs",
            "CJK_Compatibility_Ideographs_Supplement",
            "CJK_Radicals_Supplement",
            "CJK_Strokes",
            "CJK_Symbols_and_Punctuation",
            "CJK_Unified_Ideographs",
            "CJK_Unified_Ideographs_Extension_A",
            "CJK_Unified_Ideographs_Extension_B",
            "CJK_Unified_Ideographs_Extension_C",
            "CJK_Unified_Ideographs_Extension_D",
            "Combining_Diacritical_Marks",
            "Combining_Diacritical_Marks_Supplement",
            "Combining_Half_Marks",
            "Common_Indic_Number_Forms",
            "Control_Pictures",
            "Coptic",
            "Counting_Rod_Numerals",
            "Cuneiform",
            "Cuneiform_Numbers_and_Punctuation",
            "Currency_Symbols",
            "Cypriot_Syllabary",
            "Cyrillic",
            "Cyrillic_Extended_A",
            "Cyrillic_Extended_B",
            "Cyrillic_Supplementary",
            "Deseret",
            "Devanagari",
            "Devanagari_Extended",
            "Dingbats",
            "Domino_Tiles",
            "Egyptian_Hieroglyphs",
            "Emoticons",
            "Enclosed_Alphanumeric_Supplement",
            "Enclosed_Alphanumerics",
            "Enclosed_CJK_Letters_and_Months",
            "Enclosed_Ideographic_Supplement",
            "Ethiopic",
            "Ethiopic_Extended",
            "Ethiopic_Extended_A",
            "Ethiopic_Supplement",
            "General_Punctuation",
            "Geometric_Shapes",
            "Georgian",
            "Georgian_Supplement",
            "Glagolitic",
            "Gothic",
            "Greek_Extended",
            "Gujarati",
            "Gurmukhi",
            "Halfwidth_and_Fullwidth_Forms",
            "Hangul_Compatibility_Jamo",
            "Hangul_Jamo",
            "Hangul_Jamo_Extended_A",
            "Hangul_Jamo_Extended_B",
            "Hangul_Syllables",
            "Hanunoo",
            "Hebrew",
            "High_Private_Use_Surrogates",
            "High_Surrogates",
            "Hiragana",
            "Ideographic_Description_Characters",
            "Imperial_Aramaic",
            "Inscriptional_Pahlavi",
            "Inscriptional_Parthian",
            "IPA_Extensions",
            "Javanese",
            "Kaithi",
            "Kana_Supplement",
            "Kanbun",
            "Kangxi_Radicals",
            "Kannada",
            "Katakana",
            "Katakana_Phonetic_Extensions",
            "Kayah_Li",
            "Kharoshthi",
            "Khmer",
            "Khmer_Symbols",
            "Lao",
            "Latin-1_Supplement",
            "Latin_Extended_A",
            "Latin_Extended_Additional",
            "Latin_Extended_B",
            "Latin_Extended_C",
            "Latin_Extended_D",
            "Lepcha",
            "Letterlike_Symbols",
            "Limbu",
            "Linear_B_Ideograms",
            "Linear_B_Syllabary",
            "Lisu",
            "Low_Surrogates",
            "Lycian",
            "Lydian",
            "Mahjong_Tiles",
            "Malayalam",
            "Mandaic",
            "Mathematical_Alphanumeric_Symbols",
            "Mathematical_Operators",
            "Meetei_Mayek",
            "Miscellaneous_Mathematical_Symbols_A",
            "Miscellaneous_Mathematical_Symbols_B",
            "Miscellaneous_Symbols",
            "Miscellaneous_Symbols_and_Arrows",
            "Miscellaneous_Symbols_And_Pictographs",
            "Miscellaneous_Technical",
            "Modifier_Tone_Letters",
            "Mongolian",
            "Musical_Symbols",
            "Myanmar",
            "Myanmar_Extended_A",
            "New_Tai_Lue",
            "NKo",
            "Number_Forms",
            "Ogham",
            "Ol_Chiki",
            "Old_Italic",
            "Old_Persian",
            "Old_South_Arabian",
            "Old_Turkic",
            "Optical_Character_Recognition",
            "Oriya",
            "Osmanya",
            "Phags-pa",
            "Phaistos_Disc",
            "Phoenician",
            "Phonetic_Extensions",
            "Phonetic_Extensions_Supplement",
            "Playing_Cards",
            "Private_Use_Area",
            "Rejang",
            "Rumi_Numeral_Symbols",
            "Runic",
            "Samaritan",
            "Saurashtra",
            "Shavian",
            "Sinhala",
            "Small_Form_Variants",
            "Spacing_Modifier_Letters",
            "Specials",
            "Sundanese",
            "Superscripts_and_Subscripts",
            "Supplemental_Arrows_A",
            "Supplemental_Arrows_B",
            "Supplemental_Mathematical_Operators",
            "Supplemental_Punctuation",
            "Supplementary_Private_Use_Area_A",
            "Supplementary_Private_Use_Area_B",
            "Syloti_Nagri",
            "Syriac",
            "Tagalog",
            "Tagbanwa",
            "Tags",
            "Tai_Le",
            "Tai_Tham",
            "Tai_Viet",
            "Tai_Xuan_Jing_Symbols",
            "Tamil",
            "Telugu",
            "Thaana",
            "Thai",
            "Tibetan",
            "Tifinagh",
            "Transport_And_Map_Symbols",
            "Ugaritic",
            "Unified_Canadian_Aboriginal_Syllabics",
            "Unified_Canadian_Aboriginal_Syllabics_Extended",
            "Vai",
            "Variation_Selectors",
            "Variation_Selectors_Supplement",
            "Vedic_Extensions",
            "Vertical_Forms",
            "Yi_Radicals",
            "Yi_Syllables",
            "Yijing_Hexagram_Symbols",
          ];
        class jt extends le.Z {
          parseComplete() {
            le.Z.prototype.parseComplete.call(this);
            const e =
                this.script.match(/^(?:(\w+)=(\w+)|(I[ns])(\w+)|()(\w+))$/) ||
                [],
              t = (0, s.Z)(e, 7),
              r = t[1],
              n = t[2],
              a = t[3],
              i = t[4],
              o = t[5],
              c = t[6],
              l = r || a || o,
              u = n || i || c;
            let h = !1;
            "Is" === l
              ? (h = xt.includes(u) || bt.includes(u) || ft.includes(l + u))
              : "In" === l || "blk" === l || "block" === l
              ? (h = vt.includes(u))
              : "script" === l || "sc" === l
              ? (h = bt.includes(u))
              : "general_category" === l || "gc" === l
              ? (h = xt.includes(u))
              : l || (h = ft.includes(u) || xt.includes(u)),
              (this.category = l),
              (this.script = u),
              h || this.setError(g.xi);
          }
        }
        const yt = jt;
        class Ot extends u.Z {
          constructor(e) {
            super(e, o.zB),
              (this.leftToken = null),
              (this.rightToken = null),
              this.setStyle(m.Z.meta),
              (this.quantifiable = !1),
              (this.length = 1);
          }
          _getNextState(e) {
            return e.charClassModifiers.push(this), e;
          }
          getTooltipMarkerRange() {
            const e = u.Z.prototype.getTooltipMarkerRange.call(this);
            if (!this.error && null != this.parent) {
              const t = this.parent.getTooltipMarkerRange().primary;
              e.secondary = t;
            }
            return e;
          }
          parseComplete() {
            this.parent.charClassIntersection = !0;
          }
          _revalidate(e, t) {
            return (
              (e &&
                t &&
                e.type !== o.HI &&
                e.type !== o.zB &&
                t.type !== o.U6 &&
                t.type !== o.zB) ||
                this.setError(g.jz),
              !!this.error
            );
          }
        }
        const wt = Ot;
        class Ct extends E.Z {
          parseComplete() {
            E.Z.prototype.parseComplete.call(this),
              "\\0" === this.string && this.setError(g.mi);
          }
        }
        const Et = Ct,
          Zt = class extends ye {
            parseComplete() {
              "{" === this.string.charAt(0) && "}" !== this.string.slice(-1)
                ? this.setError(g.YY)
                : ye.prototype.parseComplete.call(this);
            }
          };
        var St = r(24051);
        class kt extends St.Z {
          _getNextState(e) {
            return (
              this.state.flags.includes("x") &&
                /[ \t\r\n\f]/.test(this.string) &&
                ((e.previousToken = this.state.previousToken),
                (this.ignoreOnHover = !0)),
              e
            );
          }
        }
        const Pt = kt;
        class Nt extends w.Z {
          parseComplete() {
            w.Z.prototype.parseComplete.call(this),
              this.state.subpatterns.includes(this.reference) ||
                this.setError(g.sb);
          }
        }
        const _t = Nt,
          Tt = [
            Pe,
            (e, t, r) => {
              if ("[" === t && e.match(/^\[\^?/)) return new gt.Z(r);
            },
            (e, t, r) => {
              if (r.inCharClass && e.matchString("&&")) return new wt(r);
            },
            Ze.q1,
            Ae,
            (e, t, r) => {
              if ("\\" === t && e.match(/^\\0(?:[0-3]?[0-7]{1,2})?/))
                return new Et(r);
            },
            (e, t, r) => {
              if ("\\" === t) {
                const t = e.match(/^\\[1-9]\d*/);
                if (t) {
                  let s = parseInt(t[0].slice(1), 10);
                  for (; ("" + s).length > 0 && s > r.captureGroupCount; )
                    s = Math.floor(s / 10);
                  return e.backUp(t[0].length - ("\\" + s).length), new ut(r);
                }
              }
            },
            (e, t, r) => {
              if (!r.inCharClass && "(" === t && e.match(/^\(\?[misxu-]*\)/))
                return new Z.Z(r);
            },
            (e, t, r) => {
              let s;
              if (
                !r.inCharClass &&
                "(" === t &&
                (s = e.match(
                  /^\((?:\?(?:[misxu-]*:|[>!=]|<[=!]|<[a-zA-Z0-9]+>))?/
                ))
              ) {
                const e = s[0].replace(/\w+/g, "");
                if ("(" === s[0]) return new T.Z(r);
                if ("(?:" === s[0]) return new G.Z(r);
                if ("(?>" === s[0]) return new A.Z(r);
                if ("(?=" === e) return new V.Z(r, !1);
                if ("(?!" === e) return new U.Z(r, !1);
                if ("(?<>" === e) return new M.Z(r);
                if ("(?<=" === e) return new B.Z(r, !1);
                if ("(?<!" === e) return new F.Z(r, !1);
                if (/^\(\?[misxu-]+:/.test(s[0])) return new L.Z(r);
                d.O7(new Error(`Unknown group structure '${e}'`));
              }
            },
            Ze.fF,
            Ze.MH,
            (e, t, r) => {
              if (!r.inCharClass && e.match(/^(?:[*+?]|{\d+,?\d*}|{)/))
                return new Zt(r);
            },
            (e, t, r) => {
              if ("\\" === t && e.match(/^\\[Pp]{(?:\w+=)?\w*}?/))
                return new yt(r);
            },
            (e, t, r) => {
              if (!r.inCharClass && "\\" === t && e.match(/^\\k<\w+>/))
                return new _t(r);
            },
            it,
            (e, t, r) => {
              if ("\\" === t && e.match(Se.t)) return new dt.Z(r);
            },
            Ze.oY,
            Ze.Nk,
            (e, t, r) => {
              let s;
              if ("\\" === t && (s = e.match(/^\\[dDsSwWbBAGZztrnfaeRhHvV]/)))
                return r.inCharClass
                  ? /^\\[trnfaedDsSwWhHvV]/.test(s[0])
                    ? new te.Z(r)
                    : new mt.Z(r)
                  : new te.Z(r);
            },
            (e, t, r) => {
              if ("\\" === t && e.match(/^\\u[0-9A-Fa-f]{4}/))
                return new ht.Z(r);
            },
            (0, Ze.eb)(mt.Z),
            (e, t, r) => {
              if ("#" === t && r.flags.includes("x") && e.match(/^#.*/))
                return new pt.Z(r);
            },
            Ze.k_,
            Ze.sN,
            (e, t, r) => (e.next(), new Pt(r)),
          ];
        var At = r(15170),
          It = r(78172);
        function Rt(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Dt(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Rt(Object(r), !0).forEach(function (t) {
                  (0, n.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Rt(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        let Lt = !1,
          Mt = !1,
          Ut = !1;
        class Ft extends a.Z {
          constructor() {
            super(),
              (this.captureGroupCount = 0),
              (this.captureGroupMap = {}),
              (this.subpatterns = []),
              (this.alternatives = 0),
              (this.definedSubpatterns = []),
              (this._getTokenizers = (e) => {
                switch (e) {
                  case l().PCRE2:
                    return We;
                  case l().PCRE:
                    return $e;
                  case l().JAVASCRIPT:
                    return Ye.ZP;
                  case l().GOLANG:
                    return ot;
                  case l().PYTHON:
                    return ct.Z;
                  case l().JAVA:
                    return Tt;
                  case l().DOTNET:
                    return At.ZP;
                  default:
                    throw new Error(`There is no tokenizer for '${e}'`);
                }
              }),
              (this._initialState = {
                alternatives: 0,
                parents: [],
                previousToken: null,
                actualPreviousToken: null,
                lineTerminators: null,
                captureGroups: [],
                captureGroupCount: 0,
                captureGroupMap: {},
                subpatterns: [],
                definedSubpatterns: [],
                groups: [],
                conditionals: [],
                lookbehinds: [],
                lookbehindCount: 0,
                lookaroundCount: 0,
                inDEFINE: !1,
                inDuplicateSubpatternGroup: !1,
                inCharClass: !1,
                charClasses: [],
                ranges: [],
                charClassModifiers: [],
                condition: null,
                expectingCondition: !1,
                subpatternTokens: [],
                unicodeEnabled: !1,
                ucpVerb: !1,
              });
          }
          parseRegex(e, t, r) {
            const s = [];
            let n = t;
            const a = new i.Z(e);
            for (; !a.eof(); ) {
              const t = a.position,
                i = this._token(r.flavor, a, n),
                c = a.position;
              if (
                ((i.position = { start: t, end: c }),
                (i.string = e.slice(t, c)),
                i.parseComplete(),
                s.push(i),
                o.tK(i.type) && ")" !== i.string)
              ) {
                const e = new p(i.getNextState());
                s.push(e), (n = e.getNextState());
              } else n = i.getNextState();
            }
            return (
              (this.captureGroupCount = n.captureGroupCount),
              (this.captureGroupMap = n.captureGroupMap),
              (this.subpatterns = n.subpatterns),
              (this.alternatives = n.alternatives),
              (this.definedSubpatterns = n.definedSubpatterns),
              (this.captureGroups = n.captureGroups),
              [s, n]
            );
          }
          revalidate(e, t) {
            this._patternError = t.patternError;
            const r = [].concat(
              t.groups,
              t.charClasses,
              t.subpatternTokens,
              t.ranges,
              t.conditionals,
              t.lookbehinds,
              t.charClassModifiers
            );
            for (let s = 0, n = r.length; s < n; s++) {
              const n = r[s];
              let a = !1;
              if (n.type === o.jt) {
                const t = e.indexOf(n),
                  r = n.state.previousToken,
                  s = e[t + 1];
                a = n._revalidate(r, s);
              } else if (n.type === o.zB) {
                const t = e.indexOf(n),
                  r = e[t - 1],
                  s = e[t + 1];
                a = n._revalidate(r, s);
              } else a = n._revalidate(t);
              this._patternError = this._patternError || a;
            }
          }
          parse(e, t = {}) {
            let r = Dt(
              Dt(
                Dt({}, a.Z.copyState(this._initialState)),
                {},
                { flavor: l().PCRE2 },
                t
              ),
              {},
              {
                unicodeEnabled: this._checkUnicodeEnabled(t.flags, t.flavor),
                lineTerminators: (0, It.m)(t.flavor || l().PCRE2),
              }
            );
            const n = new p(r);
            r = n.getNextState();
            const i = this.parseRegex(e, r, t),
              o = (0, s.Z)(i, 2),
              c = o[0],
              u = o[1];
            return (
              this.revalidate(c, u), (this.tokens = [n, ...c]), this.tokens
            );
          }
          _checkUnicodeEnabled(e = "", t = l().PCRE2) {
            return (
              t === l().GOLANG ||
              t === l().DOTNET ||
              (t === l().JAVA && e.includes("U")) ||
              (t !== l().GOLANG && t !== l().JAVA && e.includes("u"))
            );
          }
        }
        const Gt = Ft;
        function Vt() {
          Lt = !0;
        }
        function Bt() {
          Mt = !0;
        }
        function qt() {
          Ut = !0;
        }
        function Ht() {
          return Lt;
        }
        function $t() {
          return Mt;
        }
        function zt() {
          return Ut;
        }
      },
      32774: (e, t, r) => {
        "use strict";
        r.d(t, { t: () => s, i: () => n });
        const s =
            /^\\u[dD](?:[89]|[ABab])[\dA-Fa-f]{2}\\u[dD][C-Fc-f][\dA-Fa-f]{2}/,
          n = /^\\(?:[WwDdSsVvHhaefntrXBbRKCGAZzQEckgPpuLlUo]|N(?:{\w*}?)?)/;
      },
      15170: (e, t, r) => {
        "use strict";
        r.d(t, { ZP: () => X, fR: () => J });
        var s = r(1277),
          n = r(86700),
          a = r(38645),
          i = r(99520),
          o = r(67664),
          c = r(53996),
          l = r(4458);
        class u extends c.Z {
          constructor(e) {
            super(e, s.WE), this.setStyle(l.Z.backreference);
          }
          _revalidate(e) {
            if (this.error) return;
            const t = parseInt(this.string.slice(1), 10);
            return (
              (this.reference = t),
              null == e.captureGroupMap[t] &&
                (/^\\[0-7]{2,3}$/.test(this.string)
                  ? ((this.type = s.Pg),
                    (this.charCode = parseInt(this.string.slice(1), 8) || 0))
                  : this.setError(o.Bj)),
              !!this.error
            );
          }
        }
        const h = u;
        var p = r(22028);
        const d = [
          "IsBasicLatin",
          "IsLatin-1Supplement",
          "IsLatinExtended-A",
          "IsLatinExtended-B",
          "IsIPAExtensions",
          "IsSpacingModifierLetters",
          "IsCombiningDiacriticalMarks",
          "IsGreek",
          "IsGreekandCoptic",
          "IsCyrillic",
          "IsCyrillicSupplement",
          "IsArmenian",
          "IsHebrew",
          "IsArabic",
          "IsSyriac",
          "IsThaana",
          "IsDevanagari",
          "IsBengali",
          "IsGurmukhi",
          "IsGujarati",
          "IsOriya",
          "IsTamil",
          "IsTelugu",
          "IsKannada",
          "IsMalayalam",
          "IsSinhala",
          "IsThai",
          "IsLao",
          "IsTibetan",
          "IsMyanmar",
          "IsGeorgian",
          "IsHangulJamo",
          "IsEthiopic",
          "IsCherokee",
          "IsUnifiedCanadianAboriginalSyllabics",
          "IsOgham",
          "IsRunic",
          "IsTagalog",
          "IsHanunoo",
          "IsBuhid",
          "IsTagbanwa",
          "IsKhmer",
          "IsMongolian",
          "IsLimbu",
          "IsTaiLe",
          "IsKhmerSymbols",
          "IsPhoneticExtensions",
          "IsLatinExtendedAdditional",
          "IsGreekExtended",
          "IsGeneralPunctuation",
          "IsSuperscriptsandSubscripts",
          "IsCurrencySymbols",
          "IsCombiningDiacriticalMarksforSymbols",
          "IsCombiningMarksforSymbols",
          "IsLetterlikeSymbols",
          "IsNumberForms",
          "IsArrows",
          "IsMathematicalOperators",
          "IsMiscellaneousTechnical",
          "IsControlPictures",
          "IsOpticalCharacterRecognition",
          "IsEnclosedAlphanumerics",
          "IsBoxDrawing",
          "IsBlockElements",
          "IsGeometricShapes",
          "IsMiscellaneousSymbols",
          "IsDingbats",
          "IsMiscellaneousMathematicalSymbols-A",
          "IsSupplementalArrows-A",
          "IsBraillePatterns",
          "IsSupplementalArrows-B",
          "IsMiscellaneousMathematicalSymbols-B",
          "IsSupplementalMathematicalOperators",
          "IsMiscellaneousSymbolsandArrows",
          "IsCJKRadicalsSupplement",
          "IsKangxiRadicals",
          "IsIdeographicDescriptionCharacters",
          "IsCJKSymbolsandPunctuation",
          "IsHiragana",
          "IsKatakana",
          "IsBopomofo",
          "IsHangulCompatibilityJamo",
          "IsKanbun",
          "IsBopomofoExtended",
          "IsKatakanaPhoneticExtensions",
          "IsEnclosedCJKLettersandMonths",
          "IsCJKCompatibility",
          "IsCJKUnifiedIdeographsExtensionA",
          "IsYijingHexagramSymbols",
          "IsCJKUnifiedIdeographs",
          "IsYiSyllables",
          "IsYiRadicals",
          "IsHangulSyllables",
          "IsHighSurrogates",
          "IsHighPrivateUseSurrogates",
          "IsLowSurrogates",
          "IsPrivateUse",
          "IsPrivateUseArea",
          "IsCJKCompatibilityIdeographs",
          "IsAlphabeticPresentationForms",
          "IsArabicPresentationForms-A",
          "IsVariationSelectors",
          "IsCombiningHalfMarks",
          "IsCJKCompatibilityForms",
          "IsSmallFormVariants",
          "IsArabicPresentationForms-B",
          "IsHalfwidthandFullwidthForms",
          "IsSpecials",
          "Lu",
          "Ll",
          "Lt",
          "Lm",
          "Lo",
          "L",
          "Mn",
          "Mc",
          "Me",
          "M",
          "Nd",
          "Nl",
          "No",
          "N",
          "Pc",
          "Pd",
          "Ps",
          "Pe",
          "Pi",
          "Pf",
          "Po",
          "P",
          "Sm",
          "Sc",
          "Sk",
          "So",
          "S",
          "Zs",
          "Zl",
          "Zp",
          "Z",
          "Cc",
          "Cf",
          "Cs",
          "Co",
          "Cn",
          "C",
        ];
        class g extends p.Z {
          parseComplete() {
            (this.script = this.string.slice(2).replace(/[^\w-]+/g, "")),
              this.string.endsWith("}")
                ? d.includes(this.script) || this.setError(o.xi)
                : this.setError(o.YY);
          }
        }
        const m = g;
        var f = r(54602),
          x = r(32973),
          b = r(78338),
          v = r(61923),
          j = r(53980),
          y = r(16770),
          O = r(93210),
          w = r(75262),
          C = r(29328),
          E = r(23550),
          Z = r(6975),
          S = r(23049),
          k = r(43276),
          P = r(64375),
          N = r(87263);
        class _ extends N.Z {
          constructor(e, t, r) {
            super(e, s.oK, !0),
              (this.expectCondition = !1),
              (this.condition = null),
              (this.implicitLookahead = !1),
              (this.lookaround = !1),
              (this.backreference = !1),
              (this.subroutine = !1),
              (this.reference = null),
              (this.expectCondition = r || null == t),
              (this.implicitLookahead = r),
              (this.backreference = null != t),
              (this.reference = t),
              (this.condition = t);
          }
          setCondition(e) {
            (this.lookaround = !0), (this.condition = e);
          }
          parseComplete() {
            N.Z.prototype.parseComplete.call(this);
          }
          _getNextState(e) {
            return (
              e.conditionals.push(this),
              (e.addImplicitLookahead = this.implicitLookahead),
              this.expectCondition && (e.expectingCondition = !0),
              N.Z.prototype._getNextState.call(this, e)
            );
          }
          _revalidate(e) {
            return (
              ((this.backreference || this.condition) && this.closeGroup) ||
                this.setError(o.CL),
              !!this.error
            );
          }
        }
        const T = _;
        class A extends E.Z {
          _getNextState(e) {
            return (
              (e.addImplicitLookahead = !1),
              E.Z.prototype._getNextState.call(this, e)
            );
          }
        }
        const I = A;
        var R = r(41026),
          D = r(53467);
        class L extends D.Z {
          parseComplete() {
            D.Z.prototype.parseComplete.call(this),
              (this.from > 2147483647 ||
                (this.to !== 1 / 0 && this.to > 2147483647)) &&
                this.setError(o.Vt);
          }
        }
        const M = L;
        var U = r(98152);
        class F extends w.Z {
          constructor(e) {
            super(e, s.sr), (this.balancedGroup = null);
          }
          parseComplete() {
            const e = this.string.slice(3, -1).split("-"),
              t = (0, U.Z)(e, 2),
              r = t[0],
              s = t[1];
            (this.subpattern = r),
              (this.balancedGroup = s),
              w.Z.prototype.parseComplete.call(this);
          }
          _getNextState(e) {
            return (
              e.subpatternTokens.push(this),
              w.Z.prototype._getNextState.call(this, e)
            );
          }
          _revalidate(e) {
            return (
              null == e.captureGroupMap[this.balancedGroup] &&
                this.setError(o.Bj),
              null == this.closeGroup && this.setError(o.CL),
              !!this.error
            );
          }
        }
        const G = F;
        class V extends N.Z {
          constructor(e) {
            super(e, s.ET, !0), (this.balancedGroup = null);
          }
          parseComplete() {
            const e = this.string.slice(3, -1).split("-"),
              t = (0, U.Z)(e, 2)[1];
            (this.balancedGroup = t), N.Z.prototype.parseComplete.call(this);
          }
          _getNextState(e) {
            return (
              e.subpatternTokens.push(this),
              N.Z.prototype._getNextState.call(this, e)
            );
          }
          _revalidate(e) {
            return (
              null == e.captureGroupMap[this.balancedGroup] &&
                this.setError(o.Bj),
              null == this.closeGroup && this.setError(o.CL),
              !!this.error
            );
          }
        }
        const B = V;
        var q = r(43307);
        class H extends q.Z {
          constructor(e) {
            super(e, s.Ao),
              (this.leftToken = null),
              (this.rightToken = null),
              this.setStyle(l.Z.meta),
              (this.quantifiable = !1),
              (this.length = 1);
          }
          _getNextState(e) {
            return e.charClassModifiers.push(this), e;
          }
          getTooltipMarkerRange() {
            const e = q.Z.prototype.getTooltipMarkerRange.call(this);
            if (!this.error && null != this.parent) {
              const t = this.parent.getTooltipMarkerRange().primary;
              e.secondary = t;
            }
            return e;
          }
          parseComplete() {
            this.parent.charClassSubtraction = !0;
          }
          _revalidate() {
            const e = this.parent.children;
            return (
              e.indexOf(this) !== e.length - 3 && this.setError(o.bb),
              !!this.error
            );
          }
        }
        const $ = H;
        var z = r(50439),
          W = r(4844),
          Y = r(65315),
          K = r(51402);
        const J = (e, t, r) => {
            if ("\\" === t && e.match(/^\\u[0-9A-Fa-f]{4}/)) return new f.Z(r);
          },
          X = [
            (e, t, r) => {
              if (r.addImplicitLookahead && e.matchString("("))
                return new I(r, !0);
            },
            (e, t, r) => {
              if (
                (!r.inCharClass || r.previousToken.type === s.Ao) &&
                "[" === t &&
                e.match(/^\[\^?/)
              )
                return new Y.Z(r);
            },
            (e, t, r) => {
              if (r.inCharClass && e.matchString("[::]")) return new P.Z(r);
            },
            K.q1,
            (e, t, r) => {
              if (
                r.inCharClass &&
                r.previousToken.type !== s.HI &&
                e.match(/^-(?=\[)/)
              )
                return new $(r);
            },
            K.VI,
            (e, t, r) => {
              if (!r.inCharClass && e.match(/^\\k?(?:<\w+>|'\w+')/))
                return new n.Z(r);
            },
            (e, t, r) => {
              let s;
              if ("\\" === t && (s = e.match(/^\\(\d+)/))) {
                if (!r.inCharClass && "0" !== s[1].charAt(0)) return new h(r);
                const t = s[1].match(/^[0-7]{2,3}/);
                let n = 0;
                return t
                  ? ((n = s[1].length - t[0].length),
                    n > 0 && e.backUp(n),
                    new a.Z(r))
                  : (s[0].length > 2 && e.backUp(s[0].length - 2), new R.Z(r));
              }
            },
            (e, t, r) => {
              if (
                !r.inCharClass &&
                "(" === t &&
                e.match(/^\(\?[imnsx]*(?:-[imnsx]+)?\)/)
              )
                return new i.Z(r);
            },
            K.mw,
            (e, t, r) => {
              let s;
              if (
                !r.inCharClass &&
                "(" === t &&
                (s = e.match(
                  /^\((?:\?(?:[imnsx-]*:|[>!=]|<[=!]|'\w+'|'\w*-\w+'|<\w+>|<\w*-\w+>)?)?/
                ))
              ) {
                const t = s[0];
                if ("(" === t)
                  return r.flags.includes("n") ? new j.Z(r) : new y.Z(r);
                if ("(?:" === t) return new j.Z(r);
                if ("(?>" === t) return new O.Z(r);
                if ("(?=" === t) return new E.Z(r);
                if ("(?!" === t) return new Z.Z(r);
                if ("(?<=" === t) return new S.Z(r);
                if ("(?<!" === t) return new k.Z(r);
                if (/^\(\?[a-z-]+:/i.test(t)) return new C.Z(r);
                if (t.startsWith("(?<-") || t.startsWith("(?'-"))
                  return new B(r);
                if (t.startsWith("(?<") || t.startsWith("(?'"))
                  return t.includes("-") ? new G(r) : new w.Z(r);
                if ("(?" === t) {
                  const t = e.match(/^\(\w+\)/);
                  if (t) {
                    const s = t[0].slice(1, -1);
                    return null != r.captureGroupMap[s]
                      ? new T(r, s, !1)
                      : (e.backUp(t[0].length), new T(r, null, !0));
                  }
                  return new T(r, null, !1);
                }
                W.O7(new Error(`Unknown group structure '${t}'`));
              }
            },
            K.fF,
            K.MH,
            (e, t, r) => {
              if (!r.inCharClass && e.match(/^(?:[*+?]|{\d+,?\d*})/))
                return new M(r);
            },
            (e, t, r) => {
              if ("\\" === t && e.match(/^\\[pP]{[-\w]+}?/)) return new m(r);
            },
            z.K,
            J,
            K.oY,
            K.Nk,
            (e, t, r) => {
              let s;
              if ("\\" === t && (s = e.match(/^\\[atrvfnewWsSdDAZzGbB]/)))
                return "\\v" === s[0]
                  ? new x.Z(r)
                  : r.inCharClass
                  ? "\\b" === s[0]
                    ? new v.Z(r)
                    : /^\\[atrvfnewWsSdD]/.test(s[0])
                    ? new b.Z(r)
                    : new R.Z(r)
                  : new b.Z(r);
            },
            (0, K.eb)(R.Z),
            K.tP,
            K.k_,
            K.sN,
            K.NY,
          ];
      },
      92880: (e, t, r) => {
        "use strict";
        r.d(t, { ZP: () => Q, FY: () => X });
        var s = r(4844),
          n = r(65315),
          a = r(4427),
          i = r(38645),
          o = r(16770),
          c = r(6975),
          l = r(23550),
          u = r(43276),
          h = r(23049),
          p = r(53980),
          d = r(75262),
          g = r(86700),
          m = r(78338),
          f = r(61923),
          x = r(32973),
          b = r(1277),
          v = r(43307),
          j = r(4458);
        class y extends v.Z {
          constructor(e) {
            super(e, b.jl),
              this.setStyle([j.Z.charclass, j.Z.meta]),
              (this.quantifiable = !0),
              (this.length = 1);
          }
        }
        const O = y;
        var w = r(54602),
          C = r(95165),
          E = r(24051),
          Z = r(4727),
          S = r(53996);
        class k extends S.Z {
          constructor(e, t = !1) {
            super(e, b.WE),
              this.setStyle(j.Z.backreference),
              (this.allowZeroRef = t);
          }
          _revalidate(e) {
            if (this.error) return;
            const t = this.string.replace(/\D/g, ""),
              r = parseInt(t, 10);
            return this.allowZeroRef && 0 === r
              ? ((this.reference = 0), !1)
              : (r > e.captureGroupCount &&
                  ((this.type = b.Pg),
                  (this.length = 1),
                  (this.quantifiable = !0),
                  (this.charCode = parseInt(t, 8) || 0),
                  this.setStyle(j.Z.meta)),
                (this.reference = r),
                !1);
          }
        }
        const P = k;
        var N = r(19099),
          _ = r(67664),
          T = r(72655);
        class A extends T.Z {
          _revalidate(e, t) {
            return this.state.unicodeEnabled &&
              this.type === b.jt &&
              t &&
              e.type !== b.HI &&
              t.type !== b.U6 &&
              ((e.type !== b.jt && null == e.charCode) ||
                (t.type !== b.jt && null == t.charCode))
              ? (this.setError(_.BC),
                T.Z.prototype._revalidate.apply(this, arguments))
              : !t || (null == t.charCode && t.type !== b.jt)
              ? void this._convertToPlainText()
              : T.Z.prototype._revalidate.apply(this, arguments);
          }
        }
        const I = A;
        var R = r(43949);
        class D extends v.Z {
          constructor(e) {
            super(e, b.zl), this.setError(_.IA);
          }
        }
        const L = D;
        var M = r(5786),
          U = r(98152),
          F = r(22028);
        const G = [
            "ASCII",
            "ASCII_Hex_Digit",
            "AHex",
            "Alphabetic",
            "Alpha",
            "Any",
            "Assigned",
            "Bidi_Control",
            "Bidi_C",
            "Bidi_Mirrored",
            "Bidi_M",
            "Case_Ignorable",
            "CI",
            "Cased",
            "Changes_When_Casefolded",
            "CWCF",
            "Changes_When_Casemapped",
            "CWCM",
            "Changes_When_Lowercased",
            "CWL",
            "Changes_When_NFKC_Casefolded",
            "CWKCF",
            "Changes_When_Titlecased",
            "CWT",
            "Changes_When_Uppercased",
            "CWU",
            "Dash",
            "Default_Ignorable_Code_Point",
            "DI",
            "Deprecated",
            "Dep",
            "Diacritic",
            "Dia",
            "Emoji",
            "Emoji_Component",
            "EComp",
            "Emoji_Modifier",
            "EMod",
            "Emoji_Modifier_Base",
            "EBase",
            "Emoji_Presentation",
            "EPres",
            "Extended_Pictographic",
            "ExtPict",
            "Extender",
            "Ext",
            "Grapheme_Base",
            "Gr_Base",
            "Grapheme_Extend",
            "Gr_Ext",
            "Hex_Digit",
            "Hex",
            "IDS_Binary_Operator",
            "IDSB",
            "IDS_Trinary_Operator",
            "IDST",
            "ID_Continue",
            "IDC",
            "ID_Start",
            "IDS",
            "Ideographic",
            "Ideo",
            "Join_Control",
            "Join_C",
            "Logical_Order_Exception",
            "LOE",
            "Lowercase",
            "Lower",
            "Math",
            "Noncharacter_Code_Point",
            "NChar",
            "Pattern_Syntax",
            "Pat_Syn",
            "Pattern_White_Space",
            "Pat_WS",
            "Quotation_Mark",
            "QMark",
            "Radical",
            "Regional_Indicator",
            "RI",
            "Sentence_Terminal",
            "STerm",
            "Soft_Dotted",
            "SD",
            "Terminal_Punctuation",
            "Term",
            "Unified_Ideograph",
            "UIdeo",
            "Uppercase",
            "Upper",
            "Variation_Selector",
            "VS",
            "White_Space",
            "space",
            "XID_Continue",
            "XIDC",
            "XID_Start",
            "XIDS",
          ],
          V = [
            "Cased_Letter",
            "LC",
            "Close_Punctuation",
            "Pe",
            "Connector_Punctuation",
            "Pc",
            "Control",
            "Cc",
            "cntrl",
            "Currency_Symbol",
            "Sc",
            "Dash_Punctuation",
            "Pd",
            "Decimal_Number",
            "Nd",
            "digit",
            "Enclosing_Mark",
            "Me",
            "Final_Punctuation",
            "Pf",
            "Format",
            "Cf",
            "Initial_Punctuation",
            "Pi",
            "Letter",
            "L",
            "Letter_Number",
            "Nl",
            "Line_Separator",
            "Zl",
            "Lowercase_Letter",
            "Ll",
            "Mark",
            "M",
            "Combining_Mark",
            "Math_Symbol",
            "Sm",
            "Modifier_Letter",
            "Lm",
            "Modifier_Symbol",
            "Sk",
            "Nonspacing_Mark",
            "Mn",
            "Number",
            "N",
            "Open_Punctuation",
            "Ps",
            "Other",
            "C",
            "Other_Letter",
            "Lo",
            "Other_Number",
            "No",
            "Other_Punctuation",
            "Po",
            "Other_Symbol",
            "So",
            "Paragraph_Separator",
            "Zp",
            "Private_Use",
            "Co",
            "Punctuation",
            "P",
            "punct",
            "Separator",
            "Z",
            "Space_Separator",
            "Zs",
            "Spacing_Mark",
            "Mc",
            "Surrogate",
            "Cs",
            "Symbol",
            "S",
            "Titlecase_Letter",
            "Lt",
            "Unassigned",
            "Cn",
            "Uppercase_Letter",
            "Lu",
          ],
          B = [
            "Adlam",
            "Adlm",
            "Ahom",
            "Anatolian_Hieroglyphs",
            "Hluw",
            "Arabic",
            "Arab",
            "Armenian",
            "Armn",
            "Avestan",
            "Avst",
            "Balinese",
            "Bali",
            "Bamum",
            "Bamu",
            "Bassa_Vah",
            "Bass",
            "Batak",
            "Batk",
            "Bengali",
            "Beng",
            "Bhaiksuki",
            "Bhks",
            "Bopomofo",
            "Bopo",
            "Brahmi",
            "Brah",
            "Braille",
            "Brai",
            "Buginese",
            "Bugi",
            "Buhid",
            "Buhd",
            "Canadian_Aboriginal",
            "Cans",
            "Carian",
            "Cari",
            "Caucasian_Albanian",
            "Aghb",
            "Chakma",
            "Cakm",
            "Cham",
            "Chorasmian",
            "Chrs",
            "Cherokee",
            "Cher",
            "Common",
            "Zyyy",
            "Coptic",
            "Copt",
            "Qaac",
            "Cuneiform",
            "Xsux",
            "Cypriot",
            "Cprt",
            "Cyrillic",
            "Cyrl",
            "Deseret",
            "Dsrt",
            "Devanagari",
            "Deva",
            "Dives_Akuru",
            "Diak",
            "Dogra",
            "Dogr",
            "Duployan",
            "Dupl",
            "Egyptian_Hieroglyphs",
            "Egyp",
            "Elbasan",
            "Elba",
            "Elymaic",
            "Elym",
            "Ethiopic",
            "Ethi",
            "Georgian",
            "Geor",
            "Glagolitic",
            "Glag",
            "Gothic",
            "Goth",
            "Grantha",
            "Gran",
            "Greek",
            "Grek",
            "Gujarati",
            "Gujr",
            "Gunjala_Gondi",
            "Gong",
            "Gurmukhi",
            "Guru",
            "Han",
            "Hani",
            "Hangul",
            "Hang",
            "Hanifi_Rohingya",
            "Rohg",
            "Hanunoo",
            "Hano",
            "Hatran",
            "Hatr",
            "Hebrew",
            "Hebr",
            "Hiragana",
            "Hira",
            "Imperial_Aramaic",
            "Armi",
            "Inherited",
            "Zinh",
            "Qaai",
            "Inscriptional_Pahlavi",
            "Phli",
            "Inscriptional_Parthian",
            "Prti",
            "Javanese",
            "Java",
            "Kaithi",
            "Kthi",
            "Kannada",
            "Knda",
            "Katakana",
            "Kana",
            "Kayah_Li",
            "Kali",
            "Kharoshthi",
            "Khar",
            "Khitan_Small_Script",
            "Kits",
            "Khmer",
            "Khmr",
            "Khojki",
            "Khoj",
            "Khudawadi",
            "Sind",
            "Lao",
            "Laoo",
            "Latin",
            "Latn",
            "Lepcha",
            "Lepc",
            "Limbu",
            "Limb",
            "Linear_A",
            "Lina",
            "Linear_B",
            "Linb",
            "Lisu",
            "Lycian",
            "Lyci",
            "Lydian",
            "Lydi",
            "Mahajani",
            "Mahj",
            "Makasar",
            "Maka",
            "Malayalam",
            "Mlym",
            "Mandaic",
            "Mand",
            "Manichaean",
            "Mani",
            "Marchen",
            "Marc",
            "Medefaidrin",
            "Medf",
            "Masaram_Gondi",
            "Gonm",
            "Meetei_Mayek",
            "Mtei",
            "Mende_Kikakui",
            "Mend",
            "Meroitic_Cursive",
            "Merc",
            "Meroitic_Hieroglyphs",
            "Mero",
            "Miao",
            "Plrd",
            "Modi",
            "Mongolian",
            "Mong",
            "Mro",
            "Mroo",
            "Multani",
            "Mult",
            "Myanmar",
            "Mymr",
            "Nabataean",
            "Nbat",
            "Nandinagari",
            "Nand",
            "New_Tai_Lue",
            "Talu",
            "Newa",
            "Nko",
            "Nkoo",
            "Nushu",
            "Nshu",
            "Nyiakeng_Puachue_Hmong",
            "Hmnp",
            "Ogham",
            "Ogam",
            "Ol_Chiki",
            "Olck",
            "Old_Hungarian",
            "Hung",
            "Old_Italic",
            "Ital",
            "Old_North_Arabian",
            "Narb",
            "Old_Permic",
            "Perm",
            "Old_Persian",
            "Xpeo",
            "Old_Sogdian",
            "Sogo",
            "Old_South_Arabian",
            "Sarb",
            "Old_Turkic",
            "Orkh",
            "Oriya",
            "Orya",
            "Osage",
            "Osge",
            "Osmanya",
            "Osma",
            "Pahawh_Hmong",
            "Hmng",
            "Palmyrene",
            "Palm",
            "Pau_Cin_Hau",
            "Pauc",
            "Phags_Pa",
            "Phag",
            "Phoenician",
            "Phnx",
            "Psalter_Pahlavi",
            "Phlp",
            "Rejang",
            "Rjng",
            "Runic",
            "Runr",
            "Samaritan",
            "Samr",
            "Saurashtra",
            "Saur",
            "Sharada",
            "Shrd",
            "Shavian",
            "Shaw",
            "Siddham",
            "Sidd",
            "SignWriting",
            "Sgnw",
            "Sinhala",
            "Sinh",
            "Sogdian",
            "Sogd",
            "Sora_Sompeng",
            "Sora",
            "Soyombo",
            "Soyo",
            "Sundanese",
            "Sund",
            "Syloti_Nagri",
            "Sylo",
            "Syriac",
            "Syrc",
            "Tagalog",
            "Tglg",
            "Tagbanwa",
            "Tagb",
            "Tai_Le",
            "Tale",
            "Tai_Tham",
            "Lana",
            "Tai_Viet",
            "Tavt",
            "Takri",
            "Takr",
            "Tamil",
            "Taml",
            "Tangut",
            "Tang",
            "Telugu",
            "Telu",
            "Thaana",
            "Thaa",
            "Thai",
            "Tibetan",
            "Tibt",
            "Tifinagh",
            "Tfng",
            "Tirhuta",
            "Tirh",
            "Ugaritic",
            "Ugar",
            "Vai",
            "Vaii",
            "Wancho",
            "Wcho",
            "Warang_Citi",
            "Wara",
            "Yezidi",
            "Yezi",
            "Yi",
            "Yiii",
            "Zanabazar_Square",
            "Zanb",
          ];
        class q extends F.Z {
          parseComplete() {
            F.Z.prototype.parseComplete.call(this);
            let e = this.script.split("="),
              t = (0, U.Z)(e, 2),
              r = t[0],
              s = t[1];
            null == s && ((s = r), (r = null)),
              (this.category = r),
              (this.script = s);
            let n = !0;
            switch (r) {
              case null:
                n = G.includes(s) || V.includes(s);
                break;
              case "gc":
              case "General_Category":
                n = V.includes(s);
                break;
              case "Script":
              case "sc":
              case "Script_Extensions":
              case "scx":
                n = B.includes(s);
                break;
              default:
                n = !1;
            }
            n || this.setError(_.xi);
          }
        }
        const H = q;
        var $ = r(52011);
        class z extends $.Z {
          parseComplete() {
            $.Z.prototype.parseComplete.call(this),
              /^[a-z]$/i.test(this.controlChar) || this.setError(_.Iu);
          }
        }
        const W = z;
        var Y = r(35425),
          K = r(32774),
          J = r(51402);
        const X = (e, t, r) => {
            if ("\\" === t && r.unicodeEnabled && e.match(K.t))
              return new Z.Z(r);
          },
          Q = [
            (e, t, r) => {
              if (!r.inCharClass && "[" === t && e.match(/^\[\^?/))
                return e.eat("]") ? new O(r) : new n.Z(r);
            },
            J.q1,
            (e, t, r) => {
              if (r.inCharClass && e.eat("-")) return new I(r);
            },
            (e, t, r) => {
              if (r.flags.includes("u") && "\\" === t)
                return !r.inCharClass && e.match(/^\\[1-9]\d*/)
                  ? new a.Z(r)
                  : e.match(/^\\0/)
                  ? new M.Z(r, !!e.match(/^\d+/))
                  : void 0;
              let s;
              if ("\\" === t && (s = e.match(/^\\(\d{1,3})/))) {
                const t = parseInt(s[1], 10);
                if (!r.inCharClass && t > 0) return new P(r);
                const n = s[1].match(/^(?:[0-3][0-7]{1,2}|[0-7]{1,2})/);
                let a = 0;
                return n
                  ? ((a = s[1].length - n[0].length),
                    a > 0 && e.backUp(a),
                    new i.Z(r))
                  : (s[0].length > 2 && e.backUp(s[0].length - 2), new R.Z(r));
              }
            },
            (e, t, r) => {
              if (
                (0, Y.x3)() &&
                "\\" === t &&
                !r.inCharClass &&
                e.match(/^\\k(?:<\w+>)?/)
              )
                return new g.Z(r);
            },
            (e, t, r) => {
              if (!r.inCharClass && "(" === t) {
                const t = new RegExp(
                    `^\\((?:\\?(?:${(0, Y.x3)() ? "<\\w+>|" : ""}[=!:]${
                      (0, Y.nn)() ? "|<[=!]" : ""
                    }))?`
                  ),
                  n = e.match(t);
                if (null != n) {
                  const e = n[0].replace(/\w+/g, "");
                  if ("(" === n[0]) return new o.Z(r);
                  if ("(?:" === n[0]) return new p.Z(r);
                  if ("(?=" === e) return new l.Z(r, !1);
                  if ("(?!" === e) return new c.Z(r, !1);
                  if ("(?<>" === e) return new d.Z(r);
                  if ((0, Y.nn)() && "(?<=" === e) return new h.Z(r, !1);
                  if ((0, Y.nn)() && "(?<!" === e) return new u.Z(r, !1);
                  s.O7(new Error(`Unknown group structure '${e}'`));
                }
              }
            },
            J.fF,
            J.MH,
            J.is,
            (e, t, r) => {
              if ("\\" === t) {
                const t = r.flags.includes("u")
                  ? /^\\x(?:[0-9A-Fa-f]{2})?/
                  : /^\\x[0-9A-Fa-f]{2}/;
                if (e.match(t)) return new N.Z(r);
              }
            },
            X,
            (e, t, r) => {
              if ("\\" === t) {
                const t = r.flags.includes("u")
                  ? /^\\u(?:[0-9A-Fa-f]{4}|{[^}]*}?)/
                  : /^\\u[0-9A-Fa-f]{4}/;
                if (e.match(t)) return new w.Z(r);
              }
            },
            (e, t, r) => {
              if (
                (0, Y.XG)() &&
                "\\" === t &&
                r.flags.includes("u") &&
                e.match(/^\\[pP](?:{[\w=]+}?)?/)
              )
                return new H(r);
            },
            (e, t, r) => {
              if ("\\" === t) {
                if (
                  e.match(/^\\c./) ||
                  (r.flags.includes("u") && e.match(/^\\c/))
                )
                  return new W(r);
                if (e.match(/^\\(?=c)/)) return new E.Z(r);
              }
            },
            J.Nk,
            (e, t, r) => {
              let s;
              if ("\\" === t && (s = e.match(/^\\[WwDdSsvfntrBb]/)))
                return "\\v" === s[0]
                  ? new x.Z(r)
                  : r.inCharClass
                  ? "\\b" === s[0]
                    ? new f.Z(r)
                    : /^\\[trnfaedDsSwW]/.test(s[0])
                    ? new m.Z(r)
                    : new R.Z(r)
                  : new m.Z(r);
            },
            (0, J.eb)(R.Z),
            J.k_,
            (e, t, r) => {
              if (!r.inCharClass && e.eat(r.delimiter)) return new C.Z(r);
            },
            (e, t, r) => {
              if (r.flags.includes("u") && "]{}".includes(t))
                return e.next(), new L(r);
            },
            J.NY,
          ];
      },
      50439: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => F, K: () => U });
        var s = r(4844),
          n = r(86700),
          a = r(67664),
          i = r(4427);
        class o extends i.Z {
          constructor(e) {
            super(e), e.inCharClass && this.setError(a.wW);
          }
        }
        const c = o;
        var l = r(38645),
          u = r(97027),
          h = r(16770),
          p = r(29328),
          d = r(75262),
          g = r(6975),
          m = r(43276),
          f = r(53980),
          x = r(23550),
          b = r(23049),
          v = r(78338),
          j = r(61923),
          y = r(32973),
          O = r(13511);
        class w extends O.Z {
          parseComplete() {
            O.Z.prototype.parseComplete.call(this),
              "\\x" === this.string && this.setError(a.YY);
          }
        }
        const C = w;
        var E = r(99520);
        class Z extends E.Z {
          parseComplete() {
            E.Z.prototype.parseComplete.call(this),
              0 !== this.position.start
                ? this.setError(a.M3)
                : this.flags.includes("u") &&
                  this.flags.includes("a") &&
                  this.setError(a.mB);
          }
        }
        const S = Z;
        var k = r(53467);
        class P extends k.Z {
          parseComplete() {
            k.Z.prototype.parseComplete.call(this),
              (this.from > 65535 || (this.to !== 1 / 0 && this.to > 65535)) &&
                this.setError(a.Vt);
          }
        }
        const N = P;
        var _ = r(1277),
          T = r(87263);
        class A extends T.Z {
          constructor(e) {
            super(e, _.oK, !0),
              (this.condition = null),
              (this.reference = null),
              (this.lookaround = !1),
              (this.backreference = !0),
              (this.subroutine = !1);
          }
          parseComplete() {
            T.Z.prototype.parseComplete.call(this),
              (this.condition = this.string.slice(3, -1));
          }
          _getNextState(e) {
            return (
              e.conditionals.push(this),
              T.Z.prototype._getNextState.call(this, e)
            );
          }
          _revalidate(e) {
            return this.condition && this.closeGroup
              ? ((this.reference = isNaN(this.condition)
                  ? this.condition
                  : parseInt(this.condition, 10)),
                e.captureGroupMap[this.condition] || this.setError(a.Bj),
                !!this.error)
              : (this.setError(a.CL), !0);
          }
        }
        const I = A;
        var R = r(54602);
        class D extends R.Z {
          parseComplete() {
            R.Z.prototype.parseComplete.call(this),
              parseInt(this.hex, 16) >= parseInt("0xd800", 16) &&
                parseInt(this.hex, 16) <= parseInt("0xdfff", 16) &&
                this.setError(a.oH);
          }
        }
        const L = D;
        var M = r(51402);
        const U = (e, t, r) => {
            if ("\\" === t && e.match(/^\\x(?:[0-9A-Fa-f]{2})?/))
              return new C(r);
          },
          F = [
            M.iT,
            M.q1,
            M.VI,
            (e, t, r) => {
              if (!r.inCharClass && "(" === t && e.match(/^\(\?P=\w+\)/))
                return new n.Z(r);
            },
            (0, M.UB)(2147483639),
            (e, t, r) => {
              if (
                "\\" === t &&
                (e.match(/^\\(?:0[0-7]?[0-7]?|[0-3][0-7]{2})/) ||
                  (r.inCharClass && e.match(/^\\[0-7][0-7]{0,2}/)))
              )
                return new l.Z(r);
            },
            (e, t, r) => {
              if ("\\" === t && e.match(/^\\\d{1,2}/)) return new c(r);
            },
            (e, t, r) => {
              if (!r.inCharClass && "(" === t && e.match(/^\(\?[imsuax-]*\)/))
                return new S(r);
            },
            M.mw,
            (e, t, r) => {
              let n;
              if (
                !r.inCharClass &&
                "(" === t &&
                (n = e.match(/^\((?:\?(?:<[!=]|[!=]|:|P<\w+>)?)?/))
              ) {
                const t = n[0].replace(/\w+/g, "");
                if ("(" === n[0]) return new h.Z(r);
                if ("(?:" === n[0]) return new f.Z(r);
                if ("(?<>" === t) return new d.Z(r);
                if (/^\(\?[imsuax-]+:/.test(n[0])) return new p.Z(r);
                if ("(?=" === t) return new x.Z(r);
                if ("(?!" === t) return new g.Z(r);
                if ("(?<=" === t) return new b.Z(r);
                if ("(?<!" === t) return new m.Z(r);
                if ("(?" === t) return e.match(/^\(\w+\)/), new I(r);
                s.O7(new Error(`Unknown group structure '${t}'`));
              }
            },
            M.fF,
            M.MH,
            (e, t, r) => {
              if (!r.inCharClass && e.match(/^(?:[*+?]|{(?:\d+,?\d*|,\d+)})/))
                return new N(r);
            },
            U,
            (e, t, r) => {
              if (
                "\\" === t &&
                e.match(/^\\(?:u[0-9a-fA-F]{4}|U[0-9a-fA-F]{8}|[uU])/)
              )
                return new L(r);
            },
            M.Nk,
            (e, t, r) => {
              let s;
              if ("\\" === t && (s = e.match(/^\\[WwDdSsvaefntrBbAZ]/)))
                return "\\v" === s[0]
                  ? new y.Z(r)
                  : r.inCharClass
                  ? "\\b" === s[0]
                    ? new j.Z(r)
                    : /^\\[trnfaedDsSvwW]/.test(s[0])
                    ? new v.Z(r)
                    : new u.Z(r)
                  : new v.Z(r);
            },
            (0, M.eb)(),
            M.tP,
            M.k_,
            M.sN,
            M.NY,
          ];
      },
      51402: (e, t, r) => {
        "use strict";
        r.d(t, {
          eb: () => q,
          UB: () => H,
          MH: () => R,
          VI: () => W,
          q1: () => z,
          fF: () => I,
          tP: () => L,
          oY: () => B,
          mw: () => M,
          Nk: () => V,
          iT: () => $,
          NY: () => G,
          is: () => D,
          k_: () => U,
          sN: () => F,
        });
        var s = r(4942),
          n = r(67664),
          a = r(1277),
          i = r(43307);
        function o(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function c(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? o(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : o(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        class l extends i.Z {
          constructor(e) {
            const t = e.groups[e.groups.length - 1],
              r = t ? t.type : null;
            e.parents.pop(),
              super(e, r),
              (this.openGroup = null),
              (this.groupNumber = null),
              (this.subpattern = null),
              (this.flags = null),
              t
                ? t.error
                  ? this.setError(t.error)
                  : (this.setStyle(t.style),
                    (this.openGroup = t),
                    t.setCloseGroup(this),
                    t.addRelatedToken(this))
                : this.setError(n.f0),
              null != t && (this.state.flags = t.previousFlags),
              null != this.openGroup &&
                ((this.groupNumber = this.openGroup.groupNumber),
                (this.subpattern = this.openGroup.subpattern));
          }
          getTooltipMarkerRange() {
            return {
              primary: {
                start: {
                  pos: (this.openGroup || this).editorPosition.start.pos,
                  line: (this.openGroup || this).editorPosition.start.line,
                },
                end: {
                  pos: this.editorPosition.end.pos,
                  line: this.editorPosition.end.line,
                },
              },
            };
          }
          getTooltipToken() {
            return this.openGroup || this;
          }
          _getNextState(e) {
            if (
              (e.parents.pop(),
              e.groups.pop(),
              this.error || (e.previousToken = this.openGroup),
              this.type === a.Ws)
            )
              e.inDEFINE = !1;
            else if (
              this.type === a.PG ||
              this.type === a.up ||
              this.type === a.fy
            )
              (e.lookbehindCount = this.openGroup.state.lookbehindCount),
                e.lookaroundCount--;
            else if (
              this.type === a.Gs ||
              this.type === a.Ty ||
              this.type === a.qh
            )
              e.lookbehindCount--, e.lookaroundCount--;
            else if (this.type === a.no) {
              this.openGroup.setBaseline(e);
              const t = this.parent.type === a.no;
              e = c(
                c(c({}, e), this.openGroup.getBaseline()),
                {},
                {
                  inDuplicateSubpatternGroup: t,
                  captureGroupCount: this.openGroup.finalCaptureGroupCount,
                }
              );
            }
            return e;
          }
        }
        const u = l;
        var h = r(4458);
        class p extends i.Z {
          constructor(e) {
            e.parents.pop(),
              super(e, a.hs),
              (this.alternativeNumber = null),
              this.setStyle(h.Z.alternator),
              this.parent && this.parent.addRelatedToken(this);
          }
        }
        const d = p,
          g = class extends d {
            constructor(e) {
              super(e), (this.alternativeNumber = e.alternatives + 1);
            }
            _getNextState(e) {
              return e.alternatives++, e.parents.push(this), e;
            }
          };
        function m(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function f(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? m(Object(r), !0).forEach(function (t) {
                  (0, s.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : m(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const x = class extends d {
          constructor(e) {
            super(e);
            const t = e.groups[e.groups.length - 1];
            t.addAlternative(),
              (this.alternativeNumber = t.alternatives),
              (t.type === a.Ws || (t.type === a.oK && t.alternatives > 1)) &&
                this.setError(n.cs),
              this.setStyle(t.style);
          }
          _getNextState(e) {
            e.parents.push(this);
            const t = this.state.groups[this.state.groups.length - 1];
            return (
              t &&
                t.type === a.no &&
                (t.setBaseline(e), (e = f(f({}, e), t.getBaseline()))),
              e
            );
          }
        };
        var b = r(53467),
          v = r(68120),
          j = r(1234),
          y = r(95165),
          O = r(24051);
        class w extends i.Z {
          constructor(e) {
            super(e, a.jf), this.setStyle(h.Z.comment);
          }
          getComment() {
            return this.string.slice(3, -1);
          }
          _getNextState(e) {
            return (e.previousToken = this.state.previousToken), e;
          }
        }
        const C = w;
        var E = r(78338),
          Z = r(97027),
          S = r(52011);
        class k extends i.Z {
          constructor(e) {
            super(e, a.MW),
              this.setStyle([h.Z.charclass, h.Z.meta]),
              this.setError(n.Jf);
          }
        }
        const P = k;
        var N = r(65315);
        class _ extends i.Z {
          constructor(e) {
            super(e, a.U6),
              (this.openCharClass = null),
              this.setStyle([h.Z.charclass, h.Z.meta]);
            const t = e.charClasses[e.charClasses.length - 1];
            t.addRelatedToken(this),
              (t.closeCharClass = this),
              (this.openCharClass = t),
              (this.quantifiable = !0),
              (this.length = 1);
          }
          getTooltipMarkerRange() {
            return {
              primary: {
                start: {
                  pos: (this.openCharClass || this).editorPosition.start.pos,
                  line: (this.openCharClass || this).editorPosition.start.line,
                },
                end: {
                  pos: this.editorPosition.end.pos,
                  line: this.editorPosition.end.line,
                },
              },
            };
          }
          getTooltipToken() {
            return this.openCharClass || this;
          }
          setQuantifier(e) {
            this.openCharClass
              ? this.openCharClass.setQuantifier(e)
              : (this.quantifier = e);
          }
          _getNextState(e) {
            return (
              e.charClasses.pop(),
              e.parents.pop(),
              (e.inCharClass = 0 !== e.charClasses.length),
              e
            );
          }
        }
        const T = _;
        var A = r(72655);
        const I = (e, t, r) => {
            if (!r.inCharClass && e.eat(")")) return new u(r);
          },
          R = (e, t, r) => {
            if (!r.inCharClass && e.eat("|"))
              return r.groups.length > 0 ? new x(r) : new g(r);
          },
          D = (e, t, r) => {
            if (!r.inCharClass && e.match(/^(?:[*+?]|{\d+,?\d*})/))
              return new b.Z(r);
          },
          L = (e, t, r) => {
            if (
              !r.inCharClass &&
              "#" === t &&
              r.flags.includes("x") &&
              "#" !== r.delimiter &&
              e.match(/^#.*/)
            )
              return new v.Z(r);
          },
          M = (e, t, r) => {
            if (
              !r.inCharClass &&
              "#" !== r.delimiter &&
              "(" === t &&
              e.match(/^\(\?#[^)]*\)/)
            )
              return new C(r);
          },
          U = (e, t, r) => {
            if ("\\" === t) return e.next(), new j.Z(r);
          },
          F = (e, t, r) => {
            if (e.matchString(r.delimiter)) return new y.Z(r);
          },
          G = (e, t, r) => (e.next(), new O.Z(r)),
          V = (e, t, r) => {
            if (!r.inCharClass && e.match(/^[$^.]/)) return new E.Z(r);
          },
          B = (e, t, r) => {
            if ("\\" === t && e.match(/^\\c.?/)) return new S.Z(r);
          },
          q =
            (e = Z.Z) =>
            (t, r, s) => {
              if ("\\" === r && t.position + 1 <= t.stringLength) {
                const r = t.position;
                return (
                  t.next(),
                  t.next(),
                  t.position === r + 1 ? (t.backUp(1), null) : new e(s)
                );
              }
            },
          H = (e) => (t, r, s) => {
            let n;
            if ("\\" === r && (n = t.match(/^\\\d+/))) {
              if (parseInt(n[0].slice(1), 10) > e) return new P(s);
              t.backUp(n[0].length);
            }
          },
          $ = (e, t, r) => {
            if (!r.inCharClass && "[" === t && e.match(/^\[\^?/))
              return new N.Z(r);
          },
          z = (e, t, r) => {
            if (r.inCharClass && e.eat("]"))
              return r.previousToken.type === a.HI ? new O.Z(r) : new T(r);
          },
          W = (e, t, r) => {
            if (r.inCharClass && e.eat("-")) return new A.Z(r);
          };
      },
      78172: (e, t, r) => {
        "use strict";
        r.d(t, { j: () => o, m: () => c });
        var s = r(98152),
          n = r(60370),
          a = r(81370),
          i = r.n(a);
        const o = (e, t, r = i().PCRE) => {
            let a = t.match(/^\^?([^-]*)-?(.*)/),
              o = (0, s.Z)(a, 3),
              c = o[1],
              l = o[2];
            if (r !== i().PCRE) {
              if (l.includes("-")) return [null, null, null];
              if (t.includes("^")) {
                const t = "imsnx".replace(new RegExp(`[${c}]`, "g"), "");
                l += e.replace(new RegExp(`[^${t}]`, "g"), "");
              }
            }
            l = l.replace(/-/g, "");
            const u = (0, n.Z)(e + c)
              .join("")
              .replace(new RegExp(`[${l}]`, "g"), "");
            return r === i().PCRE2
              ? [
                  c.includes("xx") || e.includes("xx")
                    ? u.replace("x", "xx")
                    : u,
                  (0, n.Z)(c.includes("xx") ? c.match(/xx|./g) : c),
                  (0, n.Z)(l.includes("xx") ? l.match(/xx|./g) : l),
                ]
              : [u, (0, n.Z)(c), (0, n.Z)(l)];
          },
          c = (e) => {
            switch (e) {
              case i().JAVA:
                return [
                  "\\r\\n",
                  "\\n",
                  "\\r",
                  "\\u2028",
                  "\\u2029",
                  "\\u0085",
                ];
              case i().PCRE2:
              case i().PYTHON:
              case i().GOLANG:
              case i().PCRE:
                return ["\\n"];
              case i().JAVASCRIPT:
                return ["\\n", "\\r", "\\u2028", "\\u2029"];
              case i().DOTNET:
                return ["\\n", "\\r"];
              default:
                throw new Error(`Unknown line terminator for ${e}`);
            }
          };
      },
      75659: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => a });
        var s = r(98152),
          n = r(23765);
        const a = class {
          constructor(e = "") {
            (this.position = 0),
              (this.string = null),
              (this.stringLength = 0),
              (this.string = e),
              (this.stringLength = this.string.length),
              (this.position = 0);
          }
          eof() {
            return this.position >= this.stringLength;
          }
          sof() {
            return 0 === this.position;
          }
          peek() {
            const e = this._getWholeCharAndI(this.string, this.position);
            return (0, s.Z)(e, 1)[0] || null;
          }
          next() {
            if (this.position < this.stringLength) {
              const e = this._getWholeCharAndI(this.string, this.position),
                t = (0, s.Z)(e, 2),
                r = t[0],
                n = t[1];
              return (this.position = n + 1), r;
            }
            return null;
          }
          eat(e) {
            const t = this._getWholeCharAndI(this.string, this.position),
              r = (0, s.Z)(t, 2),
              n = r[0],
              a = r[1];
            return n === e ? ((this.position = a + 1), n) : null;
          }
          eatWhile(e) {
            const t = this.position;
            for (; this.eat(e); );
            return this.position > t;
          }
          skipToEnd() {
            this.position = this.stringLength;
          }
          skipTo(e) {
            const t = this.string.indexOf(e, this.position);
            return t > -1 && ((this.position = t), !0);
          }
          backUp(e) {
            this.position -= e;
          }
          match(e, t = !0) {
            const r = this.string.slice(this.position).match(e);
            if (r && r.index > 0)
              throw new Error(
                `Regex match did not happen at the beginning of string ${e.toString()}`
              );
            return r && t && (this.position += r[0].length), r;
          }
          matchString(e = "", t = !0) {
            return (
              this.string.substr(this.position, e.length) === e &&
              (t && (this.position += e.length), !0)
            );
          }
          current() {
            return this.string.slice(0, this.position);
          }
          _getWholeCharAndI(e, t) {
            const r = e.charCodeAt(t);
            if (isNaN(r)) return [null, t];
            if (r < 55296 || r > 57343) return [e.charAt(t), t];
            if (55296 <= r && r <= 56319) {
              if (e.length <= t + 1)
                return (
                  n.Z.error("High surrogate without following low surrogate"),
                  [e.charAt(t), t]
                );
              const r = e.charCodeAt(t + 1);
              return 56320 > r || r > 57343
                ? (n.Z.error("High surrogate without following low surrogate"),
                  [e.charAt(t), t])
                : [e.charAt(t) + e.charAt(t + 1), t + 1];
            }
            if (0 === t)
              return (
                n.Z.error("Low surrogate without preceding high surrogate"),
                [e.charAt(t), t]
              );
            const s = e.charCodeAt(t - 1);
            return 55296 > s || s > 56319
              ? (n.Z.error("Low surrogate without preceding high surrogate"),
                [e.charAt(t), t])
              : [e.charAt(t + 1), t + 1];
          }
        };
      },
      93210: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(1277),
          n = r(87263);
        class a extends n.Z {
          constructor(e) {
            super(e, s.Jy, !0);
          }
        }
        const i = a;
      },
      61923: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => o });
        var s = r(1277),
          n = r(43307),
          a = r(4458);
        class i extends n.Z {
          constructor(e) {
            super(e, s.ZH),
              this.setStyle(a.Z.meta),
              (this.length = 1),
              (this.charCode = "\b".charCodeAt(0));
          }
        }
        const o = i;
      },
      16770: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(1277),
          n = r(87263);
        class a extends n.Z {
          constructor(e) {
            super(e, s.t, !0),
              (this.groupNumber = null),
              (this.groupNumber = e.captureGroupCount + 1);
          }
          _getNextState(e) {
            return (
              this.state.inDEFINE &&
                e.definedSubpatterns.push(this.state.captureGroupCount),
              e.captureGroupCount++,
              (e.captureGroupMap[e.captureGroupCount] = e.captureGroupCount),
              e.captureGroups.push(this),
              n.Z.prototype._getNextState.call(this, e)
            );
          }
        }
        const i = a;
      },
      72655: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => c });
        var s = r(1277),
          n = r(67664),
          a = r(43307),
          i = r(4458);
        class o extends a.Z {
          constructor(e) {
            super(e, s.jt),
              (this.leftToken = null),
              (this.rightToken = null),
              this.setStyle(i.Z.meta),
              (this.charCode = "-".charCodeAt(0));
          }
          getTooltipMarkerRange() {
            return this.type === s.zl
              ? super.getTooltipMarkerRange()
              : {
                  primary: {
                    start: {
                      pos: (this.leftToken || this).editorPosition.start.pos,
                      line: (this.leftToken || this).editorPosition.start.line,
                    },
                    end: {
                      pos: (this.rightToken || this).editorPosition.end.pos,
                      line: (this.rightToken || this).editorPosition.end.line,
                    },
                  },
                };
          }
          _getNextState(e) {
            return e.ranges.push(this), e;
          }
          _revalidate(e, t) {
            (this.leftToken = e), (this.rightToken = t);
            const r =
                (null == e ? void 0 : e.codePoint) ||
                (null == e ? void 0 : e.charCode),
              a =
                (null == t ? void 0 : t.codePoint) ||
                (null == t ? void 0 : t.charCode);
            return (
              !t ||
              t.type === s.U6 ||
              e.type === s.HI ||
              e.type === s.jt ||
              e.partOfRange ||
              t.partOfRange
                ? this._convertToPlainText()
                : null == r || null == a
                ? this.setError(n.BC)
                : r > a && this.setError(n.i0),
              !this.state.unicodeEnabled &&
                ((null != e &&
                  e.type === s.zl &&
                  e.charCode >= parseInt("0xd800", 16) &&
                  e.charCode <= parseInt("0xdfff", 16)) ||
                  (null != t &&
                    t.type === s.zl &&
                    t.charCode >= parseInt("0xd800", 16) &&
                    t.charCode <= parseInt("0xdfff", 16))) &&
                this.setError(n.Af),
              this.type !== s.zl &&
                (e.error || t.error
                  ? this.setError(n.Y4)
                  : ((e.rangeToken = t.rangeToken = this),
                    (e.partOfRange = !0),
                    (t.partOfRange = !0))),
              !!this.error
            );
          }
          _convertToPlainText() {
            var e, t;
            (this.type = s.zl),
              (this.length = 1),
              (this.isPoorlyPlaced =
                (null === (e = this.rightToken) || void 0 === e
                  ? void 0
                  : e.type) !== s.U6 &&
                (null === (t = this.leftToken) || void 0 === t
                  ? void 0
                  : t.type) !== s.HI),
              (this.leftToken = this.rightToken = void 0),
              this.setStyle(null);
          }
        }
        const c = o;
      },
      52011: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => c });
        var s = r(1277),
          n = r(67664),
          a = r(43307),
          i = r(4458);
        class o extends a.Z {
          constructor(e) {
            super(e, s.lA),
              (this.controlChar = null),
              this.setStyle(i.Z.meta),
              (this.quantifiable = !0),
              (this.length = 1);
          }
          parseComplete() {
            (this.controlChar = this.string.slice(2)),
              /^[\u0000-\u007F]$/.test(this.controlChar) || this.setError(n.Iu),
              this.controlChar &&
                (this.charCode =
                  64 ^ this.controlChar.toUpperCase().charCodeAt(0));
          }
        }
        const c = o;
      },
      41026: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(67664),
          n = r(97027);
        class a extends n.Z {
          constructor(e, t = !1) {
            super(e), (this._isSubstitution = null), (this._isSubstitution = t);
          }
          parseComplete() {
            n.Z.prototype.parseComplete.call(this),
              /^\\[!"#$%&'()*+,\-./:;<=>?@[\\\]^`{|}~]$/i.test(this.string) ||
                this.setError(s.mi);
          }
        }
        const i = a;
      },
      97027: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => u });
        var s = r(1277),
          n = r(67664),
          a = r(81370),
          i = r.n(a),
          o = r(43307),
          c = r(4458);
        class l extends o.Z {
          constructor(e) {
            super(e, s.t0),
              this.setStyle(c.Z.escaped_string),
              (this.quantifiable = !0),
              (this.length = 1);
          }
          parseComplete() {
            (this.charCode = this.string.charCodeAt(1)),
              (this.codePoint = this.string.codePointAt(1)),
              "\0" === this.string.slice(1) &&
                [i().PCRE, i().PCRE2, i().PYTHON].includes(this.state.flavor) &&
                this.setError(n.O3);
          }
        }
        const u = l;
      },
      49116: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(67664),
          n = r(97027);
        class a extends n.Z {
          constructor(e, t = !1) {
            super(e), (this._isSubstitution = null), (this._isSubstitution = t);
          }
          parseComplete() {
            n.Z.prototype.parseComplete.call(this),
              /^\\[!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]$/i.test(this.string)
                ? "\\`" === this.string
                  ? this.setError(s.Qc)
                  : this._isSubstitution &&
                    !/^\\[\\"]$/.test(this.string) &&
                    this.setError(s.mi)
                : this.setError(s.mi);
          }
        }
        const i = a;
      },
      66476: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(67664),
          n = r(13511);
        class a extends n.Z {
          constructor(e, t = !1) {
            super(e), (this._isSubstitution = null), (this._isSubstitution = t);
          }
          parseComplete() {
            this._setValues(),
              "{" === this.string.charAt(2) && "}" !== this.string.slice(-1)
                ? this.setError(s.YY)
                : parseInt(this.hex, 16) > parseInt("0xfffff", 16)
                ? (this.setError(s.y1), (this.charCode = null))
                : this._isSubstitution &&
                  !/^\\x..$/.test(this.string) &&
                  this.setError(s.YY);
          }
        }
        const i = a;
      },
      87263: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => o });
        var s = r(67664),
          n = r(43307),
          a = r(4458);
        class i extends n.Z {
          constructor(e, t, r = !1) {
            super(e, t),
              (this.alternatives = 0),
              (this.closeGroup = null),
              (this.previousFlags = null),
              this.setStyle(a.Z[`group-${Math.min(e.groups.length, 3)}`]),
              (this.quantifiable = !1),
              (this.willBeQuantifiable = r);
          }
          getTooltipMarkerRange() {
            return {
              primary: {
                start: {
                  pos: this.editorPosition.start.pos,
                  line: this.editorPosition.start.line,
                },
                end: {
                  pos: (this.closeGroup || this).editorPosition.end.pos,
                  line: (this.closeGroup || this).editorPosition.end.line,
                },
              },
            };
          }
          setCloseGroup(e) {
            (this.closeGroup = e),
              (this.closeGroup.quantifiable = this.quantifiable =
                this.willBeQuantifiable);
          }
          setQuantifier(e) {
            super.setQuantifier(e),
              this.closeGroup && this.closeGroup.setQuantifier(e);
          }
          parseComplete() {
            this.previousFlags = this.state.flags;
          }
          addAlternative() {
            this.alternatives++;
          }
          _getNextState(e) {
            return e.parents.push(this), e.groups.push(this), e;
          }
          _revalidate() {
            return this.setError(s.CL), !0;
          }
        }
        const o = i;
      },
      13511: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => c });
        var s = r(1277),
          n = r(67664),
          a = r(43307),
          i = r(4458);
        class o extends a.Z {
          constructor(e) {
            super(e, s.L3),
              (this.hex = null),
              this.setStyle(i.Z.meta),
              (this.quantifiable = !0),
              (this.length = 1);
          }
          parseComplete() {
            this._setValues(),
              "{" === this.string.charAt(2) && "}" !== this.string.slice(-1)
                ? this.setError(n.YY)
                : parseInt(this.hex, 16) > parseInt("0x10ffff", 16) &&
                  (this.setError(n.y1), (this.charCode = null));
          }
          _setValues() {
            (this.hex = this.string.slice(2).replace(/[{}]/g, "") || "00"),
              (this.charCode = parseInt(this.hex, 16));
          }
        }
        const c = o;
      },
      99520: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => p });
        var s = r(98152),
          n = r(1277),
          a = r(67664),
          i = r(78172),
          o = r(81370),
          c = r.n(o),
          l = r(43307),
          u = r(4458);
        class h extends l.Z {
          constructor(e) {
            super(e, n.RW),
              (this.flags = null),
              (this.onFlags = null),
              (this.offFlags = null),
              this.setStyle(u.Z.inline_modifiers);
          }
          parseComplete() {
            const e = (0, i.j)(
                this.state.flags,
                this.string.slice(2, -1),
                this.state.flavor
              ),
              t = (0, s.Z)(e, 3),
              r = t[0],
              n = t[1],
              o = t[2];
            if (null == r)
              return (this.flags = this.state.flags), void this.setError(a.Gz);
            (this.flags = r),
              (this.onFlags = n),
              (this.offFlags = o),
              "(?)" === this.string &&
                this.state.flavor !== c().PCRE &&
                this.state.flavor !== c().PCRE2 &&
                this.setError(a.YY);
          }
          _getNextState(e) {
            return (e.flags = this.flags), e;
          }
        }
        const p = h;
      },
      25287: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(67664),
          n = r(97027);
        class a extends n.Z {
          parseComplete() {
            n.Z.prototype.parseComplete.call(this),
              /^\\[a-z]$/i.test(this.string) && this.setError(s.mi);
          }
        }
        const i = a;
      },
      5786: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(67664),
          n = r(38645);
        class a extends n.Z {
          constructor(e, t = !1) {
            super(e), t && this.setError(s.mi);
          }
        }
        const i = a;
      },
      43949: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(67664),
          n = r(97027);
        class a extends n.Z {
          parseComplete() {
            n.Z.prototype.parseComplete.call(this),
              ((this.state.unicodeEnabled &&
                !/^\\[$()*+./?[\\\]^{|}]$/i.test(this.string)) ||
                (this.state.inCharClass && "\\k" === this.string)) &&
                this.setError(s.mi);
          }
        }
        const i = a;
      },
      19099: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(67664),
          n = r(13511);
        class a extends n.Z {
          parseComplete() {
            n.Z.prototype.parseComplete.call(this),
              ("\\x" === this.string ||
                (this.isSubstitution && !/^\\x..$/.test(this.string))) &&
                this.setError(s.YY);
          }
        }
        const i = a;
      },
      68120: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => o });
        var s = r(1277),
          n = r(43307),
          a = r(4458);
        class i extends n.Z {
          constructor(e) {
            super(e, s.qi), this.setStyle(a.Z.comment);
          }
          getComment() {
            return this.string.slice(1);
          }
          _getNextState(e) {
            return (
              (e.previousToken = this.state.previousToken),
              (e.actualPreviousToken = this.state.actualPreviousToken),
              e
            );
          }
        }
        const o = i;
      },
      85877: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => a });
        var s = r(36125);
        class n extends s.Z {
          _getNextState(e) {
            return (
              (e.lookbehindCount = 0), s.Z.prototype._getNextState.call(this, e)
            );
          }
        }
        const a = n;
      },
      36125: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => a });
        var s = r(87263);
        class n extends s.Z {
          constructor(e, t, r = !0) {
            super(e, t),
              (this.isCondition = null),
              (this.isCondition = !1),
              (this.willBeQuantifiable = r);
          }
          _getNextState(e) {
            return (
              this.state.expectingCondition &&
                (this.state.previousToken.setCondition(this),
                (e.expectingCondition = !1),
                (this.isCondition = !0),
                (this.willBeQuantifiable = !1),
                (this.quantifiable = !1)),
              e.lookaroundCount++,
              s.Z.prototype._getNextState.call(this, e)
            );
          }
        }
        const a = n;
      },
      50594: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => l });
        var s = r(1277),
          n = r(67664),
          a = r(81370),
          i = r.n(a),
          o = r(36125);
        class c extends o.Z {
          _getNextState(e) {
            return (
              e.lookbehinds.push(this),
              e.lookbehindCount++,
              o.Z.prototype._getNextState.call(this, e)
            );
          }
          _revalidate() {
            if (!this.closeGroup) return this.setError(n.CL), !0;
            if (
              this.state.flavor === i().JAVA ||
              this.state.flavor === i().JAVASCRIPT ||
              this.state.flavor === i().DOTNET
            )
              return !1;
            const e = { foundError: !1 };
            if (this.state.flavor === i().PYTHON)
              this._ensureFixedWidth(this.children, e);
            else
              for (let t = 0, r = this.children.length; t < r; t++)
                this._ensureFixedWidth(this.children[t].children, e);
            return e.foundError;
          }
          _ensureFixedWidth(e, t) {
            let r = null,
              a = 0;
            for (let i = 0, o = e.length; i < o; i++) {
              const o = e[i];
              if (o.type === s.hs) {
                const e = this._ensureFixedWidth(o.children, t);
                null == r
                  ? ((r = e), (a += e))
                  : r !== e && (o.parent.setError(n.eB), (t.foundError = !0));
              } else if ((0, s.tK)(o.type) && !(0, s.Az)(o.type)) {
                let r = this._ensureFixedWidth(o.children, t);
                const n = e[i + 1];
                n &&
                  n.type === s.Wj &&
                  ((r *= n.length), (i += n.quantifier ? 2 : 1)),
                  (a += r);
              } else a += o.length;
            }
            return a;
          }
        }
        const l = c;
      },
      78338: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => h });
        var s = r(1277),
          n = r(67664),
          a = r(81370),
          i = r.n(a),
          o = r(43307),
          c = r(4458);
        const l = /^(?:\\[zZbBAGK]|[$^])$/;
        class u extends o.Z {
          constructor(e) {
            super(e, s.MW), this.setStyle(c.Z.meta);
          }
          parseComplete() {
            switch (
              ((this.quantifiable = !l.test(this.string)),
              this.quantifier || l.test(this.string) || (this.length = 1),
              (this.state.flavor === i().PCRE2 ||
                this.state.flavor === i().PCRE) &&
                ((this.state.lookbehindCount > 0 &&
                  ("\\X" === this.string ||
                    "\\R" === this.string ||
                    ("\\C" === this.string && this.state.unicodeEnabled))) ||
                  (this.state.lookaroundCount > 0 && "\\K" === this.string)) &&
                this.setError(n.jV),
              this.string)
            ) {
              case "\\a":
                this.charCode = 7;
                break;
              case "\\b":
                this.charCode = 8;
                break;
              case "\\f":
                this.charCode = 12;
                break;
              case "\\n":
                this.charCode = 10;
                break;
              case "\\r":
                this.charCode = 13;
                break;
              case "\\t":
                this.charCode = 9;
                break;
              case "\\e":
                this.charCode = 27;
                break;
              default:
                this.charCode = null;
            }
          }
        }
        const h = u;
      },
      29328: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => l });
        var s = r(98152),
          n = r(1277),
          a = r(78172),
          i = r(67664),
          o = r(87263);
        class c extends o.Z {
          constructor(e) {
            super(e, n.df, !0),
              (this.flags = null),
              (this.onFlags = null),
              (this.offFlags = null);
          }
          parseComplete() {
            o.Z.prototype.parseComplete.call(this);
            const e = (0, a.j)(
                this.state.flags,
                this.string.slice(2, -1),
                this.state.flavor
              ),
              t = (0, s.Z)(e, 3),
              r = t[0],
              n = t[1],
              c = t[2];
            if (null == r)
              return (this.flags = this.state.flags), void this.setError(i.Gz);
            (this.flags = r), (this.onFlags = n), (this.offFlags = c);
          }
          _getNextState(e) {
            return (
              (e.flags = this.flags), o.Z.prototype._getNextState.call(this, e)
            );
          }
        }
        const l = c;
      },
      86700: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => c });
        var s = r(1277),
          n = r(67664),
          a = r(53996),
          i = r(4458);
        class o extends a.Z {
          constructor(e) {
            super(e, s.O3),
              (this.reference = null),
              this.setStyle(i.Z.backreference);
          }
          parseComplete() {
            this.reference = this.string.replace(/^(?:\(\?P=|\\[kg])|\W/g, "");
          }
          _revalidate(e) {
            return (
              this.reference
                ? e.subpatterns.includes(this.reference) || this.setError(n.Bj)
                : this.setError(n.YY),
              !!this.error
            );
          }
        }
        const c = o;
      },
      75262: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => l });
        var s = r(81370),
          n = r.n(s),
          a = r(1277),
          i = r(67664),
          o = r(87263);
        class c extends o.Z {
          constructor(e, t = a.sS) {
            super(e, t, !0),
              (this.groupNumber = null),
              (this.subpattern = null),
              (this.groupNumber = e.captureGroupCount + 1);
          }
          parseComplete() {
            const e = this.state,
              t = e.flavor,
              r = e.flags,
              s = e.inDuplicateSubpatternGroup,
              a = e.captureGroupCount,
              c = e.captureGroupMap,
              l = e.subpatterns;
            o.Z.prototype.parseComplete.call(this);
            const u =
              this.subpattern || this.string.replace("(?P", "").match(/\w+/)[0];
            this.subpattern = u;
            const h = t === n().PCRE || t === n().PCRE2 ? 32 : 2147483647;
            if (
              (u.length > h && this.setError(i.bk),
              (t === n().DOTNET ? /^\d+\D/ : /^\d/).test(u) &&
                this.setError(i.kU),
              s)
            ) {
              const e = a + 1;
              if ("string" == typeof c[e])
                return void (c[e] !== u && this.setError(i.wn));
              if ("number" == typeof c[e]) return void this.setError(i.wn);
            }
            t !== n().DOTNET &&
              l.includes(u) &&
              !r.includes("J") &&
              this.setError(i.wi);
          }
          _getNextState(e) {
            return (
              this.state.inDEFINE &&
                e.definedSubpatterns.push(this.state.captureGroupCount),
              e.subpatterns.push(this.subpattern),
              e.captureGroupCount++,
              (e.captureGroupMap[e.captureGroupCount] = this.subpattern),
              (e.captureGroupMap[this.subpattern] = e.captureGroupCount),
              e.captureGroups.push(this),
              o.Z.prototype._getNextState.call(this, e)
            );
          }
        }
        const l = c;
      },
      6975: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(1277),
          n = r(85877);
        class a extends n.Z {
          constructor(e, t) {
            super(e, s.up, t);
          }
        }
        const i = a;
      },
      43276: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(1277),
          n = r(50594);
        class a extends n.Z {
          constructor(e, t) {
            super(e, s.Ty, t);
          }
        }
        const i = a;
      },
      53980: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(1277),
          n = r(87263);
        class a extends n.Z {
          constructor(e) {
            super(e, s.xT, !0);
          }
        }
        const i = a;
      },
      4427: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => c });
        var s = r(1277),
          n = r(67664),
          a = r(53996),
          i = r(4458);
        class o extends a.Z {
          constructor(e, t = !1) {
            super(e, s.WE),
              this.setStyle(i.Z.backreference),
              (this.allowZeroRef = t);
          }
          _revalidate(e) {
            if (this.error) return;
            const t = this.string.replace(/\D/g, "");
            if (this.allowZeroRef && "0" === t) return (this.reference = 0), !1;
            let r = null;
            if (t) {
              const s = parseInt(t, 10);
              this.string.includes("-")
                ? ((r = this.state.captureGroupCount - s + 1),
                  0 === s && this.setError(n.Bj))
                : this.string.includes("+")
                ? ((r = this.state.captureGroupCount + s),
                  0 === s && this.setError(n.Bj))
                : (r = s),
                (r > e.captureGroupCount || r < 1) && this.setError(n.Bj);
            } else this.setError(n.YY);
            return (this.reference = r), !!this.error;
          }
        }
        const c = o;
      },
      38645: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => c });
        var s = r(1277),
          n = r(67664),
          a = r(43307),
          i = r(4458);
        class o extends a.Z {
          constructor(e) {
            super(e, s.Pg),
              this.setStyle(i.Z.meta),
              (this.quantifiable = !0),
              (this.length = 1);
          }
          parseComplete() {
            (this.charCode = parseInt(this.string.replace(/\D/g, ""), 8) || 0),
              this.state.unicodeEnabled &&
                this.charCode >= parseInt("0xd800", 16) &&
                this.charCode <= parseInt("0xdfff", 16) &&
                this.setError(n.oH);
          }
        }
        const c = o;
      },
      65315: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => c });
        var s = r(1277),
          n = r(67664),
          a = r(43307),
          i = r(4458);
        class o extends a.Z {
          constructor(e) {
            super(e, s.HI),
              (this.closeCharClass = null),
              (this.intersection = !1),
              this.setStyle([i.Z.charclass, i.Z.meta]),
              (this.quantifiable = !0),
              (this.length = 1);
          }
          getTooltipMarkerRange() {
            return {
              primary: {
                start: {
                  pos: this.editorPosition.start.pos,
                  line: this.editorPosition.start.line,
                },
                end: {
                  pos: (this.closeCharClass || this).editorPosition.end.pos,
                  line: (this.closeCharClass || this).editorPosition.end.line,
                },
              },
            };
          }
          _getNextState(e) {
            return (
              (e.inCharClass = !0),
              e.charClasses.push(this),
              e.parents.push(this),
              e
            );
          }
          _revalidate() {
            return this.setError(n.sw), !0;
          }
        }
        const c = o;
      },
      4462: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(67664),
          n = r(13511);
        class a extends n.Z {
          parseComplete() {
            n.Z.prototype.parseComplete.call(this),
              this.hex.length > 4 && !this.state.unicodeEnabled
                ? this.setError(s.y1)
                : this.state.unicodeEnabled &&
                  parseInt(this.hex, 16) >= parseInt("0xd800", 16) &&
                  parseInt(this.hex, 16) <= parseInt("0xdfff", 16)
                ? this.setError(s.oH)
                : "\\x{}" === this.string && this.setError(s.Yo);
          }
        }
        const i = a;
      },
      24051: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => l });
        var s = r(1277),
          n = r(81370),
          a = r.n(n),
          i = r(67664),
          o = r(43307);
        class c extends o.Z {
          constructor(e) {
            super(e, s.zl),
              (this._ignoreWhitespace = !1),
              this.setStyle(null),
              (this.quantifiable = !0),
              (this.length = 1);
          }
          parseComplete() {
            (this.charCode = this.string.charCodeAt(0)),
              (this.codePoint = this.string.codePointAt(0)),
              0 === this.charCode &&
                [a().PCRE, a().PCRE2, a().PYTHON].includes(this.state.flavor) &&
                this.setError(i.O3),
              (this._ignoreWhitespace =
                ((this.state.flags.includes("x") && !this.state.inCharClass) ||
                  this.state.flags.includes("xx")) &&
                /[ \t\r\n\f]/.test(this.string)),
              this._ignoreWhitespace && (this.length = 0);
          }
          _getNextState(e) {
            return (
              this._ignoreWhitespace &&
                ((e.previousToken = this.state.previousToken),
                (this.ignoreOnHover = !0)),
              e
            );
          }
        }
        const l = c;
      },
      23550: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(1277),
          n = r(85877);
        class a extends n.Z {
          constructor(e, t) {
            super(e, s.PG, t);
          }
        }
        const i = a;
      },
      23049: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(1277),
          n = r(50594);
        class a extends n.Z {
          constructor(e, t) {
            super(e, s.Gs, t);
          }
        }
        const i = a;
      },
      53467: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => h });
        var s = r(1277),
          n = r(67664),
          a = r(81370),
          i = r.n(a),
          o = r(35425),
          c = r(43307),
          l = r(4458);
        class u extends c.Z {
          constructor(e) {
            super(e, s.Wj),
              (this.to = null),
              (this.from = null),
              (this.possessive = !1),
              (this.lazy = !1),
              this.setStyle(
                e.previousToken &&
                  ((0, s.tK)(e.previousToken.type) ||
                    e.previousToken.type === s.Wj)
                  ? e.previousToken.style
                  : l.Z.quantifier
              ),
              (this.quantifiable = !0),
              (this.lazy = e.flags.includes("U"));
          }
          getTooltipMarkerRange() {
            const e = {
              start: {
                pos: this.editorPosition.start.pos,
                line: this.editorPosition.start.line,
              },
              end: {
                pos: this.editorPosition.end.pos,
                line: this.editorPosition.end.line,
              },
            };
            if (this.error) return { primary: e };
            let t = this.state.previousToken,
              r = {};
            return (
              t &&
                t.type === s.Wj &&
                ((e.start.pos = t.editorPosition.start.pos),
                (e.start.line = t.editorPosition.start.line),
                (t = t.state.previousToken)),
              this.quantifier &&
                ((e.end.pos = this.quantifier.editorPosition.end.pos),
                (e.end.line = this.quantifier.editorPosition.end.line)),
              t && (r = t.getTooltipMarkerRange().primary),
              { primary: e, secondary: r }
            );
          }
          getTooltipToken() {
            return !this.error &&
              this.state.previousToken &&
              this.state.previousToken.type === s.Wj
              ? this.state.previousToken
              : this;
          }
          parseComplete() {
            if (
              (this._calculateDimension(),
              this.state.previousToken && this.state.previousToken.quantifiable)
            ) {
              if (
                ((this.length = this._getLength()),
                this.state.previousToken.type === s.Wj)
              ) {
                const e = (this.state.previousToken.string + this.string).slice(
                  -1
                );
                this._validateQuantifier(e), (this.quantifiable = !1);
              }
              this.error ||
                ((this.state.previousToken.possessive = this.possessive),
                (this.state.previousToken.lazy = this.lazy),
                this.state.previousToken.setQuantifier(this),
                this.state.previousToken.addRelatedToken(this));
            } else this.setError(n.RY);
          }
          _calculateDimension() {
            const e = this.state.flavor,
              t = this.string.charAt(0),
              r = this.state.lookbehindCount > 0,
              s = (e === i().JAVASCRIPT && (0, o.nn)()) || e === i().DOTNET;
            if ("{" === t) {
              const t = this.string.replace(/[^\d,]/g, "").split(","),
                a = t[0] ? parseInt(t[0], 10) : 0;
              let o;
              (o =
                void 0 === t[1] ? a : "" === t[1] ? 1 / 0 : parseInt(t[1], 10)),
                (this.to = o),
                (this.from = a),
                a > o
                  ? this.setError(n.Hh)
                  : r &&
                    !s &&
                    (e === i().JAVA
                      ? o === 1 / 0 && this.setError(n.Cc)
                      : a !== o
                      ? this.setError(n.Cc)
                      : (e !== i().PCRE && e !== i().PYTHON) ||
                        0 !== o ||
                        this.setError(n.Cc));
            } else
              r &&
                !s &&
                (e === i().JAVA
                  ? "?" !== t && this.setError(n.Cc)
                  : this.setError(n.Cc)),
                "*" === t
                  ? ((this.from = 0), (this.to = 1 / 0))
                  : "+" === t
                  ? ((this.from = 1), (this.to = 1 / 0))
                  : ((this.from = 0), (this.to = 1));
          }
          _getLength() {
            return this.state.previousToken.type === s.Wj
              ? this.state.previousToken.length
              : this.from === this.to
              ? this.from * Math.max(this.state.previousToken.length, 1) -
                this.state.previousToken.length
              : 1 / 0;
          }
          _validateQuantifier(e) {
            "?" === e ? (this.lazy = !this.lazy) : this.setError(n.RY);
          }
        }
        const h = u;
      },
      53996: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => c });
        var s = r(81370),
          n = r.n(s),
          a = r(67664),
          i = r(43307);
        class o extends i.Z {
          constructor(e, t) {
            super(e, t),
              (this.reference = null),
              (this.quantifiable = !0),
              (this.length = 0),
              this.state.flavor !== n().JAVASCRIPT &&
                e.lookbehindCount > 0 &&
                this.setError(a.jV);
          }
          _getNextState(e) {
            return e.subpatternTokens.push(this), e;
          }
          _revalidate() {
            throw new Error(
              "Reference token has not implemented `_revalidate`"
            );
          }
        }
        const c = o;
      },
      4727: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => o });
        var s = r(1277),
          n = r(43307),
          a = r(4458);
        class i extends n.Z {
          constructor(e) {
            super(e, s.bO),
              (this.highBits = null),
              (this.lowBits = null),
              this.setStyle(a.Z.meta),
              (this.quantifiable = !0),
              (this.length = 1);
          }
          parseComplete() {
            (this.highBits = this.string.slice(2, 6)),
              (this.lowBits = this.string.slice(8)),
              (this.charCode = this.codePoint =
                parseInt("0x10000", 16) +
                (parseInt(this.highBits, 16) - parseInt("0xd800", 16)) *
                  parseInt("0x400", 16) +
                (parseInt(this.lowBits, 16) - parseInt("0xdc00", 16)));
          }
        }
        const o = i;
      },
      43307: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(64023),
          n = r(67664),
          a = r(4458);
        const i = class {
          constructor(e, t) {
            var r;
            (this.state = null),
              (this.type = null),
              (this.error = null),
              (this.parent = null),
              (this.children = []),
              (this.string = null),
              (this.position = null),
              (this.editorPosition = null),
              (this.style = null),
              (this.quantifiable = null),
              (this.quantifier = null),
              (this.partOfRange = !1),
              (this.rangeToken = null),
              (this.relatedTokens = []),
              (this.ignoreOnHover = !1),
              (this.length = 0),
              (this.charCode = null),
              (this.codePoint = null),
              (this.isPoorlyPlaced = !1),
              (this.isSubstitution = !1),
              (this.charClassIntersection = !1),
              (this.charClassSubtraction = !1),
              (this.state = e),
              (this.type = t),
              this.setParent(
                null === (r = e.parents) || void 0 === r
                  ? void 0
                  : r[e.parents.length - 1]
              );
          }
          getNextState() {
            var e;
            const t = s.Z.copyState(this.state);
            return (
              (t.previousToken = this),
              (t.actualPreviousToken = this),
              (null === (e = this._getNextState) || void 0 === e
                ? void 0
                : e.call(this, t)) || t
            );
          }
          getRelatedTokens() {
            const e = [];
            return (
              (function t(r) {
                r.forEach((r) => {
                  e.includes(r) || (e.push(r), t(r.relatedTokens));
                });
              })(this.relatedTokens),
              e
            );
          }
          getTooltipMarkerRange() {
            return this.partOfRange
              ? this.rangeToken.getTooltipMarkerRange()
              : {
                  primary: {
                    start: {
                      pos: this.editorPosition.start.pos,
                      line: this.editorPosition.start.line,
                    },
                    end: {
                      pos: this.editorPosition.end.pos,
                      line: this.editorPosition.end.line,
                    },
                  },
                };
          }
          getTooltipToken() {
            return this.partOfRange ? this.rangeToken : this;
          }
          setError(e) {
            var t, r;
            (this.error = e),
              (this.quantifiable = !1),
              (this.style = a.Z.error),
              (this.state.patternError = !0),
              null === (t = this.quantifier) ||
                void 0 === t ||
                t.setError(n.RY),
              null === (r = this.closeGroup) || void 0 === r || r.setError(e);
          }
          setParent(e) {
            e && ((this.parent = e), this.parent.addChild(this));
          }
          setStyle(e) {
            if (this.error) return;
            const t = e || [];
            this.state.inCharClass
              ? (this.style = [a.Z.inCharClass].concat(t).join(" "))
              : this.state.inQuote
              ? (this.style = [a.Z.inQuote].concat(t).join(" "))
              : (this.style = [].concat(e).join(" "));
          }
          setQuantifier(e) {
            if (!this.quantifiable && !this.willBeQuantifiable)
              throw new Error(
                "Trying to add quantifier to non-quantifiable token"
              );
            this.quantifier = e;
          }
          addChild(e) {
            this.children.push(e);
          }
          addRelatedToken(e) {
            this.relatedTokens.includes(e) ||
              (this.relatedTokens.push(e), e.addRelatedToken(this));
          }
          parseComplete() {}
        };
      },
      1234: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => o });
        var s = r(1277),
          n = r(67664),
          a = r(43307);
        class i extends a.Z {
          constructor(e) {
            super(e, s.zl), this.setError(n.zX);
          }
        }
        const o = i;
      },
      95165: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => o });
        var s = r(1277),
          n = r(67664),
          a = r(43307);
        class i extends a.Z {
          constructor(e) {
            super(e, s.cF), this.setError(n.t0);
          }
        }
        const o = i;
      },
      54602: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => c });
        var s = r(1277),
          n = r(67664),
          a = r(43307),
          i = r(4458);
        class o extends a.Z {
          constructor(e) {
            super(e, s.Yb),
              (this.hex = null),
              this.setStyle(i.Z.meta),
              (this.quantifiable = !0),
              (this.length = 1);
          }
          parseComplete() {
            (this.hex = this.string.replace(/^\\u|[{}]/gi, "")),
              (this.charCode = parseInt(this.hex, 16)),
              ("{" === this.string.charAt(2) &&
                "}" !== this.string.slice(-1)) ||
              "" === this.hex
                ? this.setError(n.YY)
                : /[^a-f0-9]/i.test(this.hex)
                ? this.setError(n.K0)
                : parseInt(this.hex, 16) > parseInt("10ffff", 16)
                ? this.setError(n.y1)
                : this.isSubstitution &&
                  !/^\\u.{4}$/.test(this.string) &&
                  this.setError(n.K0);
          }
        }
        const c = o;
      },
      22028: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => c });
        var s = r(1277),
          n = r(67664),
          a = r(43307),
          i = r(4458);
        class o extends a.Z {
          constructor(e) {
            super(e, s.dz),
              (this.script = null),
              (this.category = null),
              this.setStyle(i.Z.meta),
              (this.quantifiable = !0),
              (this.length = 1);
          }
          parseComplete() {
            (this.script = this.string.slice(2).replace(/[^&\w\-=]/g, "")),
              (!this.script ||
                ("{" === this.string.charAt(2) &&
                  "}" !== this.string.slice(-1))) &&
                this.setError(n.YY);
          }
        }
        const c = o;
      },
      64375: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => o });
        var s = r(1277),
          n = r(67664),
          a = r(43307);
        class i extends a.Z {
          constructor(e) {
            super(e, s.MW), this.setError(n.RH);
          }
        }
        const o = i;
      },
      32973: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => o });
        var s = r(1277),
          n = r(43307),
          a = r(4458);
        class i extends n.Z {
          constructor(e) {
            super(e, s.Tf),
              this.setStyle(a.Z.meta),
              (this.quantifiable = !0),
              (this.charCode = "\v".charCodeAt(0)),
              (this.length = 1);
          }
        }
        const o = i;
      },
      74387: (e) => {
        (e.exports.JL = "0.2s"),
          (e.exports.t2 = "0.25s"),
          (e.exports.E2 = "0.2s"),
          (e.exports.DP = "0.1s"),
          (e.exports.ug = "0.5s"),
          (e.exports.Y4 = "0.25s"),
          (e.exports.oA = "0.3s"),
          (e.exports.s_ = "0.25s"),
          (e.exports.K0 = "1s");
      },
      41163: (e) => {
        (e.exports.zj = "5px"),
          (e.exports.Pt = "785px"),
          (e.exports.bP = "900px"),
          (e.exports.D6 = "900px"),
          (e.exports.p4 = "1080px");
      },
      4844: (e, t, r) => {
        "use strict";
        r.d(t, { O7: () => h, S1: () => l, PC: () => u, fo: () => p });
        var s = r(23765),
          n = r(25968),
          a = r(45987);
        const i = ["regexAreaParser"];
        let o = null,
          c = null;
        function l() {
          (window.onerror = (e, t, r, n, a) => {
            null == a
              ? s.Z.error({ message: e, url: t, line: r, column: n })
              : h(a);
          }),
            (window.onunhandledrejection = (e) => h(e.reason, e.promise));
        }
        async function u() {
          return (
            null == c &&
              (c = r
                .e(530)
                .then(r.bind(r, 35135))
                .then(
                  (e) => (
                    (window.onerror = null),
                    (window.onunhandledrejection = null),
                    e.init({
                      dsn: "https://5f9e813965e0433598973663dff85743@sentry.io/102476",
                      release: "7.1.4",
                      normalizeDepth: 6,
                      allowUrls: ["regex101.com"],
                    }),
                    e
                  )
                )),
            c
          );
        }
        async function h(e, t = null) {
          try {
            n.ZP.emit(n.P), s.Z.error(e);
            const r = await u();
            r.withScope((s) => {
              null != o &&
                (function (e, t, r) {
                  const s = r.regexEditor,
                    n = s.regex,
                    o = s.delimiter,
                    c = s.flavor,
                    l = s.flags,
                    u = s.testString,
                    h = s.substString,
                    p = r.general,
                    d = p.permalinkFragment,
                    g = p.version,
                    m = p.userId,
                    f = p.email;
                  e.setUser({ id: m, email: f }),
                    t.setContext("permalink", {
                      permalinkFragment: d,
                      version: g,
                    }),
                    t.setContext("editor", {
                      regex: n,
                      delimiter: o,
                      flavor: c,
                      flags: l,
                      testString: u,
                      substString: h,
                    }),
                    t.setTag("flavor", c),
                    t.setTag("permalink", d),
                    r.regexAreaParser;
                  const x = (0, a.Z)(r, i);
                  t.setContext("redux.state", x);
                })(r, s, o.getState()),
                null != t
                  ? (s.setExtra("unhandledPromiseRejection", !0),
                    r.captureException(e, { originalException: t }))
                  : r.captureException(e);
            });
          } catch (e) {
            s.Z.error("Unable to submit error report", e),
              (window.onerror = null);
          }
        }
        function p(e) {
          o = e;
        }
      },
      58317: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(31807),
          n = r.n(s),
          a = r(23765);
        const i = new (class {
          get(e, t = !0) {
            if (!n()) return {};
            try {
              if (
                !window.localStorage ||
                "function" != typeof window.localStorage.getItem
              )
                throw new Error(
                  "localStorage not accessible or function `getItem` missing. Aborting."
                );
              const t = window.localStorage.getItem(e);
              return JSON.parse(t) || null;
            } catch (e) {
              if ((a.Z.error(e), !t)) throw e;
            }
          }
          save(e, t, r = !0) {
            if (n())
              try {
                if (
                  !window.localStorage ||
                  "function" != typeof window.localStorage.setItem
                )
                  throw new Error(
                    "localStorage not accessible or function `setItem` missing. Aborting."
                  );
                const r = JSON.stringify(t);
                window.localStorage.setItem(e, r);
              } catch (e) {
                if ((a.Z.error(e), !r)) throw e;
              }
          }
          delete(e, t = !0) {
            if (n())
              try {
                if (
                  !window.localStorage ||
                  "function" != typeof window.localStorage.removeItem
                )
                  throw new Error(
                    "localStorage not accessible or function `removeItem` missing. Aborting."
                  );
                window.localStorage.removeItem(e);
              } catch (e) {
                if ((a.Z.error(e), !t)) throw e;
              }
          }
        })();
      },
      42623: (e, t, r) => {
        "use strict";
        r.d(t, { C: () => s });
        const s = (0, r(68692).Z)((e, t, r) => {
          const s = n(e),
            a = n(t),
            i = r / 100;
          return `rgb(${(a.r - s.r) * i + s.r}, ${(a.g - s.g) * i + s.g}, ${
            (a.b - s.b) * i + s.b
          })`;
        });
        function n(e) {
          (e = e.trim()).length < 7 && (e += e.slice(1));
          const t = /^#([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(e);
          if (t)
            return {
              r: parseInt(t[1], 16),
              g: parseInt(t[2], 16),
              b: parseInt(t[3], 16),
            };
          throw new Error(`Invalid color '${e}'`);
        }
      },
      70872: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => n });
        var s = r(23765);
        function n(e) {
          const t = parseFloat(e);
          let r = e.match(/m?s/);
          switch ((r && (r = r[0]), r)) {
            case "s":
              return 1e3 * t;
            case "ms":
              return t;
            default:
              return s.Z.error(new Error(`Unknown unit '${r}'`)), 0;
          }
        }
      },
      25968: (e, t, r) => {
        "use strict";
        r.d(t, {
          ZP: () => u,
          B3: () => h,
          LG: () => p,
          P: () => d,
          AZ: () => g,
          U0: () => m,
          $7: () => f,
          Rd: () => x,
          l2: () => b,
          yM: () => v,
          Fx: () => j,
          ji: () => y,
          fZ: () => O,
          En: () => w,
        });
        var s = r(31807),
          n = r.n(s),
          a = r(23765);
        class i {
          constructor() {
            this.hasStoppedPropagation = !1;
          }
          stopPropagation() {
            this.hasStoppedPropagation = !0;
          }
        }
        function o(e) {
          return "string" == typeof e;
        }
        function c(e) {
          return "function" == typeof e;
        }
        function l(e) {
          return "object" == typeof e && null !== e;
        }
        const u = new (class {
            constructor() {
              (this._events = {}), (this._maxListeners = 10);
            }
            setMaxListeners(e) {
              if ("number" != typeof e || e < 0 || isNaN(e))
                throw TypeError("n must be a positive number");
              return (this._maxListeners = e), this;
            }
            emit(e) {
              let t;
              this._events || (this._events = {});
              const r = this._events[e];
              if (void 0 === r) return !1;
              const s = new i();
              if (c(r))
                switch (arguments.length) {
                  case 1:
                    r.call(this, s);
                    break;
                  case 2:
                    r.call(this, s, arguments[1]);
                    break;
                  case 3:
                    r.call(this, s, arguments[1], arguments[2]);
                    break;
                  default:
                    (t = [s, ...Array.prototype.slice.call(arguments, 1)]),
                      r.apply(this, t);
                }
              else if (l(r)) {
                t = [s, ...Array.prototype.slice.call(arguments, 1)];
                const e = r.slice();
                for (
                  let r = e.length - 1;
                  r >= 0 && (e[r].apply(this, t), !s.hasStoppedPropagation);
                  r--
                );
              }
              return !0;
            }
            addListener(e, t) {
              if (n()) {
                if (!c(t)) throw TypeError("listener must be a function");
                return (
                  this._events[e]
                    ? l(this._events[e])
                      ? this._events[e].includes(t)
                        ? a.Z.error(
                            new Error(
                              `Listener for ${e} added multiple times. Name: '${t.name}'`
                            )
                          )
                        : this._events[e].push(t)
                      : this._events[e] === t
                      ? a.Z.error(
                          new Error(
                            `Listener for ${e} already added. Name: '${t.name}'`
                          )
                        )
                      : (this._events[e] = [this._events[e], t])
                    : (this._events[e] = t),
                  l(this._events[e]) &&
                    !this._events[e].warned &&
                    this._events[e].length > this._maxListeners &&
                    ((this._events[e].warned = !0),
                    a.Z.error(
                      new Error(
                        `Possible EventEmitter memory leak detected. ${this._events[e].length} listeners added. Use setMaxListeners() to increase limit.`
                      )
                    )),
                  this
                );
              }
            }
            on(e) {
              if (o(e)) return this.addListener.apply(this, arguments);
              for (const t in e)
                e.hasOwnProperty(t) && this.addListener.call(this, t, e[t]);
              return this;
            }
            once(e, t) {
              if (!c(t)) throw TypeError("listener must be a function");
              let r = !1;
              function s() {
                this.removeListener(e, s),
                  r || ((r = !0), t.apply(this, arguments));
              }
              return (s.listener = t), this.on(e, s), this;
            }
            removeListener(e, t) {
              if (!c(t)) throw TypeError("listener must be a function");
              if (!this._events || !this._events[e]) return this;
              const r = this._events[e];
              if (r === t || (c(r.listener) && r.listener === t))
                delete this._events[e],
                  this._events.removeListener &&
                    this.emit("removeListener", e, t);
              else if (l(r)) {
                let s = -1;
                for (let e = r.length - 1; e >= 0; e--)
                  if (r[e] === t || (r[e].listener && r[e].listener === t)) {
                    s = e;
                    break;
                  }
                if (s < 0) return this;
                1 === r.length
                  ? ((r.length = 0), delete this._events[e])
                  : r.splice(s, 1),
                  this._events.removeListener &&
                    this.emit("removeListener", e, t);
              }
              return this;
            }
            off(e) {
              if (o(e)) return this.removeListener.apply(this, arguments);
              for (const t in e)
                e.hasOwnProperty(t) && this.removeListener(t, e[t]);
              return this;
            }
            removeAllListeners(e) {
              if (!this._events) return this;
              if (!this._events.removeListener)
                return (
                  0 === arguments.length
                    ? (this._events = {})
                    : this._events[e] && delete this._events[e],
                  this
                );
              if (0 === arguments.length) {
                for (const e in this._events)
                  "removeListener" !== e && this.removeAllListeners(e);
                return (
                  this.removeAllListeners("removeListener"),
                  (this._events = {}),
                  this
                );
              }
              const t = this._events[e];
              if (c(t)) this.removeListener(e, t);
              else if (t)
                for (; t.length; ) this.removeListener(e, t[t.length - 1]);
              return delete this._events[e], this;
            }
            listeners(e) {
              return this._events && this._events[e]
                ? c(this._events[e])
                  ? [this._events[e]]
                  : this._events[e].slice()
                : [];
            }
            listenerCount(e) {
              if (this._events) {
                const t = this._events[e];
                if (c(t)) return 1;
                if (t) return t.length;
              }
              return 0;
            }
          })(),
          h = "disable:shortcut",
          p = "enable:shortcut",
          d = "flush:state",
          g = "testarea:hideCanvas",
          m = "testarea:showCanvas",
          f = "testarea:resize",
          x = "closeLeftSidebar",
          b = "set:substString",
          v = "testlist:open",
          j = "testlist:close",
          y = "matchGroup:click",
          O = "quickref:loadExample",
          w = "loading:finish";
      },
      39781: (e, t, r) => {
        "use strict";
        r.d(t, { G: () => a });
        var s = r(81370),
          n = r.n(s);
        const a = (e) => e === n().PCRE || e === n().PCRE2;
      },
      99237: (e, t, r) => {
        "use strict";
        r.d(t, { R: () => a, n: () => i });
        var s = r(68692),
          n = r(34595);
        const a = (0, s.Z)((e) =>
            getComputedStyle(document.documentElement).getPropertyValue(e)
          ),
          i = (e, t, r) =>
            a(
              r
                ? "--match-highlight-color"
                : `--match-group-${((e - 1) % n.GROUP_COUNT) + 1}${
                    t ? "-alt" : ""
                  }`
            );
      },
      424: (e, t, r) => {
        "use strict";
        r.d(t, {
          Sf: () => i.Z,
          vI: () => n,
          $5: () => o.Z,
          DB: () => c,
          OL: () => h,
          aL: () => O.ZP,
          kF: () => m,
          YX: () => y,
          Sj: () => a.Z,
        });
        var s = r(67294);
        const n = (e, t) => {
          const r = (0, s.useRef)(!1);
          (0, s.useEffect)(() => {
            let t;
            return (
              r.current ? (t = e()) : (r.current = !0),
              () => {
                var e;
                return null === (e = t) || void 0 === e ? void 0 : e();
              }
            );
          }, t),
            (0, s.useEffect)(() => () => (r.current = !1), []);
        };
        var a = r(82935),
          i = r(90375),
          o = r(58830);
        const c = (e, t) => {
          (0, s.useRef)(!1), (0, s.useLayoutEffect)(e, t);
        };
        var l = r(19272),
          u = r(96974);
        const h = () => {
          const e = (0, u.TH)();
          (0, s.useEffect)(() => {
            var t;
            (t = e.pathname), (0, l.set)({ page: t }), (0, l.pageview)(t);
          }, [e.pathname]);
        };
        var p = r(93942),
          d = r(14850),
          g = r(34595);
        const m = (e, t = g.DEFAULT_META_DESCRIPTION) => {
          const r = (0, p.I0)(),
            n = (0, u.TH)();
          (0, s.useEffect)(() => {
            var s;
            (document.title = `regex101: ${e || g.DEFAULT_PAGE_TITLE}`),
              null ===
                (s = document.querySelector('meta[name="description"]')) ||
                void 0 === s ||
                s.setAttribute("content", t),
              r((0, d.Dk)(e)),
              r((0, d.Ub)(t));
          }, [e, t, r, n]);
        };
        var f = r(98152),
          x = r(42623),
          b = r(99237),
          v = r(9599),
          j = r(7551);
        const y = () => {
          const e = (0, p.I0)(),
            t = (0, p.v9)((e) => e.general.currentTheme),
            r = (0, p.v9)((e) => e.settings.theme),
            n = (0, s.useState)(t),
            a = (0, f.Z)(n, 2),
            i = a[0],
            o = a[1];
          (0, s.useEffect)(() => o(t), [t]),
            (0, s.useEffect)(() => {
              var e, t, s;
              const n = (e) => {
                if (r !== j.B7) return;
                const t = e.matches ? j.Py : j.rp;
                o(t);
              };
              return (
                null === (e = window) ||
                  void 0 === e ||
                  null === (t = e.matchMedia("(prefers-color-scheme: dark)")) ||
                  void 0 === t ||
                  null === (s = t.addEventListener) ||
                  void 0 === s ||
                  s.call(t, "change", n),
                () => {
                  var e, t, r;
                  return null === (e = window) ||
                    void 0 === e ||
                    null ===
                      (t = e.matchMedia("(prefers-color-scheme: dark)")) ||
                    void 0 === t ||
                    null === (r = t.removeEventListener) ||
                    void 0 === r
                    ? void 0
                    : r.call(t, "change", n);
                }
              );
            }, [r, e]),
            (0, s.useEffect)(() => {
              document.documentElement.setAttribute("data-theme", i),
                (function () {
                  const e = document.querySelector("meta[name=theme-color]");
                  e && e.setAttribute("content", (0, b.R)("--primary-color"));
                })(),
                b.R.clear(),
                x.C.clear(),
                e((0, v.Z)(i));
            }, [e, i]);
        };
        var O = r(84665);
      },
      90375: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => i });
        var s = r(67294),
          n = r(91296),
          a = r.n(n);
        const i = function (e, t, r = "flush") {
          const n = (0, s.useCallback)(
            a()((...t) => e(...t), t),
            [t]
          );
          return (
            (0, s.useEffect)(
              () => () => {
                switch (r) {
                  case "flush":
                    return n.flush();
                  case "cancel":
                    return n.cancel();
                  default:
                    throw new Error(`Unknown cleanup '${r}'`);
                }
              },
              [n, r]
            ),
            n
          );
        };
      },
      58830: (e, t, r) => {
        "use strict";
        r.d(t, { U: () => l, Z: () => u });
        var s = r(98152),
          n = r(67294),
          a = r(93942),
          i = r(31807),
          o = r.n(i),
          c = r(23765);
        const l = (0, n.createContext)({
            promises: [],
            resolvedData: {},
            redirect: {},
            addPromise: () => {},
            setResolvedData: () => {},
            getResolvedData: () => {},
            setRedirectTo: () => {},
            SSR: !1,
          }),
          u = (e) => {
            const t = (0, n.useRef)(null),
              r = (0, a.I0)(),
              i = (0, n.useContext)(l),
              u = i.getResolvedData(e),
              h = (0, n.useState)(u || { loading: !1, error: null }),
              p = (0, s.Z)(h, 2),
              d = p[0],
              g = p[1],
              m = (0, n.useCallback)(
                (s) => {
                  var n, a, l;
                  null == u &&
                    (g({ loading: !0, error: null }),
                    null === (n = t.current) ||
                      void 0 === n ||
                      null === (a = n.cancel) ||
                      void 0 === a ||
                      a.call(n),
                    (t.current = r(s)
                      .then(() => {
                        t.current = null;
                        const r = { loading: !1, error: null };
                        i.setResolvedData(e, r), g(r);
                      })
                      .catch((t) => {
                        if (o() && t.code === DOMException.ABORT_ERR)
                          c.Z.warn(
                            `Data fetch for '${e}' aborted because the parent has unmounted`
                          ),
                            i.setResolvedData(e, { loading: !1, error: null });
                        else {
                          const r = { loading: !1, error: t };
                          i.setResolvedData(e, r), g(r);
                        }
                      })),
                    o() &&
                      null ==
                        (null === (l = t.current) || void 0 === l
                          ? void 0
                          : l.cancel) &&
                      c.Z.error(`Fetch '${e}' has no cancel`),
                    i.addPromise(t.current));
                },
                [r, i, e, u]
              );
            return (
              (0, n.useEffect)(
                () => () => {
                  var e, r;
                  null === (e = t.current) ||
                    void 0 === e ||
                    null === (r = e.cancel) ||
                    void 0 === r ||
                    r.call(e),
                    (t.current = null);
                },
                []
              ),
              [d.loading, d.error, m]
            );
          };
      },
      84665: (e, t, r) => {
        "use strict";
        r.d(t, { yg: () => x, W5: () => b, ZP: () => v });
        var s,
          n,
          a,
          i,
          o,
          c,
          l,
          u = r(67294),
          h = r(93942),
          p = r(31807),
          d = r.n(p),
          g = r(25968),
          m = r(49061),
          f = r(12037);
        const x =
            d() &&
            ((null !== (s = navigator) &&
              void 0 !== s &&
              null !== (n = s.userAgentData) &&
              void 0 !== n &&
              null !== (a = n.platform) &&
              void 0 !== a &&
              null !== (i = a.toLowerCase()) &&
              void 0 !== i &&
              i.includes("mac")) ||
              (null !== (o = navigator) &&
                void 0 !== o &&
                null !== (c = o.userAgent) &&
                void 0 !== c &&
                null !== (l = c.toLowerCase()) &&
                void 0 !== l &&
                l.includes("mac")))
              ? m.v
              : m.B,
          b = (e) => `${x === m.B ? "Ctrl" : "\u2318"}+${e}`,
          v = () => {
            const e = (0, h.v9)((e) => e.settings.disableKeyboardShortcuts),
              t = (0, u.useRef)([]),
              r = (0, u.useCallback)((e) => {
                var r, s, n, a, i, o;
                const c =
                  e.target instanceof HTMLInputElement ||
                  e.target instanceof HTMLTextAreaElement ||
                  "input" ===
                    (null === (r = e.target) ||
                    void 0 === r ||
                    null === (s = r.tagName) ||
                    void 0 === s
                      ? void 0
                      : s.toLowerCase()) ||
                  "textarea" ===
                    (null === (n = e.target) ||
                    void 0 === n ||
                    null === (a = n.tagName) ||
                    void 0 === a
                      ? void 0
                      : a.toLowerCase()) ||
                  (null === (i = e.target) ||
                  void 0 === i ||
                  null === (o = i.className) ||
                  void 0 === o
                    ? void 0
                    : o.includes("CodeMirror"));
                for (const r in f)
                  if (Object.prototype.hasOwnProperty.call(f, r)) {
                    const s = f[r],
                      n = !!s.metaKey == !!(x === m.v ? e.metaKey : e.ctrlKey),
                      a = !!s.altKey == !!e.altKey,
                      i = !!s.shiftKey == !!e.shiftKey,
                      o = s.overrideInput || !c;
                    if (
                      ((!e.key && s.keyCode.includes(e.which)) ||
                        (e.key &&
                          s.key.toLowerCase() === e.key.toLowerCase())) &&
                      n &&
                      a &&
                      i &&
                      o &&
                      !t.current.includes(s.name)
                    ) {
                      const t = `key:${s.name}`;
                      (g.ZP.listeners(t).length > 0 || s.alwaysConsume) &&
                        (e.preventDefault(), e.stopPropagation(), g.ZP.emit(t));
                    }
                  }
              }, []);
            (0, u.useEffect)(() => {
              const s = (e, r) => {
                  t.current = t.current.filter((e) => e !== r.name);
                },
                n = (e, r) => t.current.push(r.name);
              return (
                e ||
                  (document.addEventListener("keydown", r),
                  g.ZP.on({ [g.LG]: s, [g.B3]: n })),
                () => {
                  document.removeEventListener("keydown", r),
                    g.ZP.off({ [g.LG]: s, [g.B3]: n });
                }
              );
            }, [e, r]);
          };
      },
      82935: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => o });
        var s = r(98152),
          n = r(67294),
          a = r(31807),
          i = r.n(a);
        const o = (...e) => {
          const t = (0, n.useState)({
              width: i() ? window.innerWidth : 1920,
              height: i() ? window.innerHeight : 1080,
            }),
            r = (0, s.Z)(t, 2),
            a = r[0],
            o = r[1];
          return (
            (0, n.useEffect)(() => {
              let t,
                r = a.width;
              return (
                window.addEventListener(
                  "resize",
                  (t = () => {
                    const t = i() ? window.innerWidth : 1920,
                      s = i() ? window.innerHeight : 1080;
                    for (let n = 0, a = e.length; n < a; n++) {
                      const a = e[n];
                      if ((t < a && a < r) || (t >= a && r <= a)) {
                        o({ width: t, height: s }), (r = t);
                        break;
                      }
                    }
                  }),
                  { passive: !0 }
                ),
                () => {
                  window.removeEventListener("resize", t, { passive: !0 });
                }
              );
            }, [a.width, e]),
            a
          );
        };
      },
      23765: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => n });
        var s = r(2043);
        const n = r.n(s)();
      },
      44466: (e, t, r) => {
        "use strict";
        r.d(t, { u: () => s });
        const s = (e) => e.toString().replace(/\B(?=(?:.{3})+$)/g, "\u2009");
      },
      68692: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => s });
        const s = (e) => {
          const t = e.length,
            r = function () {
              const s = arguments,
                n = r.cache;
              if (t < 2) {
                const e = s[0];
                if (n[e]) return n[e];
              } else
                for (let e = 0, r = n[0].length; e < r; e++) {
                  let r = !1;
                  for (let a = 0; a < t && ((r = n[0][e][a] === s[a]), r); a++);
                  if (r) return n[1][e];
                }
              const a = e.apply(this, arguments);
              if (t < 2) n[s[0]] = a;
              else {
                const e = [];
                n[0].push(e), n[1].push(a);
                for (let t = 0, r = s.length; t < r; t++) e[t] = s[t];
              }
              return a;
            };
          return (
            (r.clear = () => {
              r.cache = t < 2 ? Object.create(null) : [[], []];
            }),
            r.clear(),
            r
          );
        };
      },
      53808: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => n, a: () => a });
        let s = {};
        const n = function (e) {
          const t = s[e] || e;
          return t.replace(/#?{[1-9]\d*}/g, (t) => {
            if ("#" === t.charAt(0)) return t.slice(1);
            const r = parseInt(t.slice(1, -1), 10);
            if (null == arguments[r])
              throw new Error(
                `Placeholder '${r}' referencing invalid argument: '${e}'`
              );
            if (
              "string" != typeof arguments[r] &&
              "number" != typeof arguments[r]
            )
              throw new Error(
                `Placeholder '${r}' is not a string: '${typeof arguments[r]}'`
              );
            return arguments[r];
          });
        };
        function a(e) {
          s = e;
        }
      },
      60370: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => s });
        const s = (e) => {
          const t = "string" == typeof e ? e.split("") : e;
          return t.filter((e, r) => t.indexOf(e) === r);
        };
      },
      15935: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => y });
        var s = r(81370),
          n = r.n(s);
        function a() {
          return new Worker(r.p + "golang.worker.ed67540443e44633f75b.js");
        }
        function i() {
          return new Worker(r.p + "pcre2.worker.d9cfc3e7eb27d47614f8.js");
        }
        function o() {
          return new Worker(r.p + "pcre.worker.299ff4e44d4f872ff81c.js");
        }
        function c() {
          return new Worker(r.p + "javascript.worker.bf186ccdf7165f6255ce.js");
        }
        function l() {
          return new Worker(r.p + "java.worker.61fd7939d45da2206d5f.js");
        }
        function u() {
          return new Worker(r.p + "dotnet.worker.77dd9bc4d949f76f61a1.js");
        }
        var h = r(4942),
          p = r(26681),
          d = r(32774),
          g = r(1277);
        function m(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function f(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? m(Object(r), !0).forEach(function (t) {
                  (0, h.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : m(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        let x = { regex: null, flags: null, data: {} };
        function b(e, t, r) {
          return t === g.MW && "\\Z" === e
            ? "\\z"
            : t === g.MW && "\\v" === e
            ? "\\x{0B}"
            : t === g.Wj && "{," === e.slice(0, 2)
            ? "{0," + e.slice(2)
            : t === g.Yb && "\\u" === e.slice(0, 2).toLowerCase()
            ? "\\x{" + e.slice(2) + "}"
            : t === g.t0 && d.i.test(e)
            ? e.slice(1)
            : r && t === g.zl && ".=:".includes(e)
            ? "\\" + e
            : t === g.RW
            ? e.replace(/[au]/g, "")
            : t === g.MW && "\\v" === e
            ? "\\x0B"
            : e;
        }
        var v = r(54292);
        class j extends v.Z {
          getWorker(e) {
            switch (e) {
              case n().PCRE2:
                return i;
              case n().PCRE:
              case n().PYTHON:
                return o;
              case n().JAVASCRIPT:
                return c;
              case n().GOLANG:
                return a;
              case n().JAVA:
                return l;
              case n().DOTNET:
                return u;
              default:
                throw new Error(`No worker file exists for flavor '${e}'`);
            }
          }
          runMatch(e, t, r, s = {}, a) {
            let i = {
              regex: e,
              flags: t,
              testString: r,
              options: {
                isDebugging: !!s.debugging,
                calculateSteps: !!s.calculateRegexSteps,
              },
            };
            return (
              s.flavor === n().PYTHON &&
                (i = (function (e) {
                  if (
                    null != x.regex &&
                    null != x.flags &&
                    x.regex === e.regex &&
                    x.flags === e.flags
                  )
                    return f(
                      f({}, e),
                      {},
                      {
                        regex: x.cachedRegex,
                        flags: x.cachedFlags,
                        options: f(f({}, e.options), {}, { bumpalong: !0 }),
                      }
                    );
                  const t = p.Z.tokens;
                  let r = "",
                    s = "";
                  for (let e = 0, s = t.length; e < s; e++) {
                    const s = t[e],
                      n = s.type;
                    r += b(s.string, n, s.state.inCharClass);
                  }
                  const n = t[0].state.flags;
                  s = n.includes("a")
                    ? n.replace(/[au]/g, "") + "P"
                    : n.replace(/a/g, "") + "u";
                  const a = f(
                    f({}, e),
                    {},
                    {
                      regex: r,
                      flags: s,
                      options: f(f({}, e.options), {}, { bumpalong: !0 }),
                    }
                  );
                  return (
                    (x = {
                      regex: e.regex,
                      flags: e.flags,
                      cachedRegex: r,
                      cachedFlags: s,
                    }),
                    a
                  );
                })(i)),
              super.runWorker(i, s, a)
            );
          }
        }
        const y = j;
      },
      54292: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => c });
        var s = r(34768),
          n = r(34595),
          a = r(81370),
          i = r.n(a),
          o = r(23765);
        const c = class {
          constructor() {
            (this._worker = null),
              (this._timeout = null),
              (this._currentFlavor = null),
              (this._runTimeout = null),
              (this._recentReset = !1);
          }
          getWorker() {
            throw new Error("Method not implemented");
          }
          runWorker(e, t, r) {
            this.isRunning() && ((this._recentReset = !0), this.resetWorker()),
              clearTimeout(this._runTimeout),
              (this._runTimeout = setTimeout(
                () => {
                  (this._recentReset = !1), this._runWorker(e, t, r);
                },
                this._recentReset ? n.UPDATE_RESULT_DELAY : 1
              ));
          }
          async _runWorker(e, t = {}, r) {
            if (
              (t.maxExecutionTime || (t.maxExecutionTime = 2e3),
              t.flavor || (t.flavor = i().PCRE2),
              t.flavor !== this._currentFlavor &&
                ((this._currentFlavor = t.flavor), this.resetWorker()),
              !this._worker)
            )
              try {
                await this._createWorker(),
                  (this._worker.callback = r),
                  (this._worker.onmessage = (e) => {
                    clearTimeout(this._timeout),
                      (this._timeout = null),
                      this._worker.callback(e.data, e.data.error || null);
                  }),
                  (this._worker.onerror = (e) => {
                    e.preventDefault(),
                      o.Z.warn(
                        "Web worker encountered an unhandled error:",
                        e.filename,
                        "Line:",
                        e.lineno,
                        "Col:",
                        e.colno,
                        "Msg:",
                        e.message
                      ),
                      (this._worker.callback || r)(null, s.Y8);
                  });
              } catch (e) {
                return o.Z.error(e), void r(null, s.Y8);
              }
            this._worker && (this._worker.callback = r),
              (this._timeout = setTimeout(() => {
                this._worker.callback(null, s.ik), this.resetWorker();
              }, t.maxExecutionTime));
              window?.OnPostMessageToWorker(this, e, t);
              this._worker.postMessage(e);
          }
          isRunning() {
            return null != this._timeout;
          }
          resetWorker() {
            clearTimeout(this._runTimeout),
              clearTimeout(this._timeout),
              (this._timeout = null),
              (this._runTimeout = null),
              this._worker &&
                ((this._worker.callback = () => {}),
                this._worker.terminate(),
                (this._worker = null));
          }
          async _createWorker() {
            return (
              clearTimeout(this._timeout),
              (this._timeout = null),
              new Promise((e, t) => {
                const r = this.getWorker(this._currentFlavor);
                (this._worker = new r()),
                  (this._timeout = setTimeout(
                    () => (
                      this.resetWorker(),
                      t(new Error("Unable to load worker, timeout after 10s"))
                    ),
                    1e4
                  )),
                  (this._worker.onmessage = (t) => {
                    "onload" === t.data && (clearTimeout(this._timeout), e());
                  }),
                  (this._worker.onerror = (e) => {
                    e.stopPropagation(), e.preventDefault(), t(e);
                  });
              })
            );
          }
        };
      },
      6817: (e, t, r) => {
        "use strict";
        r.d(t, { P: () => up });
        var s = {};
        r.r(s),
          r.d(s, {
            account: () => te,
            general: () => W,
            libraryEntry: () => ue,
            quiz: () => me,
            regexAreaParser: () => ve,
            regexEditor: () => Z,
            regexLibrary: () => ie,
            rightSidebar: () => b,
            settings: () => _,
            unitTests: () => F,
          });
        var n = r(73935),
          a = r(4942);
        function i(e) {
          if (e.status >= 200 && e.status < 300) return e;
          const t = new Error(e.statusText);
          throw ((t.response = e), t);
        }
        function o(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        var c = r(23765),
          l = r(14890),
          u = r(53894);
        const h = "EXPLANATION",
          p = "MATCH_INFO",
          d = "QUICKREF";
        var g = r(34963);
        function m(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function f(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? m(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : m(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const x = {
            activeSubsection: h,
            visibleSections: [h, p, d],
            hiddenSections: [],
            width: null,
          },
          b = function (e = x, t = {}) {
            switch (t.type) {
              case g.CJ:
                return f(f({}, e), {}, { width: t.value });
              case g.ro:
                const r = t.value.subsection,
                  s = e.visibleSections.includes(r);
                return f(
                  f({}, e),
                  {},
                  s
                    ? {
                        visibleSections: e.visibleSections.filter(
                          (e) => e !== r
                        ),
                        hiddenSections: [...e.hiddenSections, r],
                      }
                    : {
                        visibleSections: [...e.visibleSections, r],
                        hiddenSections: e.hiddenSections.filter((e) => e !== r),
                      }
                );
              case g.WV:
                return f(f({}, e), {}, { activeSubsection: t.value });
              case g.tc:
                return f(f({}, e), {}, { activeSubsection: h });
              default:
                return e;
            }
          };
        var v = r(81370),
          j = r.n(v),
          y = r(78850),
          O = r.n(y);
        function w(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function C(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? w(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : w(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const E = {
          flavor: v.PCRE2,
          delimiter: "/",
          flags: "gm",
          regex: "",
          testString: "",
          matchResult: [],
          error: null,
          substString: "",
          listSubstString: "",
          hasUnsavedData: !1,
          regexVersions: 0,
          showMatchArea: !0,
          showSubstitutionArea: !1,
          showUnitTestArea: !1,
          showListSubstitutionArea: !1,
        };
        function Z(e = E, t = {}) {
          var r;
          switch (t.type) {
            case g.r$:
              return C(C({}, e), {}, { listSubstString: t.value });
            case g.R8:
              return C(
                C({}, e),
                {},
                {
                  showMatchArea: !1,
                  showSubstitutionArea: !1,
                  showUnitTestArea: !1,
                  showListSubstitutionArea: !0,
                  hasUnsavedData: !!e.regex,
                }
              );
            case g.YW:
              return C(
                C({}, e),
                {},
                {
                  showMatchArea: !1,
                  showSubstitutionArea: !1,
                  showUnitTestArea: !0,
                  showListSubstitutionArea: !1,
                }
              );
            case g.T_:
              return C(
                C({}, e),
                {},
                {
                  showMatchArea: !1,
                  showSubstitutionArea: !0,
                  showUnitTestArea: !1,
                  showListSubstitutionArea: !1,
                  hasUnsavedData: !!e.regex,
                }
              );
            case g.RS:
              return C(
                C({}, e),
                {},
                {
                  showMatchArea: !0,
                  showSubstitutionArea: !1,
                  showUnitTestArea: !1,
                  showListSubstitutionArea: !1,
                }
              );
            case g.hl:
              return C(C({}, e), {}, { flavor: t.value, hasUnsavedData: !0 });
            case g.DA:
              return C(C({}, e), {}, { flags: t.value, hasUnsavedData: !0 });
            case g.Sr:
              return C(
                C({}, e),
                {},
                { delimiter: t.value, hasUnsavedData: !0 }
              );
            case g.KE:
              const s = t.value;
              return 0 !== s.length ||
                (0 !== e.matchResult.length && 0 === s.length)
                ? C(C({}, e), {}, { matchResult: s })
                : e;
            case g.u8:
              return C(
                C({}, e),
                {},
                {
                  substString: t.value,
                  hasUnsavedData: t.value !== e.substString || e.hasUnsavedData,
                }
              );
            case g.a0:
              return C(
                C({}, e),
                {},
                {
                  regex: t.value,
                  hasUnsavedData: t.value !== e.regex || e.hasUnsavedData,
                }
              );
            case g.Cy:
              return C(
                C({}, e),
                {},
                {
                  testString: t.value,
                  hasUnsavedData: t.value !== e.testString || e.hasUnsavedData,
                }
              );
            case g.Nl:
              return C(C({}, e), {}, { error: t.value });
            case g.lA:
            case g.rT:
            case g.LM:
            case g.mo:
              return C(C({}, e), {}, { hasUnsavedData: !0 });
            case g.nU:
              return C(
                C({}, e),
                {},
                { hasUnsavedData: !t.value.permalinkFragment }
              );
            case g.sk:
              let n = e.flavor || v.PCRE2;
              "" === e.regex &&
                e.flavor === v.PCRE2 &&
                null !== (r = t.value.settings) &&
                void 0 !== r &&
                r.defaultFlavor &&
                (n = t.value.settings.defaultFlavor);
              let a = e.delimiter;
              return (
                O()[n].includes(a) || (a = O()[n][0]),
                C(C({}, e), {}, { flavor: n, delimiter: a, hasUnsavedData: !1 })
              );
            case g.r0:
              return C(C({}, e), {}, { regexVersions: t.value });
            default:
              return e;
          }
        }
        var S = r(7551);
        function k(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function P(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? k(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : k(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const N = {
            maxExecutionTime: 2e3,
            theme: S.B7,
            nonParticipatingGroups: !1,
            displayWhitespace: !0,
            colorizeSyntax: !0,
            autoComplete: !1,
            wrapLines: !0,
            testAreaLineNumbers: !1,
            regexAreaLineNumbers: !1,
            language: "ENGLISH",
            storageSaved: null,
            storageLoaded: null,
            editorTooltips: !0,
            alwaysCollapseLeftSidebar: !1,
            alwaysCollapseRightSidebar: !1,
            defaultFlavor: v.PCRE2,
            showWarningUnsavedProgress: !0,
            defaultCodeGenLanguage: "",
            calculateRegexSteps: !0,
            defaultTabBehavior: !0,
            disableKeyboardShortcuts: !1,
          },
          _ = function (e = N, t = {}) {
            switch (t.type) {
              case g.jo:
                return P(P({}, e), t.value);
              case g.sk:
                return P(P({}, e), {}, { storageLoaded: new Date().getTime() });
              case g.fB:
                return P(P({}, e), {}, { storageSaved: new Date().getTime() });
              default:
                return e;
            }
          };
        var T = r(45987);
        const A = "PASS",
          I = "FAIL",
          R = "ALL";
        function D(e) {
          var t = (function (e, t) {
            if ("object" != typeof e || null === e) return e;
            var r = e[Symbol.toPrimitive];
            if (void 0 !== r) {
              var s = r.call(e, "string");
              if ("object" != typeof s) return s;
              throw new TypeError(
                "@@toPrimitive must return a primitive value."
              );
            }
            return String(e);
          })(e);
          return "symbol" == typeof t ? t : String(t);
        }
        function L(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function M(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? L(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : L(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const U = {
            tests: [],
            testResults: {},
            testsRunning: !1,
            testFilter: R,
          },
          F = function (e = U, t = {}) {
            let r;
            switch (t.type) {
              case g.lA:
                return M(
                  M({}, e),
                  {},
                  {
                    tests: [
                      ...e.tests,
                      M(
                        M({}, t.value),
                        {},
                        { key: Math.random().toString(36).slice(2) }
                      ),
                    ],
                  }
                );
              case g.rT:
                const s = e.tests[t.value].key,
                  n = e.testResults,
                  a = (n[s], (0, T.Z)(n, [s].map(D)));
                return M(
                  M({}, e),
                  {},
                  {
                    tests: [
                      ...e.tests.slice(0, t.value),
                      ...e.tests.slice(t.value + 1),
                    ],
                    testResults: a,
                  }
                );
              case g.LM: {
                const r = t.value,
                  s = r.testKey,
                  n = r.test,
                  a = e.tests.findIndex((e) => e.key === s);
                return null == a
                  ? (c.Z.warn(
                      `Tried to update unit test with ${s} but could not find it`
                    ),
                    e)
                  : M(
                      M({}, e),
                      {},
                      {
                        tests: [
                          ...e.tests.slice(0, a),
                          M(M({}, e.tests[a]), n),
                          ...e.tests.slice(a + 1),
                        ],
                      }
                    );
              }
              case g.mo:
                const i = t.value.oldIndex,
                  o = t.value.newIndex;
                return (
                  (r = e.tests.slice()),
                  r.splice(o, 0, r.splice(i, 1)[0]),
                  M(M({}, e), {}, { tests: r })
                );
              case g.p2:
                return M(M({}, e), {}, { testsRunning: !0 });
              case g.lZ:
                return M(M({}, e), {}, { testsRunning: !1 });
              case g.ES: {
                const r = t.value,
                  s = r.testKey,
                  n = r.error,
                  a = r.steps,
                  i = r.time;
                return M(
                  M({}, e),
                  {},
                  {
                    testResults: M(
                      M({}, e.testResults),
                      {},
                      {
                        [s]: {
                          error: n,
                          hasError: !!n,
                          steps: a || null,
                          time: i,
                        },
                      }
                    ),
                  }
                );
              }
              case g.Jb:
                return M(M({}, e), {}, { testFilter: t.value });
              default:
                return e;
            }
          };
        var G = r(9599);
        function V(e) {
          const t = e.getState().settings.theme;
          e.dispatch((0, G.Z)(t === S.B7 ? B() : t));
        }
        function B() {
          var e, t, r;
          return null !== (e = window) &&
            void 0 !== e &&
            null !== (t = e.matchMedia) &&
            void 0 !== t &&
            null !== (r = t.call(e, "(prefers-color-scheme: dark)")) &&
            void 0 !== r &&
            r.matches
            ? S.Py
            : S.rp;
        }
        var q = r(34595);
        function H(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function $(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? H(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : H(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const z = {
            permalinkFragment: null,
            version: null,
            deleteCode: null,
            userId: null,
            email: null,
            profilePicture: null,
            serviceProvider: null,
            isFavorite: !1,
            isLibraryEntry: !1,
            title: null,
            documentTitle: q.DEFAULT_PAGE_TITLE,
            metaDescription: q.DEFAULT_META_DESCRIPTION,
            tags: [],
            cookie: "",
            sponsorData: null,
            currentTheme: S.B7,
            permalinkIsEditable: !0,
            isOwner: !1,
          },
          W = function (e = z, t = {}) {
            switch (t.type) {
              case g._:
                return $($({}, e), {}, { permalinkIsEditable: t.value });
              case g.jo:
                return $(
                  $({}, e),
                  {},
                  { currentTheme: t.value.theme === S.B7 ? B() : t.value.theme }
                );
              case g.yM:
                return $($({}, e), {}, { currentTheme: t.value });
              case g.qI:
                return $($({}, e), {}, { sponsorData: t.value || null });
              case g.nU:
                const r = t.value,
                  s = r.permalinkFragment,
                  n = r.version,
                  a = r.deleteCode,
                  i = void 0 === a ? e.deleteCode : a,
                  o = r.isLibraryEntry,
                  c = void 0 === o ? e.isLibraryEntry : o,
                  l = r.title,
                  u = void 0 === l ? e.title : l,
                  h = r.tags,
                  p = void 0 === h ? e.tags : h,
                  d = r.isOwner,
                  m = void 0 === d ? e.isOwner : d;
                return $(
                  $({}, e),
                  {},
                  {
                    error: null,
                    isFavorite: s === e.permalinkFragment && e.isFavorite,
                    permalinkFragment: s,
                    version: n,
                    deleteCode: i,
                    isLibraryEntry:
                      c || (s === e.permalinkFragment && e.isLibraryEntry),
                    title: u,
                    tags: p,
                    isOwner: m,
                    permalinkIsEditable: !0,
                  }
                );
              case g.RT:
                const f = t.value,
                  x = f.userId,
                  b = f.email,
                  v = f.profilePicture,
                  j = f.serviceProvider;
                return $(
                  $({}, e),
                  {},
                  { userId: x, email: b, profilePicture: v, serviceProvider: j }
                );
              case g.yF:
                return $($({}, e), {}, { isFavorite: t.value });
              case g.th:
                return $($({}, e), {}, { cookie: t.value });
              case g.yB:
                return $($({}, e), {}, { deleteCode: t.value });
              case g.se:
                return $($({}, e), {}, { title: t.value });
              case g.CN:
                return $($({}, e), {}, { tags: t.value });
              case g.ol:
                return $($({}, e), {}, { documentTitle: t.value });
              case g.lK:
                return $($({}, e), {}, { metaDescription: t.value });
              default:
                return e;
            }
          };
        var Y = r(60370);
        const K = ["itemIndex"];
        function J(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function X(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? J(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : J(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Q = { data: [], pages: 0, allTags: [], staleData: !0 };
        function ee(e, t, r) {
          return { data: [...e.data.slice(0, t), r, ...e.data.slice(t + 1)] };
        }
        const te = function (e = Q, t = {}) {
          switch (t.type) {
            case g.sH:
              return X(X({}, e), t.value);
            case g.Ht:
              const r = t.value,
                s = r.itemIndex,
                n = (0, T.Z)(r, K),
                a = X(X({}, e.data[s]), n);
              return X(X({}, e), ee(e, s, a));
            case g.Xm:
              const i = t.value,
                o = i.itemIndex,
                c = i.tags,
                l = X(X({}, e.data[o]), {}, { tags: [...c] }),
                u = (0, Y.Z)(e.allTags.concat(c));
              return X(X(X({}, e), ee(e, o, l)), {}, { allTags: u });
            case g.go:
              return Q;
            default:
              return e;
          }
        };
        function re(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function se(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? re(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : re(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const ne = { libraryData: [], pages: 0, details: null };
        function ae(e, t) {
          let r = e.userVote > 0 ? e.upvotes - 1 : e.upvotes,
            s = e.userVote < 0 ? e.downvotes - 1 : e.downvotes;
          return (
            t > 0 ? r++ : t < 0 && s++,
            se(se({}, e), {}, { userVote: t, upvotes: r, downvotes: s })
          );
        }
        const ie = function (e = ne, t = {}) {
          switch (t.type) {
            case g.b9:
              const r = t.value,
                s = r.libraryData,
                n = r.pages;
              return se(se({}, e), {}, { libraryData: s, pages: n });
            case g.BS:
              const a = t.value,
                i = a.vote,
                o = a.permalinkFragment,
                c = e.libraryData.findIndex((e) => e.permalinkFragment === o);
              return -1 === c || null == e.libraryData[c]
                ? e
                : se(
                    se({}, e),
                    {},
                    {
                      libraryData: [
                        ...e.libraryData.slice(0, c),
                        ae(e.libraryData[c], i),
                        ...e.libraryData.slice(c + 1),
                      ],
                    }
                  );
            case g.mX:
              return se(se({}, e), {}, { details: t.value });
            default:
              return e;
          }
        };
        function oe(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function ce(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? oe(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : oe(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const le = { title: null, description: null, author: null },
          ue = function (e = le, t = {}) {
            if (t.type === g.DE) {
              const r = t.value,
                s = r.title,
                n = r.description,
                a = r.author;
              return ce(ce({}, e), {}, { title: s, description: n, author: a });
            }
            return e;
          },
          he = ["taskIdx"];
        function pe(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function de(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? pe(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : pe(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const ge = { allTasks: [] },
          me = function (e = ge, t = {}) {
            switch (t.type) {
              case g.te:
                return de(
                  de({}, e),
                  {},
                  {
                    allTasks: t.value.reduce(
                      (t, r, s) =>
                        e.allTasks[s]
                          ? [...t, de(de({}, e.allTasks[s]), r)]
                          : [...t, r],
                      []
                    ),
                  }
                );
              case g.nA:
                const r = t.value,
                  s = r.errorMessage,
                  n = r.testNumber,
                  a = r.totalTests;
                return de(
                  de({}, e),
                  {},
                  {
                    allTasks: [
                      ...e.allTasks.slice(0, t.value.taskNumber),
                      de(
                        de({}, e.allTasks[t.value.taskNumber]),
                        {},
                        { errorMessage: s, failingTestNumber: n, totalTests: a }
                      ),
                      ...e.allTasks.slice(t.value.taskNumber + 1),
                    ],
                  }
                );
              case g.Sb:
                const i = t.value,
                  o = i.taskNumber,
                  c = i.successMessage;
                return de(
                  de({}, e),
                  {},
                  {
                    allTasks: [
                      ...e.allTasks.slice(0, o),
                      de(
                        de({}, e.allTasks[o]),
                        {},
                        { successMessage: c, errorMessage: null, hasSolved: !0 }
                      ),
                      ...e.allTasks.slice(o + 1),
                    ],
                  }
                );
              case g.F:
                const l = t.value,
                  u = l.taskIdx,
                  h = (0, T.Z)(l, he);
                return de(
                  de({}, e),
                  {},
                  {
                    allTasks: [
                      ...e.allTasks.slice(0, u),
                      de(
                        de({}, e.allTasks[u]),
                        {},
                        { latest: de(de({}, e.allTasks[u].latest), h) }
                      ),
                      ...e.allTasks.slice(u + 1),
                    ],
                  }
                );
              case g.$Z:
                const p = t.value,
                  d = p.taskIdx,
                  m = p.stats;
                return de(
                  de({}, e),
                  {},
                  {
                    allTasks: [
                      ...e.allTasks.slice(0, d),
                      de(de({}, e.allTasks[d]), {}, { stats: m }),
                      ...e.allTasks.slice(d + 1),
                    ],
                  }
                );
              default:
                return e;
            }
          };
        function fe(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function xe(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? fe(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : fe(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const be = {
            tokens: [],
            subpatterns: [],
            captureGroupMap: {},
            captureGroupCount: 0,
            status: null,
            definedSubpatterns: [],
          },
          ve = function (e = be, t = {}) {
            return t.type === g.NJ ? xe(xe({}, e), t.value) : e;
          };
        var je = r(14850);
        const ye = function (e, t) {
          const r = {};
          return t.forEach((t) => (r[t] = e[t])), r;
        };
        var Oe = r(58317),
          we = r(31807),
          Ce = r.n(we);
        const Ee = (e, t) => Ze(e, t);
        function Ze(...e) {
          const t = (e) => e && "object" == typeof e;
          return e.reduce(
            (e, r) => (
              Object.keys(r).forEach((s) => {
                const n = e[s],
                  a = r[s];
                Array.isArray(a)
                  ? (e[s] = a)
                  : t(n) && t(a)
                  ? (e[s] = Ze(n, a))
                  : (e[s] = a);
              }),
              e
            ),
            {}
          );
        }
        const Se = {
          [g.rx]: {
            reducersToSave: ["settings", "rightSidebar"],
            key: q.STATE_STORAGE_KEY,
          },
          [g.xw]: {
            reducersToSave: ["regexEditor"],
            key: q.STATE_TEMP_REGEX_EDITOR_KEY,
          },
        };
        var ke = r(2043),
          Pe = r.n(ke),
          Ne = r(19272);
        function _e() {
          (0, Ne.initialize)("UA-33878479-1");
        }
        var Te = r(76493),
          Ae = r.n(Te);
        function Ie() {
          const e = /test/,
            t = void 0 !== e.unicode,
            r = void 0 !== e.dotAll;
          let s = void 0 !== e.sticky;
          const n = void 0 !== e.hasIndices;
          try {
            "aaa".match(/^a/gy).length > 1 &&
              ((s = !1),
              c.Z.warn(
                "Sticky flag for JS has been disabled as behavior in this browser is non-standard"
              ));
          } catch (e) {
            c.Z.warn("Unable to test for sticky flag, continuing...");
          }
          Ae().extendFlags(
            j().JAVASCRIPT,
            (s ? "y" : "") + (t ? "u" : "") + (r ? "s" : "") + (n ? "d" : "")
          );
        }
        var Re = r(35425);
        function De() {
          try {
            new RegExp("(?<=test)regex").test("testregex") && (0, Re.wx)();
          } catch (e) {
            c.Z.warn(
              "This browser does not have lookbehind support for the javascript flavor"
            );
          }
          try {
            new RegExp("(?<name>test)").test("test") && (0, Re.fg)();
          } catch (e) {
            c.Z.warn(
              "This browser does not have named group support for the javascript flavor"
            );
          }
          try {
            new RegExp("\\p{Letter}", "u").test("test") && (0, Re.IP)();
          } catch (e) {
            c.Z.warn(
              "This browser does not have named group support for the javascript flavor"
            );
          }
        }
        var Le = r(94500);
        function Me(e) {
          const t = e.getState().general.permalinkFragment;
          if (!t) return;
          const r = (0, Le.$Z)(t);
          r && e.dispatch((0, je.Ky)(r));
        }
        function Ue() {
          "serviceWorker" in navigator &&
            window.addEventListener("load", () => {
              navigator.serviceWorker.register("/sw.js").then(
                () => c.Z.info("Successfully registered service worker"),
                (e) =>
                  c.Z.warn(
                    "Unable to initializer service worker, proceeding.",
                    e
                  )
              );
            });
        }
        var Fe = r(14144),
          Ge = r.n(Fe);
        function Ve(e) {
          const t = Oe.Z.get("regex101-sponsor"),
            r = (!Array.isArray(t) && t) || null;
          if (r) {
            const e = new Date().toDateString();
            Object.keys(r).forEach((t) => {
              const s = r[t];
              new Date(s.lastSeen).toDateString() !== e &&
                ((s.lastSeen = new Date()), (s.todayCount = 0));
            });
          }
          const s =
            "https://srv.buysellads.com/ads/CESIEKJM.json" +
            (r
              ? "?freqcap=" +
                Object.keys(r)
                  .map((e) => {
                    const t = r[e],
                      s = t.allTimeCount;
                    return `${e}:${t.todayCount},${s}`;
                  })
                  .join(";")
              : "");
          Ge()(s)
            .then((e) => e.json())
            .then((t) => {
              t &&
                t.ads &&
                Array.isArray(t.ads) &&
                e.dispatch(
                  (0, je.IU)(
                    r,
                    t.ads.find((e) => !(null == e || !e.statlink))
                  )
                );
            })
            .catch((t) => {
              Pe().error("Unable to load sponsor data", t),
                e.dispatch({ type: g.qI, value: { adBlock: !0 } });
            });
        }
        async function Be(e) {
          const t = e.getState().settings.language;
          null != t && "ENGLISH" !== t && (await e.dispatch((0, je.BF)(t, !1)));
        }
        function qe() {
          document.body.addEventListener("mousedown", () => {
            document.body.classList.remove("using-keyboard");
          }),
            document.body.addEventListener("keydown", (e) => {
              ("Tab" !== e.key && 9 !== e.which && 9 !== e.keyCode) ||
                document.body.classList.add("using-keyboard");
            });
        }
        function He() {
          Oe.Z.delete(q.STATE_TEMP_REGEX_EDITOR_KEY);
        }
        var $e = r(4844),
          ze = r(67294),
          We = r(93942),
          Ye = r(39711),
          Ke = r(96974),
          Je = r(94184),
          Xe = r.n(Je),
          Qe = r(424),
          et = r(53808),
          tt = r(25968),
          rt = r(63101),
          st = r(98152),
          nt = r(79352),
          at = r(47516),
          it = r(5434),
          ot = r(82935),
          ct = r(41163);
        const lt = "mNcTS",
          ut = "j_FSe";
        var ht = r(85893);
        const pt = parseFloat(ct.bP),
          dt = ({ noClick: e, className: t }) => {
            const r = (0, ot.Z)(pt);
            return (
              r.width,
              (0, ht.jsx)("h1", {
                children: (0, ht.jsxs)(rt.rU, {
                  className: Xe()("djxIS", e && "SZppj", t),
                  to: "/",
                  absolute: !0,
                  tabIndex: e ? -1 : 0,
                  "aria-label": "regular expressions 101",
                  children: [
                    pt >= r.width
                      ? (0, ht.jsxs)(ht.Fragment, {
                          children: [
                            (0, ht.jsx)("span", {
                              className: lt,
                              children: "Reg",
                            }),
                            (0, ht.jsx)("span", {
                              className: ut,
                              children: "Ex",
                            }),
                          ],
                        })
                      : (0, ht.jsxs)(ht.Fragment, {
                          children: [
                            (0, ht.jsx)("span", {
                              className: lt,
                              children: "Regular",
                            }),
                            " ",
                            (0, ht.jsx)("span", {
                              className: ut,
                              children: "Expressions",
                            }),
                            " ",
                          ],
                        }),
                    (0, ht.jsx)("span", {
                      className: "kkc8H",
                      children: "101",
                    }),
                  ],
                }),
              })
            );
          };
        var gt = r(23543);
        const mt = parseFloat(ct.Pt),
          ft = (0, ze.forwardRef)(
            (
              {
                link: e,
                icon: t,
                text: r,
                label: s,
                className: n,
                direction: a = gt.qF.S,
                onClick: i,
              },
              o
            ) => {
              const c = (0, ot.Z)(mt);
              return mt >= c.width
                ? (0, ht.jsx)(rt.x6, {
                    to: e,
                    noTheme: !0,
                    absolute: !0,
                    target: "_blank",
                    tooltip: s,
                    onClick: i,
                    tooltipDirection: a,
                    size: 28,
                    className: Xe()("jm3JB", "v_pM0"),
                    ref: o,
                    children: (0, ht.jsx)(t, { className: n, size: 16 }),
                  })
                : (0, ht.jsxs)(rt.rU, {
                    className: "a4ddH",
                    to: e,
                    noTheme: !0,
                    absolute: !0,
                    target: "_blank",
                    "aria-label": s,
                    onClick: i,
                    children: [
                      (0, ht.jsx)(t, { className: Xe()("xfXAE", n), size: 14 }),
                      (0, ht.jsx)("span", { className: "t1rej", children: r }),
                    ],
                  });
            }
          ),
          xt = (0, ze.memo)(ft);
        var bt = r(3262),
          vt = r(91536),
          jt = r(58461),
          yt = r(95712);
        const Ot = ["fallback", "className"];
        function wt(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Ct(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? wt(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : wt(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Et = Ce()
            ? (0, ze.lazy)(() =>
                Promise.all([r.e(215), r.e(101)]).then(r.bind(r, 44652))
              )
            : () => {},
          Zt = (e) => {
            let t = e.fallback,
              r = e.className,
              s = (0, T.Z)(e, Ot);
            const n = (0, ht.jsxs)("div", {
              className: Xe()("GIfGY", r),
              children: [
                (0, ht.jsx)(rt.$j, { className: "V0n59", size: gt.J7.TC }),
                (0, ht.jsx)("div", {
                  className: "TnH56",
                  children: (0, et.Z)("Loading markdown..."),
                }),
              ],
            });
            return (0, ht.jsx)(rt.I2, {
              fallback: t || n,
              children: (0, ht.jsx)(Et, Ct(Ct({}, s), {}, { className: r })),
            });
          },
          St = ({ isOpen: e, onModalClose: t, title: r, textUrl: s }) => {
            const n = (0, ze.useState)(""),
              a = (0, st.Z)(n, 2),
              i = a[0],
              o = a[1],
              l = (0, ze.useState)({ isFetching: !1, fetchError: !1 }),
              u = (0, st.Z)(l, 2),
              h = u[0],
              p = u[1];
            (0, ze.useEffect)(() => {
              let t = null;
              return (
                e &&
                  (o(""),
                  p({ isFetching: !0, fetchError: !1 }),
                  (t = fetch(s)
                    .then((e) => e.text())
                    .then((e) => {
                      o(e), p({ isFetching: !1, fetchError: !1 });
                    })
                    .catch((e) => {
                      e.code !== DOMException.ABORT_ERR &&
                        (c.Z.error("Unable to fetch text", e),
                        p({ isFetching: !1, fetchError: !0 }));
                    }))),
                () => {
                  var e;
                  return null === (e = t) || void 0 === e ? void 0 : e.cancel();
                }
              );
            }, [e, s]);
            const d = (0, ht.jsxs)("div", {
              className: "e4TKI",
              children: [
                (0, ht.jsx)(rt.$j, { className: "emNHs" }),
                (0, ht.jsx)("div", {
                  className: "J0NvP",
                  children: (0, et.Z)("Loading content..."),
                }),
              ],
            });
            return (0, ht.jsxs)(bt.Z, {
              onModalClose: t,
              isOpen: e,
              children: [
                (0, ht.jsx)(vt.Z, { children: r }),
                (0, ht.jsxs)(jt.Z, {
                  children: [
                    h.isFetching && d,
                    h.fetchError &&
                      (0, ht.jsx)(rt.qX, {
                        type: gt.gr.pn,
                        children: (0, et.Z)(
                          "Unable to fetch content, please try again later"
                        ),
                      }),
                    !h.isFetching &&
                      !h.fetchError &&
                      (0, ht.jsx)(Zt, {
                        className: "pWUrQ",
                        fallback: d,
                        children: i,
                      }),
                  ],
                }),
                (0, ht.jsx)(yt.Z, {
                  children: (0, ht.jsx)(rt.zx, {
                    text: (0, et.Z)("Close"),
                    onClick: t,
                    type: gt.V5.n1,
                  }),
                }),
              ],
            });
          },
          kt = "Gceny",
          Pt = parseFloat(ct.p4),
          Nt = parseFloat(ct.D6),
          _t = ({
            alwaysCollapseLeftSidebar: e,
            alwaysCollapseRightSidebar: t,
          }) => {
            const r = (0, ot.Z)(Pt, Nt),
              s = (0, ze.useState)(!1),
              n = (0, st.Z)(s, 2),
              a = n[0],
              i = n[1],
              o = (0, Ke.TH)(),
              c = !/^\/(?:account.*|settings.*|library.*|quiz\/?)$/.test(
                o.pathname
              ),
              l = e || r.width < Pt,
              u = t || r.width < Nt;
            return (0, ht.jsxs)("header", {
              className: Xe()(kt, l && "V13Sk", c && u && "wlvok"),
              children: [
                (0, ht.jsx)(dt, { className: "ZPud1" }),
                (0, ht.jsxs)("div", {
                  className: "YxYLF",
                  children: [
                    (0, ht.jsx)(xt, {
                      className: "LTJnM",
                      label: (0, et.Z)("Follow me on twitter!"),
                      text: "@regex101",
                      icon: nt.x2F,
                      link: "https://twitter.com/regex101",
                    }),
                    (0, ht.jsx)(xt, {
                      className: "paRbz",
                      label: (0, et.Z)(
                        "Like regex101? Support it by donating!"
                      ),
                      text: (0, et.Z)("Donate"),
                      icon: at.pu9,
                      link: q.DONATION_LINK,
                    }),
                    (0, ht.jsx)(xt, {
                      className: "FRRzx",
                      label: (0, et.Z)("Become a sponsor!"),
                      text: (0, et.Z)("Sponsor"),
                      icon: nt.iB2,
                      link: q.SPONSOR_LINK,
                    }),
                    (0, ht.jsx)(xt, {
                      className: "azy0N",
                      label: (0, et.Z)("Send me an email"),
                      text: (0, et.Z)("Contact"),
                      icon: nt.YTS,
                      link: "mailto:contact@regex101.com",
                    }),
                    (0, ht.jsx)(xt, {
                      className: "h8KP1",
                      label: (0, et.Z)("Bugs or suggestions go here"),
                      text: (0, et.Z)("Bug Reports & Feedback"),
                      icon: it.mvF,
                      link: "https://github.com/firasdib/Regex101/issues",
                    }),
                    (0, ht.jsx)(xt, {
                      className: "x0HyW",
                      label: (0, et.Z)("Wiki (Info & FAQ)"),
                      text: (0, et.Z)("Wiki"),
                      icon: nt.qvv,
                      link: "https://github.com/firasdib/Regex101/wiki",
                    }),
                    (0, ht.jsx)(xt, {
                      direction: gt.qF.SW,
                      className: "OFFYM",
                      label: (0, et.Z)("Whats new?"),
                      text: (0, et.Z)("Whats new?"),
                      icon: nt.lBz,
                      link: "/static/assets/changelog.md",
                      onClick: (e) => {
                        e.preventDefault(), e.stopPropagation(), i(!0);
                      },
                    }),
                  ],
                }),
                (0, ht.jsx)(St, {
                  isOpen: a,
                  onModalClose: () => i(!1),
                  textUrl: "/static/assets/changelog.md",
                  title: (0, et.Z)("What's new?"),
                }),
              ],
            });
          },
          Tt = (0, ze.memo)(_t);
        var At = r(70872),
          It = r(74387);
        const Rt = (0, At.Z)(It.ug),
          Dt = { exit: "uKbj5", exitActive: "xPMjQ" },
          Lt = () => {
            const e = (0, ze.useState)(!0),
              t = (0, st.Z)(e, 2),
              r = t[0],
              s = t[1],
              n = (0, ze.useState)(!0),
              a = (0, st.Z)(n, 2),
              i = a[0],
              o = a[1];
            return (
              (0, ze.useEffect)(
                () => (
                  tt.ZP.once(tt.En, () => {
                    s(!1), setTimeout(() => o(!1), Rt);
                  }),
                  () => clearTimeout(void 0)
                ),
                []
              ),
              i
                ? (0, ht.jsx)(rt.uT, {
                    className: Xe()("QzY4i", !r && "sr6nN"),
                    classNames: Dt,
                    appear: !1,
                    enter: !1,
                    timeout: Rt,
                    in: r,
                    children: (0, ht.jsxs)("div", {
                      className: "sNjVA",
                      children: [
                        (0, ht.jsx)("div", {
                          className: kt,
                          children: (0, ht.jsx)(dt, { noClick: !0 }),
                        }),
                        (0, ht.jsxs)("div", {
                          className: "GwqPG",
                          children: [
                            (0, ht.jsx)(rt.$j, {}),
                            (0, ht.jsx)("div", {
                              className: "RIMEV",
                              children: (0, et.Z)(
                                "Please wait while the app is loading..."
                              ),
                            }),
                          ],
                        }),
                        (0, ht.jsx)(rt.A5, {}),
                      ],
                    }),
                  })
                : null
            );
          },
          Mt = (0, ze.memo)(Lt);
        var Ut = r(43406),
          Ft = r(54430),
          Gt = r(23584);
        const Vt = "wcfss",
          Bt = () => {
            const e = (0, We.I0)(),
              t = (0, ze.useState)(!1),
              r = (0, st.Z)(t, 2),
              s = r[0],
              n = r[1],
              a = (0, We.v9)((e) => e.regexEditor.flavor),
              i = (0, We.v9)((e) => e.regexEditor.flags),
              o = (0, ze.useCallback)(
                (t) => {
                  (0, Ne.event)({
                    category: "regexFlavor",
                    action: `Selected ${t.toLowerCase()} flavor`,
                  });
                  const r = O()[t][0];
                  e(je.o6(t)), e(je.G6(r)), e(je.dL(i, i, t));
                },
                [e, i]
              ),
              c = (0, ze.useCallback)((e) => {
                e.preventDefault(), n(!0);
              }, []),
              l = (0, ze.useCallback)(() => n(!1), []);
            return (0, ht.jsxs)(Ft.Z, {
              className: Vt,
              header: (0, et.Z)("Flavor"),
              headerChildren: (0, ht.jsx)(Gt.Z, {
                to: "/static/assets/flavors.md",
                onClick: c,
                className: "IC7U1",
                tooltip: (0, et.Z)("Need help selecting flavor?"),
                size: 16,
                children: (0, ht.jsx)(nt.zXH, { size: 16 }),
              }),
              children: [
                (0, ht.jsx)(Ut.Z, {
                  icon: nt.mV1,
                  onClick: () => o(j().PCRE2),
                  isActive: a === j().PCRE2,
                  children: "PCRE2 (PHP >=7.3)",
                }),
                (0, ht.jsxs)(Ut.Z, {
                  icon: nt.mV1,
                  onClick: () => o(j().PCRE),
                  isActive: a === j().PCRE,
                  children: ["PCRE (PHP ", "<7.3", ")"],
                }),
                (0, ht.jsx)(Ut.Z, {
                  icon: nt.mV1,
                  onClick: () => o(j().JAVASCRIPT),
                  isActive: a === j().JAVASCRIPT,
                  children: "ECMAScript (JavaScript)",
                }),
                (0, ht.jsx)(Ut.Z, {
                  icon: nt.mV1,
                  onClick: () => o(j().PYTHON),
                  isActive: a === j().PYTHON,
                  children: "Python",
                }),
                (0, ht.jsx)(Ut.Z, {
                  icon: nt.mV1,
                  onClick: () => o(j().GOLANG),
                  isActive: a === j().GOLANG,
                  children: "Golang",
                }),
                (0, ht.jsx)(Ut.Z, {
                  icon: nt.mV1,
                  onClick: () => o(j().JAVA),
                  isActive: a === j().JAVA,
                  children: "Java 8",
                }),
                (0, ht.jsx)(Ut.Z, {
                  icon: nt.mV1,
                  onClick: () => o(j().DOTNET),
                  isActive: a === j().DOTNET,
                  children: ".NET (C#)",
                }),
                (0, ht.jsx)(St, {
                  title: (0, et.Z)("Flavor Help"),
                  onModalClose: l,
                  textUrl: "/static/assets/flavors.md",
                  isOpen: s,
                }),
              ],
            });
          };
        var qt = r(80471),
          Ht = r(12037),
          $t = r(34768),
          zt = r(35383),
          Wt = r(86135);
        const Yt = "PEVyC",
          Kt = [
            "children",
            "icon",
            "absolute",
            "to",
            "className",
            "isDisabled",
          ];
        function Jt(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Xt(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Jt(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Jt(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Qt = (e) => {
            let t = e.children,
              r = e.icon,
              s = e.absolute,
              n = e.to,
              a = e.className,
              i = e.isDisabled,
              o = (0, T.Z)(e, Kt);
            return (0, ht.jsx)(
              zt.Z,
              Xt(
                Xt({ isDisabled: i, className: a }, o),
                {},
                {
                  children: (0, ht.jsx)(rt.rU, {
                    tabIndex: i ? -1 : void 0,
                    to: n,
                    absolute: s,
                    className: Yt,
                    noTheme: !0,
                    children: (0, ht.jsx)(Wt.Z, {
                      icon: r,
                      children: t,
                      className: a,
                    }),
                  }),
                }
              )
            );
          },
          er = (0, ze.memo)(Qt);
        var tr = r(87287);
        function rr(e, t = 1) {
          return e ? `/r/${e}/${t}` : "/";
        }
        var sr = r(17563);
        const nr = "SOmBr",
          ar = "UfPXv",
          ir = ({
            text: e,
            onDelete: t,
            clickable: r = !1,
            index: s,
            size: n = gt.J7.M2,
            isSelected: a = !1,
            to: i,
          }) => {
            const o = Xe()(
              "iFPCp",
              t && "EvQAt",
              r && "LNuoU",
              n === gt.J7.M2 && "sDfVp",
              n === gt.J7.HC && "k7DPw",
              a && "ociUu"
            );
            return t
              ? (0, ht.jsx)(rt.Yd, {
                  className: o,
                  onClick: () => t(s),
                  children: (0, ht.jsxs)("div", {
                    className: "i_U6u",
                    children: [
                      (0, ht.jsx)("div", { className: ar, children: e }),
                      t && (0, ht.jsx)(nt.eSQ, { className: nr }),
                    ],
                  }),
                })
              : r
              ? (0, ht.jsx)(rt.rU, {
                  className: o,
                  to: i,
                  noTheme: !0,
                  children: e,
                })
              : (0, ht.jsxs)("span", {
                  className: o,
                  children: [
                    (0, ht.jsx)("span", { className: ar, children: e }),
                    t && (0, ht.jsx)(nt.eSQ, { className: nr }),
                  ],
                });
          },
          or = (0, ze.memo)(ir),
          cr = ["className", "tags", "ignoreEmpty"];
        function lr(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function ur(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? lr(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : lr(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const hr = (e) => {
            let t = e.className,
              r = e.tags,
              s = e.ignoreEmpty,
              n = (0, T.Z)(e, cr);
            const a = (0, Ke.TH)();
            if (0 === r.length)
              return s
                ? null
                : (0, ht.jsx)(rt.qX, {
                    children: (0, et.Z)(
                      "You have no tags yet, add some and organize your entries!"
                    ),
                  });
            const i = sr.parse(a.search),
              o = [].concat(i.filterTags || []);
            return (0, ht.jsx)("div", {
              className: Xe()("e_47g", t),
              children: r.sort().map((e, t) => {
                const r = o.includes(e),
                  s = ur(
                    ur({}, a),
                    {},
                    {
                      search: sr.stringify(
                        ur(
                          ur({}, i),
                          {},
                          {
                            filterTags: r
                              ? o.filter((t) => t !== e)
                              : [...o, e],
                          }
                        )
                      ),
                    }
                  );
                return (0, ht.jsx)(
                  or,
                  ur({ text: e, index: t, isSelected: r, to: s }, n),
                  `tag-${t}`
                );
              }),
            });
          },
          pr = (0, ze.memo)(hr),
          dr = "EHJke",
          gr = ({
            title: e = "",
            tags: t = [],
            onTagsChange: r,
            onTitleChange: s,
            disabled: n,
            className: a,
          }) => {
            const i = (0, ze.useState)(""),
              o = (0, st.Z)(i, 2),
              c = o[0],
              l = o[1],
              u = (0, ze.useCallback)((e) => l(e), []),
              h = (e) => {
                e.stopPropagation(),
                  e.preventDefault(),
                  c.length > 0 && r([...t, c]),
                  l("");
              };
            return (0, ht.jsxs)("div", {
              className: Xe()("b_UzD", n && "ICuz5", a),
              children: [
                (0, ht.jsxs)("div", {
                  className: dr,
                  children: [
                    (0, ht.jsx)(rt.__, {
                      text: (0, et.Z)("Edit personal title"),
                    }),
                    (0, ht.jsx)(rt.oi, {
                      value: e,
                      onChange: s,
                      placeholder: (0, et.Z)("Insert a personal title"),
                      maxlength: 150,
                    }),
                  ],
                }),
                (0, ht.jsxs)("div", {
                  className: dr,
                  children: [
                    (0, ht.jsx)(rt.__, { text: (0, et.Z)("Tags") }),
                    (0, ht.jsx)(pr, {
                      tags: t,
                      onDelete: (e) => r([...t.slice(0, e), ...t.slice(e + 1)]),
                    }),
                  ],
                }),
                (0, ht.jsxs)("form", {
                  className: "ECIrE",
                  onSubmit: h,
                  children: [
                    (0, ht.jsx)(rt.__, { text: (0, et.Z)("Add tag") }),
                    (0, ht.jsxs)("div", {
                      className: "MPX5Z",
                      children: [
                        (0, ht.jsx)(rt.oi, {
                          onChange: u,
                          placeholder: (0, et.Z)(
                            "Any word can be used as a tag"
                          ),
                          value: c,
                          maxlength: 125,
                          className: "GoqIP",
                          validation: /^\w*$/u,
                        }),
                        (0, ht.jsx)(rt.hU, {
                          tooltip: (0, et.Z)("Add tag"),
                          className: "fyf3i",
                          disabled: 0 === c.length,
                          size: 28,
                          onClick: h,
                          children: (0, ht.jsx)(nt.p22, { size: 22 }),
                        }),
                      ],
                    }),
                  ],
                }),
              ],
            });
          },
          mr = "LrAFA",
          fr = "Tpbre",
          xr = ({
            permalink: e,
            error: t,
            userId: r,
            isOwner: s,
            deleteCode: n,
            isLoading: a,
          }) =>
            t
              ? (0, ht.jsx)("div", {
                  className: mr,
                  children: (0, ht.jsx)(rt.qX, {
                    type: gt.gr.pn,
                    children: (0, et.Z)(
                      "There was an error trying to save your regex. Please try again later."
                    ),
                  }),
                })
              : a
              ? (0, ht.jsxs)("div", {
                  className: mr,
                  children: [
                    (0, ht.jsx)(rt.$j, {}),
                    (0, ht.jsx)("div", {
                      className: "BjqNv",
                      children: (0, et.Z)(
                        "Please wait while your request is being processed..."
                      ),
                    }),
                  ],
                })
              : (0, ht.jsxs)("div", {
                  children: [
                    (0, ht.jsx)(rt.__, {
                      text: (0, et.Z)("Link to regular expression"),
                    }),
                    (0, ht.jsx)(rt.oi, {
                      type: "text",
                      value: e,
                      selectOnMount: !0,
                      selectOnFocus: !0,
                      readOnly: !0,
                      copyButton: !0,
                    }),
                    (0, ht.jsx)(rt.qX, {
                      className: fr,
                      children: (0, et.Z)(
                        "Your regex has been permanently saved and may be accessed with this link by anybody you give it to."
                      ),
                    }),
                    null != r &&
                      s &&
                      (0, ht.jsx)(rt.qX, {
                        className: fr,
                        children: (0, et.Z)(
                          "The entry has automatically been added to your account which means you can at any time delete this entry, make it private and much much more."
                        ),
                      }),
                    null == r &&
                      s &&
                      null != n &&
                      (0, ht.jsxs)("div", {
                        className: "XXWwF",
                        children: [
                          (0, ht.jsx)(rt.__, {
                            text: (0, et.Z)("Delete regular expression"),
                          }),
                          (0, ht.jsx)(rt.oi, {
                            type: "text",
                            value: `${window.location.protocol}//${window.location.hostname}/delete/${n}`,
                            readOnly: !0,
                            copyButton: !0,
                            selectOnFocus: !0,
                          }),
                          (0, ht.jsx)(rt.qX, {
                            className: fr,
                            children: (0, et.Z)(
                              "Because you are not signed in this entry has not been tied to an account. It is recommended you sign in so that your entries are never lost and you can manage them from the account page whenever you like."
                            ),
                          }),
                        ],
                      }),
                  ],
                }),
          br = (0, ze.memo)(xr),
          vr = [],
          jr = ({ isUpdating: e, onModalClose: t, isOpen: r }) => {
            const s = (0, Ke.s0)(),
              n = (0, We.I0)(),
              a = (0, We.v9)((e) => e.general.permalinkFragment),
              i = (0, We.v9)((e) => e.general.userId),
              o = (0, We.v9)((e) => e.general.title) || "",
              l = (0, We.v9)((e) => e.general.tags) || vr,
              u = (0, We.v9)((e) => e.general.isOwner),
              h = (0, We.v9)((e) => e.general.isFavorite),
              p = (0, ze.useState)(!1),
              d = (0, st.Z)(p, 2),
              g = d[0],
              m = d[1],
              f = (0, ze.useState)(o),
              x = (0, st.Z)(f, 2),
              b = x[0],
              v = x[1],
              j = (0, ze.useState)(l),
              y = (0, st.Z)(j, 2),
              O = y[0],
              w = y[1],
              C = (0, ze.useState)({
                isLoadingRegex: !1,
                hasRegexError: !1,
                isLoadingAcc: !1,
                hasAccError: !1,
              }),
              E = (0, st.Z)(C, 2),
              Z = E[0],
              S = E[1],
              k = (0, ze.useState)(null),
              P = (0, st.Z)(k, 2),
              N = P[0],
              _ = P[1],
              T = (0, ze.useState)(null),
              A = (0, st.Z)(T, 2),
              I = A[0],
              R = A[1],
              D = (0, ze.useState)(!1),
              L = (0, st.Z)(D, 2),
              M = L[0],
              U = L[1];
            (0, ze.useEffect)(() => {
              r && (U(!1), m(!1), _(null), R(null));
            }, [r]);
            const F = (0, ze.useCallback)((e) => {
                w(e), m(!0);
              }, []),
              G = (0, ze.useCallback)((e) => {
                v(e), m(!0);
              }, []);
            (0, ze.useEffect)(() => {
              v(o), w(l);
            }, [l, o]),
              (0, ze.useEffect)(() => {
                r &&
                  !M &&
                  (U(!0),
                  S({
                    isLoadingRegex: !0,
                    hasRegexError: !1,
                    isLoadingAcc: !1,
                    hasAccError: !1,
                  }),
                  n((0, je.by)(e))
                    .then((e) => {
                      const t = rr(e.permalinkFragment, e.version);
                      s(t, { replace: !0 }),
                        _(
                          `${window.location.protocol}//${window.location.hostname}${t}`
                        ),
                        R(e.deleteCode),
                        S({
                          isLoadingAcc: !1,
                          isLoadingRegex: !1,
                          hasAccError: !1,
                          hasRegexError: !1,
                        });
                    })
                    .catch((e) => {
                      c.Z.error("Unable to save regex", e),
                        S({
                          isLoadingAcc: !1,
                          isLoadingRegex: !1,
                          hasAccError: !1,
                          hasRegexError: !0,
                        });
                    }));
              }, [r, n, s, e, M]);
            const V = e
                ? (0, et.Z)("Update Regular Expression")
                : (0, et.Z)("Save Regular Expression"),
              B =
                !Z.isLoadingRegex && null != i && !Z.hasRegexError && (u || h);
            return (0, ht.jsxs)(bt.Z, {
              isOpen: r,
              onModalClose: t,
              isLoading: Z.isLoadingRegex || Z.isLoadingAcc,
              children: [
                (0, ht.jsx)(vt.Z, { children: V }),
                (0, ht.jsxs)(jt.Z, {
                  children: [
                    (0, ht.jsx)(br, {
                      error: Z.hasRegexError,
                      permalink: N,
                      userId: i,
                      isOwner: u,
                      deleteCode: I,
                      isLoading: Z.isLoadingRegex,
                    }),
                    B &&
                      N &&
                      (0, ht.jsx)(gr, {
                        title: b,
                        tags: O,
                        onTagsChange: F,
                        onTitleChange: G,
                        disabled: Z.isLoadingAcc,
                        className: "D7pB5",
                      }),
                  ],
                }),
                (0, ht.jsxs)(yt.Z, {
                  children: [
                    Z.isLoadingAcc &&
                      (0, ht.jsx)(rt.$j, {
                        className: "Yc0v9",
                        size: gt.J7.TC,
                      }),
                    Z.hasAccError &&
                      (0, ht.jsx)(rt.lx, {
                        text: (0, et.Z)(
                          "Unable to save changes, please try again"
                        ),
                        direction: gt.qF.N,
                        children: (0, ht.jsx)("div", {
                          className: "uYI6N",
                          role: "alert",
                          children: (0, ht.jsx)(nt.j6O, { size: 20 }),
                        }),
                      }),
                    B &&
                      (0, ht.jsx)(rt.zx, {
                        onClick: async () => {
                          S({
                            isLoadingRegex: !1,
                            hasRegexError: !1,
                            isLoadingAcc: !0,
                            hasAccError: !1,
                          });
                          try {
                            await Promise.all([
                              n((0, je.ML)(O, null, a)),
                              n((0, je._1)(b, null, a)),
                              new Promise((e) => setTimeout(e, 500)),
                            ]),
                              S({
                                isLoadingRegex: !1,
                                hasRegexError: !1,
                                isLoadingAcc: !1,
                                hasAccError: !1,
                              }),
                              t();
                          } catch (e) {
                            c.Z.error("Unable to save account data", e),
                              S({
                                isLoadingRegex: !1,
                                hasRegexError: !1,
                                isLoadingAcc: !1,
                                hasAccError: !0,
                              });
                          }
                        },
                        text: (0, et.Z)("Save"),
                        className: "JySmX",
                        disabled: !g,
                      }),
                    (0, ht.jsx)(rt.zx, {
                      type: gt.V5.n1,
                      onClick: t,
                      text: (0, et.Z)("Close"),
                    }),
                  ],
                }),
              ],
            });
          };
        function yr(e, t, r) {
          let s = 0;
          return ze.Children.map(e, (e) => {
            if ((0, ze.isValidElement)(e)) {
              const n = s;
              return s++, t.call(r, e, n);
            }
            return e;
          });
        }
        function Or(e, t) {
          let r;
          return (
            (function (e, t, r) {
              let s = 0;
              ze.Children.forEach(e, (e) => {
                (0, ze.isValidElement)(e) && (t.call(void 0, e, s), s++);
              });
            })(e, (s, n) => {
              !r && t(s, n, e) && (r = s);
            }),
            r
          );
        }
        var wr = r(45697),
          Cr = r.n(wr);
        const Er = ({ children: e }) => e;
        Er.propTypes = { children: Cr().node.isRequired };
        const Zr = Er,
          Sr = ({ children: e, className: t, tabs: r, renderToolbar: s }) => {
            const n = (0, ze.useState)(0),
              a = (0, st.Z)(n, 2),
              i = a[0],
              o = a[1];
            return (0, ht.jsxs)("div", {
              className: Xe()("xcnvY", t),
              children: [
                (0, ht.jsxs)("div", {
                  className: "JIZX7",
                  children: [
                    r.map((e, t) =>
                      (0, ht.jsx)(
                        rt.Yd,
                        {
                          className: Xe()("KDcqY", t === i && "hVcJX"),
                          onClick: () => o(t),
                          children: e,
                        },
                        `tabview-tab-${t}`
                      )
                    ),
                    s && s(i),
                  ],
                }),
                Or(e, (e, t) => i === t),
              ],
            });
          };
        var kr = r(89583);
        const Pr = {
            menuPortal: "tdkJ8",
            insideModal: "zXY8d",
            menuScroll: "NrXoa",
            menu: "f6YSB",
            enterBottom: "NrZNZ",
            enterTop: "MpxoU",
            enterActive: "uarNo",
            leave: "SSIhI",
            leaveActiveBottom: "oupK4",
            leaveActiveTop: "b8xoE",
          },
          Nr = [
            "className",
            "children",
            "target",
            "isOpen",
            "onMenuClose",
            "closeOnClick",
            "insideModal",
            "placement",
          ];
        function _r(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Tr(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? _r(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : _r(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Ar = (0, At.Z)(It.t2),
          Ir = (e) => {
            let t = e.className,
              r = e.children,
              s = e.target,
              n = e.isOpen,
              a = e.onMenuClose,
              i = e.closeOnClick,
              o = void 0 !== i && i,
              c = e.insideModal,
              l = e.placement,
              u = void 0 === l ? "bottom" : l,
              h = (0, T.Z)(e, Nr);
            const p = (0, ze.useRef)(null),
              d = (0, ze.useCallback)(
                (e) => {
                  e.stopPropagation(), a();
                },
                [a]
              );
            (0, ze.useEffect)(() => {
              let e;
              const t = (e) => {
                var t;
                (null !== (t = p.current) &&
                  void 0 !== t &&
                  t.contains(e.target)) ||
                  (null != s && s.contains(e.target)) ||
                  s === e.target ||
                  a();
              };
              return (
                n &&
                  (e = setTimeout(() => {
                    var e, r;
                    tt.ZP.once("key:escape", d),
                      null === (e = document.body) ||
                        void 0 === e ||
                        e.addEventListener("mousedown", t, { passive: !0 }),
                      null === (r = document.body) ||
                        void 0 === r ||
                        r.addEventListener("touchend", t, { passive: !0 });
                  }, Ar)),
                () => {
                  var r, s;
                  clearTimeout(e),
                    tt.ZP.off("key:escape", d),
                    null === (r = document.body) ||
                      void 0 === r ||
                      r.removeEventListener("mousedown", t, { passive: !0 }),
                    null === (s = document.body) ||
                      void 0 === s ||
                      s.removeEventListener("touchend", t, { passive: !0 });
                }
              );
            }, [n, a, s, d]);
            const g = {
              appear: "bottom" === u ? Pr.enterBottom : Pr.enterTop,
              appearActive: Pr.enterActive,
              enter: Pr.enter,
              enterActive: Pr.enterActive,
              exit: Pr.leave,
              exitActive:
                "bottom" === u ? Pr.leaveActiveBottom : Pr.leaveActiveTop,
            };
            return (0, ht.jsx)(rt.Yv, {
              className: Pr.menuPortal,
              target: s,
              isOpen: n,
              closeTimeout: Ar,
              placement: u,
              children: (0, ht.jsx)(
                rt.uT,
                Tr(
                  Tr(
                    {
                      className: Xe()(Pr.menu, t, c && Pr.insideModal),
                      classNames: g,
                      timeout: Ar,
                      in: n,
                      ref: p,
                    },
                    h
                  ),
                  {},
                  {
                    children: (0, ht.jsx)(rt.iQ, {
                      children: (0, ht.jsx)(ht.Fragment, {
                        children: yr(r, (e) => {
                          return (0, ze.cloneElement)(e, {
                            onClick:
                              e.props.onClick &&
                              ((t = e.props.onClick),
                              (e) => {
                                o && a(), null == t || t(e);
                              }),
                          });
                          var t;
                        }),
                      }),
                    }),
                  }
                )
              ),
            });
          },
          Rr = "TjiR_",
          Dr = "IQ0Dq",
          Lr = "i0q6u",
          Mr = "Ung4t",
          Ur = ["isActive", "children", "className"];
        function Fr(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Gr(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Fr(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Fr(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Vr = (e) => {
            let t = e.isActive,
              r = e.children,
              s = e.className,
              n = (0, T.Z)(e, Ur);
            return (0, ht.jsxs)(
              rt.Yd,
              Gr(
                Gr({ className: Xe()(Rr, s) }, n),
                {},
                {
                  children: [
                    (0, ht.jsx)("div", { className: Lr, children: r }),
                    (0, ht.jsx)(nt.xuy, {
                      size: 18,
                      className: Xe()(Dr, !t && Mr),
                    }),
                  ],
                }
              )
            );
          },
          Br = (0, ze.memo)(Vr),
          qr = ["text"];
        function Hr(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function $r(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Hr(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Hr(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const zr = (e) => {
            let t = e.text,
              r = (0, T.Z)(e, qr);
            return (0, ht.jsx)(
              "h4",
              $r($r({ className: "KMW6D" }, r), {}, { children: t })
            );
          },
          Wr = (0, ze.memo)(zr),
          Yr = () => (0, ht.jsx)("hr", { className: "dYvK9" }),
          Kr = ["isActive", "children", "className", "disabled"];
        function Jr(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Xr(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Jr(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Jr(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Qr = (e) => {
            let t = e.isActive,
              r = e.children,
              s = e.className,
              n = e.disabled,
              a = (0, T.Z)(e, Kr);
            return (0, ht.jsxs)(
              rt.rU,
              Xr(
                Xr(
                  {
                    className: Xe()(Rr, n && "roQ4U", s),
                    tabIndex: n ? -1 : void 0,
                    "aria-disabled": n,
                    noTheme: !0,
                  },
                  a
                ),
                {},
                {
                  children: [
                    (0, ht.jsx)("div", { className: Lr, children: r }),
                    (0, ht.jsx)(nt.xuy, {
                      size: 18,
                      className: Xe()(Dr, !t && Mr),
                    }),
                  ],
                }
              )
            );
          },
          es = (0, ze.memo)(Qr),
          ts = ["onHeaderClick"];
        function rs(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function ss(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? rs(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : rs(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const ns = (e) => {
            let t = e.onHeaderClick,
              r = (0, T.Z)(e, ts);
            return (0, ht.jsxs)(
              Ir,
              ss(
                ss({ closeOnClick: !0, insideModal: !0 }, r),
                {},
                {
                  children: [
                    (0, ht.jsx)(Wr, { text: (0, et.Z)("Headers") }),
                    (0, ht.jsx)(Yr, {}),
                    (0, ht.jsx)(Br, { onClick: () => t("# "), children: "H1" }),
                    (0, ht.jsx)(Br, {
                      onClick: () => t("## "),
                      children: "H2",
                    }),
                    (0, ht.jsx)(Br, {
                      onClick: () => t("### "),
                      children: "H3",
                    }),
                  ],
                }
              )
            );
          },
          as = ({ children: e }) =>
            (0, ht.jsx)("div", { className: "sswmd", children: e }),
          is = ["tooltip", "lastGroup", "icon", "isMenu"];
        function os(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function cs(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? os(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : os(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const ls = (0, ze.forwardRef)((e, t) => {
          let r = e.tooltip,
            s = e.lastGroup,
            n = e.icon,
            a = e.isMenu,
            i = (0, T.Z)(e, is);
          return (0, ht.jsx)(rt.lx, {
            text: r,
            direction: s ? gt.qF.NW : gt.qF.N,
            children: (0, ht.jsxs)(
              rt.Yd,
              cs(
                cs({ className: "rYU7E" }, i),
                {},
                {
                  ref: t,
                  children: [
                    (0, ht.jsx)(n, { className: "HJfpj" }),
                    a && (0, ht.jsx)(nt.ZXJ, { className: "wTcsC" }),
                  ],
                }
              )
            ),
          });
        });
        ls.propTypes = {
          tooltip: Cr().string.isRequired,
          icon: Cr().elementType.isRequired,
          onClick: Cr().func.isRequired,
          lastGroup: Cr().bool,
          isMenu: Cr().bool,
        };
        const us = ls,
          hs = ({
            onTextChange: e,
            className: t,
            getStart: r,
            getEnd: s,
            value: n,
          }) => {
            const a = (0, ze.useRef)(),
              i = (0, ze.useState)(!1),
              o = (0, st.Z)(i, 2),
              c = o[0],
              l = o[1],
              u = (t = "", n = "") => {
                const a = t + d() + n;
                e(p(a), r() + t.length, s() + t.length);
              },
              h = (t) => {
                const n = d(),
                  a = n.split("\n").map(t).join("\n");
                e(p(a), r(), s() + a.length - n.length);
              },
              p = (e) => n.substring(0, r()) + e + n.substring(s()),
              d = () => n.substring(r(), s());
            return (0, ht.jsxs)("div", {
              className: Xe()("CHR_O", t),
              children: [
                (0, ht.jsxs)(as, {
                  children: [
                    (0, ht.jsx)(us, {
                      icon: kr.YHB,
                      tooltip: (0, et.Z)("Add header"),
                      onClick: () => l(!0),
                      isMenu: !0,
                      ref: a,
                    }),
                    (0, ht.jsx)(us, {
                      icon: kr.PKR,
                      tooltip: (0, et.Z)("Add bold text"),
                      onClick: () => u("**", "**"),
                    }),
                    (0, ht.jsx)(us, {
                      icon: kr.Mef,
                      tooltip: (0, et.Z)("Add italic text"),
                      onClick: () => u("_", "_"),
                    }),
                  ],
                }),
                (0, ht.jsxs)(as, {
                  children: [
                    (0, ht.jsx)(us, {
                      icon: kr.fkU,
                      tooltip: (0, et.Z)("Insert quote"),
                      onClick: () => h((e) => "> " + e),
                    }),
                    (0, ht.jsx)(us, {
                      icon: kr.tvD,
                      tooltip: (0, et.Z)("Insert code snippet"),
                      onClick: () => {
                        -1 !== d().indexOf("\n")
                          ? h((e) => " ".repeat(4) + e)
                          : u("`", "`");
                      },
                    }),
                    (0, ht.jsx)(us, {
                      icon: kr.gjK,
                      tooltip: (0, et.Z)("Insert link"),
                      onClick: () => {
                        const t = d(),
                          s = `[${t}](url)`,
                          n = r() + t.length + 3,
                          a = n + 3;
                        e(p(s), n, a);
                      },
                    }),
                  ],
                }),
                (0, ht.jsxs)(as, {
                  children: [
                    (0, ht.jsx)(us, {
                      icon: kr.AeW,
                      tooltip: (0, et.Z)("Add bulleted list"),
                      onClick: () => h((e) => "- " + e),
                      lastGroup: !0,
                    }),
                    (0, ht.jsx)(us, {
                      icon: kr.Fe1,
                      tooltip: (0, et.Z)("Add numbered list"),
                      onClick: () => h((e, t) => t + 1 + ". " + e),
                      lastGroup: !0,
                    }),
                  ],
                }),
                (0, ht.jsx)(ns, {
                  isOpen: c,
                  onMenuClose: () => l(!1),
                  onHeaderClick: (e) => u(e),
                  target: a.current,
                }),
              ],
            });
          },
          ps = (0, ze.memo)(hs),
          ds = "YONkN",
          gs = "PhRac",
          ms = "FVje3",
          fs = [
            "defaultValue",
            "value",
            "onChange",
            "containerClassName",
            "className",
          ];
        function xs(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function bs(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? xs(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : xs(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const vs = (e) => {
            let t = e.defaultValue,
              r = e.value,
              s = e.onChange,
              n = (e.containerClassName, e.className),
              a = (0, T.Z)(e, fs);
            const i = (0, ze.useRef)(),
              o = (0, ze.useState)(t || r || ""),
              c = (0, st.Z)(o, 2),
              l = c[0],
              u = c[1],
              h = (0, ze.useCallback)(() => {
                var e;
                return (
                  (null === (e = i.current) || void 0 === e
                    ? void 0
                    : e.selectionStart) || 0
                );
              }, []),
              p = (0, ze.useCallback)(() => {
                var e;
                return (
                  (null === (e = i.current) || void 0 === e
                    ? void 0
                    : e.selectionEnd) || 0
                );
              }, []),
              d = (0, ze.useCallback)(
                (e) => {
                  u(e), s && s(e);
                },
                [s]
              ),
              g = (0, ze.useCallback)(
                (e, t, r) => {
                  s && s(e),
                    i.current &&
                      (u(e),
                      setTimeout(() => {
                        i.current &&
                          (i.current.focus(),
                          i.current.setSelectionRange(t, r));
                      }));
                },
                [s]
              ),
              m = [(0, et.Z)("Write"), (0, et.Z)("Preview")];
            return (0, ht.jsxs)(Sr, {
              className: n,
              tabs: m,
              renderToolbar: (e) =>
                0 !== e
                  ? null
                  : (0, ht.jsx)(ps, {
                      className: "MafZJ",
                      onTextChange: g,
                      getStart: h,
                      getEnd: p,
                      value: l,
                    }),
              children: [
                (0, ht.jsxs)(Zr, {
                  children: [
                    (0, ht.jsx)("div", {
                      className: gs,
                      children: (0, ht.jsx)(
                        rt.oi,
                        bs(
                          bs({}, a),
                          {},
                          {
                            onChange: d,
                            className: ms,
                            value: l,
                            ref: i,
                            multiline: !0,
                          }
                        )
                      ),
                    }),
                    (0, ht.jsx)(rt.rU, {
                      to: "http://whatismarkdown.com/",
                      absolute: !0,
                      target: "_blank",
                      className: ds,
                      children: (0, et.Z)("Styling with Markdown is supported"),
                    }),
                  ],
                }),
                (0, ht.jsxs)(Zr, {
                  children: [
                    (0, ht.jsxs)("div", {
                      className: gs,
                      children: [
                        (0, ht.jsx)(
                          rt.oi,
                          bs(
                            bs({}, a),
                            {},
                            {
                              className: ms,
                              value: l,
                              multiline: !0,
                              disabled: !0,
                            }
                          )
                        ),
                        (0, ht.jsx)(Zt, {
                          className: "w0msh",
                          children: l || (0, et.Z)("Nothing to preview"),
                        }),
                      ],
                    }),
                    (0, ht.jsx)(rt.rU, {
                      to: "http://whatismarkdown.com/",
                      absolute: !0,
                      target: "_blank",
                      className: ds,
                      children: (0, et.Z)("Styling with Markdown is supported"),
                    }),
                  ],
                }),
              ],
            });
          },
          js = (0, ze.memo)(vs),
          ys = ({ title: e, children: t, required: r }) =>
            (0, ht.jsxs)("div", {
              className: "WQ5ax",
              children: [(0, ht.jsx)(rt.__, { text: e, required: r }), t],
            }),
          Os = (0, ze.memo)(ys),
          ws = ({ onModalClose: e, isOpen: t }) => {
            const r = (0, We.I0)(),
              s = (0, We.v9)((e) => e.general.isLibraryEntry),
              n = (0, We.v9)((e) => e.libraryEntry.description) || "",
              a = (0, We.v9)((e) => e.libraryEntry.title) || "",
              i = (0, We.v9)((e) => e.libraryEntry.author) || "",
              o = (0, We.v9)((e) => e.general.permalinkIsEditable),
              l = s && o,
              u = (0, ze.useState)(!1),
              h = (0, st.Z)(u, 2),
              p = h[0],
              d = h[1],
              g = (0, ze.useState)(l ? a : ""),
              m = (0, st.Z)(g, 2),
              f = m[0],
              x = m[1],
              b = (0, ze.useState)(l ? i : ""),
              v = (0, st.Z)(b, 2),
              j = v[0],
              y = v[1],
              O = (0, ze.useState)(l ? n : ""),
              w = (0, st.Z)(O, 2),
              C = w[0],
              E = w[1],
              Z = (0, ze.useState)(""),
              S = (0, st.Z)(Z, 2),
              k = S[0],
              P = S[1],
              N = (0, ze.useState)({
                isLoading: !1,
                hasError: !1,
                success: !1,
              }),
              _ = (0, st.Z)(N, 2),
              T = _[0],
              A = _[1],
              I = (0, ze.useCallback)((e) => {
                x(e), d(!0);
              }, []),
              R = (0, ze.useCallback)((e) => {
                y(e), d(!0);
              }, []),
              D = (0, ze.useCallback)((e) => {
                E(e), d(!0);
              }, []);
            return (
              (0, ze.useEffect)(() => {
                t &&
                  (l ? (x(a), y(i), E(n)) : (x(""), y(""), E("")),
                  A({ isLoading: !1, hasError: !1, success: !1 }));
              }, [t, a, i, n, l]),
              (0, ht.jsxs)(bt.Z, {
                onModalClose: e,
                isOpen: t,
                isLoading: T.isLoading,
                children: [
                  (0, ht.jsx)(vt.Z, {
                    children: l
                      ? (0, et.Z)("Update Library Entry")
                      : (0, et.Z)("Submit Workspace to Regex Library"),
                  }),
                  (0, ht.jsx)(jt.Z, {
                    children: (0, ht.jsxs)("div", {
                      className: Xe()("_GCcL", T.isLoading && "sXKS3"),
                      children: [
                        T.success &&
                          (0, ht.jsxs)("div", {
                            className: "tuaRV",
                            children: [
                              (0, ht.jsx)("div", {
                                className: "ns94K",
                                children: (0, et.Z)(
                                  "Your workspace has been successfully submitted to the library!"
                                ),
                              }),
                              (0, ht.jsx)(rt.vV, {
                                tag: "p",
                                text: "You can find the library entry here: {1}",
                                ph1: (0, ht.jsx)(rt.rU, {
                                  to: `/library/${k}`,
                                  absolute: !0,
                                  children: `/library/${k}`,
                                }),
                              }),
                              (0, ht.jsx)(rt.vV, {
                                tag: "p",
                                text: "Any changes to the library entry, both the expression, as well as title/description/etc, can be made at the following url: {1}",
                                ph1: (0, ht.jsx)(rt.rU, {
                                  to: rr(k),
                                  absolute: !0,
                                  children: rr(k),
                                }),
                              }),
                              (0, ht.jsx)("p", {
                                children: (0, et.Z)(
                                  "You can continue to edit in this workspace without affecting the entry you just submitted."
                                ),
                              }),
                              (0, ht.jsx)("strong", {
                                children: (0, et.Z)(
                                  "Thank you for your contribution"
                                ),
                              }),
                            ],
                          }),
                        !T.success &&
                          (0, ht.jsxs)(ht.Fragment, {
                            children: [
                              (0, ht.jsx)(Os, {
                                title: (0, et.Z)("Title"),
                                required: !0,
                                children: (0, ht.jsx)(rt.oi, {
                                  maxlength: 150,
                                  onChange: I,
                                  defaultValue: f,
                                  placeholder: (0, et.Z)(
                                    "Title of regular expression"
                                  ),
                                }),
                              }),
                              (0, ht.jsx)(Os, {
                                title: (0, et.Z)("Description"),
                                required: !0,
                                children: (0, ht.jsx)(js, {
                                  maxlength: 5e3,
                                  onChange: D,
                                  placeholder: (0, et.Z)(
                                    "Description of regular expression"
                                  ),
                                  defaultValue: C,
                                }),
                              }),
                              (0, ht.jsx)(Os, {
                                title: (0, et.Z)("Author"),
                                className: "H7aJ9",
                                children: (0, ht.jsx)(rt.oi, {
                                  maxlength: 150,
                                  onChange: R,
                                  defaultValue: j,
                                  placeholder: (0, et.Z)(
                                    "Name or other identifier of the author"
                                  ),
                                }),
                              }),
                            ],
                          }),
                      ],
                    }),
                  }),
                  (0, ht.jsxs)(yt.Z, {
                    children: [
                      T.isLoading &&
                        (0, ht.jsx)(rt.$j, {
                          className: "GjCIr",
                          size: gt.J7.TC,
                        }),
                      T.hasError &&
                        (0, ht.jsx)(rt.lx, {
                          text: (0, et.Z)(
                            "There was a problem while trying to submit your regex to the library. Please try again later."
                          ),
                          direction: gt.qF.N,
                          children: (0, ht.jsx)("div", {
                            className: "QokGJ",
                            role: "alert",
                            children: (0, ht.jsx)(nt.j6O, { size: 20 }),
                          }),
                        }),
                      !T.success &&
                        (0, ht.jsx)(rt.zx, {
                          text: s ? (0, et.Z)("Update") : (0, et.Z)("Submit"),
                          disabled:
                            !p ||
                            0 === f.length ||
                            0 === C.length ||
                            T.isLoading,
                          onClick: async () => {
                            A({ isLoading: !0, hasError: !1, success: !1 });
                            try {
                              const t = await r(
                                s && o
                                  ? (0, je.ZD)(f, C, j)
                                  : (0, je.Tr)(f, C, j)
                              );
                              l
                                ? e()
                                : (P(t),
                                  A({
                                    isLoading: !1,
                                    hasError: !1,
                                    success: !0,
                                  }));
                            } catch (e) {
                              c.Z.error(
                                "Unable to create or update library entry",
                                e
                              ),
                                A({ isLoading: !1, hasError: !0, success: !1 });
                            }
                          },
                          className: "ZmwNY",
                        }),
                      (0, ht.jsx)(rt.zx, {
                        text: T.success
                          ? (0, et.Z)("Close")
                          : (0, et.Z)("Cancel"),
                        onClick: e,
                        type: gt.V5.n1,
                        disabled: T.isLoading,
                      }),
                    ],
                  }),
                ],
              })
            );
          },
          Cs = ({
            title: e,
            children: t,
            onModalClose: r,
            isOpen: s,
            onConfirmClick: n,
            confirmText: a = (0, et.Z)("Ok"),
            isDanger: i,
            isLoading: o,
          }) =>
            (0, ht.jsxs)(bt.Z, {
              onModalClose: r,
              isOpen: s,
              className: "LZ_87",
              isLoading: o,
              children: [
                (0, ht.jsx)(vt.Z, { className: "CrJ1q", children: e }),
                (0, ht.jsx)(jt.Z, { className: "EgtQt", children: t }),
                (0, ht.jsxs)(yt.Z, {
                  children: [
                    (0, ht.jsx)(rt.zx, {
                      text: a,
                      onClick: n,
                      style: { marginRight: 10 },
                      type: i ? gt.V5.T : gt.V5.OK,
                      disabled: o,
                    }),
                    (0, ht.jsx)(rt.zx, {
                      text: (0, et.Z)("Close"),
                      onClick: r,
                      type: gt.V5.n1,
                      disabled: o,
                    }),
                  ],
                }),
              ],
            });
        function Es(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Zs(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Es(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Es(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Ss = (e) =>
          (0, ht.jsxs)(
            Cs,
            Zs(
              Zs(
                {
                  title: (0, et.Z)("Delete Regex"),
                  confirmText: (0, et.Z)("Yes, delete"),
                  isDanger: !0,
                },
                e
              ),
              {},
              {
                children: [
                  (0, ht.jsx)("div", {
                    children: (0, et.Z)(
                      "Are you sure you want to delete this regex? This action is non-reversible and will delete all versions of this regex."
                    ),
                  }),
                  (0, ht.jsx)(rt.qX, {
                    type: gt.gr.pn,
                    className: "GCjCg",
                    children: (0, et.Z)(
                      "The data can never be recovered again!"
                    ),
                  }),
                ],
              }
            )
          );
        var ks = r(27582);
        const Ps = () => {
            const e = (0, We.I0)(),
              t = (0, We.v9)((e) => e.regexEditor.regex),
              r = (0, We.v9)((e) => e.regexEditor.error),
              s = (0, We.v9)((e) => e.regexEditor.hasUnsavedData),
              n = (0, We.v9)((e) => e.general.permalinkFragment),
              a = (0, We.v9)((e) => e.general.isOwner),
              i = (0, We.v9)((e) => e.general.userId),
              o = (0, We.v9)((e) => e.general.isFavorite),
              c = (0, We.v9)((e) => e.general.isLibraryEntry),
              l = (0, We.v9)((e) => e.general.deleteCode),
              u = (0, We.v9)((e) => e.general.permalinkIsEditable),
              h = (0, ze.useState)(!1),
              p = (0, st.Z)(h, 2),
              d = p[0],
              g = p[1],
              m = (0, ze.useState)(!1),
              f = (0, st.Z)(m, 2),
              x = f[0],
              b = f[1],
              v = (0, ze.useState)(!1),
              j = (0, st.Z)(v, 2),
              y = j[0],
              O = j[1],
              w = (0, ze.useState)(!1),
              C = (0, st.Z)(w, 2),
              E = C[0],
              Z = C[1],
              S = (0, ze.useCallback)(() => O(!0), []),
              k = (0, ze.useCallback)((e) => {
                e.preventDefault(), Z(!0);
              }, []),
              P = (0, ze.useCallback)(() => Z(!1), []),
              N = (0, ze.useCallback)(() => O(!1), []),
              _ = (0, ze.useCallback)(async () => {
                await e(je.MX(n, l)), (window.location.href = "/");
              }, [e, n, l]),
              T = (0, ze.useCallback)(async () => {
                await e(je.Ez(n, null, !o)), e(je.jb(!o));
              }, [e, o, n]),
              A = (0, ze.useCallback)(() => {
                g(!1), b(!1);
              }, []),
              I = (0, ze.useCallback)(
                (e) => {
                  (0, Ne.event)({
                    category: "saveRegex",
                    action: "User saved regex",
                  }),
                    e.stopPropagation(),
                    "" !== t && s && g(!0);
                },
                [t, s]
              ),
              R = (0, ze.useCallback)(
                (e) => {
                  (0, Ne.event)({
                    category: "updateRegex",
                    action: "User updated regex",
                  }),
                    e.stopPropagation(),
                    "" !== t && s && null != n && u && (b(!0), g(!0));
                },
                [t, s, n, u]
              );
            return (
              (0, ze.useEffect)(
                () => (
                  tt.ZP.on({ "key:updateRegex": R, "key:saveRegex": I }),
                  () => {
                    tt.ZP.off({ "key:updateRegex": R, "key:saveRegex": I });
                  }
                ),
                [R, I]
              ),
              (0, ht.jsxs)(Ft.Z, {
                className: Vt,
                header: (0, et.Z)("Save & Share"),
                children: [
                  (0, ht.jsx)(ks.Z, {
                    icon: nt.d26,
                    onClick: I,
                    isDisabled: "" === t || !s,
                    className: "wHTes",
                    rightElement: (0, ht.jsx)(rt.aX, {
                      shortcut: Ht.SAVE_REGEX,
                    }),
                    monospace: !1,
                    children: (0, et.Z)("Save Regex"),
                  }),
                  null != n &&
                    u &&
                    (0, ht.jsx)(ks.Z, {
                      icon: nt.PwW,
                      onClick: R,
                      isDisabled: "" === t || !s,
                      rightElement: (0, ht.jsx)(rt.aX, {
                        shortcut: Ht.UPDATE_REGEX,
                      }),
                      monospace: !1,
                      children: c
                        ? (0, et.Z)("Update Library Regex")
                        : (0, et.Z)("Update Regex"),
                    }),
                  null != l &&
                    (0, ht.jsx)(er, {
                      to: `/delete/${l}`,
                      icon: nt.M$4,
                      className: "QQcsx",
                      onClick: k,
                      absolute: !0,
                      tabIndex: -1,
                      children: (0, et.Z)("Delete Regex"),
                    }),
                  c &&
                    a &&
                    (0, ht.jsx)(tr.Z, {
                      isDisabled: "" === t || r === $t.D9,
                      icon: nt.tuW,
                      onClick: S,
                      children: (0, et.Z)("Edit Library Entry"),
                    }),
                  !c &&
                    null != i &&
                    (0, ht.jsx)(tr.Z, {
                      isDisabled: "" === t || r === $t.D9,
                      icon: nt.tuW,
                      onClick: S,
                      children: (0, et.Z)("Add to Public Library"),
                    }),
                  null != i &&
                    null != n &&
                    (0, ht.jsx)(tr.Z, {
                      icon: nt.iB2,
                      className: "XusZa",
                      onClick: T,
                      children: o
                        ? (0, et.Z)("Unfavorite Regex")
                        : (0, et.Z)("Favorite Regex"),
                    }),
                  c &&
                    (0, ht.jsx)(er, {
                      to: `/library/${n}`,
                      icon: qt.bwQ,
                      children: (0, et.Z)("Go to library entry"),
                    }),
                  (0, ht.jsx)(jr, {
                    isUpdating: x,
                    onModalClose: A,
                    isOpen: d,
                  }),
                  (0, ht.jsx)(ws, { isOpen: y, onModalClose: N }),
                  (0, ht.jsx)(Ss, {
                    isOpen: E,
                    onModalClose: P,
                    onConfirmClick: _,
                  }),
                ],
              })
            );
          },
          Ns = () => {
            const e = (0, We.I0)(),
              t = (0, We.v9)((e) => e.regexEditor.showMatchArea),
              r = (0, We.v9)((e) => e.regexEditor.showSubstitutionArea),
              s = (0, We.v9)((e) => e.regexEditor.showListSubstitutionArea),
              n = (0, We.v9)((e) => e.regexEditor.showUnitTestArea),
              a = (0, We.v9)((e) => e.unitTests.tests.length),
              i = (0, ze.useCallback)(
                (t) => {
                  t.stopPropagation(),
                    (0, Ne.event)({
                      category: "regexFunction",
                      action: "Switched to matching",
                    }),
                    e(je.Iu());
                },
                [e]
              ),
              o = (0, ze.useCallback)(
                (t) => {
                  t.stopPropagation(),
                    (0, Ne.event)({
                      category: "regexFunction",
                      action: "Switched to substitution",
                    }),
                    e(je.ux());
                },
                [e]
              ),
              c = (0, ze.useCallback)(
                (t) => {
                  t.stopPropagation(),
                    (0, Ne.event)({
                      category: "regexFunction",
                      action: "Switched to unit test",
                    }),
                    e(je.rI());
                },
                [e]
              ),
              l = (0, ze.useCallback)(
                (t) => {
                  t.stopPropagation(),
                    (0, Ne.event)({
                      category: "regexFunction",
                      action: "Switched to list substitution",
                    }),
                    e(je.vn());
                },
                [e]
              );
            return (
              (0, ze.useEffect)(
                () => (
                  tt.ZP.on({
                    "key:ctrl1": i,
                    "key:ctrl2": o,
                    "key:ctrl3": l,
                    "key:ctrl4": c,
                  }),
                  () => {
                    tt.ZP.off({
                      "key:ctrl1": i,
                      "key:ctrl2": o,
                      "key:ctrl3": l,
                      "key:ctrl4": c,
                    });
                  }
                ),
                [i, o, l, c]
              ),
              (0, ht.jsxs)(Ft.Z, {
                className: Vt,
                header: (0, et.Z)("Function"),
                children: [
                  (0, ht.jsx)(Ut.Z, {
                    icon: nt.tJT,
                    onClick: i,
                    isActive: t,
                    children: (0, et.Z)("Match"),
                  }),
                  (0, ht.jsx)(Ut.Z, {
                    icon: nt.EgU,
                    onClick: o,
                    isActive: r && !n,
                    children: (0, et.Z)("Substitution"),
                  }),
                  (0, ht.jsx)(Ut.Z, {
                    icon: nt.dR_,
                    onClick: l,
                    isActive: s,
                    children: (0, et.Z)("List"),
                  }),
                  (0, ht.jsx)(Ut.Z, {
                    icon: nt.aJY,
                    onClick: c,
                    isActive: n,
                    children: (0, et.Z)(
                      "Unit Tests {1}",
                      a > 0 ? `(${a})` : ""
                    ),
                  }),
                ],
              })
            );
          };
        var _s = r(14578),
          Ts = r(39781),
          As = r(90732);
        const Is = () => {
            const e = (0, Ke.s0)(),
              t = (0, We.v9)((e) => e.regexEditor.flavor),
              r = (0, We.v9)((e) => e.regexEditor.regex),
              s = (0, We.v9)((e) => e.regexEditor.error),
              n = (0, We.v9)((e) => e.regexEditor.showListSubstitutionArea),
              a = (0, We.v9)((e) => e.regexEditor.showUnitTestArea),
              i = (0, We.v9)((e) => e.settings.defaultCodeGenLanguage),
              o = (0, ze.useCallback)(
                (s) => {
                  s.stopPropagation(),
                    "" !== r && e(`codegen?language=${i || (0, As.Wr)(t)}`);
                },
                [r, i, t, e]
              ),
              c = (0, ze.useCallback)(
                (t) => {
                  t.stopPropagation(),
                    "" === r || s === $t.D9 || a || e("debugger");
                },
                [r, s, a, e]
              );
            return (
              (0, ze.useEffect)(
                () => (
                  tt.ZP.on({ "key:ctrlB": c, "key:ctrlG": o }),
                  () => {
                    tt.ZP.off({ "key:ctrlB": c, "key:ctrlG": o });
                  }
                ),
                [c, o]
              ),
              (0, ht.jsxs)(Ft.Z, {
                header: (0, et.Z)("Tools"),
                children: [
                  (0, ht.jsx)(er, {
                    icon: _s.xv9,
                    isDisabled: "" === r || n,
                    to: `codegen?language=${i || (0, As.Wr)(t)}`,
                    children: (0, et.Z)("Code Generator"),
                  }),
                  (0, Ts.G)(t) &&
                    (0, ht.jsx)(er, {
                      icon: nt.RwU,
                      isDisabled: "" === r || s === $t.D9 || a,
                      to: "debugger",
                      children: (0, et.Z)("Regex Debugger"),
                    }),
                ],
              })
            );
          },
          Rs = () =>
            (0, ht.jsxs)(ht.Fragment, {
              children: [
                (0, ht.jsx)(Ps, {}),
                (0, ht.jsx)(Bt, {}),
                (0, ht.jsx)(Ns, {}),
                (0, ht.jsx)(Is, {}),
              ],
            });
        var Ds = r(8193),
          Ls = r(87740);
        const Ms = ["to", "children", "icon", "isDisabled", "isActive"];
        function Us(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Fs(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Us(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Us(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Gs = (e) => {
            let t = e.to,
              r = e.children,
              s = e.icon,
              n = e.isDisabled,
              a = e.isActive,
              i = (0, T.Z)(e, Ms);
            const o = (0, Ke.bS)(t);
            return (0, ht.jsx)(
              zt.Z,
              Fs(
                Fs({ isDisabled: n }, i),
                {},
                {
                  children: (0, ht.jsx)(rt.rU, {
                    tabIndex: n ? -1 : 0,
                    to: t,
                    className: Yt,
                    noTheme: !0,
                    children: (0, ht.jsx)(Wt.Z, {
                      icon: s,
                      children: (0, ht.jsx)(Ls.Z, {
                        children: r,
                        isActive: a || !!o,
                      }),
                    }),
                  }),
                }
              )
            );
          },
          Vs = (0, ze.memo)(Gs);
        var Bs = r(35896),
          qs = r.n(Bs);
        function Hs(e) {
          switch (e) {
            case qs().MOST_RECENT:
              return (0, et.Z)("Most Recent");
            case qs().MOST_POINTS:
              return (0, et.Z)("Most Points");
            case qs().LEAST_POINTS:
              return (0, et.Z)("Fewest Points");
            case qs().RELEVANCE:
              return (0, et.Z)("Relevance");
            default:
              throw new Error(`Unknown order ${e}`);
          }
        }
        const $s = [
            { flavor: j().PCRE2, string: "PCRE2" },
            { flavor: j().PCRE, string: "PCRE" },
            { flavor: j().JAVASCRIPT, string: "ECMAScript" },
            { flavor: j().PYTHON, string: "Python" },
            { flavor: j().GOLANG, string: "Golang" },
            { flavor: j().JAVA, string: "Java" },
            { flavor: j().DOTNET, string: ".NET" },
          ],
          zs = (e) => {
            switch (e) {
              case qs().MOST_RECENT:
                return Ds.dT6;
              case qs().MOST_POINTS:
                return at.PNI;
              case qs().LEAST_POINTS:
                return at.a7d;
              case qs().RELEVANCE:
                return Ds.Ehc;
              default:
                throw new Error(`Unknown library sorting order "${e}"`);
            }
          },
          Ws = () => {
            const e = (0, Ye.lr)(),
              t = (0, st.Z)(e, 1)[0],
              r = t.getAll("filterFlavors"),
              s = t.get("orderBy") || qs().MOST_RECENT,
              n = t.get("search") || "";
            return (0, ht.jsxs)(ht.Fragment, {
              children: [
                (0, ht.jsx)(Ft.Z, {
                  header: (0, et.Z)("Order By"),
                  className: Vt,
                  children: qs()
                    .all.filter(
                      (e) => !(e === qs().RELEVANCE && 0 === n.length)
                    )
                    .map((e) =>
                      (0, ht.jsx)(
                        Vs,
                        {
                          to: `?${sr.stringify({
                            filterFlavors: r,
                            search: n,
                            orderBy: e,
                          })}`,
                          isActive: s === e,
                          icon: zs(e),
                          children: Hs(e),
                        },
                        `library-order-menu-${e}`
                      )
                    ),
                }),
                (0, ht.jsx)(Ft.Z, {
                  header: (0, et.Z)("Filter by Flavor"),
                  children: $s.map((e) => {
                    let t = [].concat(r);
                    const a = t.includes(e.flavor);
                    return (
                      a
                        ? (t = t.filter((t) => t !== e.flavor))
                        : t.push(e.flavor),
                      (0, ht.jsx)(
                        Vs,
                        {
                          icon: nt.mV1,
                          isActive: a,
                          to: `?${sr.stringify({
                            search: n,
                            orderBy: s,
                            filterFlavors: t,
                          })}`,
                          children: e.string,
                        },
                        `library-flavor-${e.flavor}`
                      )
                    );
                  }),
                }),
              ],
            });
          },
          Ys = () =>
            (0, ht.jsxs)("div", {
              className: "sFanj",
              children: [
                (0, ht.jsx)(rt.__, { text: (0, et.Z)("Settings") }),
                (0, ht.jsxs)("div", {
                  children: [
                    (0, et.Z)(
                      "All settings to control the application are located here."
                    ),
                    (0, ht.jsx)("br", {}),
                    (0, ht.jsx)("br", {}),
                    (0, et.Z)(
                      "They are automatically saved as you change them and will be automatically loaded every time."
                    ),
                  ],
                }),
              ],
            }),
          Ks = (0, ze.memo)(Ys);
        var Js = r(60155),
          Xs = r(7504),
          Qs = r.n(Xs),
          en = r(13201),
          tn = r.n(en);
        const rn = [
            { string: "Google", icon: nt.D27, to: "/connect/google" },
            { string: "Github", icon: nt.q7V, to: "/connect/github" },
            { string: "Twitter", icon: nt.x2F, to: "/connect/twitter" },
          ],
          sn = ({
            onModalClose: e,
            isOpen: t,
            returnTo: r = "/account/all",
          }) => {
            const s = (0, We.I0)(),
              n = (0, ze.useCallback)(() => s({ type: g.xw }), [s]);
            return (0, ht.jsxs)(bt.Z, {
              onModalClose: e,
              isOpen: t,
              className: "dyCRh",
              children: [
                (0, ht.jsx)(vt.Z, { children: (0, et.Z)("Sign In") }),
                (0, ht.jsxs)(jt.Z, {
                  className: "HLkfc",
                  children: [
                    (0, ht.jsx)(Ft.Z, {
                      header: (0, et.Z)("Select a service provider"),
                      className: "gT9Zk",
                      children: rn.map((e) =>
                        (0, ht.jsx)(
                          er,
                          {
                            to: `${e.to}?returnTo=${r}`,
                            icon: e.icon,
                            onClick: n,
                            absolute: !0,
                            children: e.string,
                          },
                          `provider-${e.string}`
                        )
                      ),
                    }),
                    (0, ht.jsxs)("div", {
                      className: "gYcOc",
                      children: [
                        (0, ht.jsx)(rt.qX, {
                          noMargin: !0,
                          children: (0, et.Z)(
                            "Only the bare minimum information is retrieved and saved in order to identify your account."
                          ),
                        }),
                        (0, ht.jsx)(rt.qX, {
                          noMargin: !0,
                          type: gt.gr.u_,
                          children: (0, et.Z)(
                            "Note that clicking any of the links above will refresh the page. Your data will be saved to local storage and restored once you return to the website."
                          ),
                        }),
                      ],
                    }),
                  ],
                }),
                (0, ht.jsx)(yt.Z, {
                  children: (0, ht.jsx)(rt.zx, {
                    text: (0, et.Z)("Close"),
                    onClick: e,
                    type: gt.V5.n1,
                  }),
                }),
              ],
            });
          },
          nn = () => {
            const e = (0, We.v9)((e) => e.account.allTags),
              t = (0, We.v9)((e) => e.account.staleData);
            return (0, ht.jsxs)(ht.Fragment, {
              children: [
                (0, ht.jsx)(rt.__, { text: (0, et.Z)("Tags") }),
                t
                  ? (0, ht.jsx)(rt.$j, {
                      size: gt.J7.TC,
                      style: { margin: "0 auto" },
                    })
                  : (0, ht.jsx)(pr, { tags: e, clickable: !0 }),
              ],
            });
          },
          an = "qxoBe";
        function on(e) {
          switch (e) {
            case tn().GOOGLE:
              return nt.D27;
            case tn().TWITTER:
              return nt.x2F;
            case tn().GITHUB:
              return nt.q7V;
            default:
              throw new Error("Unknown service provider " + e);
          }
        }
        const cn = () => {
            const e = (0, We.v9)((e) => e.general.userId),
              t = (0, We.v9)((e) => e.general.email),
              r = (0, We.v9)((e) => e.general.serviceProvider),
              s = (0, ze.useState)(!1),
              n = (0, st.Z)(s, 2),
              a = n[0],
              i = n[1],
              o = (0, ze.useState)(!1),
              c = (0, st.Z)(o, 2),
              l = c[0],
              u = c[1],
              h = (0, ze.useState)(!1),
              p = (0, st.Z)(h, 2),
              d = p[0],
              g = p[1],
              m = (0, ze.useCallback)(() => i(!0), []),
              f = (0, ze.useCallback)(() => u(!0), []),
              x = (0, ze.useCallback)(() => {
                i(!1), u(!1);
              }, []),
              b = (0, ze.useCallback)(async () => {
                g(!0);
                try {
                  await fetch("/api/user/", {
                    method: "DELETE",
                    credentials: "same-origin",
                    headers: {
                      Accept: "application/json",
                      "Content-Type": "application/json",
                    },
                  });
                } finally {
                  window.location.href = "/account";
                }
              }, []),
              v = [
                {
                  string: (0, et.Z)("My Expressions"),
                  icon: nt.U$J,
                  scope: Qs().MINE,
                },
                {
                  string: (0, et.Z)("My Favorites"),
                  icon: nt.iB2,
                  scope: Qs().FAVORITES,
                },
                {
                  string: (0, et.Z)("My Library Entries"),
                  icon: Js.Q0w,
                  scope: Qs().LIBRARY,
                },
              ];
            return (0, ht.jsxs)(ht.Fragment, {
              children: [
                (0, ht.jsxs)(Ft.Z, {
                  header: (0, et.Z)("Control"),
                  className: an,
                  children: [
                    null == e &&
                      (0, ht.jsx)(tr.Z, {
                        onClick: m,
                        icon: nt.yrM,
                        children: (0, et.Z)("Sign In"),
                      }),
                    null != e &&
                      null != t &&
                      null != r &&
                      (0, ht.jsx)(tr.Z, {
                        className: "Hp8EU",
                        icon: on(r),
                        isDisabled: !0,
                        children: t,
                      }),
                    null != e &&
                      (0, ht.jsx)(tr.Z, {
                        icon: nt.Xgw,
                        className: "VsHye",
                        onClick: f,
                        children: (0, et.Z)("Delete account"),
                      }),
                    null != e &&
                      (0, ht.jsx)(er, {
                        to: "/login/destroy",
                        absolute: !0,
                        icon: nt.Xgw,
                        children: (0, et.Z)("Sign out"),
                      }),
                  ],
                }),
                null != e &&
                  (0, ht.jsx)(Ft.Z, {
                    header: (0, et.Z)("Category"),
                    className: an,
                    children: v.map((e) =>
                      (0, ht.jsx)(
                        Vs,
                        {
                          to: `/account/${e.scope}`,
                          icon: e.icon,
                          children: e.string,
                        },
                        `account-category-${e.scope}`
                      )
                    ),
                  }),
                null != e && (0, ht.jsx)(nn, {}),
                (0, ht.jsx)(sn, { onModalClose: x, isOpen: a }),
                (0, ht.jsx)(Cs, {
                  onModalClose: x,
                  title: (0, et.Z)("Delete Account and Data"),
                  isLoading: d,
                  isOpen: l,
                  onConfirmClick: b,
                  isDanger: !0,
                  confirmText: (0, et.Z)("Yes, delete everything"),
                  children: (0, ht.jsxs)("div", {
                    className: "hvqpn",
                    children: [
                      (0, ht.jsx)("strong", {
                        children: (0, et.Z)(
                          "Are you sure you want to delete your account?"
                        ),
                      }),
                      (0, ht.jsx)("div", {
                        children: (0, et.Z)(
                          "All associated data with your account will be permanently deleted, such as your saved expressions, your library entries, and your quiz progression."
                        ),
                      }),
                      (0, ht.jsx)(rt.qX, {
                        type: gt.gr.pn,
                        className: "A9fBo",
                        children: (0, et.Z)(
                          "Your data can never be recovered again!"
                        ),
                      }),
                    ],
                  }),
                }),
              ],
            });
          },
          ln = "zcg3R",
          un = () =>
            null == (0, We.v9)((e) => e.general.userId)
              ? null
              : (0, ht.jsxs)(Ft.Z, {
                  header: (0, et.Z)("Tasks"),
                  className: ln,
                  children: [
                    (0, ht.jsx)(Vs, {
                      icon: nt.iB2,
                      to: "/quiz",
                      children: (0, et.Z)("Introduction"),
                    }),
                    (0, ht.jsx)(hn, {}),
                  ],
                }),
          hn = () => {
            const e = (0, We.v9)((e) => e.general.userId),
              t = (0, We.v9)((e) => e.quiz.allTasks),
              r = (0, Qe.$5)("getQuizTasks"),
              s = (0, st.Z)(r, 3),
              n = s[0],
              a = s[1],
              i = s[2];
            return (
              (0, Qe.DB)(() => {
                e && 0 === t.length && i((0, je.Ak)());
              }, [i, t.length, e]),
              null == e
                ? null
                : n
                ? (0, ht.jsx)(rt.$j, { size: gt.J7.TC, className: "upLOL" })
                : a
                ? (0, ht.jsx)(rt.qX, {
                    type: gt.gr.pn,
                    className: "UPygB",
                    children: (0, et.Z)(
                      "There was an error fetching the quiz data. Please try again later."
                    ),
                  })
                : t.map((e, t) => {
                    const r = t + 1;
                    return (0, ht.jsxs)(
                      Vs,
                      {
                        icon: nt.XBp,
                        to: `/quiz/${r}`,
                        isDisabled: !e.canSolve,
                        children: [
                          r,
                          ". ",
                          e.title,
                          " ",
                          e.isOptional && `(${(0, et.Z)("optional")})`,
                        ],
                      },
                      `task-${e.taskNumber}`
                    );
                  })
            );
          },
          pn = () => {
            const e = (0, ze.useState)(!1),
              t = (0, st.Z)(e, 2),
              r = t[0],
              s = t[1],
              n = (0, We.v9)((e) => e.general.userId),
              a = (0, ze.useCallback)(() => s(!0), []),
              i = (0, ze.useCallback)(() => s(!1), []);
            return (0, ht.jsxs)(ht.Fragment, {
              children: [
                (0, ht.jsx)(un, {}),
                (0, ht.jsxs)(Ft.Z, {
                  header: (0, et.Z)("Control"),
                  className: ln,
                  children: [
                    null == n &&
                      (0, ht.jsx)(tr.Z, {
                        onClick: a,
                        icon: nt.yrM,
                        children: (0, et.Z)("Sign In"),
                      }),
                    null != n &&
                      (0, ht.jsx)(er, {
                        to: "/login/destroy",
                        absolute: !0,
                        icon: nt.Xgw,
                        children: (0, et.Z)("Sign out"),
                      }),
                  ],
                }),
                (0, ht.jsx)(sn, {
                  onModalClose: i,
                  isOpen: r,
                  returnTo: "/quiz",
                }),
              ],
            });
          };
        var dn = r(70666);
        const gn = "VUMXN",
          mn = "WIk_o",
          fn = (0, At.Z)(It.K0),
          xn = {
            appear: gn,
            appearActive: mn,
            enter: gn,
            enterActive: mn,
            exit: "gGhok",
            exitActive: "cQ7Yd",
          },
          bn = ({ children: e, className: t }) => {
            const r = ze.Children.toArray(e),
              s = (0, ze.useState)(
                ((o = r.length), Math.floor(Math.random() * o))
              ),
              n = (0, st.Z)(s, 2),
              a = n[0],
              i = n[1];
            var o;
            return (
              (0, ze.useEffect)(() => {
                let e;
                return (
                  r.length > 1 &&
                    (e = setTimeout(() => i((a + 1) % r.length), 3e4)),
                  () => clearTimeout(e)
                );
              }, [a, r.length]),
              (0, ht.jsx)(dn.Z, {
                children: (0, ht.jsx)(
                  rt.uT,
                  {
                    in: !0,
                    classNames: xn,
                    className: Xe()("byHyj", t),
                    timeout: fn,
                    children: r[a],
                  },
                  `carousel-child-${a}`
                ),
              })
            );
          },
          vn = "RhnCb",
          jn = ({ className: e }) => {
            var t;
            const r = (0, ze.useState)(!1),
              s = (0, st.Z)(r, 2),
              n = s[0],
              a = s[1],
              i = (0, We.v9)((e) => e.general.sponsorData),
              o = (0, ze.useCallback)(
                () =>
                  (0, Ne.outboundLink)({ label: "Doppler Sponsor" }, () => {}),
                []
              ),
              c = (0, ze.useCallback)(
                () =>
                  (0, Ne.outboundLink)({ label: "Moovweb Sponsor" }, () => {}),
                []
              ),
              l = (0, ze.useCallback)(
                () =>
                  (0, Ne.outboundLink)({ label: "Carbon Sponsor" }, () => {}),
                []
              ),
              u = (0, ze.useCallback)(() => a(!0), []),
              h = (0, ze.useCallback)(() => a(!1), []),
              p = null == i ? void 0 : i.statlink,
              d = null == i ? void 0 : i.adBlock,
              g = null == i && !d;
            return (0, ht.jsxs)("div", {
              className: Xe()("jyUE5", e),
              children: [
                (0, ht.jsx)("div", {
                  className: "M4byA",
                  children: (0, ht.jsx)("div", {
                    className: "tSxrO",
                    children: (0, et.Z)("Sponsors"),
                  }),
                }),
                (0, ht.jsx)("div", {
                  className: "Di8kW",
                  children: (0, ht.jsxs)(bn, {
                    children: [
                      (0, ht.jsxs)(rt.rU, {
                        className: "X2oC_",
                        to: "https://www.layer0.co/?utm_medium=referral&utm_source=regex101&utm_campaign=regex101",
                        onClick: c,
                        target: "_blank",
                        rel: "nofollow noopener",
                        absolute: !0,
                        children: [
                          (0, ht.jsx)("div", { className: vn }),
                          "Jamstack at Scale",
                        ],
                      }),
                      (0, ht.jsxs)(rt.rU, {
                        className: "duRSK",
                        to: "https://www.doppler.com/?utm_campaign=github_repo&utm_medium=referral&utm_content=regex101&utm_source=github",
                        onClick: o,
                        target: "_blank",
                        rel: "nofollow noopener",
                        absolute: !0,
                        children: [
                          (0, ht.jsx)("div", { className: vn }),
                          "All your environment variables, in one place",
                        ],
                      }),
                    ],
                  }),
                }),
                p &&
                  (0, ht.jsxs)("div", {
                    className: "G3BCS",
                    children: [
                      (0, ht.jsxs)(rt.rU, {
                        className: "Ct5Li",
                        to: `${i.statlink}?segment=placement:regex101com`,
                        rel: "nofollow noopener",
                        onClick: l,
                        target: "_blank",
                        absolute: !0,
                        children: [
                          (0, ht.jsx)("img", {
                            src: i.smallImage,
                            width: 120,
                            height: 90,
                            loading: "lazy",
                            alt: i.description,
                            children: i.title,
                          }),
                          (0, ht.jsx)("div", {
                            className: "tgFFz",
                            children: i.description,
                          }),
                          null === (t = i.pixel) || void 0 === t
                            ? void 0
                            : t
                                .split("||")
                                .map((e, t) =>
                                  (0, ht.jsx)(
                                    "img",
                                    {
                                      src: e.replace(
                                        "[timestamp]",
                                        i.timestamp
                                      ),
                                      style: { display: "none" },
                                      height: 0,
                                      width: 0,
                                      alt: "",
                                    },
                                    `pixel-${t}`
                                  )
                                ),
                        ],
                      }),
                      (0, ht.jsx)(rt.rU, {
                        to: i.ad_via_link,
                        className: "JLQ9d",
                        rel: "nofollow noopener",
                        target: "_blank",
                        absolute: !0,
                        children: "Ads via Carbon",
                      }),
                    ],
                  }),
                d &&
                  (0, ht.jsx)("div", {
                    className: "_gHmG",
                    children: (0, ht.jsxs)(rt.qX, {
                      noMargin: !0,
                      children: [
                        (0, et.Z)(
                          "If you're running an ad blocker, consider whitelisting regex101 to support the website."
                        ),
                        " ",
                        (0, ht.jsx)(rt.Yd, {
                          onClick: u,
                          className: "Q1PRl",
                          children: (0, et.Z)("Read more"),
                        }),
                        ".",
                      ],
                    }),
                  }),
                g &&
                  (0, ht.jsxs)("div", {
                    className: "EJDHZ",
                    children: [
                      (0, ht.jsx)("div", { className: "k0UBc" }),
                      (0, ht.jsxs)("div", {
                        className: "IAz16",
                        children: [
                          (0, ht.jsx)("div", {}),
                          (0, ht.jsx)("div", {}),
                          (0, ht.jsx)("div", {}),
                        ],
                      }),
                    ],
                  }),
                (0, ht.jsxs)(bt.Z, {
                  isOpen: n,
                  onModalClose: h,
                  className: "sM6Wv",
                  children: [
                    (0, ht.jsx)(vt.Z, {
                      children: (0, et.Z)("Advertisements and your privacy"),
                    }),
                    (0, ht.jsxs)(jt.Z, {
                      className: "hv1JN",
                      children: [
                        (0, ht.jsxs)("p", {
                          children: [
                            (0, et.Z)(
                              "The advertisements are provided by Carbon, but implemented by regex101."
                            ),
                            (0, ht.jsx)("br", {}),
                            (0, ht.jsx)("strong", {
                              children: (0, et.Z)(
                                "No cookies will be used for tracking and no third party scripts will be loaded."
                              ),
                            }),
                          ],
                        }),
                        (0, ht.jsx)(rt.vV, {
                          text: "The information is fetched using a JSONP request, which contains the ad text and a link to the ad image. The JSON file and images are fetched from {1} or {2}.",
                          ph1: (0, ht.jsx)("em", {
                            children: "buysellads.com",
                          }),
                          ph2: (0, ht.jsx)("em", {
                            children: "buysellads.net",
                          }),
                          tag: "p",
                        }),
                        (0, ht.jsx)(rt.vV, {
                          text: "If you have any questions or concerns, please feel free to {1}.",
                          ph1: (0, ht.jsx)(rt.rU, {
                            to: "mailto:contact@regex101.com",
                            absolute: !0,
                            children: (0, et.Z)("send an email"),
                          }),
                          tag: "p",
                        }),
                      ],
                    }),
                    (0, ht.jsx)(yt.Z, {
                      children: (0, ht.jsx)(rt.zx, {
                        onClick: h,
                        text: (0, et.Z)("Close"),
                        type: gt.V5.n1,
                      }),
                    }),
                  ],
                }),
              ],
            });
          },
          yn = (0, ze.memo)(jn),
          On = "regex101-nickname",
          wn = "_eLp0",
          Cn = "zOliV",
          En = 34,
          Zn = ({ className: e }) => {
            const t = (0, We.v9)((e) => e.general.permalinkFragment),
              r = (0, We.v9)((e) => e.general.version),
              s = (0, We.v9)((e) => e.general.profilePicture),
              n = (0, ze.useRef)(
                (function () {
                  let e = Oe.Z.get(On);
                  return (
                    (!e ||
                      "string" != typeof e ||
                      e.length > 16 ||
                      e.includes("...")) &&
                      ((e = (function () {
                        const e = [
                          "Adelie",
                          "Hound",
                          "Civet",
                          "Ainu",
                          "Akbash",
                          "Akita",
                          "Ant",
                          "Fox",
                          "Hare",
                          "Wolf",
                          "Mist",
                          "Avocet",
                          "Baboon",
                          "Camel",
                          "Badger",
                          "Barb",
                          "Bat",
                          "Beagle",
                          "Bear",
                          "Collie",
                          "Beaver",
                          "Beetle",
                          "Bichon",
                          "Bird",
                          "Birman",
                          "Bison",
                          "Bobcat",
                          "Bombay",
                          "Bongo",
                          "Bonobo",
                          "Booby",
                          "Boykin",
                          "Budgie",
                          "Fish",
                          "Caiman",
                          "Lizard",
                          "Canaan",
                          "Cat",
                          "Cesky",
                          "Fousek",
                          "Coati",
                          "Coral",
                          "Cougar",
                          "Cow",
                          "Coyote",
                          "Crab",
                          "Crane",
                          "Cuscus",
                          "Frog",
                          "Deer",
                          "Bracke",
                          "Dhole",
                          "Dingo",
                          "Discus",
                          "Dodo",
                          "Dog",
                          "Dogo",
                          "Donkey",
                          "Drever",
                          "Duck",
                          "Dugong",
                          "Dunker",
                          "Dusky",
                          "Eagle",
                          "Mau",
                          "Emu",
                          "Falcon",
                          "Fennec",
                          "Ferret",
                          "Spitz",
                          "Fly",
                          "Fossa",
                          "Gar",
                          "Gecko",
                          "Gerbil",
                          "Gibbon",
                          "Goat",
                          "Oriole",
                          "Goose",
                          "Gopher",
                          "Grouse",
                          "Guppy",
                          "Shark",
                          "Heron",
                          "Horse",
                          "Human",
                          "Hyena",
                          "Ibis",
                          "Iguana",
                          "Impala",
                          "Indri",
                          "Insect",
                          "Setter",
                          "Jackal",
                          "Jaguar",
                          "Kakapo",
                          "Kiwi",
                          "Koala",
                          "Kudu",
                          "Lemur",
                          "Liger",
                          "Lion",
                          "Llama",
                          "Owl",
                          "Lynx",
                          "Macaw",
                          "Magpie",
                          "Mayfly",
                          "Mole",
                          "Molly",
                          "Monkey",
                          "Moose",
                          "Eel",
                          "Moray",
                          "Moth",
                          "Mouse",
                          "Mule",
                          "Newt",
                          "Numbat",
                          "Ocelot",
                          "Okapi",
                          "Olm",
                          "Otter",
                          "Oyster",
                          "Parrot",
                          "Pig",
                          "Pika",
                          "Pike",
                          "Poodle",
                          "Possum",
                          "Prawn",
                          "Puffin",
                          "Pug",
                          "Puma",
                          "Pygmy",
                          "Quail",
                          "Quokka",
                          "Quoll",
                          "Rabbit",
                          "Rat",
                          "Robin",
                          "Saola",
                          "Seal",
                          "Serval",
                          "Sheep",
                          "Shrimp",
                          "Skunk",
                          "Sloth",
                          "Snail",
                          "Snake",
                          "Somali",
                          "Sponge",
                          "Squid",
                          "Stoat",
                          "Swan",
                          "Tang",
                          "Tapir",
                          "Tetra",
                          "Tiger",
                          "Toucan",
                          "Turkey",
                          "Uakari",
                          "Uguisu",
                          "Walrus",
                          "Wasp",
                          "Weasel",
                          "Wombat",
                          "Wrasse",
                          "Yak",
                          "Yorkie",
                          "Zebra",
                          "Zebu",
                          "Zonkey",
                          "Zorse",
                        ];
                        return `re101-${e[
                          Math.floor(Math.random() * e.length)
                        ].toLowerCase()}-?`;
                      })()),
                      Oe.Z.save(On, e)),
                    e
                  );
                })() || "re101-guest-?"
              ).current,
              a = (0, ze.useCallback)(() => {
                tt.ZP.emit(tt.Rd);
              }, []);
            return (0, ht.jsxs)("nav", {
              className: Xe()("uOmOI", e),
              children: [
                (0, ht.jsx)(rt.x6, {
                  tooltip: (0, et.Z)("Regex Editor"),
                  tooltipDirection: gt.qF.E,
                  to: null != t ? rr(t, r) : "/",
                  onClick: a,
                  size: En,
                  className: wn,
                  activeClassName: Cn,
                  activeRegex: /^\/(?!library|account|quiz|settings)/i,
                  noTheme: !0,
                  children: (0, ht.jsx)(nt.mV1, { size: 18 }),
                }),
                (0, ht.jsx)(rt.x6, {
                  tooltip: (0, et.Z)("Regex Library"),
                  tooltipDirection: gt.qF.E,
                  to: "/library",
                  onClick: a,
                  size: En,
                  className: wn,
                  activeClassName: Cn,
                  activeRegex: /^\/library/i,
                  noTheme: !0,
                  children: (0, ht.jsx)(Js.Q0w, { size: 18 }),
                }),
                (0, ht.jsx)(rt.x6, {
                  tooltip: (0, et.Z)("Account"),
                  tooltipDirection: gt.qF.E,
                  to: "/account/mine",
                  onClick: a,
                  size: En,
                  className: s ? "eDcsT" : wn,
                  activeClassName: Cn,
                  activeRegex: /^\/account/i,
                  noTheme: !0,
                  children: s
                    ? (0, ht.jsx)("img", {
                        src: s,
                        style: { height: En, width: En },
                        alt: "",
                      })
                    : (0, ht.jsx)(nt.dgb, { size: 18 }),
                }),
                (0, ht.jsx)(rt.x6, {
                  tooltip: (0, et.Z)("Regex Quiz"),
                  tooltipDirection: gt.qF.E,
                  to: "/quiz",
                  onClick: a,
                  size: En,
                  className: wn,
                  activeClassName: Cn,
                  activeRegex: /^\/quiz/i,
                  noTheme: !0,
                  children: (0, ht.jsx)(nt.Xhu, { size: 18 }),
                }),
                (0, ht.jsx)(rt.x6, {
                  tooltip: (0, et.Z)("Settings"),
                  tooltipDirection: gt.qF.E,
                  to: "/settings",
                  onClick: a,
                  size: En,
                  className: wn,
                  activeClassName: Cn,
                  activeRegex: /^\/settings/i,
                  noTheme: !0,
                  children: (0, ht.jsx)(it.b9P, { size: 18 }),
                }),
                (0, ht.jsx)(rt.x6, {
                  tooltip: (0, et.Z)("Live Help"),
                  tooltipDirection: gt.qF.E,
                  to: q.WEBCHAT_LINK.replace("<NICKNAME>", n),
                  target: "_blank",
                  size: En,
                  className: wn,
                  noTheme: !0,
                  absolute: !0,
                  children: (0, ht.jsx)(nt.IGw, {}),
                }),
              ],
            });
          },
          Sn = ["tooltipDirection", "tooltipText", "onClick", "className"];
        function kn(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Pn(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? kn(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : kn(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Nn = (e) => {
            let t = e.tooltipDirection,
              r = e.tooltipText,
              s = e.onClick,
              n = e.className,
              a = (0, T.Z)(e, Sn);
            return (0, ht.jsx)(
              rt.hU,
              Pn(
                Pn(
                  {
                    tooltip: r,
                    tooltipDirection: t,
                    size: 28,
                    onClick: s,
                    className: Xe()("k3zrI", n),
                    tag: "div",
                  },
                  a
                ),
                {},
                {
                  children: (0, ht.jsx)("div", {
                    className: "_wt32",
                    children: (0, ht.jsx)(nt.B4m, {
                      size: 16,
                      className: "wL3Ov",
                    }),
                  }),
                }
              )
            );
          },
          _n = (0, ze.memo)(Nn),
          Tn = ["onClick"];
        function An(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        const In = (e) => {
            let t = e.onClick,
              r = (0, T.Z)(e, Tn);
            return (
              (0, ze.useEffect)(() => {
                const e =
                    (e) =>
                    (...r) => {
                      t(), tt.ZP.emit(e, ...r);
                    },
                  r = e("key:updateRegex"),
                  s = e("key:saveRegex"),
                  n = e("key:ctrl1"),
                  a = e("key:ctrl2"),
                  i = e("key:ctrl3"),
                  o = e("key:ctrl4"),
                  c = e("key:ctrlB"),
                  l = e("key:ctrlG");
                return (
                  tt.ZP.on({
                    "key:updateRegex": r,
                    "key:saveRegex": s,
                    "key:ctrl1": n,
                    "key:ctrl2": a,
                    "key:ctrl3": i,
                    "key:ctrl4": o,
                    "key:ctrlB": c,
                    "key:ctrlG": l,
                  }),
                  () =>
                    tt.ZP.off({
                      "key:updateRegex": r,
                      "key:saveRegex": s,
                      "key:ctrl1": n,
                      "key:ctrl2": a,
                      "key:ctrl3": i,
                      "key:ctrl4": o,
                      "key:ctrlB": c,
                      "key:ctrlG": l,
                    })
                );
              }, [t]),
              (0, ht.jsx)(
                _n,
                (function (e) {
                  for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? arguments[t] : {};
                    t % 2
                      ? An(Object(r), !0).forEach(function (t) {
                          (0, a.Z)(e, t, r[t]);
                        })
                      : Object.getOwnPropertyDescriptors
                      ? Object.defineProperties(
                          e,
                          Object.getOwnPropertyDescriptors(r)
                        )
                      : An(Object(r)).forEach(function (t) {
                          Object.defineProperty(
                            e,
                            t,
                            Object.getOwnPropertyDescriptor(r, t)
                          );
                        });
                  }
                  return e;
                })({ onClick: t }, r)
              )
            );
          },
          Rn = "MPQtP",
          Dn = "XZcdB",
          Ln = "Hf3vu",
          Mn = (0, At.Z)(It.s_),
          Un = {
            appear: Dn,
            appearActive: Ln,
            enter: Dn,
            enterActive: Ln,
            exit: "LSp5h",
            exitActive: "rMyiN",
          },
          Fn = ({ children: e }) => {
            const t = (0, ze.useState)(!1),
              r = (0, st.Z)(t, 2),
              s = r[0],
              n = r[1],
              a = (0, ze.useCallback)((e) => {
                e.stopPropagation(), n(!1);
              }, []),
              i = (0, ze.useCallback)(() => n(!0), []),
              o = (0, ze.useCallback)((e) => {
                e.stopPropagation(), e.preventDefault();
              }, []);
            return (
              (0, ze.useEffect)(
                () => (
                  s && (tt.ZP.once("key:escape", a), tt.ZP.once(tt.Rd, a)),
                  () => {
                    tt.ZP.off("key:escape", a), tt.ZP.off(tt.Rd, a);
                  }
                ),
                [s, a]
              ),
              (0, ht.jsxs)("div", {
                children: [
                  (0, ht.jsx)(In, {
                    className: "SjbhX",
                    tooltipDirection: gt.qF.SE,
                    tooltipText: (0, et.Z)("Show Sidebar"),
                    onClick: i,
                  }),
                  (0, ht.jsx)(rt.h_, {
                    isOpen: s,
                    closeTimeout: Mn,
                    children: (0, ht.jsx)(rt.uT, {
                      className: "cek5f",
                      classNames: Un,
                      timeout: Mn,
                      in: s,
                      onMouseUp: a,
                      children: (0, ht.jsx)(rt.iQ, {
                        children: (0, ht.jsxs)("div", {
                          className: Rn,
                          onMouseUp: o,
                          children: [
                            (0, ht.jsx)(dt, {
                              className: "cfODq",
                              noClick: !0,
                            }),
                            e,
                          ],
                        }),
                      }),
                    }),
                  }),
                ],
              })
            );
          },
          Gn = parseFloat(ct.p4),
          Vn = ({ alwaysCollapseLeftSidebar: e }) => {
            const t = (0, Qe.Sj)(Gn),
              r = (0, ze.useState)(!Ce() || window.navigator.onLine),
              s = (0, st.Z)(r, 2),
              n = s[0],
              a = s[1];
            (0, ze.useEffect)(() => {
              const e = () => a(!0),
                t = () => a(!1);
              return (
                window.addEventListener("online", e),
                window.addEventListener("offline", t),
                () => {
                  window.removeEventListener("online", e),
                    window.removeEventListener("offline", t);
                }
              );
            }, []);
            const i = (0, ht.jsxs)(ht.Fragment, {
              children: [
                (0, ht.jsxs)("div", {
                  className: "AkJag",
                  children: [
                    (0, ht.jsx)(Zn, { className: "i1N2B" }),
                    (0, ht.jsx)("div", {
                      className: "hIvL6",
                      children: (0, ht.jsxs)(Ke.Z5, {
                        children: [
                          (0, ht.jsx)(Ke.AW, {
                            path: "library/*",
                            element: (0, ht.jsx)(Ws, {}),
                          }),
                          (0, ht.jsx)(Ke.AW, {
                            path: "/settings/*",
                            element: (0, ht.jsx)(Ks, {}),
                          }),
                          (0, ht.jsx)(Ke.AW, {
                            path: "/quiz/*",
                            element: (0, ht.jsx)(pn, {}),
                          }),
                          (0, ht.jsx)(Ke.AW, {
                            path: "/account/*",
                            element: (0, ht.jsx)(cn, {}),
                          }),
                          (0, ht.jsx)(Ke.AW, {
                            path: "/r/:permalinkFragment/:version/*",
                            element: (0, ht.jsx)(Rs, {}),
                          }),
                          (0, ht.jsx)(Ke.AW, {
                            path: "/*",
                            element: (0, ht.jsx)(Rs, {}),
                          }),
                        ],
                      }),
                    }),
                  ],
                }),
                (0, ht.jsx)(yn, { className: "XNbml" }),
                !n &&
                  (0, ht.jsx)(rt.qX, {
                    type: gt.gr.pn,
                    className: "ELopF",
                    children: (0, et.Z)("No Internet Connection"),
                  }),
              ],
            });
            return e || t.width <= Gn
              ? (0, ht.jsx)(Fn, { children: i })
              : (0, ht.jsx)("div", { className: Rn, children: i });
          };
        var Bn = r(11162);
        const qn = Ce()
            ? (0, ze.lazy)(() =>
                Promise.all([r.e(648), r.e(961)]).then(r.bind(r, 87168))
              )
            : () => {},
          Hn = () => {
            const e = (0, We.v9)((e) => e.regexEditor.regex),
              t = (0, We.v9)((e) => e.regexEditor.flags),
              r = (0, We.v9)((e) => e.regexEditor.delimiter),
              s = (0, We.v9)((e) => e.regexEditor.testString),
              n = (0, We.v9)(
                (e) =>
                  e.regexEditor.showSubstitutionArea ||
                  e.regexEditor.showListSubstitutionArea
              ),
              a = (0, We.v9)((e) => e.regexEditor.substString),
              i = (0, We.v9)((e) => e.regexEditor.flavor),
              o = (0, Ye.lr)({ language: As.aQ }),
              c = (0, st.Z)(o, 1)[0];
            if (!e) return (0, ht.jsx)(rt.l_, { to: "/" });
            const l = c.get("language"),
              u = As.vI.find((e) => e.value === l) || As.vI[0],
              h = (0, ht.jsxs)("div", {
                className: "KRaGv",
                children: [
                  (0, ht.jsx)(rt.$j, { className: "cvoeF", size: gt.J7.TC }),
                  (0, et.Z)("Loading code sample..."),
                ],
              });
            return (0, ht.jsxs)("div", {
              className: "zOaGx",
              children: [
                (0, ht.jsxs)("div", {
                  className: "vkmye",
                  children: [
                    (0, ht.jsx)(rt.gx, {
                      header: (0, ht.jsx)(rt.__, {
                        text: (0, et.Z)("Language"),
                      }),
                      className: "kolUL",
                      children: (0, ht.jsx)(Ft.Z, {
                        children: As.vI.map((e) =>
                          (0, ht.jsx)(
                            Vs,
                            {
                              isActive: e.value === u.value,
                              icon: nt.mV1,
                              to: `?language=${e.value}`,
                              children: e.string,
                            },
                            `codegen-${e.value}`
                          )
                        ),
                      }),
                    }),
                    (0, ht.jsx)(rt.gx, {
                      header: (0, ht.jsx)(rt.__, {
                        text: (0, et.Z)("Generated Code"),
                      }),
                      className: "EHsbj",
                      children: (0, ht.jsx)(Bn.Z, {
                        className: "tu4NX",
                        children: (0, ht.jsx)(rt.I2, {
                          fallback: h,
                          children: (0, ht.jsx)(qn, {
                            regex: e,
                            flags: t,
                            delimiter: r,
                            testString: s,
                            isSubstituting: n,
                            substString: a,
                            flavor: i,
                            isGlobal: t.includes("g"),
                            language: u.value,
                          }),
                        }),
                      }),
                    }),
                  ],
                }),
                (0, ht.jsx)(rt.qX, {
                  className: "UB_yQ",
                  children: (0, ht.jsxs)("p", {
                    children: [
                      (0, et.Z)(
                        "Please keep in mind that these code samples are automatically generated and are not guaranteed to work. If you find any syntax errors, feel free to submit a bug report."
                      ),
                      " ",
                      (0, et.Z)(
                        "For a full regex reference for {1}, please visit:",
                        u.string
                      ),
                      " ",
                      (0, ht.jsx)(rt.rU, {
                        to: u.referencePage,
                        absolute: !0,
                        target: "_blank",
                        children: u.referencePage,
                      }),
                    ],
                  }),
                }),
              ],
            });
          },
          $n = Ce()
            ? (0, ze.lazy)(() => r.e(153).then(r.bind(r, 49159)))
            : () => {},
          zn = () => {
            const e = (0, Ke.UO)(),
              t = e.permalinkFragment,
              r = e.version,
              s = (0, Ye.lr)(),
              n = (0, st.Z)(s, 1)[0].get("testId"),
              a = (0, We.v9)((e) => e.regexEditor.showUnitTestArea),
              i = (0, We.v9)((e) => (isNaN(n) ? null : e.unitTests.tests[n])),
              o = (0, We.v9)((e) => e.regexEditor.regex),
              c = (0, We.v9)((e) => e.regexEditor.delimiter),
              l = (0, We.v9)((e) => e.regexEditor.flags),
              u = (0, We.v9)((e) => e.regexEditor.testString),
              h = (0, We.v9)((e) => e.regexEditor.flavor);
            if (!(0, Ts.G)(h) || "" === o || (a && null == i)) {
              const e = null != t ? `/r/${t}/${r}` : "/";
              return (0, ht.jsx)(rt.l_, { to: e });
            }
            const p = (0, ht.jsxs)("div", {
              className: "pWsZe",
              children: [
                (0, ht.jsx)(rt.$j, { className: "q_luf" }),
                (0, ht.jsx)("div", {
                  className: "_6fv9",
                  children: (0, et.Z)(
                    "Please wait while your expression is being debugged..."
                  ),
                }),
              ],
            });
            return (0, ht.jsx)(rt.I2, {
              fallback: p,
              errorClassName: "LeB5S",
              children: (0, ht.jsx)($n, {
                regex: o,
                flags: l,
                testString: (null == i ? void 0 : i.testString) || u,
                flavor: h,
                delimiter: c,
              }),
            });
          };
        var Wn = r(17159);
        const Yn = "luWMx",
          Kn = "xYbLs";
        function Jn(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Xn(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Jn(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Jn(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Qn = (0, At.Z)(It.oA),
          ea = {
            appear: Yn,
            appearActive: Kn,
            enter: Yn,
            enterActive: Kn,
            exit: "d0ccR",
            exitActive: "CZqGt",
          },
          ta = ({
            children: e,
            title: t,
            preserveLocation: r,
            location: s,
          }) => {
            const n = (0, Ke.s0)(),
              a = (0, ze.useMemo)(() => {
                const e = (0, Ke.i3)("..", s.pathname);
                return r ? Xn(Xn({}, s), {}, { pathname: e.pathname }) : e;
              }, [s, r]),
              i = (0, ze.useCallback)(
                (e) => {
                  e.stopPropagation(), n(a);
                },
                [n, a]
              );
            (0, ze.useEffect)(
              () => (
                tt.ZP.once("key:escape", i),
                tt.ZP.emit(tt.B3, Ht.UPDATE_REGEX),
                tt.ZP.emit(tt.B3, Ht.SAVE_REGEX),
                () => {
                  tt.ZP.off("key:escape", i),
                    tt.ZP.emit(tt.LG, Ht.UPDATE_REGEX),
                    tt.ZP.emit(tt.LG, Ht.SAVE_REGEX);
                }
              ),
              [i]
            );
            const o = (0, ze.useCallback)((e) => e.stopPropagation(), []);
            return (0, ht.jsx)(rt.iQ, {
              children: (0, ht.jsx)("div", {
                className: "FAEdS",
                onClick: i,
                children: (0, ht.jsx)("div", {
                  className: "oc96W",
                  children: (0, ht.jsxs)("div", {
                    className: "Q0dmP",
                    onClick: o,
                    children: [
                      (0, ht.jsxs)("div", {
                        className: "OaNsb",
                        children: [
                          (0, ht.jsx)("h1", { children: t }),
                          (0, ht.jsx)(rt.Yd, {
                            className: "MGagp",
                            onClick: i,
                            "aria-label": (0, et.Z)("Close"),
                            children: (0, ht.jsx)(nt.eSQ, {
                              size: 24,
                              className: "e1IQs",
                            }),
                          }),
                        ],
                      }),
                      (0, ht.jsx)("div", { className: "wy53k", children: e }),
                    ],
                  }),
                }),
              }),
            });
          },
          ra = ({
            children: e,
            title: t,
            preserveLocation: r = !1,
            path: s,
          }) => {
            const n = (0, Ke.TH)();
            return (0, ht.jsx)(rt.h_, {
              isOpen: !0,
              closeTimeout: Qn,
              children: (0, ht.jsx)(dn.Z, {
                component: null,
                children: (0, ht.jsx)(
                  Wn.Z,
                  {
                    classNames: ea,
                    timeout: Qn,
                    children: (0, ht.jsx)(Ke.Z5, {
                      location: n,
                      children: (0, ht.jsx)(Ke.AW, {
                        path: s,
                        element: (0, ht.jsx)(ta, {
                          children: e,
                          title: t,
                          preserveLocation: r,
                          location: n,
                        }),
                      }),
                    }),
                  },
                  n.pathname
                ),
              }),
            });
          };
        var sa = r(90375);
        const na = "PngQi",
          aa = ({ onResize: e, className: t }) => {
            const r = (0, ze.useState)(!1),
              s = (0, st.Z)(r, 2),
              n = s[0],
              a = s[1],
              i = (0, ze.useState)(0),
              o = (0, st.Z)(i, 2),
              c = o[0],
              l = o[1],
              u = (0, ze.useState)(0),
              h = (0, st.Z)(u, 2),
              p = h[0],
              d = h[1],
              g = (0, ze.useCallback)((e) => {
                a(!0), l(e.clientX), d(e.clientY);
              }, []);
            return (
              (0, ze.useEffect)(() => {
                const t = (t) =>
                    e({
                      x: t.clientX,
                      y: t.clientY,
                      dx: Math.abs(c - t.clientX),
                      dy: Math.abs(p - t.clientY),
                    }),
                  r = () => {
                    document.body.classList.remove(na),
                      window.removeEventListener("mouseup", r, { passive: !0 }),
                      window.removeEventListener("mousemove", t, {
                        passive: !0,
                      }),
                      a(!1);
                  };
                return (
                  n &&
                    (document.body.classList.add(na),
                    window.addEventListener("mouseup", r, { passive: !0 }),
                    window.addEventListener("mousemove", t, { passive: !0 })),
                  () => {
                    document.body.classList.remove(na),
                      window.removeEventListener("mouseup", r, { passive: !0 }),
                      window.removeEventListener("mousemove", t, {
                        passive: !0,
                      });
                  }
                );
              }, [n, e, c, p]),
              (0, ht.jsx)("div", {
                className: Xe()("Kmeux", t),
                onMouseDown: g,
              })
            );
          },
          ia = (0, ze.memo)(aa),
          oa = ({ children: e }) => {
            const t = (0, We.I0)(),
              r = (0, We.v9)((e) => e.rightSidebar.width),
              s = (0, ze.useState)(r),
              n = (0, st.Z)(s, 2),
              a = n[0],
              i = n[1],
              o = (0, ze.useRef)(null),
              c = (0, sa.Z)((e) => {
                t((0, je.Gj)(e)), t((0, je.Ot)()), i(e);
              }, q.UPDATE_RESULT_DELAY),
              l = (0, ze.useCallback)(
                (e) => {
                  var t;
                  tt.ZP.emit(tt.$7);
                  const r = window.innerWidth - e.x;
                  c(r),
                    null !== (t = o.current) &&
                      void 0 !== t &&
                      t.style &&
                      (o.current.style.width = `${r}px`);
                },
                [c]
              );
            return (
              (0, ze.useEffect)(() => () => c.cancel(), [c]),
              (0, ht.jsxs)("div", {
                className: "IPjTl",
                style: { width: `${a}px` },
                ref: o,
                children: [
                  (0, ht.jsx)(ia, { className: "RyQaE", onResize: l }),
                  e,
                ],
              })
            );
          },
          ca = [
            "className",
            "nodeLabel",
            "children",
            "defaultCollapsed",
            "onClick",
          ];
        function la(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function ua(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? la(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : la(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const ha = (e) => {
          let t = e.className,
            r = e.nodeLabel,
            s = e.children,
            n = e.defaultCollapsed,
            a = void 0 !== n && n,
            i = e.onClick,
            o = (0, T.Z)(e, ca);
          const c = (0, ze.useState)(a),
            l = (0, st.Z)(c, 2),
            u = l[0],
            h = l[1],
            p = (0, ze.useCallback)(
              (...e) => {
                h((e) => !e), i && i(...e);
              },
              [i]
            );
          return (0, ht.jsxs)(
            "div",
            ua(
              ua({ className: Xe()("UHIuh", t), onClick: i }, o),
              {},
              {
                children: [
                  (0, ht.jsxs)("div", {
                    className: "eZsI3",
                    children: [
                      (0, ht.jsx)(rt.Yd, {
                        className: "ng0cj",
                        onClick: p,
                        "aria-label": u
                          ? (0, et.Z)("Expand Subtree")
                          : (0, et.Z)("Collapse Subtree"),
                        children: (0, ht.jsx)("div", {
                          className: Xe()("NjK4I", u && "qtFSJ"),
                        }),
                      }),
                      r,
                    ],
                  }),
                  !u && (0, ht.jsx)("div", { className: "UF5u5", children: s }),
                ],
              }
            )
          );
        };
        var pa = r(67664),
          da = r(1277),
          ga = r(20400),
          ma = r(1947);
        function fa(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function xa(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? fa(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : fa(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        function ba(e) {
          return (0, ht.jsx)("span", {
            className: ma.Z.tokenSample,
            children: (0, ht.jsx)(ga.Z, { text: e }),
          });
        }
        function va(e) {
          return (0, ht.jsx)("span", { className: ma.Z.keyword, children: e });
        }
        function ja(e) {
          return (0, ht.jsx)("span", {
            className: ma.Z.plainText,
            children: (0, ht.jsx)(ga.Z, { text: e, removeNewlines: !0 }),
          });
        }
        function ya(e) {
          const t = ["th", "st", "nd", "rd"],
            r = e % 100;
          return e + (t[(r - 20) % 10] || t[r] || t[0]);
        }
        function Oa(e) {
          return e.map((e, t) =>
            e.error
              ? (0, ht.jsxs)(
                  "div",
                  {
                    children: [
                      (0, ht.jsx)("span", {
                        className: Xe()(ma.Z.token, e.style),
                        children: e.string,
                      }),
                      " ",
                      wa(e.error),
                    ],
                  },
                  `error-explanation-${t}`
                )
              : null
          );
        }
        function wa(e) {
          switch (e) {
            case pa.CL:
              return (0, et.Z)("Incomplete group structure");
            case pa.Xu:
              return (0, et.Z)(
                "The condition is invalid (you may be referencing a non-existent subpattern or group)"
              );
            case pa.wi:
              return (0, et.Z)("A subpattern name must be unique");
            case pa.kU:
              return (0, et.Z)(
                "A subpattern name must be alpha numeric and may not begin with a digit"
              );
            case pa.cs:
              return (0, et.Z)(
                "There are too many alternatives within the parent structure"
              );
            case pa.gN:
              return (0, et.Z)("This verb is unknown or invalid");
            case pa.As:
              return (0, et.Z)(
                "This verb must be placed at the start of the regex"
              );
            case pa.Bj:
              return (0, et.Z)(
                "This token references a non-existent or invalid subpattern"
              );
            case pa.RY:
              return (0, et.Z)("The preceding token is not quantifiable");
            case pa.Hh:
              return (0, et.Z)("The quantifier range is out of order");
            case pa.sw:
              return (0, et.Z)("Character class missing closing bracket");
            case pa.i0:
              return (0, et.Z)("Character range is out of order");
            case pa.fA:
              return (0, et.Z)(
                "A posix character class may only appear inside a character class"
              );
            case pa.VM:
              return (0, et.Z)("The posix class is unknown/invalid");
            case pa.RH:
              return (0, et.Z)(
                "This token is either not supported by the selected flavor or by regex101"
              );
            case pa.zX:
              return (0, et.Z)("Pattern may not end with a trailing backslash");
            case pa.t0:
              return (0, ht.jsx)(rt.vV, {
                text: "An unescaped delimiter must be escaped with a backslash ({1})",
                ph1: ba("\\"),
              });
            case pa.Yo:
              return (0, et.Z)("No hex code was specified");
            case pa.y1:
              return (0, et.Z)("The character offset is too large");
            case pa.oH:
              return (0, et.Z)(
                "Surrogate values are disallowed in Unicode mode"
              );
            case pa.Rf:
              return (0, et.Z)("The value specified is too large");
            case pa.XD:
              return (0, et.Z)(
                "A quote without content has ambiguous behavior and should be avoided"
              );
            case pa.YY:
              return (0, et.Z)("The token is incomplete");
            case pa.xi:
              return (0, et.Z)("This script is unknown/invalid");
            case pa.Iu:
              return (0, et.Z)("Invalid control character");
            case pa.mi:
              return (0, et.Z)(
                "This token has no special meaning and has thus been rendered erroneous"
              );
            case pa.bk:
              return (0, et.Z)(
                "A named subpattern may not have a name which length exceeds 32 characters"
              );
            case pa.eB:
              return (0, et.Z)("A lookbehind assertion has to be fixed width");
            case pa.jV:
              return (0, et.Z)(
                "This token can not be used in a lookbehind due to either making it non-fixed width or interfering with the pattern matching"
              );
            case pa.Cc:
              return (0, et.Z)(
                "A quantifier inside a lookbehind makes it non-fixed width"
              );
            case pa.M3:
              return (0, et.Z)(
                "Regex101 only supports inline modifiers to be placed at the start of the regex for python (which is also best practice)"
              );
            case pa.mB:
              return (0, ht.jsx)(rt.vV, {
                text: "You can not set both the {1} and {2} flag simultaneously",
                ph1: (0, ht.jsx)("strong", {
                  className: ma.Z.flags,
                  children: "a",
                }),
                ph2: (0, ht.jsx)("strong", {
                  className: ma.Z.flags,
                  children: "u",
                }),
              });
            case pa.BC:
              return (0, et.Z)(
                "You cannot create a range with shorthand escape sequences"
              );
            case pa.jb:
              return (0, et.Z)(
                "The escape sequence to match backspace is not supported in the selected flavor"
              );
            case pa.d3:
              return (0, et.Z)(
                "Due to a bug in PCRE creating ranges with an escaped literal is unsafe. To avoid this, simply use the literal representation instead"
              );
            case pa.K0:
              return (0, et.Z)("Invalid unicode escape");
            case pa.Vt:
              return (0, et.Z)("Quantifier range is too large");
            case pa.wn:
              return (0, et.Z)(
                "Groups with the same index must either have the same name or both be non-named groups"
              );
            case pa.f0:
              return (0, et.Z)("Unmatched parenthesis");
            case pa.IA:
              return (0, ht.jsx)(rt.vV, {
                text: "This token must be escaped when the {1} flag is enabled unless they form a valid quantifier",
                ph1: (0, ht.jsx)("strong", {
                  className: ma.Z.flag,
                  children: "u",
                }),
              });
            case pa.Y4:
              return (0, et.Z)(
                "The range is invalid because either the left or right token is erroneous"
              );
            case pa.wW:
              return (0, et.Z)(
                "Bogus escape: this escape is not recognized in the python flavor"
              );
            case pa.Qc:
              return (0, ht.jsx)(rt.vV, {
                text: "Backticks can not be used in a raw string, use {1} instead",
                ph1: ba("\\x60"),
              });
            case pa.$H:
              return (0, et.Z)(
                "POSIX Word Boundaries must be the only item inside a character class"
              );
            case pa.Af:
              return (0, et.Z)(
                "Character range with surrogate pairs without unicode enabled results in ambiguous behavior"
              );
            case pa.of:
              return (0, ht.jsx)(rt.vV, {
                text: "This token is not valid under strict mode, and may cause certain browsers to throw errors. If you need to reference this subpattern, use the {1} syntax, otherwise use the token literally.",
                ph1: ba("$n"),
              });
            case pa.Gz:
              return (0, et.Z)(
                "Invalid placement of hyphen; there may only be one inside the group"
              );
            case pa.rs:
              return (0, et.Z)("Unmatched opening bracket");
            case pa.Jf:
              return (0, et.Z)(
                "The number following the backslash is too large"
              );
            case pa.O3:
              return (0, et.Z)(
                "You may not use a null byte in your regex, as that effectively terminates it at that position"
              );
            case pa.jz:
              return (0, et.Z)(
                "Invalid character class intersection. Make sure the tokens to the left and right of this token are intersectable"
              );
            case pa.sb:
              return (0, et.Z)(
                "Named backreference may not be used before group definition"
              );
            case pa.Oy:
              return (0, et.Z)(
                "Backreferences may not be placed inside character classes. If you meant to create an octal escape, prefix the escape with a 0."
              );
            case pa.Ey:
              return (0, ht.jsx)(rt.vV, {
                text: "End quote literals without a corresponding open quote literal {1} match null, and only serve to create visual noise. If you meant to match the literal {2}, remove the backslash.",
                ph1: ba("\\Q"),
                ph2: ja("E"),
              });
            case pa.xX:
              return (0, et.Z)(
                "You cannot nest conditional replacements more than 10 levels deep"
              );
            case pa.KE:
              return (0, et.Z)(
                "You cannot create a range with an opening bracket"
              );
            case pa.bb:
              return (0, et.Z)(
                "Character class subtraction may only be done at the end of a character class"
              );
            default:
              return $e.O7(new Error(`Unknown error type '${e}'`)), null;
          }
        }
        function Ca(e, t = !1, r = !1) {
          const s = e.state.lineTerminators;
          let n = "";
          t &&
            s.includes("\\r") &&
            s.includes("\\n") &&
            !s.includes("\\r\\n") &&
            (n = `(${(0, et.Z)(
              "with no special consideration for the \\r\\n sequence"
            )})`);
          let a = "";
          return (
            (a = r
              ? (0, et.Z)("Lines are delimited by: {1} {2}", s.join(", "), n)
              : (0, et.Z)("Line terminator(s) are: {1} {2}", s.join(", "), n)),
            (0, ht.jsx)(rt.lx, {
              text: a,
              direction: gt.qF.NW,
              multiline: !0,
              children: (0, ht.jsx)("div", {
                className: ma.Z.tooltip,
                role: "figure",
                children: (0, ht.jsx)(nt.zXH, {
                  size: 16,
                  className: ma.Z.icon,
                }),
              }),
            })
          );
        }
        const Ea = (e) => {
          const t = [];
          let r = null;
          for (let s = 0, n = e.length; s < n; s++) {
            const n = e[s];
            if (!n.string) continue;
            const a = { string: n.string, style: n.style };
            n.editorPosition &&
              (a.editorPosition = {
                start: {
                  pos: n.editorPosition.start.pos,
                  line: n.editorPosition.start.line,
                },
                end: {
                  pos: n.editorPosition.end.pos,
                  line: n.editorPosition.end.line,
                },
              }),
              r && r.style === a.style
                ? ((r.string += a.string),
                  a.editorPosition &&
                    (r.editorPosition.end = a.editorPosition.end))
                : (t.push(a), (r = a));
          }
          return t;
        };
        function Za(e, t) {
          return Sa(e, t);
        }
        function Sa(e, t, r = !1) {
          const s = e.state.flags.includes("x"),
            n = e.state.flags.includes("xx"),
            a = e.state.flags.includes("i");
          let i = t;
          if (
            (!r &&
              ((s && !e.state.inCharClass) || n) &&
              e.type !== da.$U &&
              (i = i.replace(/[ \t\r\n\f]/g, "")),
            0 === i.length)
          )
            return { explanation: null };
          const o = e.codePoint || e.charCode;
          if (e.isSubstitution)
            return {
              explanation: (0, ht.jsx)(rt.vV, {
                text: "inserts the character {1} with index {2} ({3} or {4})",
                ph1: ja(i),
                ph2: va(
                  (0, ht.jsxs)(ht.Fragment, {
                    children: [o, (0, ht.jsx)("sub", { children: "10" })],
                  })
                ),
                ph3: va(
                  (0, ht.jsxs)(ht.Fragment, {
                    children: [
                      o.toString(16).toUpperCase(),
                      (0, ht.jsx)("sub", { children: "16" }),
                    ],
                  })
                ),
                ph4: va(
                  (0, ht.jsxs)(ht.Fragment, {
                    children: [
                      o.toString(8).toUpperCase(),
                      (0, ht.jsx)("sub", { children: 8 }),
                    ],
                  })
                ),
              }),
            };
          const c = ((e) => {
              let t = 0;
              for (let r = 0; r < e.length; ) {
                let s = e.codePointAt(r),
                  n = 0;
                for (; s; ) (n += 1), (s >>= 8);
                (r += Math.round(n / 2)), (t += 1);
              }
              return t;
            })(i),
            l = a ? (0, et.Z)("case insensitive") : (0, et.Z)("case sensitive");
          if (e.state.inCharClass && c > 1) {
            const e = (0, Y.Z)(i).join("");
            return {
              explanation: (0, ht.jsxs)(ht.Fragment, {
                children: [
                  (0, et.Z)("matches a single character in the list"),
                  " ",
                  ja(e),
                  " (",
                  l,
                  ")",
                ],
              }),
            };
          }
          const u =
            e.state.inCharClass && e.isPoorlyPlaced && "-" === t
              ? (0, ht.jsx)(rt.qX, {
                  children: (0, et.Z)(
                    "This hyphen is treated literally, which might be confusing for others. Consider escaping it or placing at the start or end of the class."
                  ),
                })
              : null;
          return 1 === c && e.type !== da.$U
            ? {
                explanation: (0, ht.jsx)(rt.vV, {
                  text: "matches the character {1} with index {2} ({3} or {4}) literally ({5})",
                  ph1: ja(i),
                  ph2: va(
                    (0, ht.jsxs)(ht.Fragment, {
                      children: [o, (0, ht.jsx)("sub", { children: "10" })],
                    })
                  ),
                  ph3: va(
                    (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        o.toString(16).toUpperCase(),
                        (0, ht.jsx)("sub", { children: "16" }),
                      ],
                    })
                  ),
                  ph4: va(
                    (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        o.toString(8).toUpperCase(),
                        (0, ht.jsx)("sub", { children: 8 }),
                      ],
                    })
                  ),
                  ph5: l,
                }),
                notice: u,
              }
            : {
                explanation: (0, ht.jsx)(rt.vV, {
                  text: "matches the characters {1} literally ({2})",
                  ph1: ja(i),
                  ph2: l,
                }),
                notice: u,
              };
        }
        function ka(e) {
          return 0 === e
            ? (0, et.Z)("zero")
            : 1 === e
            ? (0, et.Z)("one")
            : e === 1 / 0
            ? (0, et.Z)("unlimited")
            : e;
        }
        function Pa(e, t, r, s) {
          const n = (function (e, t, r) {
            if ("g" === t)
              return (0, ht.jsx)(rt.vV, {
                text: "{1}. All matches (don't return after first match)",
                ph1: (0, ht.jsxs)(ht.Fragment, {
                  children: [(0, ht.jsx)("strong", { children: "g" }), "lobal"],
                }),
              });
            if ("i" === t)
              return r
                ? (0, ht.jsx)(rt.vV, {
                    text: "{1}. Case insensitive match (ignores case of {2})",
                    ph1: (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        (0, ht.jsx)("strong", { children: "i" }),
                        "nsensitive",
                      ],
                    }),
                    ph2: ba("[a-zA-Z]"),
                  })
                : (0, ht.jsx)(rt.vV, {
                    text: "{1}. Case sensitive match",
                    ph1: (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        "-",
                        (0, ht.jsx)("strong", { children: "i" }),
                        "nsensitive",
                      ],
                    }),
                  });
            if ("J" === t)
              return r
                ? (0, ht.jsx)(rt.vV, {
                    text: "Allow duplicate subpattern names",
                  })
                : (0, ht.jsx)(rt.vV, {
                    text: "Disallow duplicate subpattern names",
                  });
            if ("s" === t)
              return r
                ? (0, ht.jsx)(rt.vV, {
                    text: "{1}. Dot matches newline characters {2}",
                    ph1: (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        (0, ht.jsx)("strong", { children: "s" }),
                        "ingle line",
                      ],
                    }),
                    ph2:
                      e === j().JAVASCRIPT
                        ? (0, ht.jsx)("strong", { children: "(draft)" })
                        : "",
                  })
                : (0, ht.jsx)(rt.vV, {
                    text: "{1}. A dot won't match {2}",
                    ph1: (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        "-",
                        (0, ht.jsx)("strong", { children: "s" }),
                        "ingle line",
                      ],
                    }),
                    ph2: ba("\\n"),
                  });
            if ("m" === t)
              return r
                ? (0, ht.jsx)(rt.vV, {
                    text: "{1}. Causes {2} and {3} to match the begin/end of each line (not only begin/end of string)",
                    ph1: (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        (0, ht.jsx)("strong", { children: "m" }),
                        "ulti line",
                      ],
                    }),
                    ph2: ba("^"),
                    ph3: ba("$"),
                  })
                : (0, ht.jsx)(rt.vV, {
                    text: "{1}. Causes {2} and {3} to match begin/end of string",
                    ph1: (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        "-",
                        (0, ht.jsx)("strong", { children: "m" }),
                        "ulti line",
                      ],
                    }),
                    ph2: ba("^"),
                    ph3: ba("$"),
                  });
            if ("xx" === t)
              return r
                ? (0, ht.jsx)(rt.vV, {
                    text: "{1}. Spaces and text after a {2} in the pattern are ignored (even whitespace inside character classes)",
                    ph1: (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        "e",
                        (0, ht.jsx)("strong", { children: "x" }),
                        "tra e",
                        (0, ht.jsx)("strong", { children: "x" }),
                        "tended",
                      ],
                    }),
                    ph2: va("#"),
                  })
                : (0, ht.jsx)(rt.vV, {
                    text: "{1}. Whitespaces and {2} in the pattern are treated literally",
                    ph1: (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        "-e",
                        (0, ht.jsx)("strong", { children: "x" }),
                        "tra e",
                        (0, ht.jsx)("strong", { children: "x" }),
                        "tended",
                      ],
                    }),
                    ph2: va("#"),
                  });
            if ("x" === t)
              return r
                ? (0, ht.jsx)(rt.vV, {
                    text: "{1}. Spaces and text after a {2} in the pattern are ignored",
                    ph1: (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        "e",
                        (0, ht.jsx)("strong", { children: "x" }),
                        "tended",
                      ],
                    }),
                    ph2: va("#"),
                  })
                : (0, ht.jsx)(rt.vV, {
                    text: "{1}. Whitespaces and {2} in the pattern are treated literally",
                    ph1: (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        "-e",
                        (0, ht.jsx)("strong", { children: "x" }),
                        "tended",
                      ],
                    }),
                    ph2: va("#"),
                  });
            if ("X" === t)
              return (0, ht.jsx)(rt.vV, {
                text: "{1}. A {2} followed by a letter with no special meaning is faulted",
                ph1: (0, ht.jsxs)(ht.Fragment, {
                  children: [
                    "e",
                    (0, ht.jsx)("strong", { children: "X" }),
                    "tra",
                  ],
                }),
                ph2: va("\\"),
              });
            if ("A" === t)
              return (0, ht.jsx)(rt.vV, {
                text: "{1}. The pattern is forced to become anchored at the start of the search, or at the position of the last successful match, equivalent to a {2}",
                ph1: (0, ht.jsxs)(ht.Fragment, {
                  children: [
                    (0, ht.jsx)("strong", { children: "A" }),
                    "nchored",
                  ],
                }),
                ph2: ba("\\G"),
              });
            if ("U" === t)
              return e === j().JAVA
                ? (0, ht.jsx)(rt.vV, {
                    text: "{1}. Enable the built in character classes to also match unicode characters",
                    ph1: (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        (0, ht.jsx)("strong", { children: "U" }),
                        "nicode",
                      ],
                    }),
                  })
                : r
                ? (0, ht.jsx)(rt.vV, {
                    text: "{1}. The match becomes lazy by default. Now a {2} following a quantifier makes it greedy",
                    ph1: (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        (0, ht.jsx)("strong", { children: "U" }),
                        "ngreedy",
                      ],
                    }),
                    ph2: ba("?"),
                  })
                : (0, ht.jsx)(rt.vV, {
                    text: "{1}. The match becomes greedy by default",
                    ph1: (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        "-",
                        (0, ht.jsx)("strong", { children: "U" }),
                        "ngreedy",
                      ],
                    }),
                  });
            if ("u" === t) {
              if (e === j().PCRE || e === j().PCRE2)
                return (0, ht.jsx)(rt.vV, {
                  text: "{1}. Pattern strings are treated as {2}. Also causes escape sequences to match unicode characters",
                  ph1: (0, ht.jsxs)(ht.Fragment, {
                    children: [
                      (0, ht.jsx)("strong", { children: "u" }),
                      "nicode",
                    ],
                  }),
                  ph2: va("UTF-16"),
                });
              if (e === j().PYTHON)
                return (0, ht.jsx)(rt.vV, {
                  text: "{1}. Make {2}, {3}, {4}, {5}, {6}, {7}, {8} and {9} perform matching with Unicode semantic (redundant in Python 3)",
                  ph1: (0, ht.jsxs)(ht.Fragment, {
                    children: [
                      (0, ht.jsx)("strong", { children: "u" }),
                      "nicode",
                    ],
                  }),
                  ph2: ba("\\w"),
                  ph3: ba("\\W"),
                  ph4: ba("\\b"),
                  ph5: ba("\\B"),
                  ph6: ba("\\d"),
                  ph7: ba("\\D"),
                  ph8: ba("\\s"),
                  ph9: ba("\\S"),
                });
              if (e === j().JAVASCRIPT)
                return (0, ht.jsx)(rt.vV, {
                  text: "{1}. Enable all unicode features and interpret all unicode escape sequences as such",
                  ph1: (0, ht.jsxs)(ht.Fragment, {
                    children: [
                      (0, ht.jsx)("strong", { children: "u" }),
                      "nicode",
                    ],
                  }),
                });
              if (e === j().JAVA)
                return r
                  ? (0, ht.jsx)(rt.vV, {
                      text: "{1}. Apply case insensitive matching to unicode characters in accordance with the unicode standard",
                      ph1: (0, ht.jsxs)(ht.Fragment, {
                        children: [
                          (0, ht.jsx)("strong", { children: "u" }),
                          "nicode case",
                        ],
                      }),
                    })
                  : (0, ht.jsx)(rt.vV, {
                      text: "{1}. Case insensitive matching is only applied to the US-ASCII character set",
                      ph1: (0, ht.jsxs)(ht.Fragment, {
                        children: [
                          "-",
                          (0, ht.jsx)("strong", { children: "u" }),
                          "nicode case",
                        ],
                      }),
                    });
            }
            return "a" === t
              ? (0, ht.jsx)(rt.vV, {
                  text: "{1}. Force the escape sequences {2}, {3}, {4}, {5}, {6}, {7}, {8} and {9} to perform ASCII-only matching instead of full Unicode matching",
                  ph1: (0, ht.jsxs)(ht.Fragment, {
                    children: [
                      (0, ht.jsx)("strong", { children: "a" }),
                      "scii",
                    ],
                  }),
                  ph2: ba("\\w"),
                  ph3: ba("\\W"),
                  ph4: ba("\\b"),
                  ph5: ba("\\B"),
                  ph6: ba("\\d"),
                  ph7: ba("\\D"),
                  ph8: ba("\\s"),
                  ph9: ba("\\S"),
                })
              : "D" === t
              ? (0, ht.jsx)(rt.vV, {
                  text: "{1}. Force the a dollar sign, {2}, to always match end of the string, instead of end of the line. This option is ignored if the {3}-flag is set",
                  ph1: (0, ht.jsxs)(ht.Fragment, {
                    children: [
                      (0, ht.jsx)("strong", { children: "D" }),
                      "ollar",
                    ],
                  }),
                  ph2: ba("$"),
                  ph3: ba("m"),
                })
              : "y" === t
              ? (0, ht.jsx)(rt.vV, {
                  text: "{1}. Force the pattern to only match consecutive matches from where the previous match ended.",
                  ph1: (0, ht.jsxs)(ht.Fragment, {
                    children: [
                      "stick",
                      (0, ht.jsx)("strong", { children: "y" }),
                    ],
                  }),
                })
              : "n" === t
              ? r
                ? (0, ht.jsx)(rt.vV, {
                    text: "{1}. All capturing groups {2} are instead treated as if they were non-capturing groups {3}.",
                    ph1: (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        (0, ht.jsx)("strong", { children: "n" }),
                        "o capture",
                      ],
                    }),
                    ph2: ba("()"),
                    ph3: ba("(?:)"),
                  })
                : (0, ht.jsx)(rt.vV, {
                    text: "{1}. Capturing groups {2} are no longer treated as if they were non-capturing groups {3}.",
                    ph1: (0, ht.jsxs)(ht.Fragment, {
                      children: [
                        (0, ht.jsx)("strong", { children: "n" }),
                        "o capture",
                      ],
                    }),
                    ph2: ba("()"),
                    ph3: ba("(?:)"),
                  })
              : "d" === t
              ? (0, ht.jsx)(rt.vV, {
                  text: "{1}. The JavaScript regex engine now returns the indices at which the regex matched in the subject string.",
                  ph1: (0, ht.jsxs)(ht.Fragment, {
                    children: [
                      "in",
                      (0, ht.jsx)("strong", { children: "d" }),
                      "ices",
                    ],
                  }),
                })
              : "R" === t
              ? (0, ht.jsx)(rt.vV, {
                  text: "{1}. The .NET regex engine now now performs matches from right to left, instead of left ro right.",
                  ph1: (0, ht.jsxs)(ht.Fragment, {
                    children: [
                      (0, ht.jsx)("strong", { children: "R" }),
                      "ight to left",
                    ],
                  }),
                })
              : void 0;
          })(e, t, s);
          return n
            ? (0, ht.jsxs)(
                "div",
                {
                  children: [
                    (0, ht.jsx)("span", {
                      className: Xe()(ma.Z.flag, !s && ma.Z.flagDisabled),
                      children: (0, et.Z)("{1} modifier:", t),
                    }),
                    " ",
                    n,
                  ],
                },
                `flag-${t}-${s}-${r}`
              )
            : ($e.O7(new Error(`Unable to explain '${t}'`)), null);
        }
        const Na = function (e, t, r) {
            return [].concat(
              null == e ? void 0 : e.map((e, t) => Pa(r, e, t, !0)),
              null == t ? void 0 : t.map((e, t) => Pa(r, e, t, !1))
            );
          },
          _a = (e) => {
            switch (e) {
              case "Letter":
              case "L":
                return (0, et.Z)(
                  "matches any kind of letter from any language"
                );
              case "Lowercase_Letter":
              case "Ll":
                return (0, et.Z)(
                  "matches a lowercase letter that has an uppercase variant"
                );
              case "Uppercase_Letter":
              case "Lu":
                return (0, et.Z)(
                  "matches an uppercase letter that has a lowercase variant"
                );
              case "Titlecase_Letter":
              case "Lt":
                return (0, et.Z)(
                  "matches a letter that appears at the start of a word when only the first letter of the word is capitalized"
                );
              case "Cased_Letter":
              case "LC":
              case "L&":
                return (0, ht.jsx)(rt.vV, {
                  text: "matches a letter that exists in lowercase and uppercase variants (combination of {1}, {2} and {3})",
                  ph1: ba("Ll"),
                  ph2: ba("Lu"),
                  ph3: ba("Lt"),
                });
              case "Modifier_Letter":
              case "Lm":
                return (0, et.Z)(
                  "matches a special character that is used like a letter"
                );
              case "Other_Letter":
              case "Lo":
                return (0, et.Z)(
                  "matches a letter or ideograph that does not have lowercase and uppercase variants"
                );
              case "Mark":
              case "M":
                return (0, et.Z)(
                  "matches a character intended to be combined with another character (e.g. accents, umlauts, enclosing boxes, etc.)"
                );
              case "Nonspacing_Mark":
              case "Mn":
                return (0, et.Z)(
                  "matches a character intended to be combined with another character without taking up extra space (e.g. accents, umlauts, etc.)"
                );
              case "Spacing_Mark":
              case "Mc":
                return (0, et.Z)(
                  "matches a character intended to be combined with another character that takes up extra space (vowel signs in many Eastern languages)"
                );
              case "Enclosing_Mark":
              case "Me":
                return (0, et.Z)(
                  "matches a character that encloses the character is is combined with (circle, square, keycap, etc.)"
                );
              case "Separator":
              case "Z":
                return (0, et.Z)(
                  "matches any kind of whitespace or invisible separator"
                );
              case "Space_Separator":
              case "Zs":
                return (0, et.Z)(
                  "matches a whitespace character that is invisible, but does take up space"
                );
              case "Line_Separator":
              case "Zl":
                return (0, ht.jsx)(rt.vV, {
                  text: "matches a line separator character {1}",
                  ph1: va("U+2028"),
                });
              case "Paragraph_Separator":
              case "Zp":
                return (0, ht.jsx)(rt.vV, {
                  text: "matches a paragraph separator character {1}",
                  ph1: va("U+2029"),
                });
              case "Symbol":
              case "S":
                return (0, et.Z)(
                  "matches any math symbols, currency signs, dingbats, box-drawing characters, etc"
                );
              case "Math_Symbol":
              case "Sm":
                return (0, et.Z)("matches any mathematical symbol");
              case "Currency_Symbol":
              case "Sc":
                return (0, et.Z)("matches any currency sign");
              case "Modifier_Symbol":
              case "Sk":
                return (0, et.Z)(
                  "matches a combining character (mark) as a full character on its own"
                );
              case "Other_Symbol":
              case "So":
                return (0, et.Z)(
                  "matches various symbols that are not math symbols, currency signs, or combining characters"
                );
              case "Number":
              case "N":
                return (0, et.Z)(
                  "matches any kind of numeric character in any script"
                );
              case "Decimal_Number":
              case "Nd":
                return (0, et.Z)(
                  "matches a digit zero through nine in any script except ideographic scripts"
                );
              case "Letter_Number":
              case "Nl":
                return (0, et.Z)(
                  "matches a number that looks like a letter, such as a Roman numeral"
                );
              case "Other_Number":
              case "No":
                return (0, et.Z)(
                  "matches a superscript or subscript digit, or a number that is not a digit (excluding numbers from ideographic scripts)"
                );
              case "Punctuation":
              case "P":
                return (0, et.Z)("matches any kind of punctuation character");
              case "Dash_Punctuation":
              case "Pd":
                return (0, et.Z)("matches any kind of hyphen or dash");
              case "Open_Punctuation":
              case "Ps":
                return (0, et.Z)("matches any kind of opening bracket");
              case "Close_Punctuation":
              case "Pe":
                return (0, et.Z)("matches any kind of closing bracket");
              case "Initial_Punctuation":
              case "Pi":
                return (0, et.Z)("matches any kind of opening quote");
              case "Final_Punctuation":
              case "Pf":
                return (0, et.Z)("matches any kind of closing quote");
              case "Connector_Punctuation":
              case "Pc":
                return (0, et.Z)(
                  "matches a punctuation character such as an underscore that connects words"
                );
              case "Other_Punctuation":
              case "Po":
                return (0, et.Z)(
                  "matches any kind of punctuation character that is not a dash, bracket, quote or connector"
                );
              case "Other":
              case "C":
                return (0, et.Z)(
                  "matches invisible control characters and unused code points"
                );
              case "Control":
              case "Cc":
                return (0, ht.jsx)(rt.vV, {
                  text: "matches an ASCII {1} or Latin-1 {2} control character",
                  ph1: ba("[\\x00-\\x1F]"),
                  ph2: ba("[\\x80-\\x9F]"),
                });
              case "Format":
              case "Cf":
                return (0, et.Z)("matches invisible formatting indicator");
              case "Private_Use":
              case "Co":
                return (0, et.Z)(
                  "matches any code point reserved for private use"
                );
              case "Surrogate":
              case "Cs":
                return (0, ht.jsx)(rt.vV, {
                  text: "matches one half of a surrogate pair in {1} encoding",
                  ph1: va("UTF-16"),
                });
              case "Unassigned":
              case "Cn":
                return (0, et.Z)(
                  "matches any code point to which no character has been assigned"
                );
              default:
                return null;
            }
          };
        function Ta(e, t, r) {
          const s = e.codePoint || e.charCode,
            n = String.fromCodePoint(s);
          if (e.isSubstitution)
            return {
              explanation: (0, ht.jsx)(rt.vV, {
                text: "inserts the character {1} with index {2} ({3} or {4})",
                ph1: ja(n),
                ph2: va(
                  (0, ht.jsxs)(ze.Fragment, {
                    children: [
                      s.toString(t).toUpperCase(),
                      (0, ht.jsx)("sub", { children: t }),
                    ],
                  })
                ),
                ph3: va(
                  (0, ht.jsxs)(ze.Fragment, {
                    children: [s, (0, ht.jsx)("sub", { children: "10" })],
                  })
                ),
                ph4: va(
                  (0, ht.jsxs)(ze.Fragment, {
                    children: [
                      s.toString(r).toUpperCase(),
                      (0, ht.jsx)("sub", { children: r }),
                    ],
                  })
                ),
              }),
            };
          const a = e.state.flags.includes("i")
            ? (0, et.Z)("case insensitive")
            : (0, et.Z)("case sensitive");
          return {
            explanation: (0, ht.jsx)(rt.vV, {
              text: "matches the character {1} with index {2} ({3} or {4}) literally ({5})",
              ph1: ja(n),
              ph2: va(
                (0, ht.jsxs)(ze.Fragment, {
                  children: [
                    s.toString(t).toUpperCase(),
                    (0, ht.jsx)("sub", { children: t }),
                  ],
                })
              ),
              ph3: va(
                (0, ht.jsxs)(ze.Fragment, {
                  children: [s, (0, ht.jsx)("sub", { children: "10" })],
                })
              ),
              ph4: va(
                (0, ht.jsxs)(ze.Fragment, {
                  children: [
                    s.toString(r).toUpperCase(),
                    (0, ht.jsx)("sub", { children: r }),
                  ],
                })
              ),
              ph5: a,
            }),
          };
        }
        function Aa(e) {
          const t =
            isNaN(e.reference) || null == e.reference
              ? e.reference
              : ya(e.reference);
          if (e.backreference)
            return (0, ht.jsx)(rt.vV, {
              tag: "span",
              text: "Conditionally matches one of two options depending on whether the {1} capturing group matched",
              ph1: va(t),
            });
          if (e.subroutine)
            return null === t && "R" === e.condition
              ? (0, ht.jsx)(rt.vV, {
                  tag: "span",
                  text: "Checks whether the whole pattern matches",
                  ph1: va(t),
                })
              : (0, ht.jsx)(rt.vV, {
                  tag: "span",
                  text: "Checks whether the {1} subroutine matches",
                  ph1: va(t),
                });
          throw new Error("Condition type is not specified");
        }
        const Ia = function (e) {
          const t = e.conditional;
          return t.lookaround
            ? {
                explanation: (0, ht.jsx)(rt.vV, {
                  text: "Conditionally matches one of two options depending on whether the lookaround matches",
                }),
              }
            : { explanation: Aa(t) };
        };
        var Ra = r(43154),
          Da = r(20411);
        function La(e, t = {}) {
          return (function (e, t) {
            const r = e.token,
              s = e.string,
              n = r.type;
            return n === da.MW
              ? (function (e, t) {
                  const r =
                      e.string.length > 1
                        ? e.string.charAt(1)
                        : e.string.charAt(0),
                    s = e.state.flags.includes("u"),
                    n = e.state.flags.includes("m"),
                    a = e.state.flags.includes("s"),
                    i = e.state.flags.includes("D"),
                    o = e.state.flavor === j().JAVASCRIPT,
                    c = e.state.flavor === j().PYTHON,
                    l = e.state.flavor === j().DOTNET;
                  if ("w" === r)
                    return (s && !o) || l
                      ? {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "match any word character in any script (equivalent to {1})",
                            ph1: ba("[\\p{L}\\p{N}_]"),
                          }),
                        }
                      : {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches any word character (equivalent to {1})",
                            ph1: ba("[a-zA-Z0-9_]"),
                          }),
                        };
                  if ("W" === r)
                    return (s && !o) || l
                      ? {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "match any non-word character in any script (equivalent to {1})",
                            ph1: ba("[^\\p{L}\\p{N}_]"),
                          }),
                        }
                      : {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches any non-word character (equivalent to {1})",
                            ph1: ba("[^a-zA-Z0-9_]"),
                          }),
                        };
                  if ("d" === r)
                    return (s && !o) || l
                      ? {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches a digit zero through nine in any script except ideographic scripts (equivalent to {1})",
                            ph1: ba("\\p{Nd}"),
                          }),
                        }
                      : {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches a digit (equivalent to {1})",
                            ph1: ba("[0-9]"),
                          }),
                        };
                  if ("D" === r)
                    return (s && !o) || l
                      ? {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches any non-numeric character in any script (equivalent to {1})",
                            ph1: ba("\\p{Nd}"),
                          }),
                        }
                      : {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches any character that's not a digit (equivalent to {1})",
                            ph1: ba("[^0-9]"),
                          }),
                        };
                  if ("s" === r) {
                    if (o)
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches any whitespace character (equivalent to {1})",
                          ph1: ba(
                            "[\\r\\n\\t\\f\\v \\u00a0\\u1680\\u2000-\\u200a\\u2028\\u2029\\u202f\\u205f\\u3000\\ufeff]"
                          ),
                        }),
                      };
                    if (s || l)
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches any kind of invisible character (equivalent to {1})",
                          ph1: ba("[\\p{Z}\\h\\v]"),
                        }),
                      };
                    const e = ba(
                      c ? "[\\r\\n\\t\\f\\v \xa0]" : "[\\r\\n\\t\\f\\v ]"
                    );
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "matches any whitespace character (equivalent to {1})",
                        ph1: e,
                      }),
                    };
                  }
                  if ("S" === r)
                    return o
                      ? {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches any non-whitespace character (equivalent to {1})",
                            ph1: ba(
                              "[^\\r\\n\\t\\f\\v \\u00a0\\u1680\\u2000-\\u200a\\u2028\\u2029\\u202f\\u205f\\u3000\\ufeff]"
                            ),
                          }),
                        }
                      : s || l
                      ? {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches any kind of visible character (equivalent to {1})",
                            ph1: ba("[^\\p{Z}\\h\\v]"),
                          }),
                        }
                      : {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches any non-whitespace character (equivalent to {1})",
                            ph1: ba("[^\\r\\n\\t\\f\\v ]"),
                          }),
                        };
                  if ("h" === r)
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "matches any horizontal whitespace character (equivalent to {1})",
                        ph1: ba("[[:blank:]]"),
                      }),
                    };
                  if ("H" === r)
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "matches any character that's not a horizontal whitespace character",
                      }),
                    };
                  if ("v" === r)
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "matches any vertical whitespace character",
                      }),
                    };
                  if ("V" === r)
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "matches any character that's not a vertical whitespace character",
                      }),
                    };
                  if ("N" === r)
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "matches any non-newline character",
                      }),
                    };
                  if ("R" === r)
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "matches any Unicode newline sequence",
                      }),
                    };
                  if ("C" === r)
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "matches one data unit, even in UTF mode (best avoided)",
                      }),
                    };
                  if ("X" === r)
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "matches any number of Unicode characters that form an extended Unicode sequence",
                      }),
                    };
                  if ("t" === r)
                    return e.isSubstitution
                      ? {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "inserts a tab character {1}",
                            ph1: va("(ASCII 9)"),
                          }),
                        }
                      : {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches a tab character {1}",
                            ph1: va("(ASCII 9)"),
                          }),
                        };
                  if ("r" === r)
                    return e.isSubstitution
                      ? {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "inserts a carriage return {1}",
                            ph1: va("(ASCII 13)"),
                          }),
                        }
                      : {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches a carriage return {1}",
                            ph1: va("(ASCII 13)"),
                          }),
                        };
                  if ("n" === r)
                    return e.isSubstitution
                      ? {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "inserts a line-feed (newline) character {1}",
                            ph1: va("(ASCII 10)"),
                          }),
                        }
                      : {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches a line-feed (newline) character {1}",
                            ph1: va("(ASCII 10)"),
                          }),
                        };
                  if ("f" === r)
                    return e.isSubstitution
                      ? {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "inserts a form-feed character {1}",
                            ph1: va("(ASCII 12)"),
                          }),
                        }
                      : {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches a form-feed character {1}",
                            ph1: va("(ASCII 12)"),
                          }),
                        };
                  if ("a" === r)
                    return e.isSubstitution
                      ? {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "inserts the bell character {1}",
                            ph1: va("(ASCII 7)"),
                          }),
                        }
                      : {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches the bell character {1}",
                            ph1: va("(ASCII 7)"),
                          }),
                        };
                  if ("e" === r)
                    return e.isSubstitution
                      ? {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "inserts esc {1}",
                            ph1: va("(ASCII 7)"),
                          }),
                        }
                      : {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches esc {1}",
                            ph1: va("(ASCII 7)"),
                          }),
                        };
                  if ("b" === r) {
                    const e = (0, ht.jsx)("span", {
                        className: ma.Z.zeroWidth,
                      }),
                      t = (0, ht.jsxs)("span", {
                        className: ma.Z.tokenSample,
                        children: [
                          "(^",
                          e,
                          "\\w|\\w",
                          e,
                          "$|\\W",
                          e,
                          "\\w|\\w",
                          e,
                          "\\W)",
                        ],
                      });
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "assert position at a word boundary: {1}",
                        ph1: t,
                      }),
                    };
                  }
                  if ("B" === r)
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "assert position where {1} does not match",
                        ph1: ba("\\b"),
                      }),
                    };
                  if ("A" === r)
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "asserts position at start of the string",
                      }),
                    };
                  if ("z" === r)
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "asserts position at the end of the string",
                      }),
                    };
                  if ("G" === r)
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "asserts position at the end of the previous match or the start of the string for the first match",
                      }),
                    };
                  if ("K" === r)
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "resets the starting point of the reported match. Any previously consumed characters are no longer included in the final match",
                      }),
                    };
                  if ("." === r) {
                    let r = "";
                    return (
                      a || (r = (0, et.Z)("(except for line terminators)")),
                      {
                        explanation: (0, ht.jsxs)("span", {
                          children: [
                            s &&
                              (0, et.Z)(
                                "matches any character, including unicode {1}",
                                r
                              ),
                            !s && (0, et.Z)("matches any character {1}", r),
                            !a && !t.brief && Ca(e),
                          ],
                        }),
                      }
                    );
                  }
                  if ("^" === r) {
                    let r = (0, et.Z)("the string");
                    return (
                      n && (r = (0, et.Z)("a line")),
                      {
                        explanation: (0, ht.jsxs)("span", {
                          children: [
                            (0, et.Z)("asserts position at start of {1}", r),
                            n && !t.brief && Ca(e, !0, !0),
                          ],
                        }),
                      }
                    );
                  }
                  if ("Z" === r)
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "asserts position at the end of the string, or before the line terminator right at the end of the string (if any)",
                      }),
                    };
                  if ("$" === r) {
                    let r = "";
                    return (
                      (r = n
                        ? (0, et.Z)("asserts position at the end of a line")
                        : i || o || e.state.flavor === j().GOLANG
                        ? (0, et.Z)("asserts position at the end of the string")
                        : (0, et.Z)(
                            "asserts position at the end of the string, or before the line terminator right at the end of the string (if any)"
                          )),
                      {
                        explanation: (0, ht.jsxs)("span", {
                          children: [r, !i && !t.brief && Ca(e, !0, n)],
                        }),
                      }
                    );
                  }
                  return (
                    $e.O7(
                      new Error(
                        `Unable to explain token '${e.type}': '${e.string}'`
                      )
                    ),
                    { explanation: null }
                  );
                })(r, t)
              : n === da.t0
              ? (function (e) {
                  return Sa(e, e.string.slice(1), !0);
                })(r)
              : n === da.zl
              ? Za(r, s)
              : n === da.hs
              ? (function (e, { alternatives: t, brief: r }) {
                  var s;
                  if (r)
                    return (null === (s = e.parent) || void 0 === s
                      ? void 0
                      : s.type) === da.oK
                      ? {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "Separates the true and false case of the parent conditional.",
                          }),
                        }
                      : {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "Equivalent to boolean OR",
                          }),
                        };
                  if (e.parent) {
                    if (e.parent.type === da.oK)
                      return 0 === e.alternativeNumber
                        ? {
                            explanation: (0, ht.jsx)(rt.vV, {
                              text: "If condition is met, match the following regex",
                            }),
                          }
                        : {
                            explanation: (0, ht.jsx)(rt.vV, {
                              text: "Else match the following regex",
                            }),
                          };
                    if (0 === e.parent.alternatives)
                      return { explanation: null };
                  } else if (0 === t) return { explanation: null };
                  return {
                    explanation: (0, ht.jsx)(rt.vV, {
                      text: "{1} Alternative",
                      ph1: ya(e.alternativeNumber + 1),
                    }),
                  };
                })(r, t)
              : n === da.$U
              ? (function (e) {
                  const t = e.string.replace(/^\\Q|\\E$/g, "");
                  return "" === t
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches an empty string (any position)",
                        }),
                      }
                    : Za(e, t);
                })(r)
              : n === da.RW
              ? (function (e) {
                  return {
                    explanation: (0, ht.jsx)(rt.vV, {
                      text: "match the remainder of the pattern with the following effective flags: {1}",
                      ph1: va(e.flags),
                    }),
                    children: Na(e.onFlags, e.offFlags, e.state.flavor),
                  };
                })(r)
              : n === da.Pg
              ? (function (e) {
                  return Ta(e, 8, 16);
                })(r)
              : n === da.bO || n === da.L3 || n === da.Yb
              ? (function (e) {
                  return Ta(e, 16, 8);
                })(r)
              : n === da.dz
              ? (function (e) {
                  if (
                    "\\P" === e.string.slice(0, 2) ||
                    e.string.includes("^")
                  ) {
                    const t = e.string.includes("{")
                      ? `\\p{${e.script}}`
                      : `\\p${e.script}`;
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "matches any characters that {1} does not",
                        ph1: ba(t),
                      }),
                    };
                  }
                  if (null != _a(e.script))
                    return {
                      explanation: (0, ht.jsx)("span", {
                        children: _a(e.script),
                      }),
                    };
                  const t =
                    null == e.category || "Script" === e.category
                      ? (0, et.Z)("script")
                      : (0, et.Z)("script extension");
                  return {
                    explanation: (0, ht.jsx)(rt.vV, {
                      text: "matches any characters in the {1} {2}",
                      ph1: va(e.script),
                      ph2: t,
                    }),
                  };
                })(r)
              : n === da.lA
              ? (function (e) {
                  return {
                    explanation: (0, ht.jsx)(rt.vV, {
                      text: "matches the control sequence {1} {2}",
                      ph1: ba("CTRL+" + e.controlChar),
                      ph2: va("(ASCII " + e.charCode + ")"),
                    }),
                  };
                })(r)
              : n === da.Eb
              ? (function (e) {
                  return {
                    explanation: (0, ht.jsx)(rt.vV, {
                      text: "Global pattern flags",
                    }),
                    children: Na(e.globalFlags.split(""), [], e.flavor),
                  };
                })(r)
              : da.tK(n)
              ? (function (e) {
                  switch (e.type) {
                    case da.t:
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "{1} Capturing Group",
                          ph1: ya(e.groupNumber),
                        }),
                      };
                    case da.df:
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Non-capturing Group. Matches the tokens contained with the following effective flags: {1}",
                          ph1: va(e.flags),
                        }),
                        children: Na(e.onFlags, e.offFlags, e.state.flavor),
                      };
                    case da.xT:
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Non-capturing group",
                        }),
                      };
                    case da.Ws:
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Subpattern definition construct",
                        }),
                        notice: (0, ht.jsx)(rt.qX, {
                          children: (0, et.Z)(
                            "May only be used to define functions. No matching is done in this group."
                          ),
                        }),
                      };
                    case da.oK:
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Conditional",
                        }),
                      };
                    case da.Ty:
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Negative Lookbehind",
                        }),
                        notice: (0, ht.jsx)(rt.qX, {
                          children: (0, et.Z)(
                            "Assert that the Regex below does not match"
                          ),
                        }),
                      };
                    case da.Gs:
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Positive Lookbehind",
                        }),
                        notice: (0, ht.jsx)(rt.qX, {
                          children: (0, et.Z)(
                            "Assert that the Regex below matches"
                          ),
                        }),
                      };
                    case da.up:
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Negative Lookahead",
                        }),
                        notice: (0, ht.jsx)(rt.qX, {
                          children: (0, et.Z)(
                            "Assert that the Regex below does not match"
                          ),
                        }),
                      };
                    case da.PG:
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Positive Lookahead",
                        }),
                        notice: (0, ht.jsx)(rt.qX, {
                          children: (0, et.Z)(
                            "Assert that the Regex below matches"
                          ),
                        }),
                      };
                    case da.fy:
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Non-atomic Positive Lookahead",
                        }),
                        notice: (0, ht.jsx)(rt.qX, {
                          children: (0, et.Z)(
                            "Assert that the Regex below matches"
                          ),
                        }),
                      };
                    case da.qh:
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Non-atomic Positive Lookbehind",
                        }),
                        notice: (0, ht.jsx)(rt.qX, {
                          children: (0, et.Z)(
                            "Assert that the Regex below matches"
                          ),
                        }),
                      };
                    case da.sS:
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Named Capture Group {1}",
                          ph1: va(e.subpattern),
                        }),
                      };
                    case da.no:
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Branch Reset Group",
                        }),
                        notice: (0, ht.jsx)(rt.qX, {
                          children: (0, et.Z)(
                            "Subpatterns declared within each alternative of this construct will start over from the same index."
                          ),
                        }),
                      };
                    case da.Jy:
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Atomic Group",
                        }),
                        notice: (0, ht.jsx)(rt.qX, {
                          children: (0, et.Z)(
                            "Non-capturing group that discards backtracking positions once matched."
                          ),
                        }),
                      };
                    case da.sr:
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Balancing Named Capturing Group {1}",
                          ph1: va(e.subpattern),
                        }),
                        notice: (0, ht.jsx)(rt.qX, {
                          children: (0, ht.jsx)(rt.vV, {
                            text: "Removes the most recently matched text from the group {1} if the contained pattern matches, and captures the text between the two groups in {2}",
                            ph1: va(e.balancedGroup),
                            ph2: va(e.subpattern),
                          }),
                        }),
                      };
                    case da.ET:
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Balancing Non-capturing Group",
                        }),
                        notice: (0, ht.jsx)(rt.qX, {
                          children: (0, ht.jsx)(rt.vV, {
                            text: "Removes the most recently matched text from the group {1} if the contained pattern matches",
                            ph1: va(e.balancedGroup),
                          }),
                        }),
                      };
                    default:
                      return (
                        $e.O7(
                          new Error(
                            `Unable to match group type '${e.type}' to a component: '${e.string}'`
                          )
                        ),
                        null
                      );
                  }
                })(r)
              : n === da.Wj
              ? (function (e) {
                  const t = e.state.previousToken.type;
                  let r;
                  "?" === e.string ||
                  "??" === e.string ||
                  e.state.flavor === j().DOTNET ||
                  (t !== da.t && t !== da.sS)
                    ? (0, da.Az)(t) &&
                      t !== da.qh &&
                      t !== da.fy &&
                      (r = (0, ht.jsx)(rt.qX, {
                        type: gt.gr.u_,
                        children: (0, et.Z)(
                          "A quantifier following a lookaround serves no purpose, and can safely be removed from the regular expression"
                        ),
                      }))
                    : (r = (0, ht.jsx)(rt.qX, {
                        type: gt.gr.u_,
                        children: (0, et.Z)(
                          "A repeated capturing group will only capture the last iteration. Put a capturing group around the repeated group to capture all iterations or use a non-capturing group instead if you're not interested in the data"
                        ),
                      }));
                  const s = e.to === 1 / 0 || e.to <= 1 ? ka(e.to) : e.to,
                    n = e.to === 1 / 0 || e.to <= 1 ? ka(e.from) : e.from;
                  if (e.from === e.to) {
                    let t;
                    return (
                      1 === e.from
                        ? (t = (0, et.Z)("meaningless quantifier"))
                        : 0 === e.from &&
                          (t = (0, et.Z)("causes token to be ignored")),
                      {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches the previous token exactly {1} {2} {3}",
                          ph1: va(n),
                          ph2:
                            1 !== e.from
                              ? (0, et.Z)("times")
                              : (0, et.Z)("time"),
                          ph3: t ? `(${t})` : "",
                        }),
                        notice: r,
                      }
                    );
                  }
                  let a, i;
                  return (
                    e.possessive
                      ? ((a = (0, et.Z)(
                          "as many times as possible, without giving back"
                        )),
                        (i = (0, et.Z)("possessive")))
                      : e.lazy
                      ? ((a = (0, et.Z)(
                          "as few times as possible, expanding as needed"
                        )),
                        (i = (0, et.Z)("lazy")))
                      : ((a = (0, et.Z)(
                          "as many times as possible, giving back as needed"
                        )),
                        (i = (0, et.Z)("greedy"))),
                    {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "matches the previous token between {1} and {2} times, {3} {4}",
                        ph1: va(n),
                        ph2: va(s),
                        ph3: a,
                        ph4:
                          ((o = "(" + i + ")"),
                          (0, ht.jsx)("span", {
                            className: ma.Z.info,
                            children: o,
                          })),
                      }),
                      notice: r,
                    }
                  );
                  var o;
                })(r)
              : n === da._w || n === da.eq
              ? (function (e) {
                  return null === e.reference
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches the entire pattern",
                        }),
                      }
                    : /^\d+$/.test(e.reference)
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches the expression defined in the {1} capture group",
                          ph1: va(ya(e.reference)),
                        }),
                      }
                    : {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: 'matches the expression defined in the capture group "{1}"',
                          ph1: va(e.reference),
                        }),
                      };
                })(r)
              : n === da.WE || n === da.O3 || n === da.bJ || n === da.hb
              ? (function (e) {
                  return 0 === e.reference
                    ? e.isSubstitution
                      ? {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "inserts the same text as most recently matched by the entire pattern",
                          }),
                        }
                      : {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches the same text as most recently matched by the entire pattern",
                          }),
                        }
                    : /^\d+$/.test(e.reference)
                    ? e.isSubstitution
                      ? {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "inserts the same text as most recently matched by the {1} capturing group",
                            ph1: va(ya(e.reference)),
                          }),
                        }
                      : {
                          explanation: (0, ht.jsx)(rt.vV, {
                            text: "matches the same text as most recently matched by the {1} capturing group",
                            ph1: va(ya(e.reference)),
                          }),
                        }
                    : e.isSubstitution
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "inserts the same text as most recently matched by the capturing group named {1}",
                          ph1: va(e.reference),
                        }),
                      }
                    : {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches the same text as most recently matched by the capturing group named {1}",
                          ph1: va(e.reference),
                        }),
                      };
                })(r)
              : n === da.qi || n === da.jf
              ? (function (e, t) {
                  return t.brief
                    ? {
                        explanation: (0, ht.jsx)("span", {
                          children: (0, et.Z)(
                            "Inline comment, discarded by the engine when matching the regex"
                          ),
                        }),
                      }
                    : {
                        explanation: (0, ht.jsxs)("span", {
                          children: [" ", e.getComment()],
                        }),
                        string: (0, et.Z)("Comment") + ":",
                      };
                })(r, t)
              : n === da.vU
              ? (function (e) {
                  return "UTF" === e.verb.slice(0, 3)
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "sets the property mode to {1}",
                          ph1: va("UTF-" + e.verb.replace(/\D+/g, "")),
                        }),
                      }
                    : "UCP" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "sets the property mode to Unicode",
                        }),
                      }
                    : "NO_START_OPT" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "suppresses the start-of-match optimizations that are otherwise run by Perl",
                        }),
                      }
                    : "CR" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "specifies a newline convention: carriage return",
                        }),
                      }
                    : "LF" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "specifies a newline convention: line-feed",
                        }),
                      }
                    : "CRLF" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "specifies a newline convention: {1}, followed by {2}",
                          ph1: ba("(*CR)"),
                          ph2: ba("(*LF)"),
                        }),
                      }
                    : "ANYCRLF" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "specifies a newline convention: {1}, {2} or {3}",
                          ph1: ba("(*CR)"),
                          ph2: ba("(*LF)"),
                          ph3: ba("(*CRLF)"),
                        }),
                      }
                    : "ANY" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "specifies a newline convention: all unicode newline sequences {1}",
                          ph1: ba(
                            "(?:\\r\\n|[\\r\\n\\v\\f\\x85\\u2028\\u2029])"
                          ),
                        }),
                      }
                    : "BSR_ANYCRLF" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "specifies a newline convention: {1}, {2} or {3} only",
                          ph1: ba("(*CR)"),
                          ph2: ba("(*LF)"),
                          ph3: ba("(*CRLF)"),
                        }),
                      }
                    : "BSR_UNICODE" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "specifies a newline convention: any Unicode newline sequence",
                        }),
                      }
                    : /\(\*(?:MARK)?:[^:]+\)/.test(e.verb)
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "marker verb whose main purpose is to track how a match was arrived at",
                        }),
                      }
                    : "FAIL" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "verb synonymous with {1}. Forces a matching failure at the given position in the pattern",
                          ph1: ba("(?!)"),
                        }),
                      }
                    : "F" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "shorthand for {1}",
                          ph1: ba("(*FAIL)"),
                        }),
                      }
                    : /^PRUNE(?::[^:]+)?$/.test(e.verb)
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "this verb causes the match to fail at the current starting position in the subject if the rest of the pattern does not match",
                        }),
                      }
                    : "COMMIT" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "causes the whole match to fail outright if the rest of the pattern does not match",
                        }),
                      }
                    : /^THEN(?::[^:]+)?$/.test(e.verb)
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "causes a skip to the next innermost alternative if the rest of the pattern does not match",
                        }),
                      }
                    : /^SKIP(?::[^:]+)?$/.test(e.verb)
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "acts like {1}, except that if the pattern is unanchored, the bumpalong advance is not to the next character, but to the position in the subject where {2} was encountered",
                          ph1: ba("(*PRUNE)"),
                          ph2: ba("(*SKIP)"),
                        }),
                      }
                    : "ACCEPT" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "this verb causes the match to end successfully, skipping the remainder of the pattern",
                        }),
                      }
                    : /^LIMIT_RECURSION=\d+$/.test(e.verb)
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "this verb sets the recursion limit (max depth) for the pattern",
                        }),
                      }
                    : /^LIMIT_MATCH=\d+$/.test(e.verb)
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "this verb sets the match limit (max iterations) for the pattern",
                        }),
                      }
                    : "NO_AUTO_POSSESS" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "this verb disables the internal `auto-possessification` optimization in PCRE",
                        }),
                      }
                    : "NOTEMPTY" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "this verb disables matching of empty strings",
                        }),
                      }
                    : "NOTEMPTY_ATSTART" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "this verb disables matching of empty strings at the start of the subject string",
                        }),
                      }
                    : "NO_JIT" === e.verb
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "this verb disables JIT compilation of the pattern",
                        }),
                      }
                    : {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Undescribed specific verb; No description for it yet (nothing's perfect)",
                        }),
                      };
                })(r)
              : n === da.Yz
              ? Ia(r)
              : n === da.ZH
              ? {
                  explanation: (0, ht.jsx)(rt.vV, {
                    text: "matches a backspace character {1}",
                    ph1: va("(ASCII 8)"),
                  }),
                }
              : n === da.Tf
              ? {
                  explanation: (0, ht.jsx)(rt.vV, {
                    text: "matches a vertical tab character",
                  }),
                }
              : n === da.HI
              ? (function (e, t) {
                  const r = e.string.includes("^");
                  let s;
                  return (
                    (s = e.charClassIntersection
                      ? t.brief
                        ? r
                          ? (0, et.Z)(
                              "match a single character not present in the intersection of tokens within this set"
                            )
                          : (0, et.Z)(
                              "match a single character present in the intersection of tokens within this set"
                            )
                        : r
                        ? (0, et.Z)(
                            "Match a single character not present in both the lists below"
                          )
                        : (0, et.Z)(
                            "Match a single character present in both the lists below"
                          )
                      : e.parent.charClassSubtraction
                      ? t.brief
                        ? r
                          ? (0, et.Z)(
                              "subtract the characters not present in the set from the parent character class"
                            )
                          : (0, et.Z)(
                              "subtract the characters present in the set from the parent character class"
                            )
                        : r
                        ? (0, et.Z)(
                            "Subtract the characters not present the the list below from the parent character class"
                          )
                        : (0, et.Z)(
                            "Subtract the characters present in the list below from the parent character class"
                          )
                      : e.charClassSubtraction
                      ? t.brief
                        ? r
                          ? (0, et.Z)(
                              "match a single character not present in the relative complement of the sets"
                            )
                          : (0, et.Z)(
                              "match a single character present in the relative complement of the sets"
                            )
                        : r
                        ? (0, et.Z)(
                            "Match a single character not present the relative complement of the lists below"
                          )
                        : (0, et.Z)(
                            "Match a single character present in relative complement of the lists below"
                          )
                      : t.brief
                      ? r
                        ? (0, et.Z)(
                            "match a single character not present in the set"
                          )
                        : (0, et.Z)(
                            "match a single character present in the set"
                          )
                      : r
                      ? (0, et.Z)(
                          "Match a single character not present in the list below"
                        )
                      : (0, et.Z)(
                          "Match a single character present in the list below"
                        )),
                    { explanation: (0, ht.jsx)("span", { children: s }) }
                  );
                })(r, t)
              : n === da.jt
              ? (function (e) {
                  const t = e.leftToken,
                    r = e.rightToken,
                    s = String.fromCodePoint(t.codePoint || t.charCode),
                    n = String.fromCodePoint(r.codePoint || r.charCode),
                    a = e.state.flags.includes("i")
                      ? (0, et.Z)("case insensitive")
                      : (0, et.Z)("case sensitive");
                  return {
                    explanation: (0, ht.jsx)(rt.vV, {
                      text: "matches a single character in the range between {1} {2} and {3} {4} ({5})",
                      ph1: ja(s),
                      ph2: va("(index " + (t.codePoint || t.charCode) + ")"),
                      ph3: ja(n),
                      ph4: va("(index " + (r.codePoint || r.charCode) + ")"),
                      ph5: a,
                    }),
                    string: t.string + e.string + r.string,
                  };
                })(r)
              : n === da.be
              ? (function (e) {
                  if (e.string.includes("^"))
                    return {
                      explanation: (0, ht.jsx)(rt.vV, {
                        text: "matches the negation of {1}",
                        ph1: ba(e.posixClass),
                      }),
                    };
                  const t = e.state.flags.includes("u");
                  switch (e.posixClass) {
                    case "ascii":
                      return t
                        ? {
                            explanation: (0, ht.jsx)(rt.vV, {
                              text: "equivalent to {1}",
                              ph1: ba("\\p{InBasicLatin}"),
                            }),
                          }
                        : {
                            explanation: (0, ht.jsx)(rt.vV, {
                              text: "matches a character with {1} value {2} through {3}",
                              ph1: va("ASCII"),
                              ph2: va("0"),
                              ph3: va("127"),
                            }),
                          };
                    case "alnum":
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches a alphanumeric character {1}",
                          ph1: ba(t ? "\\p{Xan}" : "[a-zA-Z0-9]"),
                        }),
                      };
                    case "word":
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches a alphanumeric character or {1} {2} (also written as {3})",
                          ph1: va("_"),
                          ph2: ba(t ? "[\\p{Xwd}]" : "[A-Za-z0-9_]"),
                          ph3: ba("\\w"),
                        }),
                      };
                    case "alpha":
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches a alphabetic character {1}",
                          ph1: ba(t ? "\\p{L}" : "[a-zA-Z]"),
                        }),
                      };
                    case "blank":
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches a whitespace character, excluding line breaks {1}",
                          ph1: ba(t ? "\\h" : "[ \\t]"),
                        }),
                      };
                    case "cntrl":
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches a control character {1}",
                          ph1: ba(t ? "\\p{Cc}" : "[\\x00-\\x1F\\x7F]"),
                        }),
                      };
                    case "digit":
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches a digit {1} (also written as {2})",
                          ph1: ba(t ? "\\p{Nd}" : "[0-9]"),
                          ph2: ba("\\d"),
                        }),
                      };
                    case "graph":
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches a visible character {1}",
                          ph1: ba(
                            t
                              ? "[\\pL\\pM\\pN\\pP\\pS\\p{Cf}]"
                              : "[\\x21-\\x7E]"
                          ),
                        }),
                      };
                    case "lower":
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches a lowercase letter {1}",
                          ph1: ba(t ? "\\p{Ll}" : "[a-z]"),
                        }),
                      };
                    case "print":
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches a visible character or the space character {1}",
                          ph1: ba(
                            t
                              ? "[\\pL\\pM\\pN\\pP\\pS\\p{Cf}\\p{Zs}]"
                              : "[\\x20-\\x7E]"
                          ),
                        }),
                      };
                    case "punct":
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches a punctuation character {1}",
                          ph1: ba(
                            t
                              ? "[\\p{P}\\p{S}]"
                              : "[!\"#$%&'()*+,\\-./:;<=>?@[\\]^_`{|}~]"
                          ),
                        }),
                      };
                    case "upper":
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches a uppercase letter {1}",
                          ph1: ba(t ? "\\p{Lu}" : "[A-Z]"),
                        }),
                      };
                    case "xdigit":
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches a hexadecimal digit {1}",
                          ph1: ba("[A-Fa-f0-9]"),
                        }),
                      };
                    case "space":
                      return {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches a whitespace character, including a line break {1} (also written as {2})",
                          ph1: ba(t ? "[\\p{xps}]" : "[ \\t\\r\\n\\v\\f]"),
                          ph2: ba("\\s"),
                        }),
                      };
                    default:
                      $e.O7(
                        new Error(
                          `Unknown posix class '${e.string}': '${e.string}'`
                        )
                      );
                  }
                })(r)
              : n === da.jl
              ? (function (e) {
                  return e.string.includes("^")
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "matches any character, including newline",
                        }),
                      }
                    : {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "empty character class \u2014 matches {1}",
                          ph1: (0, ht.jsx)("em", { children: "null" }),
                        }),
                      };
                })(r)
              : n === da.aM || n === da.py
              ? (function (e) {
                  return "\\E" === e.string
                    ? {
                        explanation: (0, ht.jsx)("span", {
                          children: (0, et.Z)(
                            "Terminates any previous text transformation (initiated with either \\U or \\L)"
                          ),
                        }),
                      }
                    : "\\l" === e.string || "\\u" === e.string
                    ? {
                        explanation: (0, ht.jsx)("span", {
                          children: (0, et.Z)(
                            "Converts the subsequent token to their {1} equivalence",
                            "\\u" === e.string
                              ? (0, et.Z)("uppercase")
                              : (0, et.Z)("lowercase")
                          ),
                        }),
                      }
                    : {
                        explanation: (0, ht.jsx)("span", {
                          children: (0, ht.jsx)(rt.vV, {
                            text: "Converts all subsequent tokens to their {1} equivalence until {2} is encountered",
                            ph1:
                              "\\U" === e.string
                                ? (0, et.Z)("uppercase")
                                : (0, et.Z)("lowercase"),
                            ph2: va("\\E"),
                          }),
                        }),
                      };
                })(r)
              : n === da.XR
              ? (function (e) {
                  const t = (0, ht.jsx)(rt.qX, {
                    type: Ra.u_,
                    children: (0, et.Z)(
                      "Avoid using this legacy syntax for any new patterns."
                    ),
                  });
                  return "[[:<:]]" === e.string
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Matches start of word (POSIX syntax), equivalent to {1}",
                          ph1: ba("\\b(?=\\w)"),
                        }),
                        notice: t,
                      }
                    : {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "Matches end of word (POSIX syntax), equivalent to {1}",
                          ph1: ba("\\b(?<=\\w)"),
                        }),
                        notice: t,
                      };
                })(r)
              : n === da.tI || n === da.hL || n === da.Cz
              ? (function (e) {
                  return "$`" === e.string
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "inserts the portion of the string that precedes the matched substring",
                        }),
                      }
                    : "$'" === e.string
                    ? {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "inserts the portion of the string that follows the matched substring",
                        }),
                      }
                    : {
                        explanation: (0, ht.jsx)(rt.vV, {
                          text: "inserts the matched substring",
                        }),
                      };
                })(r)
              : n === da.w_
              ? (function (e) {
                  const t = isNaN(e.reference)
                    ? (0, ht.jsx)(Da.Z, {
                        text: "subpattern {1}",
                        ph1: va(e.reference),
                      })
                    : (0, ht.jsx)(Da.Z, {
                        text: "{1} subpattern",
                        ph1: va(ya(e.reference)),
                      });
                  return {
                    explanation: (0, ht.jsx)(Da.Z, {
                      text: "Replaces the text conditionally depending on if the {1} matched",
                      ph1: t,
                    }),
                  };
                })(r)
              : n === da.zB
              ? (function (e, t) {
                  if (t.brief)
                    return {
                      explanation: (0, et.Z)(
                        "matches the intersection of the tokens to the left and right of this token"
                      ),
                    };
                  throw new Error(
                    "Trying to explain character class intersection token"
                  );
                })(0, t)
              : n === da.Ao
              ? (function (e, t) {
                  if (t.brief)
                    return {
                      explanation: (0, et.Z)(
                        "matches the tokens to the left of this, minus any of the tokens present on the right"
                      ),
                    };
                  throw new Error(
                    "Trying to explain character class subtraction token"
                  );
                })(0, t)
              : ($e.O7(new Error(`Unable to explain token '${n}': '${s}`)),
                { explanation: null });
          })(e, t);
        }
        function Ma(e, t = {}) {
          if (e.error) return wa(e.error);
          const r = e.getTooltipToken(),
            s = { string: r.string, children: [], nodeLabel: [], token: r };
          t.brief = !0;
          const n =
            r.type === da.oK
              ? Ia({ conditional: r }).explanation
              : La(s, t).explanation;
          return (0, ht.jsxs)("div", {
            children: [
              (0, ht.jsx)("strong", { children: Ua(e) }),
              " \u2014 ",
              n,
            ],
          });
        }
        function Ua(e) {
          switch (e.type) {
            case da.$U:
              return (0, et.Z)("Quote");
            case da.MW:
              return (0, et.Z)("Meta Escape");
            case da.hs:
              return (0, et.Z)("Alternative");
            case da.Wj:
              return (0, et.Z)("Quantifier");
            case da.zl:
            case da.t0:
              return (0, et.Z)("Text");
            case da.Qp:
              return (0, et.Z)("Lonely End Quote");
            case da.dz:
              return (0, et.Z)("Unicode Property");
            case da.Pg:
              return (0, et.Z)("Octal");
            case da.L3:
              return (0, et.Z)("Hex");
            case da.Yb:
              return (0, et.Z)("Unicode");
            case da.RW:
              return (0, et.Z)("Modifier");
            case da.lA:
              return (0, et.Z)("Control Character");
            case da.Tf:
              return (0, et.Z)("Vertical Tab");
            case da.bO:
              return (0, et.Z)("Surrogate Pair");
            case da.eq:
            case da._w:
              return (0, et.Z)("Subroutine");
            case da.O3:
            case da.hb:
            case da.bJ:
            case da.WE:
              return (0, et.Z)("Backreference");
            case da.ZH:
              return (0, et.Z)("Backspace");
            case da.jl:
            case da.HI:
            case da.U6:
              return (0, et.Z)("Character Class");
            case da.jt:
              return (0, et.Z)("Range");
            case da.XR:
            case da.be:
              return (0, et.Z)("Posix Class");
            case da.jf:
            case da.qi:
              return (0, et.Z)("Comment");
            case da.df:
            case da.sS:
            case da.no:
            case da.xT:
            case da.Jy:
            case da.t:
            case da.sr:
            case da.ET:
              return (0, et.Z)("Group");
            case da.Ws:
              return (0, et.Z)("Definition");
            case da.oK:
            case da.w_:
              return (0, et.Z)("Conditional");
            case da.vU:
              return (0, et.Z)("Verb");
            case da.Ty:
            case da.Gs:
            case da.up:
            case da.PG:
            case da.fy:
            case da.qh:
              return (0, et.Z)("Lookaround");
            case da.aM:
            case da.py:
              return (0, et.Z)("Case Modifier");
            case da.Cz:
              return (0, et.Z)("Before Match");
            case da.tI:
              return (0, et.Z)("After Match");
            case da.hL:
              return (0, et.Z)("Full Match");
            case da.zB:
              return (0, et.Z)("Class Intersection");
            case da.Ao:
              return (0, et.Z)("Class Subtraction");
            default:
              $e.O7(Error(`Unable to map title for '${e.type}'`));
          }
        }
        const Fa = "V3CMy",
          Ga = ({ className: e, tokens: t }) => {
            const r = Ea(t);
            return 0 === r.length
              ? null
              : (0, ht.jsx)("div", {
                  className: Xe()("zlDez", e),
                  children: r.map(({ string: e, style: t }, r) =>
                    null != t
                      ? (0, ht.jsx)(
                          "span",
                          {
                            className: t,
                            children: (0, ht.jsx)(rt.K, { text: e }),
                          },
                          `node-label-token-${r}`
                        )
                      : (0, ht.jsx)(rt.K, { text: e }, `node-label-token-${r}`)
                  ),
                });
          },
          Va = (0, ze.memo)(Ga),
          Ba = "XsOAS",
          qa = ({ flags: e, tokens: t, delimiter: r }) =>
            (0, ht.jsxs)("div", {
              className: "NC6ky",
              children: [
                (0, ht.jsx)("div", {
                  className: Xe()("taqI9", Ba),
                  children: r,
                }),
                (0, ht.jsx)(Va, { className: "kevho", tokens: t }),
                (0, ht.jsx)("div", {
                  className: Xe()("V9YRK", Ba),
                  children: r,
                }),
                (0, ht.jsx)("div", { className: "m1_F1", children: e }),
              ],
            }),
          Ha = (0, ze.memo)(qa),
          $a = ["tokens"];
        function za(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        const Wa = (e) => {
            let t = e.tokens,
              r = (0, T.Z)(e, $a);
            const s = t.reduce(
              (e, t) =>
                e.concat(t.token.type === da.hs ? t.token : [], t.nodeLabel),
              []
            );
            return (0, ht.jsx)(
              Ha,
              (function (e) {
                for (var t = 1; t < arguments.length; t++) {
                  var r = null != arguments[t] ? arguments[t] : {};
                  t % 2
                    ? za(Object(r), !0).forEach(function (t) {
                        (0, a.Z)(e, t, r[t]);
                      })
                    : Object.getOwnPropertyDescriptors
                    ? Object.defineProperties(
                        e,
                        Object.getOwnPropertyDescriptors(r)
                      )
                    : za(Object(r)).forEach(function (t) {
                        Object.defineProperty(
                          e,
                          t,
                          Object.getOwnPropertyDescriptor(r, t)
                        );
                      });
                }
                return e;
              })({ tokens: s }, r)
            );
          },
          Ya = new Re.ZP();
        class Ka extends ze.Component {
          render() {
            const e = this.props,
              t = e.regex,
              r = e.flags,
              s = e.delimiter,
              n = e.flavor,
              a = e.className,
              i = Ya.parse(t, { flags: r, delimiter: s, flavor: n }),
              o = (function (e, t) {
                const r = [],
                  s = [],
                  n = a(null, { string: "", type: da.hs, children: [] });
                return (
                  (function e(t, s) {
                    let n = null;
                    for (let o = 0, c = s.length; o < c; o++) {
                      const c = s[o];
                      if (r.includes(c)) continue;
                      if (
                        (r.push(c),
                        t.addNodeLabel(c),
                        c.type === da.U6 ||
                          c.type === da.Wj ||
                          (da.tK(c.type) && ")" === c.string) ||
                          c.partOfRange)
                      )
                        continue;
                      const l = a(t, c);
                      if (c.quantifier) {
                        const e = a(l, c.quantifier);
                        c.quantifier.quantifier &&
                          (e.string += c.quantifier.quantifier.string),
                          l.children.push(e);
                      } else if (i(c)) {
                        0 === n.children.length &&
                          n.children.push(xa(xa({}, n), {}, { children: [] })),
                          (n.string += c.string),
                          r.push(c),
                          n.children.push(l),
                          n.nodeLabel.push(c);
                        continue;
                      }
                      if ((t.children.push(l), c.type === da.oK)) {
                        const t = {
                          children: [],
                          conditional: c,
                          type: da.Yz,
                          string: "",
                          state: c.state,
                        };
                        c.lookaround && t.children.push(c.condition),
                          e(l, [t].concat(c.children));
                      } else c.type !== da.zl && e(l, c.children);
                      n = l;
                      const u = n.token;
                      if (u.quantifier && da.tK(u.type)) {
                        const e = u.quantifier.quantifier || u.quantifier;
                        for (let i = o + 1; i < s.length; i++) {
                          const o = s[i];
                          if (
                            (n.addNodeLabel(o),
                            r.push(o),
                            o.ignoreOnHover ||
                              o.type === da.Wj ||
                              t.children.push(a(t, o)),
                            o === e)
                          )
                            break;
                        }
                      }
                    }
                  })(n, e),
                  s.push(...n.children),
                  t &&
                    s.push({
                      children: [],
                      nodeLabel: [],
                      token: {
                        type: da.Eb,
                        globalFlags: t,
                        flavor: e[0].state.flavor,
                        children: [],
                      },
                    }),
                  s
                );
                function a(e, t) {
                  return {
                    parent: e,
                    string: t.string,
                    children: [],
                    nodeLabel: t.type !== da.hs ? [t] : [],
                    token: t,
                    addNodeLabel(e) {
                      null != this.parent && this.parent.addNodeLabel(e),
                        this.nodeLabel.push(e);
                    },
                  };
                }
                function i(e) {
                  const t = e.state.actualPreviousToken;
                  return (
                    t &&
                    e.type === da.zl &&
                    t.type === da.zl &&
                    !e.quantifier &&
                    !e.partOfRange &&
                    !t.partOfRange &&
                    !e.isPoorlyPlaced &&
                    !t.isPoorlyPlaced
                  );
                }
              })(i, r),
              c = (0, ht.jsx)(Wa, { tokens: o, delimiter: s, flags: r });
            return (0, ht.jsx)("div", {
              className: a,
              children: (0, ht.jsx)(ha, {
                nodeLabel: c,
                children:
                  null != Ya.getStatus()
                    ? this.renderErrorExplanation(i)
                    : this.renderExplanationTree(o, 0, Ya.alternatives),
              }),
            });
          }
          renderExplanationTree(e, t, r) {
            return e.map((e, s) => {
              const n = e.token;
              if (n.type === da.zB || n.type === da.Ao)
                return (0, ht.jsx)(
                  "div",
                  { className: "g3DN5" },
                  `character-intersection-${n.string}-${s}`
                );
              const a = La(e, { alternatives: r }),
                i = a.explanation,
                o = a.children,
                c = void 0 === o ? null : o,
                l = a.notice,
                u = void 0 === l ? null : l,
                h = a.string;
              if (null == i)
                return this.renderExplanationTree(e.children, t, r);
              if (n.children.length > 0 || da.Bx(n.type)) {
                const t = e.children.length,
                  r = e.children[0];
                if (
                  0 === t ||
                  (1 === t && r.token.type === da.Wj) ||
                  (1 === t && r.token.type === da.hs && 0 === r.children.length)
                ) {
                  const t = !da.Az(n.type);
                  return (0, ht.jsxs)(
                    "div",
                    {
                      children: [
                        this.renderNodeLabel(e, i),
                        " ",
                        (0, ht.jsx)(rt.vV, {
                          text: "{1}, matches any position",
                          ph1: (0, ht.jsxs)(ze.Fragment, {
                            children: [
                              "\u2014 ",
                              (0, ht.jsx)("em", { children: "null" }),
                            ],
                          }),
                        }),
                        t ? u : "",
                      ],
                    },
                    `null-match-${n.string}-${s}`
                  );
                }
              }
              if (
                e.children.length > 0 ||
                da.Bx(n.type) ||
                (null != c && 0 !== c.length)
              )
                return (0, ht.jsxs)(
                  ha,
                  {
                    nodeLabel: this.renderNodeLabel(e, i, u),
                    defaultCollapsed: t > 10 || n.type === da.zl,
                    children: [
                      c,
                      this.renderExplanationTree(e.children, t++, r),
                    ],
                  },
                  `treeview-parent-${n.children.length}-${s}`
                );
              const p = h || e.string,
                d = /^\s+$/.test(p);
              return (0, ht.jsxs)(
                "div",
                {
                  children: [
                    (0, ht.jsx)("span", {
                      className: Xe()(n.style, "uNm38", d && "mBF1Z"),
                      children: (0, ht.jsx)(rt.K, {
                        text: p,
                        removeNewlines: !0,
                      }),
                    }),
                    " ",
                    i,
                    u,
                  ],
                },
                `token-explanation-${n.string}-${s}`
              );
            });
          }
          renderNodeLabel(e, t, r = null) {
            const s = e.token;
            if (s.type === da.Yz) return (0, ht.jsx)("strong", { children: t });
            const n = (0, ht.jsx)(Va, { tokens: e.nodeLabel, className: Fa });
            return da.Bx(s.type) || s.type === da.Eb
              ? (0, ht.jsxs)("span", {
                  children: [
                    (0, ze.cloneElement)(t, { className: Xe()("N_Lxn", Fa) }),
                    " ",
                    n,
                    r,
                  ],
                })
              : (0, ht.jsxs)("span", {
                  children: [
                    n,
                    " ",
                    (0, ze.cloneElement)(t, { className: "N3KUM" }),
                    r,
                  ],
                });
          }
          renderErrorExplanation(e) {
            return (0, ht.jsxs)(
              "div",
              {
                children: [
                  (0, ht.jsx)(rt.qX, {
                    children: (0, et.Z)(
                      "All the errors detected are listed below, from left to right, as they appear in the pattern."
                    ),
                  }),
                  Oa(e),
                ],
              },
              `error-explanation-${e.length}`
            );
          }
        }
        const Ja = Ka,
          Xa = ({ text: e }) =>
            (0, ht.jsx)("div", { className: "AOv9F", children: e }),
          Qa = (0, ze.memo)(Xa),
          ei = ({ regex: e, flavor: t, delimiter: r, flags: s }) =>
            null == e || 0 === e.length
              ? (0, ht.jsx)(Qa, {
                  text: (0, et.Z)(
                    "An explanation of your regex will be automatically generated as you type."
                  ),
                })
              : (0, ht.jsx)(Ja, {
                  regex: e,
                  flavor: t,
                  delimiter: r,
                  flags: s,
                  className: "IrE8B",
                });
        var ti = r(50836),
          ri = r(26681);
        const si = {
            matchData: "amvtn",
            textTruncated: "MjTIZ",
            didNotParticipate: "aSQIC",
            groupNum: "TrT00",
            clickable: "N9b7Q",
            matchPos: "CPj3q",
            groupName: "fxJfD",
            row: "IoDqL",
            groupText: "Q8YiL",
            "group-0": "BX3FE",
            "group-1": "znTgg",
            "group-2": "v1n1J",
            "group-3": "CXLa2",
            "group-4": "nmqJh",
            "group-5": "T_XLc",
            "group-6": "m94jE",
            "group-0-alt": "KzxFx",
            "group-1-alt": "dftGW",
            "group-2-alt": "GDx0h",
            "group-3-alt": "zOJvb",
            "group-4-alt": "EMlAx",
            "group-5-alt": "heE6F",
            "group-6-alt": "UpMUh",
          },
          ni = ({
            group: e,
            evenMatch: t,
            showNonParticipatingGroups: r,
            matchNumber: s,
          }) => {
            const n = (0, ze.useState)(!1),
              a = (0, st.Z)(n, 2),
              i = a[0],
              o = a[1],
              c = (0, ze.useCallback)(() => tt.ZP.emit(tt.ji, e), [e]),
              l = (0, ze.useCallback)(() => o((e) => !e), []);
            if (!e.isParticipating && !r) return null;
            const u =
                si[
                  `group-${((e.groupNum - 1) % q.GROUP_COUNT) + 1}${
                    t ? "" : "-alt"
                  }`
                ],
              h =
                void 0 !== e.start && e.isParticipating
                  ? `${e.start}-${e.end}`
                  : "n/a",
              p = i
                ? e.content
                : (function (e, t = 20) {
                    if (null == e) return "";
                    const r = e.match(
                      new RegExp(`^.*${"\\n[^\\n]*".repeat(4)}\\n`)
                    );
                    if (r) {
                      const t = Math.min(r.index + r[0].length - 1, 100);
                      return e.slice(0, t) + "...";
                    }
                    return e.length > t + 3 ? e.slice(0, t) + "..." : e;
                  })(e.content, 100),
              d =
                null != e.content &&
                (e.content.length > 100 ||
                  (e.content.match(/\n/g) || []).length >= 5);
            return (0, ht.jsxs)("tr", {
              className: Xe()(
                si.row,
                !e.isParticipating && si.didNotParticipate
              ),
              children: [
                (0, ht.jsx)(rt.Yd, {
                  tag: "td",
                  disabled: null == e.start || !e.isParticipating,
                  className: Xe()(
                    si.groupNum,
                    null != e.start && e.isParticipating && si.clickable
                  ),
                  onClick: c,
                  children:
                    0 === e.groupNum
                      ? (0, ht.jsx)(rt.vV, {
                          text: "Match {1}",
                          ph1: (0, ht.jsx)("span", {
                            className: si.groupName,
                            children: s,
                          }),
                          className: Xe()(si.groupText, u),
                        })
                      : (0, ht.jsx)(rt.vV, {
                          text: "Group {1}",
                          ph1: (0, ht.jsxs)("span", {
                            className: si.groupName,
                            children: [
                              e.groupName || ri.Z.captureGroupMap[e.groupNum],
                              null != e.captureNum &&
                                -1 !== e.captureNum &&
                                `.${e.captureNum + 1}`,
                            ],
                          }),
                          className: Xe()(si.groupText, u),
                        }),
                }),
                (0, ht.jsx)("td", { className: si.matchPos, children: h }),
                (0, ht.jsx)("td", {
                  className: Xe()(si.matchData, d && si.textTruncated),
                  onClick: d ? l : null,
                  children: e.isParticipating
                    ? "" === p
                      ? (0, ht.jsx)("em", { children: "null" })
                      : (0, ht.jsx)(rt.K, { text: p })
                    : (0, et.Z)("group did not participate in match"),
                }),
              ],
            });
          },
          ai = (0, ze.memo)(ni),
          ii = ({
            groups: e,
            matchId: t,
            showNonParticipatingGroups: r,
            isLast: s,
          }) =>
            (0, ht.jsx)("div", {
              className: Xe()(!s && "YXXyK"),
              children: (0, ht.jsx)("table", {
                className: "EFPn1",
                children: (0, ht.jsx)("tbody", {
                  children: e.map((e, s) =>
                    (0, ht.jsx)(
                      ai,
                      {
                        group: e,
                        showNonParticipatingGroups: r,
                        evenMatch: t % 2 == 0,
                        matchNumber: t + 1,
                      },
                      `match-${t}-group-${s}`
                    )
                  ),
                }),
              }),
            }),
          oi = "IRvGa",
          ci = "LLQ0z",
          li = ({ matchError: e }) => {
            switch (e) {
              case $t.Y8:
                return (0, ht.jsx)(rt.vV, {
                  tag: "div",
                  className: ci,
                  text: "Unable to initialize the regex engine! Please try to reload the web page. If the issue persists, please open an issue here: {1}",
                  ph1: (0, ht.jsx)(rt.rU, {
                    to: "https://github.com/firasdib/Regex101/issues",
                    absolute: !0,
                    children: "https://github.com/firasdib/Regex101/issues",
                  }),
                });
              case $t.D9:
                return (0, ht.jsx)("div", {
                  className: ci,
                  children: (0, et.Z)(
                    "Your pattern contains one or more errors, please see the explanation section above."
                  ),
                });
              case $t.ik:
                return (0, ht.jsxs)("div", {
                  className: ci,
                  children: [
                    (0, ht.jsx)("div", {
                      children: (0, et.Z)(
                        "Your expression took too long to finish and was terminated. Please increase the timeout and try again."
                      ),
                    }),
                    (0, ht.jsx)("br", {}),
                    (0, ht.jsxs)("div", {
                      children: [
                        (0, et.Z)(
                          "This may be an indication of catastrophic backtracking. To find out more and what this is, please read the following article:"
                        ),
                        " ",
                        (0, ht.jsx)(rt.rU, {
                          to: "http://www.regular-expressions.info/catastrophic.html",
                          absolute: !0,
                          children: "Runaway Regular Expressions",
                        }),
                      ],
                    }),
                  ],
                });
              case $t.wm:
              case $t.VE:
                return (0, ht.jsxs)("div", {
                  className: ci,
                  children: [
                    (0, et.Z)(
                      "Catastrophic backtracking has been detected and the execution of your expression has been halted. To find out more and what this is, please read the following article:"
                    ),
                    " ",
                    (0, ht.jsx)(rt.rU, {
                      to: "http://www.regular-expressions.info/catastrophic.html",
                      absolute: !0,
                      children: "Runaway Regular Expressions",
                    }),
                    (0, ht.jsx)("br", {}),
                    (0, ht.jsx)("br", {}),
                    (0, ht.jsx)(rt.Yi, {
                      className: oi,
                      children: (0, et.Z)(
                        "Try launching the debugger to find out why."
                      ),
                    }),
                  ],
                });
              case $t.Fo:
              case $t.ek:
                return (0, ht.jsx)("div", {
                  className: ci,
                  children: (0, et.Z)(
                    "The match was halted because the offset does not point to the beginning of a valid UTF-16 character."
                  ),
                });
              case $t.Vu:
              case $t.e0:
                return (0, ht.jsx)("div", {
                  className: ci,
                  children: (0, et.Z)(
                    "The match was halted because your expression contains a recursive loop. This means either that the whole pattern, or a subpattern, has been called recursively for the second time at the same position in the subject string."
                  ),
                });
              case $t.UA:
              case $t.Rp:
                return (0, ht.jsx)("div", {
                  className: ci,
                  children: (0, et.Z)(
                    "The internal recursion limit was reached."
                  ),
                });
              case $t.Gv:
                return (0, ht.jsxs)("div", {
                  className: ci,
                  children: [
                    (0, et.Z)(
                      "The Java regex engine reached the maximum call stack size."
                    ),
                    (0, ht.jsx)("br", {}),
                    (0, ht.jsx)("br", {}),
                    (0, et.Z)(
                      "This is due to the fact that the regex engine is implemented using recursion, and is severely limited by it."
                    ),
                    " ",
                    (0, et.Z)(
                      "This indicates that your expression is not optimized for Java, and you are likely to run into similar issues in your Java code."
                    ),
                  ],
                });
              default:
                return (0, ht.jsxs)("div", {
                  className: ci,
                  children: [
                    (0, et.Z)("Your expression caused an unhandled error:"),
                    (0, ht.jsx)("br", {}),
                    (0, ht.jsx)("br", {}),
                    " ",
                    (0, ht.jsx)("strong", { children: e }),
                  ],
                });
            }
          },
          ui = (0, ze.memo)(li),
          hi = ({ className: e, children: t }) =>
            (0, ht.jsx)("label", { className: Xe()("luECo", e), children: t }),
          pi = (0, ze.memo)(hi);
        function di(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function gi(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? di(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : di(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const mi = "JSON",
          fi = "CSV",
          xi = "TEXT",
          bi = function (e, t, r) {
            const s = (function (e, t) {
              return e.map((e) =>
                e
                  .map((e) => {
                    const r = e.start,
                      s = e.end,
                      n = e.content,
                      a = e.isParticipating,
                      i = e.groupNum;
                    if (!t && 0 === i) return null;
                    let o = {
                      content: n,
                      isParticipating: a,
                      groupNum: i,
                      groupName: e.groupName || ri.Z.captureGroupMap[i] || null,
                    };
                    return (
                      null != e.start &&
                        (o = gi(gi({}, o), {}, { startPos: r, endPos: s })),
                      o
                    );
                  })
                  .filter(Boolean)
              );
            })(t, r);
            switch (e) {
              case mi:
                return JSON.stringify(s, null, 2);
              case fi:
                return (function (e) {
                  let t = "",
                    r = !1;
                  return (
                    e.forEach((e, s) => {
                      e.forEach((e) => {
                        (t +=
                          s +
                          1 +
                          "," +
                          (null != e.groupName ? e.groupName : e.groupNum) +
                          "," +
                          (e.isParticipating ? "yes" : "no") +
                          ","),
                          null != e.startPos &&
                            ((t += e.startPos + "," + e.endPos + ","),
                            (r = !0)),
                          null != e.content &&
                            (-1 !== e.content.indexOf(",")
                              ? (t += `"${e.content.replace(/"/g, '""')}"`)
                              : (t += e.content)),
                          (t += "\n");
                      });
                    }),
                    "match,group,is_participating" +
                      (r ? ",start,end" : "") +
                      ",content\n" +
                      t
                  );
                })(s);
              default:
                return (function (e) {
                  return e
                    .map((e) =>
                      e
                        .filter((e) => e.isParticipating)
                        .map((e) => e.content)
                        .join("\n")
                    )
                    .join("\n");
                })(s);
            }
          },
          vi = ({ matchData: e, isOpen: t, onModalClose: r }) => {
            const s = (0, ze.useState)(mi),
              n = (0, st.Z)(s, 2),
              a = n[0],
              i = n[1],
              o = (0, ze.useState)(!0),
              c = (0, st.Z)(o, 2),
              l = c[0],
              u = c[1],
              h = (0, ze.useRef)(null);
            return (0, ht.jsxs)(bt.Z, {
              onModalClose: r,
              isOpen: t,
              className: "icDzB",
              children: [
                (0, ht.jsx)(vt.Z, { children: (0, et.Z)("Export Matches") }),
                (0, ht.jsx)(jt.Z, {
                  children: (0, ht.jsxs)("div", {
                    className: "xTEgj",
                    children: [
                      (0, ht.jsx)(rt.gx, {
                        header: (0, ht.jsx)(rt.__, {
                          text: (0, et.Z)("Export Method"),
                        }),
                        className: "Nt7kG",
                        children: (0, ht.jsxs)(Ft.Z, {
                          children: [
                            (0, ht.jsx)(Ut.Z, {
                              isActive: a === mi,
                              icon: "file-code",
                              onClick: () => i(mi),
                              children: "JSON",
                            }),
                            (0, ht.jsx)(Ut.Z, {
                              isActive: a === fi,
                              icon: "file-excel",
                              onClick: () => i(fi),
                              children: "CSV",
                            }),
                            (0, ht.jsx)(Ut.Z, {
                              isActive: a === xi,
                              icon: "doc-text",
                              onClick: () => i(xi),
                              children: (0, et.Z)("Plain Text"),
                            }),
                          ],
                        }),
                      }),
                      (0, ht.jsx)(rt.gx, {
                        className: "CtTH_",
                        header: (0, ht.jsx)(rt.__, { text: (0, et.Z)("Data") }),
                        children: (0, ht.jsxs)("div", {
                          className: "zES36",
                          children: [
                            (0, ht.jsxs)(Bn.Z, {
                              className: "uzmGU",
                              ref: h,
                              children: [
                                t && bi(a, e, l),
                                (0, ht.jsx)(rt.Tv, {
                                  topPadding: 5,
                                  rightPos: 5,
                                  children: (0, ht.jsx)(rt.qi, {
                                    getCopyComponent: () => h.current,
                                  }),
                                }),
                              ],
                            }),
                            (0, ht.jsxs)(pi, {
                              className: "NgTKU",
                              children: [
                                (0, ht.jsx)("input", {
                                  type: "checkbox",
                                  checked: l,
                                  onChange: () => u(!l),
                                }),
                                (0, et.Z)(
                                  "Include full match in exported data"
                                ),
                              ],
                            }),
                          ],
                        }),
                      }),
                    ],
                  }),
                }),
                (0, ht.jsx)(yt.Z, {
                  children: (0, ht.jsx)(rt.zx, {
                    text: (0, et.Z)("Close"),
                    onClick: r,
                    type: gt.V5.n1,
                  }),
                }),
              ],
            });
          },
          ji = ({ matchData: e }) => {
            const t = (0, ze.useState)(!1),
              r = (0, st.Z)(t, 2),
              s = r[0],
              n = r[1],
              a = (0, ze.useCallback)(() => n(!0), []),
              i = (0, ze.useCallback)(() => n(!1), []);
            return (0, ht.jsx)(rt.Tv, {
              children: (0, ht.jsxs)(rt.Yd, {
                onClick: a,
                className: "eUlm1",
                children: [
                  (0, ht.jsx)("span", {
                    className: "YIKin",
                    children: (0, et.Z)("Export Matches"),
                  }),
                  " ",
                  (0, ht.jsx)(qt.bwQ, { size: 16 }),
                  (0, ht.jsx)(vi, { isOpen: s, onModalClose: i, matchData: e }),
                ],
              }),
            });
          },
          yi = () => {
            const e = (0, We.v9)((e) => e.regexEditor.matchResult),
              t = (0, We.v9)((e) => e.regexEditor.regex),
              r = (0, We.v9)((e) => e.regexEditor.error),
              s = (0, We.v9)((e) => e.settings.nonParticipatingGroups),
              n = (0, ze.useState)(25),
              a = (0, st.Z)(n, 2),
              i = a[0],
              o = a[1],
              c = (0, ze.useRef)(),
              l = (0, ze.useCallback)(() => {
                if (null == c.current) return;
                const t = c.current,
                  r = t.scrollTop,
                  s = t.scrollHeight,
                  n = t.offsetHeight;
                e.length > i && r >= 0.9 * (s - n) && o((e) => 2 * e);
              }, [i, e.length]),
              u = (0, ze.useMemo)(() => {
                const t = [],
                  r = Math.min(i, e.length);
                for (let n = 0; n < r; n++) {
                  const a = e[n];
                  t.push(
                    (0, ht.jsx)(
                      ii,
                      {
                        groups: a,
                        matchId: n,
                        showNonParticipatingGroups: s,
                        isLast: n === i || n + 1 === r,
                      },
                      `match-${n}`
                    )
                  );
                }
                return t;
              }, [e, i, s]);
            return null != r
              ? (0, ht.jsx)(ui, { matchError: r })
              : "" === t
              ? (0, ht.jsx)(Qa, {
                  text: (0, et.Z)(
                    "Detailed match information will be displayed here automatically."
                  ),
                })
              : 0 === e.length
              ? (0, ht.jsxs)("div", {
                  className: "muBVf",
                  children: [
                    (0, et.Z)(
                      "Your regular expression does not match the subject string."
                    ),
                    (0, ht.jsx)(ti.Z, {
                      className: oi,
                      children: (0, et.Z)(
                        "Try launching the debugger to find out why."
                      ),
                    }),
                  ],
                })
              : 0 === u.length
              ? (0, ht.jsxs)("div", {
                  children: [
                    (0, ht.jsx)("div", {
                      children: (0, et.Z)("No match groups were extracted."),
                    }),
                    (0, ht.jsx)("div", {
                      className: "FfuRb",
                      children: (0, et.Z)(
                        "This means that your pattern did match but there were no capturing groups that matched anything in the subject string."
                      ),
                    }),
                  ],
                })
              : (0, ht.jsxs)("div", {
                  className: "b62Ye",
                  onScroll: l,
                  ref: c,
                  children: [(0, ht.jsx)(ji, { matchData: e }), u],
                });
          };
        function Oi(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function wi(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Oi(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Oi(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Ci = Ce()
            ? (0, ze.lazy)(() =>
                Promise.all([r.e(483), r.e(653)]).then(r.bind(r, 97190))
              )
            : () => {},
          Ei = (e) => {
            const t = (0, ht.jsx)("div", {
              children: (0, ht.jsx)("div", {
                className: "_0eAtQ",
                children: (0, ht.jsx)(rt.$j, {}),
              }),
            });
            return (0, ht.jsx)(rt.I2, {
              fallback: t,
              children: (0, ht.jsx)(Ci, wi({}, e)),
            });
          },
          Zi = ({
            subsection: e,
            children: t,
            title: r,
            resizable: s,
            id: n,
          }) => {
            const a = (0, We.I0)(),
              i = (0, We.v9)((e) => e.rightSidebar.visibleSections),
              o = (0, ze.useCallback)(() => {
                a((0, je.SD)(e)), a((0, je.Ot)());
              }, [a, e]),
              c = i.includes(e);
            return (0, ht.jsx)(rt.gx, {
              className: Xe()("P3VvM", s && "DIFDZ", !c && "Z1_qK"),
              header: (0, ht.jsx)(rt.FX, {
                collapsed: !c,
                text: r,
                className: "fpGbf",
                onClick: o,
              }),
              contentClassName: "a0ZUJ",
              isVisible: c,
              id: n,
              children: t,
            });
          },
          Si = "CsAbs",
          ki = "_lvMT",
          Pi = (0, At.Z)(It.s_),
          Ni = {
            appear: Si,
            appearActive: ki,
            enter: Si,
            enterActive: ki,
            exit: "mpimk",
            exitActive: "CTDda",
          },
          _i = ({ children: e }) => {
            const t = (0, ze.useRef)(),
              r = (0, ze.useState)(!1),
              s = (0, st.Z)(r, 2),
              n = s[0],
              a = s[1],
              i = (0, ze.useCallback)(() => a(!0), []),
              o = (0, ze.useCallback)((e) => {
                (null != t.current && t.current.contains(e.target)) || a(!1);
              }, []);
            return (
              (0, ze.useEffect)(() => {
                const e = () => a(!1);
                return (
                  tt.ZP.on("key:escape", e), () => tt.ZP.off("key:escape", e)
                );
              }, []),
              (0, ht.jsxs)("div", {
                children: [
                  (0, ht.jsx)(_n, {
                    tooltipDirection: gt.qF.SW,
                    tooltipText: (0, et.Z)("Show Sidebar"),
                    onClick: i,
                    className: "Vg44D",
                  }),
                  (0, ht.jsx)(rt.h_, {
                    isOpen: n,
                    closeTimeout: Pi,
                    children: (0, ht.jsx)(rt.uT, {
                      className: "NtTXe",
                      classNames: Ni,
                      timeout: Pi,
                      in: n,
                      children: (0, ht.jsx)(rt.iQ, {
                        children: (0, ht.jsxs)("div", {
                          children: [
                            (0, ht.jsx)("div", {
                              className: "jJmso",
                              onClick: o,
                              onTouchEnd: o,
                            }),
                            (0, ht.jsx)("nav", {
                              ref: t,
                              className: "KwIMW",
                              children: e,
                            }),
                          ],
                        }),
                      }),
                    }),
                  }),
                ],
              })
            );
          },
          Ti = ["title", "children"];
        function Ai(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Ii(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Ai(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Ai(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Ri = (e) => {
            let t = e.title,
              r = e.children,
              s = (0, T.Z)(e, Ti);
            return (0, ht.jsxs)(
              "div",
              Ii(
                Ii({ className: "uYpkX" }, s),
                {},
                {
                  children: [
                    (0, ht.jsx)(rt.__, { text: t, className: "F61ks" }),
                    (0, ht.jsx)("div", { className: "MY46R", children: r }),
                  ],
                }
              )
            );
          },
          Di = ({ subsections: e }) => {
            const t = (0, We.I0)(),
              r = (0, We.v9)((e) => e.rightSidebar.activeSubsection);
            return (0, ht.jsx)("div", {
              className: "JPMcE",
              children: e.map((e) => {
                const s = e.tooltip,
                  n = e.icon,
                  a = e.key;
                return (0, ht.jsx)(
                  rt.hU,
                  {
                    onClick: () => t((0, je.hK)(a)),
                    size: 34,
                    tooltip: s,
                    tooltipDirection: gt.qF.SE,
                    className: Xe()("CoQ5Y", r === a && "Cikzv"),
                    children: (0, ht.jsx)(n, { size: 18 }),
                  },
                  `smallRightSidebarBtn-${a}`
                );
              }),
            });
          },
          Li = parseFloat(ct.D6),
          Mi = () => {
            const e = (0, We.v9)((e) => e.rightSidebar.activeSubsection),
              t = (0, We.v9)((e) => e.regexEditor.delimiter),
              r = (0, We.v9)((e) => e.regexEditor.flags),
              s = (0, We.v9)((e) => e.regexEditor.regex),
              n = (0, We.v9)((e) => e.regexEditor.flavor);
            switch (e) {
              case h:
                return (0, ht.jsx)(Ri, {
                  title: (0, et.Z)("Explanation"),
                  children: (0, ht.jsx)(ei, {
                    regex: s,
                    flags: r,
                    delimiter: t,
                    flavor: n,
                  }),
                });
              case p:
                return (0, ht.jsx)(Ri, {
                  title: (0, et.Z)("Match Information"),
                  children: (0, ht.jsx)(yi, {}),
                });
              case d:
                return (0, ht.jsx)(Ri, {
                  title: (0, et.Z)("Quick Reference"),
                  id: "quickrefParent",
                  children: (0, ht.jsx)(Ei, {}),
                });
              default:
                throw new Error(`Unknown subsection '${e}'`);
            }
          },
          Ui = () => {
            const e = (0, Qe.Sj)(Li),
              t = (0, We.v9)((e) => e.regexEditor.showUnitTestArea),
              r = (0, We.v9)((e) => e.settings.alwaysCollapseRightSidebar),
              s = (0, We.v9)((e) => e.regexEditor.delimiter),
              n = (0, We.v9)((e) => e.regexEditor.flags),
              a = (0, We.v9)((e) => e.regexEditor.regex),
              i = (0, We.v9)((e) => e.regexEditor.flavor);
            if (r || e.width < Li) {
              const e = [
                {
                  tooltip: (0, et.Z)("View Explanation"),
                  icon: qt.UCm,
                  key: h,
                },
              ];
              return (
                t ||
                  e.push({
                    tooltip: (0, et.Z)("View Match Information"),
                    icon: _s.n2W,
                    key: p,
                  }),
                e.push({
                  tooltip: (0, et.Z)("View Regex Quick Reference"),
                  icon: nt.CA9,
                  key: d,
                  id: "quickrefParent",
                }),
                (0, ht.jsxs)(_i, {
                  children: [
                    (0, ht.jsx)(Di, { subsections: e }),
                    (0, ht.jsx)(Mi, {}),
                  ],
                })
              );
            }
            return (0, ht.jsxs)(oa, {
              children: [
                (0, ht.jsx)(Zi, {
                  title: (0, et.Z)("Explanation"),
                  subsection: h,
                  resizable: !0,
                  children: (0, ht.jsx)(ei, {
                    regex: a,
                    flags: n,
                    delimiter: s,
                    flavor: i,
                  }),
                }),
                !t &&
                  (0, ht.jsx)(Zi, {
                    title: (0, et.Z)("Match Information"),
                    subsection: p,
                    resizable: !0,
                    children: (0, ht.jsx)(yi, {}),
                  }),
                (0, ht.jsx)(Zi, {
                  title: (0, et.Z)("Quick Reference"),
                  subsection: d,
                  id: "quickrefParent",
                  children: (0, ht.jsx)(Ei, {}),
                }),
              ],
            });
          },
          Fi = ({ result: e, className: t }) => {
            if (null == e.time && null == e.steps) return null;
            const r = Math.round(1e3 * e.time) / 1e3;
            return (0, ht.jsxs)("div", {
              className: t,
              children: [
                null != e.error &&
                  (0, ht.jsx)("div", { className: "eFWYj", children: e.error }),
                (0, ht.jsx)(rt.vV, {
                  tag: "div",
                  text: "Test finished in {1}{2}",
                  ph1:
                    null != e.steps
                      ? `${e.steps} ${
                          1 === e.steps ? (0, et.Z)("step") : (0, et.Z)("steps")
                        }`
                      : (0, et.Z)("approximately {1} ms", r),
                  ph2:
                    null != e.steps
                      ? `, ${(0, et.Z)("approximately {1} ms", r)}`
                      : "",
                }),
              ],
            });
          },
          Gi = "qI7UZ",
          Vi = "tfiLD",
          Bi = "eoxGV",
          qi = ({
            disabled: e,
            isFirstItem: t,
            isLastItem: r,
            testNumber: s,
            className: n,
          }) => {
            const a = (0, We.I0)(),
              i = (0, ze.useCallback)(() => a((0, je.ew)(s, s + 1)), [s, a]),
              o = (0, ze.useCallback)(() => a((0, je.ew)(s, s - 1)), [s, a]),
              c = (0, ze.useCallback)(() => a((0, je.K_)(s)), [s, a]),
              l = (0, We.v9)((e) => (0, Ts.G)(e.regexEditor.flavor));
            return (0, ht.jsxs)("div", {
              className: Xe()("sdZCP", n),
              children: [
                (0, ht.jsx)(rt.lx, {
                  text: (0, et.Z)("Move down"),
                  direction: gt.qF.N,
                  children: (0, ht.jsx)(rt.Yd, {
                    onClick: i,
                    disabled: r || e,
                    className: Xe()(Gi, (r || e) && Vi),
                    children: (0, ht.jsx)(nt.ebp, { size: 22 }),
                  }),
                }),
                (0, ht.jsx)(rt.lx, {
                  text: (0, et.Z)("Move up"),
                  direction: gt.qF.N,
                  children: (0, ht.jsx)(rt.Yd, {
                    onClick: o,
                    disabled: t || e,
                    className: Xe()(Gi, (t || e) && Vi),
                    children: (0, ht.jsx)(nt.Tvk, { size: 22 }),
                  }),
                }),
                l &&
                  (0, ht.jsx)(rt.lx, {
                    text: (0, et.Z)("Debug Test"),
                    direction: gt.qF.N,
                    children: (0, ht.jsx)(rt.rU, {
                      to: `debugger?testId=${s}`,
                      className: Xe()(Gi, Bi),
                      noTheme: !0,
                      children: (0, ht.jsx)(nt.RwU, { size: 18 }),
                    }),
                  }),
                (0, ht.jsx)(rt.lx, {
                  text: (0, et.Z)("Delete"),
                  direction: gt.qF.NW,
                  children: (0, ht.jsx)(rt.Yd, {
                    onClick: c,
                    disabled: e,
                    className: Xe()(Gi, Bi, e && Vi),
                    children: (0, ht.jsx)(nt.M$4, { size: 18 }),
                  }),
                }),
              ],
            });
          };
        var Hi = r(89441),
          $i = r(14824);
        const zi = (e, t) => {
            let r;
            return (
              null == e || e === Hi.m
                ? (r = [$i.FS, $i.Xg])
                : ((r = [$i.u0, $i.wU, $i.DC, $i.xz]),
                  t !== j().GOLANG && "0" !== e && r.push($i.GU)),
              r.map((e) => ({ value: e, text: $i.VO[e] }))
            );
          },
          Wi = ({ onChange: e, currentTarget: t }) => {
            const r = (0, We.v9)((e) => e.regexAreaParser.captureGroupCount),
              s = (0, We.v9)((e) => e.regexAreaParser.definedSubpatterns),
              n = (0, We.v9)((e) => e.regexAreaParser.captureGroupMap),
              a = (0, ze.useRef)(null),
              i = ((e = 0, t, r) => {
                const s = [
                  { value: Hi.m, text: Hi.H(Hi.m, r) },
                  { value: 0, text: Hi.H(0, r) },
                ];
                for (let n = 0; n < e; n++)
                  t.includes(n) ||
                    s.push({ value: n + 1, text: Hi.H(n + 1, r) });
                return s;
              })(r, s, n),
              o = (0, ze.useState)(!1),
              c = (0, st.Z)(o, 2),
              l = c[0],
              u = c[1];
            return (0, ht.jsxs)(ht.Fragment, {
              children: [
                (0, ht.jsx)(rt.CP, {
                  onClick: () => u(!0),
                  ref: a,
                  disabled: l,
                  children: (0, Hi.H)(t, n),
                }),
                (0, ht.jsxs)(Ir, {
                  isOpen: l,
                  onMenuClose: () => u(!1),
                  target: a.current,
                  closeOnClick: !0,
                  children: [
                    (0, ht.jsx)(Wr, { text: (0, et.Z)("Select target") }),
                    (0, ht.jsx)(Yr, {}),
                    i.map((r) =>
                      (0, ht.jsx)(
                        Br,
                        {
                          isActive: r.value === t,
                          onClick: () => e(r.value),
                          children: r.text,
                        },
                        `test-target-${r.value}`
                      )
                    ),
                  ],
                }),
              ],
            });
          },
          Yi = ({ onChange: e, currentTarget: t, currentCriteria: r }) => {
            const s = (0, We.v9)((e) => e.regexEditor.flavor),
              n = (0, ze.useRef)(null),
              a = zi(t, s),
              i = (0, ze.useState)(!1),
              o = (0, st.Z)(i, 2),
              c = o[0],
              l = o[1];
            return (0, ht.jsxs)(ht.Fragment, {
              children: [
                (0, ht.jsx)(rt.CP, {
                  onClick: () => l(!0),
                  ref: n,
                  disabled: c,
                  children: $i.VO[r],
                }),
                (0, ht.jsxs)(Ir, {
                  isOpen: c,
                  onMenuClose: () => l(!1),
                  target: n.current,
                  closeOnClick: !0,
                  children: [
                    (0, ht.jsx)(Wr, { text: (0, et.Z)("Select assertion") }),
                    (0, ht.jsx)(Yr, {}),
                    a.map((t) =>
                      (0, ht.jsx)(
                        Br,
                        {
                          isActive: t.value === r,
                          onClick: () => e(t.value),
                          children: t.text,
                        },
                        `test-criteria-${t.value}`
                      )
                    ),
                  ],
                }),
              ],
            });
          },
          Ki = "QChMj",
          Ji = (e) => {
            if (0 === e.length)
              return (0, ht.jsx)("em", { children: (0, et.Z)("empty string") });
            const t = e.replace(/\s+/, " ");
            return t.length > 40
              ? t.slice(0, 40) + String.fromCharCode(8230)
              : t;
          },
          Xi = ({ test: e }) => {
            const t = (0, We.v9)((e) => e.regexAreaParser.captureGroupMap),
              r = e.description,
              s = e.testString,
              n = e.target,
              a = e.criteria,
              i = e.compareString;
            return (
              r ||
              (0, ht.jsx)(rt.vV, {
                text: "given the string {1} assert that {2} {3} {4}",
                ph1: (0, ht.jsx)("span", {
                  className: Ki,
                  children: Ji(s || ""),
                }),
                ph2: Hi.H(n, t),
                ph3: $i.VO[a],
                ph4:
                  null == n || n === Hi.m
                    ? ""
                    : (0, ht.jsx)("span", {
                        className: Ki,
                        children: Ji(i || ""),
                      }),
              })
            );
          },
          Qi = "RRgDA",
          eo = "wdfE9",
          to = "zr88s",
          ro = "FHCCK",
          so = "n3dVL",
          no = ({
            testKey: e,
            testNumber: t,
            viewDetails: r,
            onViewDetailsClick: s,
            existingTest: n = {},
            isLastItem: a,
            isFirstItem: i,
            result: o = {},
          }) => {
            const c = (0, We.I0)(),
              l = (0, We.v9)((e) => e.unitTests.testsRunning),
              u = n.description,
              h = n.testString,
              p = n.compareString,
              d = n.target,
              m = n.criteria,
              f = o.hasError,
              x = (0, ze.useRef)(null),
              b = (0, ze.useState)(u || ""),
              v = (0, st.Z)(b, 2),
              j = v[0],
              y = v[1],
              O = (0, ze.useState)(h || ""),
              w = (0, st.Z)(O, 2),
              C = w[0],
              E = w[1],
              Z = (0, ze.useState)(p || ""),
              S = (0, st.Z)(Z, 2),
              k = S[0],
              P = S[1],
              N = (0, ze.useState)(d),
              _ = (0, st.Z)(N, 2),
              T = _[0],
              A = _[1],
              I = (0, ze.useState)(m),
              R = (0, st.Z)(I, 2),
              D = R[0],
              L = R[1],
              M = (0, Qe.Sf)(
                (e, t) =>
                  c(
                    (function (e, t) {
                      return { type: g.LM, value: { testKey: e, test: t } };
                    })(e, t)
                  ),
                500
              );
            (0, ze.useEffect)(() => {
              r && x.current.focus();
            }, [r]),
              (0, Qe.vI)(() => {
                M(e, {
                  description: j,
                  testString: C,
                  compareString: k,
                  target: T,
                  criteria: D,
                });
              }, [e, M, j, C, k, T, D]);
            const U = !1 === f,
              F = f;
            return (0, ht.jsxs)("div", {
              className: Xe()("_mdci", F && eo, U && Qi),
              children: [
                (0, ht.jsx)(rt.Yd, {
                  className: "CIpAk",
                  onClick: () => s(e),
                  tag: "div",
                  "aria-label": r
                    ? (0, et.Z)("Expand test")
                    : (0, et.Z)("Collapse test"),
                  children: r
                    ? (0, ht.jsx)(nt.ebp, { size: 22 })
                    : (0, ht.jsx)(nt.jZo, { size: 22 }),
                }),
                !r &&
                  (0, ht.jsxs)("div", {
                    className: "bjIoO",
                    children: [
                      (0, ht.jsx)("div", {
                        className: to,
                        children: (0, ht.jsx)(Xi, { test: n }),
                      }),
                      (0, ht.jsxs)("div", {
                        className: Xe()(ro, U && Qi, F && eo),
                        children: [
                          U && (0, ht.jsx)(nt.xuy, { size: 18 }),
                          F && (0, ht.jsx)(nt.eSQ, { size: 18 }),
                        ],
                      }),
                      (0, ht.jsx)(qi, {
                        isFirstItem: i,
                        isLastItem: a,
                        disabled: l,
                        testNumber: t,
                        className: so,
                      }),
                    ],
                  }),
                r &&
                  (0, ht.jsxs)("div", {
                    className: "oLvlF",
                    children: [
                      (0, ht.jsxs)("div", {
                        className: "nwj_2",
                        children: [
                          (0, ht.jsx)("input", {
                            placeholder: (0, et.Z)("insert test description"),
                            className: to,
                            onChange: (e) => y(e.target.value),
                            value: j,
                            ref: x,
                            spellCheck: "false",
                          }),
                          (0, ht.jsxs)("div", {
                            className: Xe()(ro, U && Qi, F && eo),
                            children: [
                              U && (0, ht.jsx)(nt.xuy, { size: 18 }),
                              F && (0, ht.jsx)(nt.eSQ, { size: 18 }),
                            ],
                          }),
                          (0, ht.jsx)(qi, {
                            isFirstItem: i,
                            isLastItem: a,
                            disabled: l,
                            testNumber: t,
                            className: so,
                          }),
                        ],
                      }),
                      (0, ht.jsx)("div", {
                        className: "fo_Hl",
                        children: (0, et.Z)("given the following test string"),
                      }),
                      (0, ht.jsx)("textarea", {
                        placeholder: (0, et.Z)("insert test string"),
                        className: "W7b7u",
                        onChange: (e) => E(e.target.value),
                        value: C,
                        rows: 2,
                        spellCheck: "false",
                      }),
                      (0, ht.jsx)(rt.vV, {
                        tag: "div",
                        className: "L5b8E",
                        text: "assert that {1} {2}",
                        ph1: (0, ht.jsx)(Wi, {
                          currentTarget: T,
                          onChange: (e) => {
                            A(e);
                            const t = zi(e);
                            L(t[0].value);
                          },
                        }),
                        ph2: (0, ht.jsx)(Yi, {
                          currentTarget: T,
                          currentCriteria: D,
                          onChange: L,
                        }),
                      }),
                      null != T &&
                        T !== Hi.m &&
                        D !== $i.GU &&
                        (0, ht.jsx)("textarea", {
                          placeholder: (0, et.Z)("insert comparison string"),
                          className: "mbbk1",
                          onChange: (e) => P(e.target.value),
                          value: k,
                        }),
                      null != o &&
                        (0, ht.jsx)(Fi, { result: o, className: "MwoOx" }),
                    ],
                  }),
              ],
            });
          },
          ao = "Yz_VU",
          io = () => {
            const e = (0, We.I0)(),
              t = (0, We.v9)((e) => e.unitTests.tests),
              r = (0, We.v9)((e) => e.unitTests.testResults),
              s = (0, We.v9)((e) => e.unitTests.testFilter),
              n = (0, ze.useState)([]),
              a = (0, st.Z)(n, 2),
              i = a[0],
              o = a[1],
              c = (e) => {
                const t = i.filter((t) => t !== e);
                t.length === i.length && t.push(e), o(t);
              };
            (0, ze.useEffect)(() => {
              const e = () => o(t.map((e) => e.key)),
                r = () => o([]);
              return (
                tt.ZP.on({ [tt.yM]: e, [tt.Fx]: r }),
                () => tt.ZP.off({ [tt.yM]: e, [tt.Fx]: r })
              );
            }, [e, t]);
            const l = (0, ze.useCallback)(() => e((0, je.CJ)()), [e]),
              u = (0, ze.useCallback)(() => e((0, je.E0)(R)), [e]),
              h = (0, ze.useMemo)(
                () =>
                  s === R
                    ? t
                    : t.filter((e) => {
                        const t = r[e.key];
                        return (null == t ? void 0 : t.hasError) === (s !== A);
                      }),
                [t, s, r]
              );
            return (0, ht.jsx)(Bn.Z, {
              className: "GuvgB",
              children:
                0 === t.length
                  ? (0, ht.jsx)(rt.vV, {
                      text: "There are no unit tests, click {1} to add some.",
                      ph1: (0, ht.jsx)(rt.Yd, {
                        onClick: l,
                        className: ao,
                        children: (0, et.Z)("here"),
                      }),
                    })
                  : 0 === h.length
                  ? (0, ht.jsx)(rt.vV, {
                      text: "No tests matched your filter, click {1} to show all.",
                      ph1: (0, ht.jsx)(rt.Yd, {
                        onClick: u,
                        className: ao,
                        children: (0, et.Z)("here"),
                      }),
                    })
                  : h.map((e, s) =>
                      (0, ht.jsx)(
                        no,
                        {
                          existingTest: e,
                          testKey: e.key,
                          testNumber: s,
                          viewDetails: i.includes(e.key),
                          onViewDetailsClick: c,
                          isLastItem: s === t.length - 1,
                          isFirstItem: 0 === s,
                          result: r[e.key],
                        },
                        `unit-test-list-${e.key}`
                      )
                    ),
            });
          };
        var oo = r(15935);
        const co = ({ className: e }) => {
            const t = (0, ze.useRef)(),
              r = (0, ze.useState)(!1),
              s = (0, st.Z)(r, 2),
              n = s[0],
              a = s[1],
              i = (0, We.I0)(),
              o = (0, We.v9)((e) => e.unitTests.testFilter),
              c = (0, ze.useCallback)(() => a(!0), []),
              l = (0, ze.useCallback)(() => a(!1), []),
              u = (0, ze.useCallback)(() => tt.ZP.emit(tt.yM), []),
              h = (0, ze.useCallback)(() => tt.ZP.emit(tt.Fx), []),
              p = (0, ze.useCallback)(() => i((0, je.E0)(R)), [i]),
              d = (0, ze.useCallback)(() => i((0, je.E0)(A)), [i]),
              g = (0, ze.useCallback)(() => i((0, je.E0)(I)), [i]);
            return (0, ht.jsxs)("div", {
              className: e,
              children: [
                (0, ht.jsx)(rt.lx, {
                  text: (0, et.Z)("Tools and Filters"),
                  direction: gt.qF.NE,
                  children: (0, ht.jsx)(rt.Yd, {
                    onClick: c,
                    className: "llECe",
                    ref: t,
                    children: (0, ht.jsx)(nt.LB8, { size: 18 }),
                  }),
                }),
                (0, ht.jsxs)(Ir, {
                  onMenuClose: l,
                  isOpen: n,
                  target: t.current,
                  placement: "top",
                  closeOnClick: !0,
                  children: [
                    (0, ht.jsx)(Wr, { text: (0, et.Z)("Tools and Filters") }),
                    (0, ht.jsx)(Yr, {}),
                    (0, ht.jsx)(Br, {
                      onClick: u,
                      children: (0, et.Z)("Expand all tests"),
                    }),
                    (0, ht.jsx)(Br, {
                      onClick: h,
                      children: (0, et.Z)("Collapse all tests"),
                    }),
                    (0, ht.jsx)(Yr, {}),
                    (0, ht.jsx)(Br, {
                      onClick: p,
                      isActive: o === R,
                      children: (0, et.Z)("Show all tests"),
                    }),
                    (0, ht.jsx)(Br, {
                      onClick: d,
                      isActive: o === A,
                      children: (0, et.Z)("Show only passed tests"),
                    }),
                    (0, ht.jsx)(Br, {
                      onClick: g,
                      isActive: o === I,
                      children: (0, et.Z)("Show only failed tests"),
                    }),
                  ],
                }),
              ],
            });
          },
          lo = (0, ze.memo)(co),
          uo = ["criteria", "target", "testString", "compareString"],
          ho = () => {
            const e = (0, We.I0)(),
              t = (0, We.v9)((e) => e.regexEditor.flavor),
              r = (0, We.v9)((e) => e.regexEditor.regex),
              s = (0, We.v9)((e) => e.regexEditor.flags),
              n = (0, We.v9)((e) => e.settings.maxExecutionTime),
              a = (0, We.v9)((e) => !!e.regexAreaParser.status),
              i = (0, We.v9)((e) => e.regexAreaParser.tokens.length > 0),
              o = (0, We.v9)(
                (e) => e.unitTests.tests,
                (e, t) => {
                  if (e.length !== t.length) return !1;
                  const r = t.reduce((e, t) => {
                    if (null == t.key) throw new Error("Invalid unit test");
                    return (e[t.key] = t), e;
                  }, {});
                  return e.every((e) =>
                    (0, We.wU)(ye(e, uo), ye(r[e.key] || {}, uo))
                  );
                }
              ),
              c = (0, ze.useRef)(new oo.Z()).current,
              l = (0, ze.useState)(0),
              u = (0, st.Z)(l, 2),
              h = u[0],
              p = u[1],
              d = (0, ze.useState)(!1),
              g = (0, st.Z)(d, 2),
              m = g[0],
              f = g[1],
              x = (0, ze.useCallback)(() => {
                c.resetWorker(), p(0), f(!1), e((0, je.jJ)());
              }, [e, c]),
              b = (0, ze.useCallback)(
                (r, s, a, i, o) => {
                  const l = {
                    maxExecutionTime: n,
                    flavor: t,
                    calculateRegexSteps: !0,
                  };
                  c.runMatch(
                    s,
                    a.replace(/g/g, ""),
                    i.testString,
                    l,
                    (t = {}, r) => {
                      e(
                        r
                          ? (0, je.UZ)(
                              i.key,
                              (0, et.Z)("Internal engine error: {1}", r)
                            )
                          : (0, je.UZ)(
                              i.key,
                              (function (e, t) {
                                switch (e.criteria) {
                                  case $i.FS:
                                    return 0 === t.length
                                      ? (0, et.Z)(
                                          "Expected regex to match, but did not."
                                        )
                                      : null;
                                  case $i.Xg:
                                    return t.length > 0
                                      ? (0, et.Z)(
                                          "Expected regex to not match, but did."
                                        )
                                      : null;
                                  default:
                                    return (function (e, t) {
                                      if (!t || 0 === t.length)
                                        return (0, et.Z)(
                                          "The regex did not match the subject string."
                                        );
                                      const r = t[e.target],
                                        s = e.criteria,
                                        n = e.compareString || "";
                                      if (s === $i.GU)
                                        return r && null != r.content
                                          ? (0, et.Z)(
                                              "Group {1} was not expected to participate in the match but did anyway",
                                              e.target
                                            )
                                          : null;
                                      if (!r)
                                        return (0, et.Z)(
                                          "Group {1} no longer exists in the pattern or did not participate in the match",
                                          e.target
                                        );
                                      let a;
                                      switch (
                                        ((a = r.name
                                          ? `${r.groupNum} (${r.name})`
                                          : 0 === r.groupNum
                                          ? `${r.groupNum} (${(0, et.Z)(
                                              "full match"
                                            )})`
                                          : r.groupNum),
                                        s)
                                      ) {
                                        case $i.DC:
                                          return null != r.content &&
                                            -1 !== r.content.indexOf(n)
                                            ? null
                                            : (0, et.Z)(
                                                "Expected group {1} to contain `{2}` but did not",
                                                a,
                                                n
                                              );
                                        case $i.xz:
                                          return r.content === n
                                            ? null
                                            : (0, et.Z)(
                                                "Expected group {1} to equal `{2}` but was instead `{3}`",
                                                a,
                                                n,
                                                r.content || ""
                                              );
                                        case $i.u0:
                                          const e =
                                            null == r.content
                                              ? ""
                                              : r.content.slice(0, n.length);
                                          return e === n
                                            ? null
                                            : (0, et.Z)(
                                                "Expected group {1} to start with `{2}` but was instead `{3}`",
                                                a,
                                                n,
                                                e
                                              );
                                        case $i.wU:
                                          const t =
                                            null == r.content
                                              ? ""
                                              : r.content.slice(-1 * n.length);
                                          return t === n
                                            ? null
                                            : (0, et.Z)(
                                                "Expected group {1} to end with `{2}` but was instead `{3}`",
                                                a,
                                                n,
                                                t
                                              );
                                        default:
                                          throw new Error(
                                            `Unknown unit test criteria '${s}'`
                                          );
                                      }
                                    })(e, t[0]);
                                }
                              })(i, t.matchResult),
                              t.steps,
                              t.time
                            )
                      ),
                        p((e) => e + 1),
                        o.next();
                    }
                  );
                },
                [n, t, e, c]
              ),
              v = (0, ze.useCallback)(() => {
                c.resetWorker(),
                  p(0),
                  f(!0),
                  e((0, je.h5)()),
                  (function (e, t, n) {
                    let a = 0,
                      i = !1;
                    const c = {
                      next() {
                        i ||
                          (a < e
                            ? (a++,
                              ((e) => {
                                b(e.iteration(), r, s, o[e.iteration()], e);
                              })(c))
                            : ((i = !0), n()));
                      },
                      iteration: () => a - 1,
                      break() {
                        (i = !0), n();
                      },
                    };
                    c.next();
                  })(o.length, 0, () => {
                    f(!1), e((0, je.jJ)());
                  });
              }, [e, b, o, r, s, c]),
              j = x,
              y = (0, ze.useCallback)(() => e((0, je.CJ)()), [e]);
            (0, ze.useEffect)(() => {
              const e = () => {
                m && x(), i && "" !== r && !a && v();
              };
              return (
                tt.ZP.on("key:ctrlEnter", e),
                () => tt.ZP.off("key:ctrlEnter", e)
              );
            }, [i, a, r, v, m, x]),
              (0, ze.useEffect)(() => {
                i && "" !== r && !a && v();
              }, [i, a, r, v]),
              (0, ze.useEffect)(() => x, [x]);
            const O = Math.max(
              0,
              o.length > 0 ? ((o.length - h) / o.length) * 100 : 100
            );
            return (0, ht.jsxs)("div", {
              className: "bc_U_",
              children: [
                (0, ht.jsxs)("div", {
                  className: "bzSeP",
                  children: [
                    (0, ht.jsx)(lo, { className: "llbAo" }),
                    (0, ht.jsxs)("div", {
                      className: "cfrN_",
                      children: [
                        !m &&
                          (0, ht.jsx)(rt.zx, {
                            text: (0, et.Z)("Run tests"),
                            disabled: 0 === o.length || "" === r || a,
                            onClick: () => {
                              !i || "" === r || a || m || v(!0);
                            },
                          }),
                        m &&
                          (0, ht.jsx)(rt.zx, {
                            type: gt.V5.T,
                            text: (0, et.Z)("Cancel"),
                            onClick: j,
                          }),
                        (0, ht.jsx)(rt.zx, {
                          text: (0, et.Z)("Add test"),
                          onClick: y,
                          className: "KuRpm",
                        }),
                      ],
                    }),
                  ],
                }),
                (0, ht.jsx)("div", {
                  className: "W3HLH",
                  style: { right: `${O}%` },
                }),
              ],
            });
          },
          po = () => {
            const e = (0, We.v9)((e) => e.unitTests.testResults),
              t = Object.values(e).reduce(
                (e, t) => {
                  const r = (0, st.Z)(e, 2),
                    s = r[0],
                    n = r[1];
                  return [
                    s + (!1 === t.hasError ? 1 : 0),
                    n + (t.hasError ? 1 : 0),
                  ];
                },
                [0, 0]
              ),
              r = (0, st.Z)(t, 2),
              s = r[0],
              n = r[1],
              a =
                (s > 0 || n > 0) &&
                (n > 0
                  ? (0, ht.jsx)("span", {
                      className: "ceywG",
                      children:
                        1 === n
                          ? (0, et.Z)("{1} test failed", n)
                          : (0, et.Z)("{1} tests failed", n),
                    })
                  : (0, ht.jsx)("span", {
                      className: "BIsZ6",
                      children: (0, et.Z)("All tests passed"),
                    }));
            return (0, ht.jsx)(rt.__, {
              className: "esMAk",
              text: (0, et.Z)("Unit Tests"),
              children: a,
            });
          },
          go = (0, ze.memo)(po),
          mo = () =>
            (0, ht.jsxs)("div", {
              className: "Av0Zr",
              children: [
                (0, ht.jsx)(go, {}),
                (0, ht.jsxs)("div", {
                  className: "YXYOI",
                  children: [(0, ht.jsx)(io, {}), (0, ht.jsx)(ho, {})],
                }),
              ],
            });
        let fo;
        r(31807) &&
          ((fo = r(4631)), r(88386), r(82801), r(64020), r(33086).Z(fo));
        const xo = fo;
        var bo = r(39912);
        function vo(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        const jo = (e) => (t) => {
            const r = document.createElement("span");
            return (
              e
                ? ((r.className = bo.Z.specialChar),
                  r.appendChild(
                    document.createTextNode(
                      `U+${(
                        "0000" + t.codePointAt(0).toString(16).toUpperCase()
                      ).slice(-4)}`
                    )
                  ))
                : r.appendChild(document.createTextNode(t)),
              r
            );
          },
          yo = ({
            onChange: e,
            onFocus: t,
            onBlur: r,
            onCursorMove: s,
            onPaste: n,
            onCreate: i,
            options: o = {},
            defaultValue: c,
            singleLine: l,
            className: u,
          }) => {
            const h = (0, ze.useRef)(null),
              p = (0, ze.useRef)(null);
            return (
              (0, ze.useEffect)(() => {
                const e = xo.fromTextArea(
                  h.current,
                  (function (e) {
                    for (var t = 1; t < arguments.length; t++) {
                      var r = null != arguments[t] ? arguments[t] : {};
                      t % 2
                        ? vo(Object(r), !0).forEach(function (t) {
                            (0, a.Z)(e, t, r[t]);
                          })
                        : Object.getOwnPropertyDescriptors
                        ? Object.defineProperties(
                            e,
                            Object.getOwnPropertyDescriptors(r)
                          )
                        : vo(Object(r)).forEach(function (t) {
                            Object.defineProperty(
                              e,
                              t,
                              Object.getOwnPropertyDescriptor(r, t)
                            );
                          });
                    }
                    return e;
                  })({ styleSelectedText: !0 }, o)
                );
                return (p.current = e), () => e.toTextArea();
              }, []),
              (0, ze.useEffect)(() => {
                e && p.current.on("change", e),
                  t && p.current.on("focus", t),
                  r && p.current.on("blur", r),
                  s && p.current.on("cursorActivity", s),
                  n && p.current.on("paste", n);
                const a = (e, t) => {
                  if (t.update) {
                    const e = t.text.join("").replace(/[\r\n]/g, "");
                    t.update(t.from, t.to, [e]);
                  }
                  return !0;
                };
                return (
                  l && p.current.on("beforeChange", a),
                  () => {
                    p.current.off("change", e),
                      p.current.off("focus", t),
                      p.current.off("blur", r),
                      p.current.off("cursorActivity", s),
                      p.current.off("paste", n),
                      p.current.off("beforeChange", a);
                  }
                );
              }, [e, t, r, s, n, l]),
              (0, ze.useEffect)(() => {
                p.current.setOption("tabindex", 0),
                  p.current.setOption("direction", "ltr");
                for (const e in o)
                  if (o.hasOwnProperty(e)) {
                    const t = o[e];
                    switch (e) {
                      case "showWhitespace":
                        p.current.setOption("specialCharPlaceholder", jo(t));
                        break;
                      case "tabindex":
                        p.current.setOption("tabindex", t);
                        break;
                      case "placeholder":
                        p.current.setOption("placeholder", t),
                          p.current.setOption("screenReaderLabel", t);
                        break;
                      default:
                        p.current.setOption(e, t);
                    }
                  }
              }, [o]),
              (0, ze.useEffect)(() => {
                c && p.current.setValue(c), null == i || i(p.current);
              }, []),
              (0, ht.jsx)("div", {
                className: Xe()(
                  u,
                  o.showWhitespace && "CodeMirror-show-whitespace"
                ),
                translate: "no",
                children: (0, ht.jsx)("textarea", {
                  style: { display: "none" },
                  ref: h,
                  defaultValue: "",
                  autoComplete: "off",
                  translate: "no",
                }),
              })
            );
          },
          Oo = (0, ze.memo)(yo);
        function wo(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Co(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? wo(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : wo(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Eo = (e, t, r) => {
            const s = e.coordsChar({ left: t, top: r }, "page");
            for (let n = 0; n < 2; n++) {
              const n = e.charCoords(s, "page");
              if (t >= n.left && t <= n.right && r >= n.top && r <= n.bottom)
                return e.indexFromPos(s);
              if (s.ch-- <= 0) break;
            }
            return null;
          },
          Zo = (e, t) => {
            if (null == t) return null;
            const r = e.posFromIndex(t),
              s = e.charCoords(r);
            return Co(
              Co({}, s),
              {},
              {
                x: s.left,
                y: s.top,
                width: s.right - s.left,
                height: s.bottom - s.top,
              }
            );
          };
        var So = r(4458);
        const ko = "zNH_P",
          Po = "_UG3a",
          No = (0, At.Z)(It.DP),
          _o = {
            appear: ko,
            appearActive: Po,
            enter: ko,
            enterActive: Po,
            exit: "i2I1d",
            exitActive: "Gb8MO",
          };
        class To extends ze.Component {
          constructor(...e) {
            super(...e),
              (this.state = { showTooltip: !1, data: null, mouseDown: !1 }),
              (this._rootRef = (0, ze.createRef)()),
              (this._arrowRef = (0, ze.createRef)()),
              (this._timeout = null);
          }
          componentDidMount() {
            var e, t;
            (this.onMouseDown = this.onMouseDown.bind(this)),
              (this.onMouseUp = this.onMouseUp.bind(this)),
              null === (e = document.body) ||
                void 0 === e ||
                e.addEventListener("mousedown", this.onMouseDown, {
                  passive: !0,
                  capture: !0,
                }),
              null === (t = document.body) ||
                void 0 === t ||
                t.addEventListener("mouseup", this.onMouseUp, {
                  passive: !0,
                  capture: !0,
                });
          }
          componentWillUnmount() {
            var e, t, r;
            null === (e = document.body) ||
              void 0 === e ||
              e.removeEventListener("mouseout", this.onMouseOut, !0),
              null === (t = document.body) ||
                void 0 === t ||
                t.removeEventListener("mousedown", this.onMouseDown, {
                  passive: !0,
                  capture: !0,
                }),
              null === (r = document.body) ||
                void 0 === r ||
                r.removeEventListener("mouseup", this.onMouseUp, {
                  passive: !0,
                  capture: !0,
                });
          }
          onMouseDown() {
            this.setState({ mouseDown: !0 });
          }
          onMouseUp() {
            this.setState({ mouseDown: !1 });
          }
          setPos(e, t) {
            if (!this._rootRef.current) return;
            const r = this._rootRef.current;
            return (
              (r.style.left = "0px"),
              (r.style.top = "0px"),
              window.cancelAnimationFrame(this._timeout),
              (this._timeout = window.requestAnimationFrame(() => {
                const r = this._rootRef.current,
                  s = this._arrowRef.current;
                if (!r || !s) return;
                const n = r.offsetWidth,
                  a = r.offsetHeight,
                  i = Math.min(
                    Math.max(5, Math.max(0, e - n / 2)),
                    window.innerWidth - n - 5
                  );
                (r.style.left = `${i}px`),
                  (r.style.top = `${Math.max(0, t - a + 5)}px`),
                  (r.style.visibility = "visible"),
                  (s.style.left = e - i + "px");
              })),
              this
            );
          }
          show(e) {
            document.body.addEventListener("mouseout", this.onMouseOut, {
              passive: !0,
            });
            const t = this._rootRef.current;
            return (
              t && ((t.style.visibility = "hidden"), (t.style.left = "0px")),
              this.setState({ showTooltip: !0, data: e }),
              this
            );
          }
          hide() {
            return (
              document.body.removeEventListener("mouseout", this.onMouseOut, {
                passive: !0,
              }),
              this.setState({ showTooltip: !1 }),
              this
            );
          }
          render() {
            const e = this.state,
              t = e.data,
              r = e.showTooltip,
              s = e.mouseDown;
            return (0, ht.jsx)(rt.h_, {
              isOpen: r && !s,
              closeTimeout: No,
              children: (0, ht.jsxs)(rt.uT, {
                classNames: _o,
                timeout: No,
                in: r,
                className: "LbBCd",
                ref: this._rootRef,
                children: [
                  (0, ht.jsx)("div", { className: "tcP1D", children: t }),
                  (0, ht.jsx)("div", {
                    className: "xVC5K",
                    ref: this._arrowRef,
                  }),
                ],
              }),
            });
          }
        }
        const Ao = To,
          Io = ({
            onCreate: e,
            onFocusChange: t,
            defaultValue: r,
            parser: s,
            onPaste: n,
            onChange: a,
            parserOptions: i,
            codeMirrorOptions: o,
            TooltipClass: c,
            singleLine: l,
            className: u,
          }) => {
            const h = (0, We.v9)((e) => e.settings.colorizeSyntax),
              p = (0, We.v9)((e) => e.settings.editorTooltips),
              d = (0, ze.useRef)(null),
              g = (0, ze.useRef)(null),
              m = (0, ze.useRef)(null),
              f = (0, ze.useRef)(null),
              x = (0, ze.useState)(-1),
              b = (0, st.Z)(x, 2),
              v = b[0],
              j = b[1],
              y = (0, ze.useState)({ value: r || "" }),
              O = (0, st.Z)(y, 2),
              w = O[0],
              C = O[1],
              E = (0, ze.useState)(!1),
              Z = (0, st.Z)(E, 2),
              S = Z[0],
              k = Z[1],
              P = (0, ze.useCallback)(
                (t) => {
                  (d.current = t),
                    (g.current = new (class {
                      constructor(e, t) {
                        (this._editor = null),
                          (this._parser = null),
                          (this._editor = t),
                          (this._parser = e);
                      }
                      parse(e, t) {
                        const r = this._parser.parse(e, t);
                        for (let e = 0, t = r.length; e < t; e++) {
                          const t = r[e];
                          if (!t.string) continue;
                          const s = t.position,
                            n = s.start,
                            a = s.end,
                            i = this._editor.posFromIndex(n),
                            o = this._editor.posFromIndex(a);
                          t.editorPosition = {
                            start: { line: i.line, pos: i.ch },
                            end: { line: o.line, pos: o.ch },
                          };
                        }
                        return r;
                      }
                      paint() {
                        const e = Ea(this._parser.tokens);
                        this._editor.operation(() => {
                          const t = this._editor.getAllMarks();
                          for (let e = 0, r = t.length; e < r; e++)
                            t[e].clear();
                          for (let t = 0, r = e.length; t < r; t++) {
                            const r = e[t],
                              s = r.style,
                              n = r.editorPosition,
                              a = n.start,
                              i = n.end,
                              o = xo.Pos(a.line, a.pos),
                              c = xo.Pos(i.line, i.pos);
                            this._editor.markText(o, c, { className: s });
                          }
                        });
                      }
                      clearPaint() {
                        this._editor.operation(() => {
                          this._editor.getAllMarks().forEach((e) => e.clear());
                        });
                      }
                      getTokenAtPos(e) {
                        return this._parser.getTokenAtPos(e);
                      }
                      getStatus() {
                        return this._parser.getStatus();
                      }
                    })(s, t)),
                    g.current.parse(t.getValue(), i),
                    h && g.current.paint(t),
                    j(t.indexFromPos(t.getCursor())),
                    null == e || e(t);
                },
                [h, e, s, i]
              ),
              N = (0, ze.useCallback)((e, t) => C({ value: e.getValue() }), []),
              _ = (0, ze.useCallback)(() => t(!0), [t]),
              T = (0, ze.useCallback)(() => {
                j(-1), t(!1);
              }, [t]),
              A = (0, ze.useCallback)(
                (e) => j(e.indexFromPos(e.getCursor())),
                []
              ),
              I = (0, ze.useCallback)(() => k(!0), []),
              R = (0, ze.useCallback)(() => k(!1), []),
              D = (0, ze.useCallback)(
                (e) => {
                  if (p && null != d.current)
                    if (S) {
                      var t;
                      null === (t = m.current) || void 0 === t || t.hide();
                    } else {
                      var r, s;
                      const t = Eo(
                          d.current,
                          e.clientX,
                          e.clientY + window.pageYOffset
                        ),
                        a =
                          null === (r = g.current) || void 0 === r
                            ? void 0
                            : r.getTokenAtPos(t);
                      null === (s = m.current) ||
                        void 0 === s ||
                        s.selectToken(a);
                      const i = Zo(d.current, t);
                      var n;
                      i &&
                        (null === (n = m.current) ||
                          void 0 === n ||
                          n.setPosition(e.clientX, i.top));
                    }
                },
                [p, S]
              );
            return (
              (0, ze.useEffect)(() => {
                const e = [];
                if (v >= 0 && !S) {
                  var t;
                  const r = g.current.getTokenAtPos(v),
                    s = r ? r.getRelatedTokens() : [];
                  null === (t = d.current) ||
                    void 0 === t ||
                    t.operation(() => {
                      s.forEach((t) => {
                        const r = xo.Pos(
                            t.editorPosition.start.line,
                            t.editorPosition.start.pos
                          ),
                          s = xo.Pos(
                            t.editorPosition.end.line,
                            t.editorPosition.end.pos
                          );
                        e.push(
                          d.current.markText(r, s, {
                            className: So.Z.cursorover,
                          })
                        );
                      });
                    });
                }
                return () => {
                  var t;
                  null === (t = d.current) ||
                    void 0 === t ||
                    t.operation(() => {
                      e.forEach((e) => e.clear());
                    });
                };
              }, [v, S]),
              (0, ze.useEffect)(() => {
                const e = new c(f.current, d.current);
                return (
                  (m.current = e),
                  () => {
                    e.destroy(), (m.current = null);
                  }
                );
              }, [c]),
              (0, Qe.vI)(() => {
                const e = g.current.parse(w.value, i);
                h ? g.current.paint() : g.current.clearPaint(),
                  a(w.value, g.current.getStatus(), e, i);
              }, [a, h, i, w]),
              (0, ht.jsxs)("div", {
                className: Xe()("h9z_E", u),
                onMouseMove: D,
                onMouseDownCapture: I,
                onMouseUpCapture: R,
                children: [
                  (0, ht.jsx)(Oo, {
                    onChange: N,
                    onFocus: _,
                    onBlur: T,
                    onPaste: n,
                    onCreate: P,
                    options: o,
                    defaultValue: r,
                    onCursorMove: A,
                    singleLine: l,
                  }),
                  (0, ht.jsx)(Ao, { ref: f }),
                ],
              })
            );
          },
          Ro = ({ token: e }) =>
            (0, ht.jsx)("div", { className: "fnwkx", children: Ma(e) }),
          Do = class {
            constructor(e, t) {
              (this._tooltip = null),
                (this._token = null),
                (this._codemirror = null),
                (this._marks = []),
                (this._tooltip = e),
                (this._codemirror = t),
                (this.onMouseOut = this.onMouseOut.bind(this));
            }
            destroy() {
              this.hide(),
                (this._tooltip = null),
                (this._codemirror = null),
                (this._marks = null),
                (this._token = null);
            }
            onMouseOut(e) {
              var t;
              (null !== (t = this._codemirror) &&
                void 0 !== t &&
                t.display.lineDiv.contains(e.relatedTarget)) ||
                this.hide();
            }
            selectToken(e) {
              var t, r, s;
              if (this._equalTokens(this._token, e)) return;
              if (((this._token = e), this._clearMarks(), !this._token))
                return void this.hide();
              const n =
                null === (t = e.getTooltipMarkerRange) || void 0 === t
                  ? void 0
                  : t.call(e);
              if (n) {
                const e = n.primary,
                  t = n.secondary;
                this._markRange(e.start, e.end),
                  t && t.start && this._markRange(t.start, t.end, !0);
              }
              null === (r = this._tooltip) ||
                void 0 === r ||
                r.show(this._getTooltipContent(e)),
                null === (s = document) ||
                  void 0 === s ||
                  s.body.addEventListener("mouseout", this.onMouseOut, {
                    passive: !0,
                  });
            }
            setPosition() {
              var e;
              null === (e = this._tooltip) ||
                void 0 === e ||
                e.setPos.apply(this._tooltip, arguments);
            }
            hide() {
              var e, t;
              null === (e = document) ||
                void 0 === e ||
                e.body.removeEventListener("mouseout", this.onMouseOut, {
                  passive: !0,
                }),
                this._clearMarks(),
                (this._token = null),
                null === (t = this._tooltip) || void 0 === t || t.hide();
            }
            _getTooltipContent() {
              throw new Error("Tooltip content not found");
            }
            _equalTokens() {
              throw new Error("Token comparison function not implemented");
            }
            _clearMarks() {
              try {
                this._marks.forEach((e) => e.clear()), (this._marks = []);
              } catch (e) {}
            }
            _markRange(e, t, r = !1) {
              const s = xo.Pos(e.line, e.pos),
                n = xo.Pos(t.line, t.pos),
                a = "mouseover" + (r ? "Related" : "");
              this._marks.push(
                this._codemirror.markText(s, n, {
                  className: So.Z[a],
                  startStyle: So.Z[a + "Left"],
                  endStyle: So.Z[a + "Right"],
                })
              );
            }
          },
          Lo = class extends Do {
            selectToken(e) {
              var t;
              null != e &&
              null !== (t = e.getTooltipToken) &&
              void 0 !== t &&
              t.call(e).ignoreOnHover
                ? this.hide()
                : Do.prototype.selectToken.apply(this, arguments);
            }
            _getTooltipContent(e) {
              return (0, ht.jsx)(Ro, { token: this._token.getTooltipToken() });
            }
            _equalTokens(e, t) {
              return (
                !((!e && t) || (e && !t)) &&
                ((null == e && null == t) ||
                  e.getTooltipToken() === t.getTooltipToken())
              );
            }
          },
          Mo = ["availableDelimiters", "delimiter", "onChange"];
        function Uo(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Fo(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Uo(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Uo(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Go = (e) => {
            let t = e.availableDelimiters,
              r = e.delimiter,
              s = e.onChange,
              n = (0, T.Z)(e, Mo);
            return (0, ht.jsxs)(
              Ir,
              Fo(
                Fo({ closeOnClick: !0 }, n),
                {},
                {
                  children: [
                    (0, ht.jsx)(Wr, { text: (0, et.Z)("Delimiters") }),
                    (0, ht.jsx)(Yr, {}),
                    t.map((e) =>
                      (0, ht.jsx)(
                        Br,
                        {
                          isActive: e === r,
                          onClick: () => {
                            e !== r && s(e);
                          },
                          className: "G9G7z",
                          children: e,
                        },
                        `delimiter-${e}`
                      )
                    ),
                  ],
                }
              )
            );
          },
          Vo = (0, ze.memo)(Go),
          Bo = ({
            flavor: e,
            delimiter: t,
            availableDelimiters: r,
            onChange: s,
          }) => {
            const n = (0, ze.useRef)(),
              a = (0, ze.useState)(!1),
              i = (0, st.Z)(a, 2),
              o = i[0],
              c = i[1],
              l = (0, ze.useCallback)(() => c(!0), []),
              u = (0, ze.useCallback)(() => c(!1), []),
              h = r.length < 2;
            return (0, ht.jsx)(rt.lx, {
              direction: gt.qF.NE,
              text: (0, et.Z)("Change delimiter"),
              children: (0, ht.jsxs)(rt.Yd, {
                disabled: h,
                className: Xe()("LEmfz", h && "bwhBe"),
                onClick: l,
                tag: "div",
                children: [
                  (0, ht.jsxs)("div", {
                    className: "RW_5t",
                    ref: n,
                    children: [
                      (0, ht.jsx)(kr.EAB, { className: "eb03W", size: 12 }),
                      e === j().PYTHON && "r",
                      t,
                    ],
                  }),
                  (0, ht.jsx)(Vo, {
                    availableDelimiters: r,
                    delimiter: t,
                    isOpen: o,
                    target: n.current,
                    onMenuClose: u,
                    onChange: s,
                  }),
                ],
              }),
            });
          };
        function qo(e, t, r) {
          switch (e) {
            case "g":
              return (0, ht.jsxs)("div", {
                className: t,
                children: [
                  (0, ht.jsx)("strong", { children: "g" }),
                  "lobal",
                  (0, ht.jsx)("div", {
                    children: (0, et.Z)("Don't return after first match"),
                  }),
                ],
              });
            case "i":
              return (0, ht.jsxs)("div", {
                className: t,
                children: [
                  (0, ht.jsx)("strong", { children: "i" }),
                  "nsensitive",
                  (0, ht.jsx)("div", {
                    children: (0, et.Z)("Case insensitive match"),
                  }),
                ],
              });
            case "m":
              return (0, ht.jsxs)("div", {
                className: t,
                children: [
                  (0, ht.jsx)("strong", { children: "m" }),
                  "ulti line",
                  (0, ht.jsx)("div", {
                    children: (0, et.Z)("^ and $ match start/end of line"),
                  }),
                ],
              });
            case "s":
              return (0, ht.jsxs)("div", {
                className: t,
                children: [
                  (0, ht.jsx)("strong", { children: "s" }),
                  "ingle line",
                  (0, ht.jsx)("div", {
                    children: (0, et.Z)("Dot matches newline"),
                  }),
                ],
              });
            case "S":
              return null;
            case "x":
              return (0, ht.jsxs)("div", {
                className: t,
                children: [
                  "e",
                  (0, ht.jsx)("strong", { children: "x" }),
                  "tended",
                  (0, ht.jsx)("div", {
                    children: (0, et.Z)("Ignore whitespace"),
                  }),
                ],
              });
            case "J":
              return (0, ht.jsxs)("div", {
                className: t,
                children: [
                  (0, ht.jsx)("strong", { children: "J" }),
                  "changed",
                  (0, ht.jsx)("div", {
                    children: (0, et.Z)("Allow duplicate subpattern names"),
                  }),
                ],
              });
            case "u":
              return r === j().JAVA
                ? (0, ht.jsxs)("div", {
                    className: t,
                    children: [
                      (0, ht.jsx)("strong", { children: "u" }),
                      "nicode case",
                      (0, ht.jsx)("div", {
                        children: (0, et.Z)(
                          "Case insensitive matching affects unicode characters as well"
                        ),
                      }),
                    ],
                  })
                : (0, ht.jsxs)("div", {
                    className: t,
                    children: [
                      (0, ht.jsx)("strong", { children: "u" }),
                      "nicode",
                      (0, ht.jsx)("div", {
                        children: (0, et.Z)("Match with full unicode"),
                      }),
                    ],
                  });
            case "U":
              return r === j().JAVA
                ? (0, ht.jsxs)("div", {
                    className: t,
                    children: [
                      (0, ht.jsx)("strong", { children: "U" }),
                      "nicode matching",
                      (0, ht.jsx)("div", {
                        children: (0, et.Z)(
                          "Enables unicode support for predefined classes"
                        ),
                      }),
                    ],
                  })
                : (0, ht.jsxs)("div", {
                    className: t,
                    children: [
                      (0, ht.jsx)("strong", { children: "U" }),
                      "ngreedy",
                      (0, ht.jsx)("div", {
                        children: (0, et.Z)("Make quantifiers lazy"),
                      }),
                    ],
                  });
            case "X":
              return (0, ht.jsxs)("div", {
                className: t,
                children: [
                  "e",
                  (0, ht.jsx)("strong", { children: "X" }),
                  "tra",
                  (0, ht.jsx)("div", {
                    children: (0, et.Z)("Disallow meaningless escapes"),
                  }),
                ],
              });
            case "A":
              return (0, ht.jsxs)("div", {
                className: t,
                children: [
                  (0, ht.jsx)("strong", { children: "A" }),
                  "nchored",
                  (0, ht.jsx)("div", {
                    children: (0, et.Z)(
                      "Anchor to start of pattern, or at the end of the most recent match"
                    ),
                  }),
                ],
              });
            case "D":
              return (0, ht.jsxs)("div", {
                className: t,
                children: [
                  (0, ht.jsx)("strong", { children: "D" }),
                  "ollar end only",
                  (0, ht.jsx)("div", {
                    children: (0, et.Z)("$ matches only end of pattern"),
                  }),
                ],
              });
            case "a":
              return (0, ht.jsxs)("div", {
                className: t,
                children: [
                  (0, ht.jsx)("strong", { children: "a" }),
                  "scii",
                  (0, ht.jsx)("div", {
                    children: (0, et.Z)(
                      "Make escape sequences perform ASCII-only matching"
                    ),
                  }),
                ],
              });
            case "y":
              return (0, ht.jsxs)("div", {
                className: t,
                children: [
                  "stick",
                  (0, ht.jsx)("strong", { children: "y" }),
                  (0, ht.jsx)("div", {
                    children: (0, et.Z)(
                      "Anchor to start of pattern, or at the end of the most recent match"
                    ),
                  }),
                ],
              });
            case "d":
              return (0, ht.jsxs)("div", {
                className: t,
                children: [
                  "in",
                  (0, ht.jsx)("strong", { children: "d" }),
                  "ices",
                  (0, ht.jsx)("div", {
                    children: (0, et.Z)(
                      "The regex engine returns match indices"
                    ),
                  }),
                ],
              });
            case "n":
              return (0, ht.jsxs)("div", {
                className: t,
                children: [
                  (0, ht.jsx)("strong", { children: "n" }),
                  "on-capturing",
                  (0, ht.jsx)("div", {
                    children: (0, et.Z)(
                      "Groups are no longer implicitly capturing"
                    ),
                  }),
                ],
              });
            case "R":
              return (0, ht.jsxs)("div", {
                className: t,
                children: [
                  (0, ht.jsx)("strong", { children: "R" }),
                  "ight to left",
                  (0, ht.jsx)("div", {
                    children: (0, et.Z)("Perform matching from right to left"),
                  }),
                ],
              });
            default:
              return $e.O7(new Error(`Unknown flag '${e}'`)), null;
          }
        }
        const Ho = ["isOpen", "flavor", "flags", "onChange"];
        function $o(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function zo(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? $o(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : $o(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Wo = (e) => {
            let t = e.isOpen,
              r = e.flavor,
              s = e.flags,
              n = e.onChange,
              a = (0, T.Z)(e, Ho);
            const i = (0, ze.useCallback)(
                (e, t, r) => {
                  let a = s;
                  r ? (a += t) : (a = a.replace(t, "")), n(a);
                },
                [s, n]
              ),
              o = (0, ze.useCallback)(
                (e) => {
                  if (!e.ctrlKey && !e.altKey && !e.metaKey) {
                    const t = e.which || e.keyCode || e.charCode,
                      r = e.char || e.key || String.fromCharCode(t);
                    1 === r.length &&
                      (e.preventDefault(), i(e, r, -1 === s.indexOf(r)));
                  }
                },
                [i, s]
              );
            (0, ze.useEffect)(
              () => (
                t && window.addEventListener("keypress", o),
                () => window.removeEventListener("keypress", o)
              ),
              [t, o]
            );
            const c = Ae()[r].split("");
            return (0, ht.jsxs)(
              Ir,
              zo(
                zo({ isOpen: t }, a),
                {},
                {
                  children: [
                    (0, ht.jsx)(Wr, { text: (0, et.Z)("Regex Flags") }),
                    (0, ht.jsx)(Yr, {}),
                    c.map((e) => {
                      const t = -1 !== s.indexOf(e);
                      return (0, ht.jsx)(
                        Br,
                        {
                          isActive: t,
                          onClick: (r) => i(r, e, !t),
                          className: "ZsQZ7",
                          children: qo(e, "COW0E", r),
                        },
                        `flag-${e}`
                      );
                    }),
                  ],
                }
              )
            );
          },
          Yo = ({ flags: e, delimiter: t, flavor: r, onChange: s }) => {
            const n = (0, ze.useRef)(null),
              a = (0, ze.useState)(!1),
              i = (0, st.Z)(a, 2),
              o = i[0],
              c = i[1];
            return (0, ht.jsx)(rt.lx, {
              direction: gt.qF.NW,
              text: (0, et.Z)("Set Regex Options"),
              children: (0, ht.jsxs)(rt.Yd, {
                tag: "div",
                className: "AhIEh",
                onClick: () => c(!0),
                children: [
                  (0, ht.jsxs)("div", {
                    className: "lqj6M",
                    ref: n,
                    children: [
                      (0, ht.jsx)("div", { className: "n9qI6", children: t }),
                      (0, ht.jsx)("div", { className: "bcp8d", children: e }),
                    ],
                  }),
                  (0, ht.jsx)(Wo, {
                    flags: e,
                    flavor: r,
                    isOpen: o,
                    target: n.current,
                    onMenuClose: () => c(!1),
                    onChange: s,
                  }),
                ],
              }),
            });
          },
          Ko = (0, ze.memo)(Yo),
          Jo = ({
            onRegexPaste: e,
            onRegexChange: t,
            onDelimiterChange: r,
            onFlagsChange: s,
            flags: n,
            flavor: a,
            delimiter: i,
            regex: o,
            onEnterClick: l,
            regexParser: u,
          }) => {
            const h = (0, We.v9)((e) => e.settings.autoComplete),
              p = (0, We.v9)((e) => e.settings.wrapLines),
              d = (0, We.v9)((e) => e.settings.regexAreaLineNumbers),
              g = (0, We.v9)((e) => e.settings.displayWhitespace),
              m = (0, We.v9)((e) => e.settings.defaultTabBehavior),
              f = (0, ze.useState)(!1),
              x = (0, st.Z)(f, 2),
              b = x[0],
              v = x[1],
              j = (0, ze.useRef)(null),
              y = (0, ze.useMemo)(
                () => ({ flavor: a, flags: n, delimiter: i }),
                [a, n, i]
              ),
              w = (0, ze.useMemo)(
                () => ({
                  lineNumbers: d,
                  mode: null,
                  autofocus: !0,
                  placeholder: (0, et.Z)("insert your regular expression here"),
                  tabSize: 4,
                  lineWrapping: p,
                  extraKeys: {
                    "Shift-Tab": !1,
                    Tab: !m && null,
                    Enter: l || !1,
                  },
                  autoCloseBrackets: h,
                  showWhitespace: g,
                }),
                [g, h, l, p, d, m]
              ),
              C = (0, ze.useCallback)((e) => v(e), []),
              E = (0, ze.useCallback)(
                (t, r) => {
                  if (t.getValue() !== t.getSelection()) return;
                  let s = "";
                  window.clipboardData && window.clipboardData.getData
                    ? (s = window.clipboardData.getData("Text"))
                    : r.clipboardData && r.clipboardData.getData
                    ? (s = r.clipboardData.getData("text/plain"))
                    : c.Z.warn("User pasted data but could not retrieve it");
                  const n = O()[a],
                    i = new RegExp(
                      `^\\s*([sm]?)(${n.join(
                        "|"
                      )})([\\s\\S]+)\\2([a-zA-Z]*)\\s*$`
                    ),
                    o = s.match(i);
                  if (null != o) {
                    const s = o[1],
                      n = o[2];
                    let a = o[3],
                      i = "";
                    const c = o[4];
                    if ("s" === s) {
                      const e = ((e, t) => {
                        let r = 0,
                          s = -1,
                          n = !1;
                        for (let a = e.length - 1; 0 <= a; a--) {
                          const i = e.charAt(a);
                          if (n)
                            if ("\\" === i) r++;
                            else {
                              if (r % 2 == 0) return s;
                              (r = 0), (s = -1), (n = !1);
                            }
                          else i === t && ((s = a), (n = !0));
                        }
                        return s;
                      })(a, n);
                      if (-1 === e) return;
                      const t = a;
                      (a = t.slice(0, e)), (i = t.slice(e + 1));
                    }
                    r.preventDefault(), r.stopPropagation(), t.setValue(a);
                    const l = {
                      delimiter: n,
                      flags: c,
                      regex: a,
                      isSub: "s" === s,
                      substText: i,
                    };
                    null == e || e(l);
                  }
                },
                [e, a]
              ),
              Z = (0, ze.useCallback)((e) => (j.current = e), []);
            return (
              (0, ze.useEffect)(() => {
                const e = (e, t) => {
                  const r = t.groupNum;
                  if (null == j.current) return;
                  const s = u.captureGroups[r - 1],
                    n = j.current.posFromIndex(
                      null == s ? 0 : s.position.start
                    );
                  j.current.setCursor(n);
                };
                return tt.ZP.on(tt.ji, e), () => tt.ZP.off(tt.ji, e);
              }, [u]),
              (0, ze.useEffect)(() => {
                const e = (e, t) => j.current.setValue(t);
                return tt.ZP.on(tt.fZ, e), () => tt.ZP.off(tt.fZ, e);
              }, [j]),
              (0, ht.jsxs)("div", {
                className: Xe()("cO83v", b && "KkBJC"),
                children: [
                  (0, ht.jsx)(Bo, {
                    availableDelimiters: O()[a],
                    delimiter: i,
                    flavor: a,
                    onChange: r,
                  }),
                  (0, ht.jsx)(Io, {
                    defaultValue: o,
                    parser: u,
                    onFocusChange: C,
                    onPaste: E,
                    onChange: t,
                    onEnterClick: l,
                    parserOptions: y,
                    codeMirrorOptions: w,
                    TooltipClass: Lo,
                    className: "T886D",
                    onCreate: Z,
                  }),
                  (0, ht.jsx)(Ko, {
                    flags: n,
                    delimiter: i,
                    flavor: a,
                    onChange: s,
                  }),
                  (0, ht.jsx)(rt.qi, {
                    basic: !0,
                    className: Xe()("OkWyQ", "" === o && "Si8g5"),
                    disabled: "" === o,
                    copyText: i + o + i + n,
                  }),
                ],
              })
            );
          };
        var Xo = r(44466);
        const Qo = "odN4_",
          ec = "J9uy0",
          tc = "zM5RE",
          rc = "Z8VZM",
          sc = "JFyYg",
          nc = "I7e3C";
        function ac(e) {
          return e > 999 ? +(e / 1e3).toFixed(1) + "s" : e.toFixed(1) + "ms";
        }
        const ic = ({
            error: e,
            matchNum: t,
            isMatching: r,
            time: s,
            steps: n,
            flavor: a,
            hasRegex: i,
          }) => {
            let o,
              c = !1,
              l = !1,
              u = "",
              h = "";
            if (r) (o = tc), (u = (0, et.Z)("Processing..."));
            else if (e)
              switch (((o = sc), e)) {
                case $t.D9:
                  u = (0, et.Z)("Pattern Error");
                  break;
                case $t.ik:
                  (u = (0, et.Z)("Timeout")), (c = !0);
                  break;
                case $t.wm:
                case $t.VE:
                  (u = (0, et.Z)("Catastrophic Backtracking")), (c = !0);
                  break;
                default:
                  (u = (0, et.Z)("Engine Error")), (l = !0);
              }
            else
              t
                ? ((o = rc),
                  (u =
                    t > 1
                      ? (0, et.Z)("{1} matches", (0, Xo.u)(t))
                      : (0, et.Z)("{1} match", t)))
                : ((o = tc), (u = (0, et.Z)("No Match")), (c = !0)),
                i &&
                  (null != n &&
                    (h +=
                      1 !== n
                        ? (0, et.Z)("{1} steps", (0, Xo.u)(n))
                        : (0, et.Z)("{1} step", n)),
                  null != s && (null != n && (h += ", "), (h += ac(s))));
            return c && i && (0, Ts.G)(a)
              ? (0, ht.jsx)(rt.Yi, {
                  className: Xe()(Qo, "iRqgt"),
                  children: (0, ht.jsxs)("div", {
                    className: Xe()(ec, o),
                    children: [
                      u,
                      h &&
                        (0, ht.jsxs)("span", {
                          className: nc,
                          children: [" (", h, ")"],
                        }),
                      (0, ht.jsx)(nt.RwU, { className: "Jfsx5" }),
                    ],
                  }),
                })
              : (0, ht.jsx)(rt.lx, {
                  disableTooltip: !l,
                  direction: gt.qF.N,
                  text:
                    null != e
                      ? (0, et.Z)("Error reported by engine: {1}", e)
                      : "",
                  children: (0, ht.jsx)("div", {
                    className: Qo,
                    children: (0, ht.jsxs)("div", {
                      className: Xe()(ec, o),
                      children: [
                        u,
                        h &&
                          (0, ht.jsxs)("span", {
                            className: nc,
                            children: [" (", h, ")"],
                          }),
                      ],
                    }),
                  }),
                });
          },
          oc = (0, ze.memo)(ic),
          cc = "NRMSt",
          lc = "XKeHF",
          uc = ({
            permalinkFragment: e,
            version: t,
            isOpen: r,
            target: s,
            onMenuClose: n,
          }) => {
            const a = (0, We.v9)((e) => e.regexEditor.regexVersions),
              i = (0, Qe.$5)("getRegexVersions"),
              o = (0, st.Z)(i, 3),
              c = o[0],
              l = o[1],
              u = o[2];
            (0, Qe.DB)(() => {
              r && e && u((0, je.zp)(e));
            }, [r, e]);
            let h = "";
            return (
              (h = l
                ? (0, ht.jsx)("div", {
                    className: cc,
                    role: "alert",
                    children: (0, ht.jsx)(rt.qX, {
                      type: gt.gr.pn,
                      className: lc,
                      children: (0, et.Z)("Unable to fetch versions"),
                    }),
                  })
                : c
                ? (0, ht.jsxs)("div", {
                    className: cc,
                    children: [
                      (0, ht.jsx)("div", {
                        className: lc,
                        children: (0, et.Z)("Loading..."),
                      }),
                      (0, ht.jsx)(rt.$j, {
                        size: gt.J7.TC,
                        className: "JVYN7",
                      }),
                    ],
                  })
                : new Array(a).fill(0).map((r, s) => {
                    const n = s + 1 === t;
                    return (0, ht.jsx)(
                      es,
                      {
                        isActive: n,
                        disabled: n,
                        to: rr(e, s + 1),
                        absolute: !0,
                        children: (0, et.Z)("Version {1}", s + 1),
                      },
                      `version-${s}`
                    );
                  })),
              (0, ht.jsxs)(Ir, {
                target: s,
                isOpen: r,
                onMenuClose: n,
                closeOnClick: !0,
                children: [
                  (0, ht.jsx)(Wr, {
                    text: (0, et.Z)("Regex Versions"),
                    tabIndex: 0,
                  }),
                  (0, ht.jsx)(Yr, {}),
                  h,
                ],
              })
            );
          },
          hc = ({ children: e }) => {
            const t = (0, We.v9)((e) => e.general.version),
              r = (0, We.v9)((e) => e.general.permalinkFragment),
              s = (0, We.v9)((e) => e.general.title),
              n = (0, ze.useState)(!1),
              a = (0, st.Z)(n, 2),
              i = a[0],
              o = a[1],
              c = (0, ze.useRef)(null),
              l = (0, ze.useCallback)(() => o(!0), []),
              u = (0, ze.useCallback)(() => o(!1), []);
            return (
              (0, Qe.kF)(s),
              (0, ht.jsx)("div", {
                className: "YZA2N",
                children: (0, ht.jsx)(rt.__, {
                  text: (0, et.Z)("Regular Expression"),
                  children: (0, ht.jsxs)("div", {
                    className: "XjlwO",
                    children: [
                      null != r &&
                        (0, ht.jsx)(rt.lx, {
                          text: (0, et.Z)("Select Regex Version"),
                          direction: gt.qF.NW,
                          children: (0, ht.jsxs)(rt.CP, {
                            onClick: l,
                            ref: c,
                            children: ["v", t],
                          }),
                        }),
                      (0, ht.jsx)(uc, {
                        isOpen: i,
                        onMenuClose: u,
                        permalinkFragment: r,
                        version: t,
                        target: c.current,
                      }),
                      e,
                    ],
                  }),
                }),
              })
            );
          },
          pc = (e) => [Math.min(e.start, e.end), Math.max(e.start, e.end)],
          dc = ({
            matchNum: e,
            group: t,
            start: r,
            end: s,
            content: n,
            captureNum: a,
          }) => {
            const i = n.length > 100 ? n.slice(0, 100) + "\u2026" : n,
              o = null != a && a > -1 ? `.${a + 1}` : "";
            return (0, ht.jsxs)("div", {
              className: "Th_7x",
              children: [
                (0, ht.jsx)(rt.vV, {
                  tag: "div",
                  className: "rameg",
                  text: "Match {1}",
                  ph1: (0, ht.jsx)("span", { children: e + 1 }),
                }),
                (0, ht.jsxs)("div", {
                  className: "p5UZM",
                  children: [
                    (0, ht.jsx)(rt.vV, {
                      text: "Group {1}",
                      ph1: t + o,
                      className: "_sUW4",
                    }),
                    ":",
                    " ",
                    (0, ht.jsx)("span", {
                      children:
                        "" === n
                          ? (0, ht.jsx)("em", { children: "null" })
                          : (0, ht.jsx)(rt.K, { text: i, removeNewlines: !0 }),
                    }),
                  ],
                }),
                null != r &&
                  (0, ht.jsxs)("div", {
                    children: [
                      (0, ht.jsx)("strong", { children: "Pos:" }),
                      " ",
                      r,
                      "-",
                      s,
                    ],
                  }),
              ],
            });
          },
          gc = (0, ze.memo)(dc),
          mc = class extends Do {
            _getTooltipContent(e) {
              return (0, ht.jsx)(gc, {
                matchNum: e.match,
                group:
                  e.groupName || ri.Z.captureGroupMap[e.groupNum] || e.groupNum,
                captureNum: e.captureNum,
                start: e.start,
                end: e.end,
                content: e.content,
              });
            }
            _equalTokens(e, t) {
              return e === t;
            }
          };
        var fc = r(99237),
          xc = r(42623);
        const bc = parseFloat(ct.zj),
          vc = (e, t, r, s, n = 0, a = 0) => ({
            left: ((e + 0.5) | 0) + bc,
            right: ((r + 0.5) | 0) + bc,
            top: 1 + ((t + 0.5) | 0),
            bottom: ((s + 0.5) | 0) - 1,
            scrollX: 0 | n,
            scrollY: (0 | a) - bc,
          }),
          jc = (e, t, r, s, n, a, i) => {
            const o = vc(t, r, s, n, i, a),
              c = o.left,
              l = o.right,
              u = o.top,
              h = o.bottom,
              p = o.scrollX,
              d = o.scrollY;
            e.beginPath(),
              (e.lineWidth = 2),
              e.setLineDash([]),
              e.moveTo(c - p - 1, h - d + 1),
              e.lineTo(l - p + 1, h - d + 1),
              e.moveTo(c - p - 1, u - d - 1),
              e.lineTo(l - p + 1, u - d - 1),
              e.moveTo(c - p - 1, u - d - 1),
              e.lineTo(c - p - 1, h - d + 1),
              e.moveTo(l - p + 1, u - d - 1),
              e.lineTo(l - p + 1, h - d + 1),
              e.closePath(),
              e.stroke();
          },
          yc = (e, t, r, s, n, a, i, o, c) => {
            if (s < 0 || t + 1 > s) return;
            const l = vc(t, r, s, n, i, a),
              u = l.left,
              h = l.right,
              p = l.top,
              d = l.bottom,
              g = l.scrollX,
              m = l.scrollY,
              f = bc,
              x = e.fillStyle;
            o &&
              ((e.fillStyle = (0, xc.C)(x, (0, fc.R)("--content-bg"), 40)),
              e.fillRect(u - f - g, p - m, f, d - p)),
              c &&
                ((e.fillStyle = (0, xc.C)(x, (0, fc.R)("--content-bg"), 40)),
                e.fillRect(h - g, p - m, f, d - p)),
              (e.fillStyle = x),
              e.fillRect(u - g, p - m, h - u, d - p);
          },
          Oc = (e, t, r) => {
            const s = vc(r.left, r.top, 0, r.bottom),
              n = s.left,
              a = s.top,
              i = s.bottom;
            (e.strokeStyle = (0, fc.R)("--match-zero-width")),
              e.setLineDash([1, 2]),
              e.beginPath(),
              e.moveTo((n - t.left) | 0, (a - t.top + bc) | 0),
              e.lineTo((n - t.left) | 0, (i - t.top + bc) | 0),
              e.closePath(),
              e.stroke();
          },
          wc = (e, t, r, s, n, a, i) => {
            const o = Cc(t, s),
              c = (0, st.Z)(o, 2),
              l = c[0],
              u = c[1];
            if (
              ((e.fillStyle = a),
              (e.strokeStyle = (0, xc.C)(
                a,
                (0, fc.R)("--match-mix-hex-color"),
                (0, fc.R)("--match-mix-amount")
              )),
              l.bottom === u.bottom)
            )
              l.left === u.right || s.start === s.end
                ? i(e, l.left, l.top, l.left + 2, u.bottom, n.top, n.left)
                : i(e, l.left, l.top, u.right, u.bottom, n.top, n.left);
            else {
              const s = n.width - r,
                a = t.defaultTextHeight();
              i(e, l.left, l.top, s, l.bottom, n.top, n.left, !1, !0);
              let o = l.top;
              for (; (o += a) < u.top - 1; )
                i(e, 0, o, s, o + l.bottom - l.top, n.top, n.left, !0, !0);
              i(
                e,
                0,
                u.top,
                Math.max(u.right, 2),
                u.bottom,
                n.top,
                n.left,
                !0,
                !1
              );
            }
          },
          Cc = (e, t) => {
            const r = pc(t),
              s = (0, st.Z)(r, 2),
              n = s[0],
              a = s[1],
              i = t.startPos || (t.startPos = e.posFromIndex(n)),
              o = t.endPos || (t.endPos = e.posFromIndex(a > n ? a - 1 : a));
            let c = e.charCoords(i, "local"),
              l = e.charCoords(o, "local");
            if (
              (c.left > l.left && c.top >= l.top) ||
              (c.left >= l.left && c.top > l.top)
            ) {
              const e = c;
              (c = l), (l = e);
            }
            return [c, l];
          },
          Ec = (function () {
            try {
              const e = document.createElement("canvas");
              if (
                !e ||
                !e.getContext("2d") ||
                !("setLineDash" in e.getContext("2d"))
              )
                return !1;
            } catch (e) {
              return !1;
            }
            return !0;
          })()
            ? ({ cmInstance: e, matchMap: t, waiting: r }) => {
                const s = (0, We.v9)((e) => e.settings.editorTooltips),
                  n = (0, We.v9)((e) => e.settings.wrapLines),
                  a = (0, We.v9)((e) => e.settings.testAreaLineNumbers),
                  i = (0, We.v9)((e) => e.general.currentTheme),
                  o = (0, ze.useRef)(null),
                  c = (0, ze.useRef)(null),
                  l = (0, ze.useRef)(null),
                  u = (0, ze.useRef)(0),
                  h = (0, ze.useState)(!0),
                  p = (0, st.Z)(h, 2),
                  d = p[0],
                  g = p[1],
                  m = (0, ze.useState)(!1),
                  f = (0, st.Z)(m, 2),
                  x = f[0],
                  b = f[1],
                  v = (0, ze.useCallback)(() => {
                    e.refresh();
                    const t = o.current,
                      r = null == t ? void 0 : t.parentNode;
                    if (null != r) {
                      const e = r.getBoundingClientRect(),
                        s = e.bottom - e.top,
                        n = e.right - e.left - 2;
                      t.style.left = `${u.current}px`;
                      const a = (n - u.current) | 0,
                        i = 0 | s;
                      (t.width === a && t.height === i) ||
                        ((t.width = a), (t.height = i));
                    }
                  }, [e]),
                  j = (0, ze.useRef)(null),
                  y = (0, ze.useCallback)(
                    (r = null, s = !0) => {
                      clearTimeout(j.current),
                        (j.current = setTimeout(() => {
                          const n = e.getScrollInfo(),
                            a = ((e, t) => {
                              const r = e.indexFromPos(
                                  e.coordsChar({ left: 0, top: t.top }, "local")
                                ),
                                s = e.indexFromPos(
                                  e.coordsChar(
                                    { right: 0, top: t.top },
                                    "local"
                                  )
                                ),
                                n = e.indexFromPos(
                                  e.coordsChar(
                                    {
                                      left: t.clientWidth,
                                      top: t.top + t.clientHeight,
                                    },
                                    "local"
                                  )
                                ),
                                a = e.indexFromPos(
                                  e.coordsChar(
                                    {
                                      right: t.clientWidth,
                                      top: t.top + t.clientHeight,
                                    },
                                    "local"
                                  )
                                );
                              return [Math.min(r, s), Math.max(n, a)];
                            })(e, n),
                            i = (0, st.Z)(a, 2),
                            o = {
                              visibleArea: n,
                              firstVisibleIndex: i[0],
                              lastVisibleIndex: i[1],
                            };
                          ((e, t, r, s, n, a, i) => {
                            if (!e || !e.canvas) return;
                            const o = t.visibleArea,
                              c = t.firstVisibleIndex,
                              l = t.lastVisibleIndex;
                            if (!o) return;
                            e.clearRect(0, 0, e.canvas.width, e.canvas.height);
                            const u = {},
                              h = [];
                            for (let t = l; c <= t; t--) {
                              const a = n[t];
                              if (null != a)
                                for (let t = 0; t < a.length; t++) {
                                  const n = a[t];
                                  if (null == n || !n.isParticipating) continue;
                                  const i = n.match,
                                    c = n.groupNum,
                                    l = n.captureNum,
                                    p = `${i}_${c}_${void 0 === l ? 0 : l}`;
                                  if (null != u[p]) continue;
                                  if (
                                    ((u[p] = !0),
                                    null != n.start && n.start === n.end)
                                  ) {
                                    h.push(n);
                                    continue;
                                  }
                                  const d = (0, fc.n)(
                                    n.groupNum,
                                    n.match % 2 != 0
                                  );
                                  wc(e, r, s, n, o, d, yc);
                                }
                            }
                            for (let t = 0, s = h.length; t < s; t++) {
                              const s = h[t],
                                n = Cc(r, s),
                                a = (0, st.Z)(n, 1)[0];
                              Oc(e, o, a);
                            }
                            if (
                              (e.clearRect(0, 0, e.canvas.width, bc),
                              e.clearRect(
                                0,
                                e.canvas.height - bc,
                                e.canvas.width,
                                e.canvas.height
                              ),
                              null != a)
                            ) {
                              const t = (0, fc.n)(
                                a.groupNum,
                                a.match % 2 != 0,
                                i
                              );
                              wc(e, r, s, a, o, t, yc),
                                wc(e, r, s, a, o, t, jc);
                            }
                          })(c.current, o, e, u.current, t, r, s);
                        }, 1));
                    },
                    [e, t]
                  );
                return (
                  (0, ze.useEffect)(
                    () => (
                      (c.current = o.current.getContext("2d", {
                        alpha: !0,
                        antialias: !1,
                      })),
                      ((e) => {
                        [
                          "imageSmoothingEnabled",
                          "mozImageSmoothingEnabled",
                          "webkitImageSmoothingEnabled",
                          "msImageSmoothingEnabled",
                        ].some((t) => null != e[t] && ((e[t] = !1), !0));
                      })(c),
                      () => clearTimeout(j.current)
                    ),
                    []
                  ),
                  (0, ze.useEffect)(() => {
                    y();
                  }, [y, n, a, i]),
                  (0, ze.useEffect)(() => {
                    let t = !1;
                    const r = () => {
                      t || y(), (t = !1);
                    };
                    e.on("scroll", r);
                    const s = () => (t = !0);
                    e.on("beforeChange", s);
                    const n = (r, s) => {
                      const n = pc(s),
                        a = (0, st.Z)(n, 1)[0],
                        i = e.posFromIndex(a);
                      (t = !0), e.setCursor(i), y(s);
                    };
                    return (
                      tt.ZP.on(tt.ji, n),
                      () => {
                        e.off("scroll", r),
                          e.off("beforeChange", s),
                          tt.ZP.off(tt.ji, n);
                      }
                    );
                  }, [e, y]),
                  (0, ze.useEffect)(() => {
                    v();
                    const e = () => g(!0),
                      t = () => b(!0);
                    let r = null;
                    const s = () => {
                      clearTimeout(r), g(!0), (r = setTimeout(t, 500));
                    };
                    return (
                      tt.ZP.on({ [tt.AZ]: e, [tt.U0]: t, [tt.$7]: s }),
                      window.addEventListener("resize", s, { passive: !0 }),
                      () => {
                        clearTimeout(r),
                          tt.ZP.off({ [tt.AZ]: e, [tt.U0]: t, [tt.$7]: s }),
                          window.removeEventListener("resize", s, {
                            passive: !0,
                          });
                      }
                    );
                  }, []),
                  (0, ze.useEffect)(() => {
                    var r, n, a;
                    const i = { passive: !0, capture: !0 },
                      c = new mc(l.current, e);
                    let u = null,
                      h = !1;
                    const p = () => {
                        (h = !0), f();
                      },
                      d = () => (h = !1);
                    null === (r = document.body) ||
                      void 0 === r ||
                      r.addEventListener("mousedown", p, i),
                      null === (n = document.body) ||
                        void 0 === n ||
                        n.addEventListener("mouseup", d, i);
                    const g = () => c.hide();
                    e.on("scroll", g);
                    const m = (r) => {
                        if (!s || h) return;
                        const n = Eo(
                            e,
                            r.clientX,
                            r.clientY + window.pageYOffset
                          ),
                          a = (function (e) {
                            if (!e || 0 === e.length) return null;
                            for (let t = e.length - 1; 0 <= t; t--) {
                              const r = e[t];
                              if (r.start !== r.end) return r;
                            }
                            return e[0];
                          })(t[n]);
                        if (null == a && null == u) return;
                        c.selectToken(a), y(a, !1);
                        const i = Zo(e, n);
                        i && c.setPosition(r.clientX, i.top), (u = a);
                      },
                      f = () => {
                        s && y();
                      },
                      x =
                        null === (a = o.current) || void 0 === a
                          ? void 0
                          : a.parentNode;
                    return (
                      null == x || x.addEventListener("mousemove", m, i),
                      null == x || x.addEventListener("mouseleave", f, i),
                      () => {
                        var t, r;
                        e.off("scroll", g),
                          null === (t = document.body) ||
                            void 0 === t ||
                            t.removeEventListener("mousedown", p, i),
                          null === (r = document.body) ||
                            void 0 === r ||
                            r.removeEventListener("mouseup", d, i),
                          null == x || x.removeEventListener("mousemove", m, i),
                          null == x ||
                            x.removeEventListener("mouseleave", f, i),
                          c.destroy();
                      }
                    );
                  }, [s, e, y, t]),
                  (0, ze.useEffect)(() => {
                    x && (v(), y(), b(!1), g(!1));
                  }, [x, v, y]),
                  (0, ze.useEffect)(() => {
                    const e = setTimeout(() => g(r), 100);
                    return () => clearTimeout(e);
                  }, [r]),
                  (0, ze.useEffect)(() => {
                    if (a) {
                      var t, r;
                      const s =
                        (null == e ||
                        null === (t = e.display) ||
                        void 0 === t ||
                        null === (r = t.gutters) ||
                        void 0 === r
                          ? void 0
                          : r.offsetWidth) || 0;
                      s !== u.current && ((u.current = s), v());
                    }
                  }),
                  (0, ht.jsxs)(ht.Fragment, {
                    children: [
                      (0, ht.jsx)("canvas", {
                        ref: o,
                        className: Xe()("MF2Zl", d && "PepZ_"),
                      }),
                      (0, ht.jsx)(Ao, { ref: l }),
                    ],
                  })
                );
              }
            : () => null,
          Zc = ({ matchMap: e, onInput: t, waiting: r }) => {
            const s = (0, We.v9)((e) => e.regexEditor.showSubstitutionArea),
              n = (0, We.v9)((e) => e.regexEditor.showListSubstitutionArea),
              a = (0, We.v9)((e) => e.regexEditor.testString),
              i = (0, We.v9)((e) => e.settings.wrapLines),
              o = (0, We.v9)((e) => e.settings.testAreaLineNumbers),
              c = (0, We.v9)((e) => e.settings.displayWhitespace),
              l = (0, We.v9)((e) => e.settings.defaultTabBehavior),
              u = (0, ze.useState)(!1),
              h = (0, st.Z)(u, 2),
              p = h[0],
              d = h[1],
              g = (0, ze.useState)(null),
              m = (0, st.Z)(g, 2),
              f = m[0],
              x = m[1],
              b = (0, ze.useCallback)(() => d(!0), []),
              v = (0, ze.useCallback)(() => d(!1), []),
              j = (0, ze.useMemo)(
                () => ({
                  lineNumbers: o,
                  mode: null,
                  autofocus: !1,
                  placeholder: (0, et.Z)("insert your test string here"),
                  tabSize: 4,
                  lineWrapping: i,
                  extraKeys: { "Shift-Tab": !1, Tab: !l && null, Enter: !1 },
                  showWhitespace: c,
                }),
                [o, i, c, l]
              ),
              y = (0, ze.useCallback)((e) => x(e), []);
            return (
              (0, ze.useEffect)(() => {
                const e = () => (null == f ? void 0 : f.refresh());
                tt.ZP.on(tt.U0, e);
                const t = (e, t, r) => f.setValue(r);
                return (
                  tt.ZP.on(tt.fZ, t),
                  () => {
                    tt.ZP.off(tt.U0, e), tt.ZP.off(tt.fZ, t);
                  }
                );
              }, [f]),
              (0, ht.jsxs)("div", {
                className: Xe()("of6uh", (s || n) && "qFwsQ"),
                children: [
                  (0, ht.jsx)(rt.__, { text: (0, et.Z)("Test String") }),
                  (0, ht.jsxs)("div", {
                    className: Xe()("s6TnK", p && "AH8pc"),
                    children: [
                      (0, ht.jsx)(Oo, {
                        onCreate: y,
                        className: "Pk2Mn",
                        onChange: t,
                        onFocus: b,
                        onBlur: v,
                        options: j,
                        defaultValue: a,
                      }),
                      null != f &&
                        (0, ht.jsx)(Ec, {
                          cmInstance: f,
                          matchMap: e,
                          waiting: r,
                        }),
                    ],
                  }),
                ],
              })
            );
          };
        function Sc() {
          return new Worker(r.p + "pcre2.worker.9bb82d09abd4f3e4f1fb.js");
        }
        function kc() {
          return new Worker(r.p + "generic.worker.6ff6ed247561ed0d883e.js");
        }
        function Pc() {
          return new Worker(r.p + "javascript.worker.f07b1b737f879a70fbe1.js");
        }
        function Nc() {
          return new Worker(r.p + "java.worker.b169e98bd292e43bd088.js");
        }
        function _c() {
          return new Worker(r.p + "dotnet.worker.72456c5074881d0b53c7.js");
        }
        var Tc = r(54292);
        const Ac = ["listMode"];
        function Ic(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Rc(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Ic(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Ic(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        class Dc extends Tc.Z {
          getWorker(e) {
            switch (e) {
              case j().PCRE2:
                return Sc;
              case j().JAVASCRIPT:
                return Pc;
              case j().PYTHON:
              case j().PCRE:
              case j().GOLANG:
                return kc;
              case j().JAVA:
                return Nc;
              case j().DOTNET:
                return _c;
              default:
                throw new Error(`No worker file exists for flavor '${e}'`);
            }
          }
          runSubst(e, t, r, s, n, a, i) {
            const o = a.listMode,
              c = (0, T.Z)(a, Ac),
              l = {
                regex: e,
                flags: t,
                testString: r,
                substString: s,
                listMode: o,
              };
            return [j().PCRE, j().PYTHON, j().GOLANG].includes(a.flavor)
              ? super.runWorker(Rc(Rc({}, l), n), c, i)
              : super.runWorker(l, c, i);
          }
        }
        const Lc = Dc;
        var Mc = r(64023),
          Uc = r(75659),
          Fc = r(4427),
          Gc = r(86700),
          Vc = r(78338),
          Bc = r(13511),
          qc = r(43307);
        class Hc extends qc.Z {
          constructor(e) {
            super(e, da.aM), this.setStyle(So.Z.meta);
          }
          _getNextState(e) {
            return (
              "\\U" === this.string
                ? ((e.uppercase = !0), (e.lowercase = !1))
                : ((e.uppercase = !1), (e.lowercase = !0)),
              e
            );
          }
        }
        const $c = Hc;
        class zc extends qc.Z {
          constructor(e) {
            super(e, da.py), this.setStyle(So.Z.meta);
          }
          _getNextState(e) {
            return (e.lowercase = !1), (e.uppercase = !1), e;
          }
        }
        const Wc = zc;
        var Yc = r(97027),
          Kc = r(1234),
          Jc = r(24051),
          Xc = r(32973),
          Qc = r(61923);
        const el = (e, t, r) => {
            if (e.match(/^\\[trnfae]/)) return new Vc.Z(r);
          },
          tl = (e, t, r) => {
            if (e.matchString("\\v")) return new Xc.Z(r);
          },
          rl = (e, t, r) => {
            if (e.match(/^\\[\s\S]/)) return new Yc.Z(r);
          },
          sl = (e, t, r) => ("\\" === e.next() ? new Kc.Z(r) : new Jc.Z(r)),
          nl = [
            (e, t, r) => {
              const s = e.match(/^[\\$]\d+/);
              if (s) {
                let t = parseInt(s[0].slice(1), 10);
                for (; ("" + t).length > 0 && t > r.captureGroupCount; )
                  t = Math.floor(t / 10);
                return (
                  e.backUp(s[0].length - ("$" + t).length), new Fc.Z(r, !0)
                );
              }
            },
            (e, t, r) => {
              if (e.match(/^(?:\${\d+}|\\g<\d+>)/)) return new Fc.Z(r, !0);
            },
            (e, t, r) => {
              if (e.match(/^(?:\${\w+}|\\g<\w+>)/)) return new Gc.Z(r);
            },
            el,
            (e, t, r) => {
              if (e.matchString("\\b")) return new Qc.Z(r);
            },
            tl,
            (e, t, r) => {
              if (e.match(/^\\x(?:[a-fA-F0-9]{2}|{[a-fA-F0-9]+})/))
                return new Bc.Z(r);
            },
            (e, t, r) =>
              e.match(/^\\[UL]/)
                ? new $c(r)
                : e.matchString("\\E")
                ? new Wc(r)
                : void 0,
            rl,
            sl,
          ];
        var al = r(19099),
          il = r(52011),
          ol = r(64375);
        class cl extends qc.Z {
          constructor(e) {
            super(e, da.hL), this.setStyle(So.Z.meta);
          }
        }
        const ll = cl;
        class ul extends qc.Z {
          constructor(e) {
            super(e, da.Cz), this.setStyle(So.Z.meta);
          }
        }
        const hl = ul;
        class pl extends qc.Z {
          constructor(e) {
            super(e, da.tI), this.setStyle(So.Z.meta);
          }
        }
        const dl = pl;
        var gl = r(5786),
          ml = r(54602),
          fl = r(43949);
        class xl extends fl.Z {
          parseComplete() {
            fl.Z.prototype.parseComplete.call(this),
              /^\\[89]$/.test(this.string) && this.setError(pa.of);
          }
        }
        const bl = xl;
        var vl = r(92880),
          jl = r(53996);
        class yl extends jl.Z {
          constructor(e) {
            super(e, da.O3),
              (this.reference = null),
              this.setStyle(So.Z.backreference);
          }
          parseComplete() {
            this.reference = this.string.replace(/^\\?\$</, "").slice(0, -1);
          }
          _revalidate(e) {
            return (
              this.reference
                ? e.subpatterns.includes(this.reference) || this.setError(pa.Bj)
                : this.setError(pa.YY),
              !!this.error
            );
          }
        }
        const Ol = yl,
          wl = (e, t, r) => {
            const s = e.match(/^\\?\$([1-9]\d?)/);
            if (s) {
              let t = parseInt(s[1], 10);
              for (; ("" + t).length > 0 && t > r.captureGroupCount; )
                t = Math.floor(t / 10);
              return e.backUp(s[1].length - ("" + t).length), new Fc.Z(r);
            }
          },
          Cl = (e, t, r) => {
            if (e.matchString("\\0")) return new gl.Z(r, !!e.match(/^\d+/));
          },
          El = (e, t, r) => {
            if (e.match(/^\\(?:[0-3][0-7]{1,2}|[0-7]{1,2})/))
              return new ol.Z(r);
          },
          Zl = (e, t, r) => {
            if (e.match(/^\\[trnfab]/)) return new Vc.Z(r);
          },
          Sl = (e, t, r) => {
            if (e.matchString("\\v")) return new Xc.Z(r);
          },
          kl = (e, t, r) => {
            if ("\\" === t && e.match(/^\\u[0-9A-Fa-f]{0,4}/))
              return new ml.Z(r, !0);
          },
          Pl = [
            (e, t, r) => {
              if (e.matchString("$$") || e.matchString("\\$$"))
                return new Yc.Z(r);
            },
            (e, t, r) => {
              if (e.matchString("$&") || e.matchString("\\$&"))
                return new ll(r);
            },
            (e, t, r) => {
              if (e.matchString("$`") || e.matchString("\\$`"))
                return new hl(r);
            },
            (e, t, r) => {
              if (e.matchString("$'") || e.matchString("\\$'"))
                return new dl(r);
            },
            (e, t, r) => {
              if ((0, Re.x3)() && e.match(/^\\?\$<[^>]*>/)) return new Ol(r);
            },
            wl,
            Cl,
            El,
            Zl,
            Sl,
            (e, t, r) => {
              if (e.match(/^\\x[a-fA-F0-9]{0,2}/)) return new al.Z(r);
            },
            vl.FY,
            kl,
            (e, t, r) => {
              if (e.match(/^\\c./)) return new il.Z(r);
            },
            (e, t, r) => {
              if ("\\" === t && e.match(/^\\[\s\S]/)) return new bl(r);
            },
            sl,
          ];
        var Nl = r(38645);
        class _l extends Nl.Z {
          parseComplete() {
            Nl.Z.prototype.parseComplete.call(this),
              4 !== this.string.length && this.setError(pa.mi);
          }
        }
        const Tl = _l;
        var Al = r(66476),
          Il = r(95165),
          Rl = r(49116);
        const Dl = [
            (e, t, r) => {
              if (e.match(/^\$(?:\d+\b|{\d+})/)) return new Fc.Z(r, !0);
            },
            (e, t, r) => {
              if (e.match(/^\$(?:\w+|{\w+})/)) return new Gc.Z(r);
            },
            (e, t, r) => {
              if (e.match(/^\\[0-7]{1,3}/)) return new Tl(r);
            },
            el,
            tl,
            (e, t, r) => {
              if (e.match(/^\\x[a-fA-F0-9]{0,2}/)) return new Al.Z(r, !0);
            },
            vl.FY,
            kl,
            (e, t, r) => {
              if (e.matchString("\\U")) return new ol.Z(r);
            },
            (e, t, r) => {
              if (e.matchString('"')) return new Il.Z(r);
            },
            (e, t, r) => {
              if (e.match(/^\\[\s\S]/)) return new Rl.Z(r, !0);
            },
            sl,
          ],
          Ll = [
            (e, t, r) => {
              if (e.match(/^\\[1-9]\d?/)) return new Fc.Z(r);
            },
            (e, t, r) => {
              if (e.match(/^\\(?:0[0-7]{1,2}|[1-3][0-7]{1,2})/))
                return new Nl.Z(r);
            },
            (e, t, r) => {
              if (e.match(/^\\g<\d+>/)) return new Fc.Z(r, !0);
            },
            (e, t, r) => {
              if (e.match(/^\\g<\w+>/)) return new Gc.Z(r);
            },
            (e, t, r) => {
              if (e.match(/^\\g/)) return new Fc.Z(r, !0);
            },
            el,
            tl,
            rl,
            sl,
          ];
        var Ml = r(4462);
        class Ul extends Yc.Z {
          parseComplete() {
            Yc.Z.prototype.parseComplete.call(this),
              /^\\[\da-z]/i.test(this.string) && this.setError(pa.mi);
          }
        }
        const Fl = Ul;
        class Gl extends qc.Z {
          constructor(e) {
            super(e, da.w_),
              (this.hasAlternative = !1),
              (this.closeGroup = null),
              (this.reference = null),
              this.setStyle(
                So.Z[`group-${Math.min(e.conditionals.length, 3)}`]
              );
          }
          getTooltipMarkerRange() {
            return {
              primary: {
                start: {
                  pos: this.editorPosition.start.pos,
                  line: this.editorPosition.start.line,
                },
                end: {
                  pos: (this.closeGroup || this).editorPosition.end.pos,
                  line: (this.closeGroup || this).editorPosition.end.line,
                },
              },
            };
          }
          parseComplete() {
            qc.Z.prototype.parseComplete.call(this),
              (this.hasAlternative = this.string.includes("-")),
              (this.reference = this.string.replace(/\W/g, ""));
          }
          setCloseGroup(e) {
            this.closeGroup = e;
          }
          _getNextState(e) {
            return e.conditionals.push(this), e.allConditionals.push(this), e;
          }
          _revalidate() {
            return (
              this.closeGroup
                ? isNaN(this.reference)
                  ? this.state.subpatterns.includes(this.reference) ||
                    this.setError(pa.Bj)
                  : this.state.conditionals.length > 9
                  ? this.setError(pa.xX)
                  : ((this.reference = parseInt(this.reference, 10)),
                    this.state.captureGroupCount < this.reference &&
                      this.setError(pa.Bj))
                : this.setError(pa.CL),
              !!this.error
            );
          }
        }
        const Vl = Gl;
        class Bl extends qc.Z {
          constructor(e) {
            const t = e.conditionals[e.conditionals.length - 1];
            super(e, t ? t.type : null),
              (this.openGroup = null),
              t
                ? t.error
                  ? this.setError(t.error)
                  : (this.setStyle(t.style),
                    (this.openGroup = t),
                    t.addRelatedToken(this),
                    t.setCloseGroup(this))
                : this.setError(pa.rs);
          }
          getTooltipMarkerRange() {
            return {
              primary: {
                start: {
                  pos: (this.openGroup || this).editorPosition.start.pos,
                  line: (this.openGroup || this).editorPosition.start.line,
                },
                end: {
                  pos: this.editorPosition.end.pos,
                  line: this.editorPosition.end.line,
                },
              },
            };
          }
          _getNextState(e) {
            return e.conditionals.pop(), e;
          }
        }
        const ql = Bl;
        class Hl extends qc.Z {
          constructor(e) {
            const t = e.conditionals[e.conditionals.length - 1];
            super(e, t.type),
              (this.conditional = null),
              t.error
                ? this.setError(t.error)
                : (this.setStyle(t.style), t.addRelatedToken(this)),
              (t.hasAlternative = !0),
              (this.conditional = t);
          }
          getTooltipMarkerRange() {
            const e = {
              pos: this.conditional.editorPosition.start.pos,
              line: this.conditional.editorPosition.start.line,
            };
            return {
              primary: {
                start: e,
                end:
                  null != this.conditional.closeGroup
                    ? {
                        pos: this.conditional.closeGroup.editorPosition.end.pos,
                        line: this.conditional.closeGroup.editorPosition.end
                          .line,
                      }
                    : e,
              },
            };
          }
        }
        const $l = Hl;
        class zl extends Fc.Z {
          parseComplete() {
            ("$" === this.string ||
              (this.string.includes("{") && !this.string.includes("}"))) &&
              this.setError(pa.YY);
          }
        }
        const Wl = zl;
        class Yl extends qc.Z {
          constructor(e) {
            super(e, da.Xq), this.setError(pa.YY);
          }
        }
        const Kl = Yl,
          Jl = [
            (e, t, r) => {
              if (r.conditionals.length > 0 && e.matchString("{"))
                return new Kl(r);
            },
            (e, t, r) => {
              if ("$" === t && e.matchString("$$")) return new Fl(r);
            },
            (e, t, r) => {
              if ("$" === t && e.match(/^\$(?:[a-z]\w*|{[a-z]\w*})/i))
                return new Gc.Z(r);
            },
            (e, t, r) => {
              if ("$" === t && e.match(/^\${(?:\d{1,2}|[a-z]\w+):[+-]/i))
                return new Vl(r);
            },
            (e, t, r) => {
              if ("$" === t && e.match(/^\$(?:\d+|{\d{1,2}})?/))
                return new Wl(r, !0);
            },
            (e, t, r) => {
              const s = r.conditionals.length;
              if (s > 0 && !r.conditionals[s - 1].hasAlternative && e.eat(":"))
                return new $l(r);
            },
            (e, t, r) => {
              if (r.conditionals.length > 0 && e.eat("}")) return new ql(r);
            },
            el,
            (e, t, r) => {
              if (e.match(/^\\x(?:[a-fA-F0-9]{2}|{[a-fA-F0-9]*}?)/))
                return new Ml.Z(r);
            },
            (e, t, r) =>
              e.match(/^\\[UL]/i)
                ? new $c(r)
                : e.matchString("\\E")
                ? new Wc(r)
                : void 0,
            (e, t, r) => {
              if ("\\" === t && e.match(/^\\[\s\S]/)) return new Fl(r);
            },
            sl,
          ];
        var Xl = r(25287);
        const Ql = (e, t, r) => {
            if (e.match(/^\${\w+}/)) return new Gc.Z(r);
          },
          eu = [
            wl,
            Ql,
            (e, t, r) => {
              if (e.match(/^\\[trnfb]/)) return new Vc.Z(r);
            },
            vl.FY,
            kl,
            (e, t, r) =>
              e.matchString("$0")
                ? new Fc.Z(r, !0)
                : e.eat("$")
                ? new Kl(r)
                : void 0,
            El,
            (e, t, r) => {
              if ("\\" === t && e.match(/^\\[\s\S]/)) return new Xl.Z(r);
            },
            sl,
          ];
        var tu = r(41026);
        class ru extends qc.Z {
          constructor(e) {
            super(e, da.Ud), this.setStyle(So.Z.meta);
          }
        }
        const su = ru;
        class nu extends qc.Z {
          constructor(e) {
            super(e, da.ul), this.setStyle(So.Z.meta);
          }
        }
        const au = nu;
        var iu = r(50439),
          ou = r(15170),
          cu = r(51402);
        const lu = [
          (e, t, r) => {
            if (e.matchString("$$")) return new Yc.Z(r);
          },
          (e, t, r) => {
            if (e.matchString("$&")) return new ll(r);
          },
          (e, t, r) => {
            if (e.matchString("$`")) return new hl(r);
          },
          (e, t, r) => {
            if (e.matchString("$'")) return new dl(r);
          },
          (e, t, r) => {
            if (e.matchString("$_")) return new su(r);
          },
          (e, t, r) => {
            if (e.matchString("$+")) return new au(r);
          },
          Ql,
          (e, t, r) => {
            const s = e.match(/^\$(\d{1,3})/);
            if (s) {
              let t = parseInt(s[1], 10);
              for (; ("" + t).length > 0 && t > r.captureGroupCount; )
                t = Math.floor(t / 10);
              return e.backUp(s[1].length - ("" + t).length), new Fc.Z(r);
            }
          },
          Cl,
          Zl,
          Sl,
          iu.K,
          ou.fR,
          (0, cu.eb)(tu.Z),
          sl,
        ];
        function uu(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function hu(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? uu(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : uu(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        class pu extends Mc.Z {
          constructor() {
            super(),
              (this._getTokenizers = (e) => {
                switch (e) {
                  case j().PCRE2:
                    return Jl;
                  case j().PCRE:
                    return nl;
                  case j().JAVASCRIPT:
                    return Pl;
                  case j().GOLANG:
                    return Dl;
                  case j().PYTHON:
                    return Ll;
                  case j().JAVA:
                    return eu;
                  case j().DOTNET:
                    return lu;
                  default:
                    throw new Error(`There is no tokenizer for '${e}'`);
                }
              }),
              (this._initialState = {
                uppercase: !1,
                lowercase: !1,
                subpatternTokens: [],
                inCharClass: !1,
                flags: "",
                subpatterns: [],
                captureGroupCount: 0,
                captureGroupMap: {},
                conditionals: [],
                allConditionals: [],
                unicodeEnabled: !1,
              }),
              (this._patternError = !1);
          }
          parse(e, t = {}) {
            const r = [],
              s = new Uc.Z(e);
            let n = hu(hu({}, this._initialState), Mc.Z.copyState(t));
            for (; !s.eof(); ) {
              const a = s.position,
                i = this._token(t.flavor, s, n),
                o = s.position;
              (i.position = { start: a, end: o }),
                (i.string = e.slice(a, o)),
                (i.isSubstitution = !0),
                i.parseComplete(),
                r.push(i),
                (n = i.getNextState());
            }
            const a = n;
            this._patternError = a.patternError;
            const i = [].concat(a.subpatternTokens, a.allConditionals);
            for (let e = 0, t = i.length; e < t; e++) {
              const t = i[e]._revalidate(a);
              this._patternError = this._patternError || t;
            }
            return (this.tokens = r), r;
          }
        }
        const du = pu,
          gu = ({
            subpatterns: e,
            captureGroupCount: t,
            substParser: r,
            defaultValue: s,
            onEnterClick: n,
            onChange: a,
            flavor: i,
            className: o,
          }) => {
            const c = (0, We.v9)((e) => e.settings.displayWhitespace),
              l = (0, We.v9)((e) => e.settings.defaultTabBehavior),
              u = (0, ze.useRef)(null),
              h = (0, ze.useMemo)(
                () => ({
                  mode: null,
                  placeholder: (0, et.Z)("insert your replacement value here"),
                  tabSize: 4,
                  extraKeys: {
                    "Shift-Tab": !1,
                    Tab: !l && null,
                    Enter: n || !1,
                  },
                  showWhitespace: c,
                }),
                [n, c, l]
              ),
              p = (0, ze.useMemo)(
                () => ({
                  flavor: i,
                  subpatterns: e,
                  captureGroupCount: t,
                  unicodeEnabled:
                    i === j().JAVASCRIPT ||
                    i === j().GOLANG ||
                    i === j().DOTNET,
                }),
                [e, t, i]
              ),
              d = (0, ze.useState)(!1),
              g = (0, st.Z)(d, 2),
              m = g[0],
              f = g[1],
              x = (0, ze.useCallback)((e) => f(e), []),
              b = (0, ze.useCallback)((e) => (u.current = e), []);
            return (
              (0, ze.useEffect)(() => {
                const e = (e, t) => u.current.setValue(t);
                return tt.ZP.on(tt.l2, e), () => tt.ZP.off(tt.l2, e);
              }, []),
              (0, ht.jsx)(Io, {
                onCreate: b,
                onChange: a,
                defaultValue: s,
                onFocusChange: x,
                parser: r,
                parserOptions: p,
                TooltipClass: Lo,
                codeMirrorOptions: h,
                className: Xe()("Pgoeh", m && "Vnkit", o),
                singleLine: !0,
              })
            );
          },
          mu = ({ isSubst: e, error: t, time: r, hasResult: s }) => {
            let n = null,
              a = null,
              i = !1;
            if (e) (n = tc), (a = (0, et.Z)("Processing..."));
            else if (t)
              switch (((n = sc), t)) {
                case $t.D9:
                  a = (0, et.Z)("Pattern Error");
                  break;
                case $t.ik:
                  a = (0, et.Z)("Timeout");
                  break;
                default:
                  (a = (0, et.Z)("Engine Error")), (i = !0);
              }
            else
              s
                ? ((a = (0, et.Z)("Success")), (n = rc))
                : ((a = (0, et.Z)("No result")), (n = tc));
            return (0, ht.jsx)(rt.lx, {
              disableTooltip: !i,
              direction: gt.qF.N,
              text:
                null != t ? (0, et.Z)("Error reported by engine: {1}", t) : "",
              children: (0, ht.jsx)("div", {
                className: "Br6dk",
                children: (0, ht.jsxs)("div", {
                  className: Xe()(ec, n),
                  children: [
                    a,
                    null != r &&
                      (0, ht.jsxs)("span", {
                        className: nc,
                        children: [" (", ac(r), ")"],
                      }),
                  ],
                }),
              }),
            });
          },
          fu = (0, ze.memo)(mu),
          xu = (0, At.Z)(It.Y4),
          bu = new du(),
          vu = [$t.Y8, $t.wm, $t.Vu, $t.D9, $t.ik, $t.Gv],
          ju = ({
            regex: e,
            substString: t,
            matchResult: r,
            testString: s,
            regexParserStatus: n,
            captureGroupMap: a,
            subpatterns: i,
            captureGroupCount: o,
            label: l,
            listMode: u,
            onValueChange: h,
          }) => {
            const p = (0, We.v9)((e) => e.settings.wrapLines),
              d = (0, We.v9)((e) => e.settings.displayWhitespace),
              g = (0, We.v9)((e) => e.settings.testAreaLineNumbers),
              m = (0, We.v9)((e) => e.settings.maxExecutionTime),
              f = (0, We.v9)((e) => e.regexEditor.flavor),
              x = (0, We.v9)((e) => e.regexEditor.flags),
              b = (0, ze.useRef)(null),
              v = (0, ze.useRef)(new Lc()),
              j = (0, ze.useState)({
                substString: t,
                tokens: [],
                status: null,
              }),
              y = (0, st.Z)(j, 2),
              O = y[0],
              w = y[1],
              C = (0, ze.useState)({
                isSubst: !0,
                time: null,
                substError: null,
                hasResult: !1,
              }),
              E = (0, st.Z)(C, 2),
              Z = E[0],
              S = E[1],
              k = (0, Qe.Sf)((e) => h(e), q.UPDATE_RESULT_DELAY),
              P = (0, Qe.Sf)(
                (e, t) => {
                  null == t ||
                    vu.includes(t) ||
                    (c.Z.error("Subst error reported by engine:", t),
                    $e.O7(new Error(t))),
                    S({
                      isSubst: !1,
                      time: null == e ? null : e.time,
                      substError: t,
                      hasResult: null != (null == e ? void 0 : e.result),
                    });
                },
                q.UPDATE_RESULT_DELAY,
                "cancel"
              ),
              N = (0, ze.useCallback)(
                (e, t, r) => w({ substString: e, status: t, tokens: r }),
                []
              ),
              _ = (0, ze.useCallback)((e) => {
                const t = b.current,
                  r = null == t ? void 0 : t.getScrollInfo(),
                  s = r.top,
                  n = r.left;
                null == t || t.setValue(e), null == t || t.scrollTo(n, s);
              }, []);
            (0, ze.useEffect)(() => {
              if (
                (k(O.substString),
                P.cancel(),
                "" === e || null != O.status || 0 === r.length || null != n)
              )
                v.current.resetWorker(),
                  "" === e
                    ? S({
                        hasResult: !1,
                        isSubst: !1,
                        time: null,
                        substError: null,
                      })
                    : P({ time: null, result: null }, O.status || n),
                  _(s || "");
              else {
                S({ hasResult: !1, isSubst: !0, time: null, substError: null });
                const t = { maxExecutionTime: m, flavor: f, listMode: u },
                  n = { matchResult: r, tokens: O.tokens, captureGroupMap: a };
                v.current.runSubst(e, x, s, O.substString, n, t, (e, t) => {
                  P(e, t),
                    _(null == (null == e ? void 0 : e.result) ? s : e.result);
                });
              }
            }, [m, r, O.substString, O.tokens, O.status, x, n, P, k, u, _]);
            const T = (0, ze.useCallback)((e) => (b.current = e), []);
            (0, ze.useEffect)(() => {
              const e = () => k.flush();
              return tt.ZP.on(tt.P, e), () => tt.ZP.off(tt.P, e);
            }, [k]),
              (0, ze.useEffect)(() => {
                tt.ZP.emit(tt.AZ);
                const e = setTimeout(() => tt.ZP.emit(tt.U0), xu);
                return () => {
                  clearTimeout(e),
                    tt.ZP.emit(tt.AZ),
                    setTimeout(() => tt.ZP.emit(tt.U0), xu);
                };
              }, []),
              (0, ze.useEffect)(() => () => v.current.resetWorker(), []);
            const A = (0, ze.useMemo)(
              () => ({
                mode: null,
                lineWrapping: p,
                readOnly: !0,
                showWhitespace: d,
                lineNumbers: g,
                extraKeys: { "Shift-Tab": !1, Tab: !1 },
                tabindex: -1,
              }),
              [g, d, p]
            );
            return (0, ht.jsxs)(ht.Fragment, {
              children: [
                (0, ht.jsx)(rt.__, { text: l, className: "llpmv" }),
                (0, ht.jsx)(fu, {
                  isSubst: Z.isSubst,
                  error: Z.substError,
                  time: Z.time,
                  hasResult: Z.hasResult,
                }),
                (0, ht.jsxs)("div", {
                  className: "uP9GB",
                  children: [
                    (0, ht.jsx)(Oo, {
                      className: "iuWEc",
                      onCreate: T,
                      options: A,
                      defaultValue: "",
                    }),
                    (0, ht.jsx)(gu, {
                      onChange: N,
                      defaultValue: t,
                      substParser: bu,
                      flavor: f,
                      captureGroupCount: o,
                      subpatterns: i,
                    }),
                  ],
                }),
              ],
            });
          },
          yu = ({
            matchResult: e,
            testString: t,
            regex: r,
            regexParserStatus: s,
            captureGroupMap: n,
            subpatterns: a,
            captureGroupCount: i,
          }) => {
            const o = (0, We.I0)(),
              c = (0, We.v9)((e) => e.regexEditor.substString),
              l = (0, ze.useCallback)((e) => o((0, je.ZI)(e)), [o]);
            return (0, ht.jsx)(ju, {
              label: (0, et.Z)("Substitution"),
              substString: c,
              testString: t,
              matchResult: e,
              regex: r,
              regexParserStatus: s,
              captureGroupMap: n,
              subpatterns: a,
              captureGroupCount: i,
              onValueChange: l,
            });
          },
          Ou = ({
            matchResult: e,
            testString: t,
            regex: r,
            regexParserStatus: s,
            captureGroupMap: n,
            subpatterns: a,
            captureGroupCount: i,
          }) => {
            const o = (0, We.I0)(),
              c = (0, We.v9)((e) => e.regexEditor.listSubstString),
              l = (0, ze.useCallback)((e) => o((0, je.ak)(e)), [o]);
            return (0, ht.jsx)(ju, {
              label: (0, et.Z)("List"),
              substString: c,
              testString: t,
              matchResult: e,
              regex: r,
              regexParserStatus: s,
              captureGroupMap: n,
              subpatterns: a,
              captureGroupCount: i,
              onValueChange: l,
              listMode: !0,
            });
          },
          wu = () => {
            const e = (0, We.I0)(),
              t = (0, We.v9)((e) => e.regexEditor.regex),
              r = (0, We.v9)((e) => e.regexEditor.flags),
              s = (0, We.v9)((e) => e.regexEditor.flavor),
              n = (0, We.v9)((e) => e.regexEditor.delimiter),
              a = (0, We.v9)((e) => e.regexEditor.testString),
              i = (0, We.v9)((e) => e.regexEditor.showUnitTestArea),
              o = (0, We.v9)((e) => e.settings.maxExecutionTime),
              c = (0, We.v9)((e) => e.settings.calculateRegexSteps),
              l = (0, We.v9)((e) => e.regexEditor.error),
              u = (0, We.v9)((e) => e.regexEditor.matchResult.length),
              h = (0, We.v9)((e) => e.regexEditor.showSubstitutionArea),
              p = (0, We.v9)((e) => e.regexEditor.showListSubstitutionArea),
              d = (0, ze.useRef)(new oo.Z()).current,
              g = (0, ze.useState)(a),
              m = (0, st.Z)(g, 2),
              f = m[0],
              x = m[1],
              b = (0, ze.useState)({
                regex: "",
                status: null,
                tokens: [],
                flavor: s,
                flags: r,
                captureGroupMap: {},
                subpatterns: [],
                captureGroupCount: 0,
                definedSubpatterns: [],
              }),
              v = (0, st.Z)(b, 2),
              y = v[0],
              O = v[1],
              w = (0, ze.useState)({ isMatching: !1, time: null, steps: null }),
              C = (0, st.Z)(w, 2),
              E = C[0],
              Z = C[1],
              S = (0, ze.useState)({ matchResult: [], matchMap: {} }),
              k = (0, st.Z)(S, 2),
              P = k[0],
              N = k[1],
              _ = (0, ze.useRef)(0),
              T = (0, ze.useState)(!1),
              A = (0, st.Z)(T, 2),
              I = A[0],
              R = A[1],
              D = (0, sa.Z)(
                (t, r) => {
                  const s = t || {},
                    n = s.steps,
                    a = s.time,
                    i = s.matchResult,
                    o = s.matchMap;
                  null != r
                    ? (Z({ isMatching: !1, time: null, steps: null }),
                      e((0, je.QF)(r)))
                    : (e((0, je.QF)(null)),
                      Z({ isMatching: !1, steps: n, time: a })),
                    e((0, je.rS)(r ? [] : i)),
                    N(
                      r
                        ? { matchResult: [], matchMap: {} }
                        : { matchResult: i, matchMap: o }
                    );
                },
                q.UPDATE_RESULT_DELAY,
                "cancel"
              ),
              L = (0, sa.Z)((t, r, s) => {
                e(
                  (0, je.og)({
                    status: r,
                    tokens: s,
                    subpatterns: ri.Z.subpatterns,
                    captureGroupMap: ri.Z.captureGroupMap,
                    captureGroupCount: ri.Z.captureGroupCount,
                    definedSubpatterns: ri.Z.definedSubpatterns,
                  })
                ),
                  e((0, je.uf)(t));
              }, q.UPDATE_RESULT_DELAY),
              M = (0, sa.Z)((t) => e((0, je.Jh)(t)), q.UPDATE_RESULT_DELAY),
              U = (0, ze.useCallback)(
                (t) => {
                  const r = t.delimiter,
                    n = t.flags,
                    a = t.isSub,
                    i = t.substText;
                  [j().PCRE, j().PCRE2].includes(s) && e((0, je.G6)(r)),
                    e((0, je.dL)("", n, s)),
                    a && (e((0, je.ux)()), tt.ZP.emit(tt.l2, i));
                },
                [s, e]
              ),
              F = (0, ze.useCallback)((t) => e((0, je.G6)(t)), [e]),
              G = (0, ze.useCallback)((t) => e((0, je.dL)(r, t, s)), [r, s, e]),
              V = (0, ze.useCallback)(
                (e, t, r, s) => {
                  const n = s.flavor,
                    a = s.flags;
                  O({
                    regex: e,
                    status: t,
                    tokens: r,
                    flavor: n,
                    flags: a,
                    subpatterns: ri.Z.subpatterns,
                    captureGroupMap: ri.Z.captureGroupMap,
                    captureGroupCount: ri.Z.captureGroupCount,
                    definedSubpatterns: ri.Z.definedSubpatterns,
                  }),
                    L(e, t, r);
                },
                [L]
              ),
              B = (0, ze.useCallback)(
                (e) => {
                  const t = e.getValue();
                  M(t), x(t);
                },
                [M]
              );
            (0, ze.useEffect)(() => {
              D.cancel();
              const e = (1e9 * Math.random()) | 0;
              _.current = e;
              const t = y.regex,
                r = y.status,
                s = y.flavor,
                n = y.flags;
              if ("" === t || null != r)
                N({ matchResult: [], matchMap: {} }),
                  D(
                    { matchResult: [], matchMap: {}, steps: null, time: null },
                    r
                  ),
                  R(!1);
              else {
                Z({ isMatching: !0, time: null, steps: null }), R(!0);
                const r = {
                  maxExecutionTime: o,
                  calculateRegexSteps: c,
                  flavor: s,
                };
                
                d.runMatch(t, n, f, r, (t, r) => {
                  window?.OnBeforeHandleMatchResult(t.matchResult, t.matchMap);
                  e === _.current &&
                    (N({
                      matchResult: (null == t ? void 0 : t.matchResult) || [],
                      matchMap: (null == t ? void 0 : t.matchMap) || {},
                    }),
                    D(t, r),
                    R(!1));
                });
              }
            }, [y, d, f, D, L, o, c]),
              (0, ze.useEffect)(() => {
                const e = () => {
                  L.flush(), M.flush();
                };
                return tt.ZP.on(tt.P, e), () => tt.ZP.off(tt.P, e);
              }, [L, M]),
              (0, ze.useEffect)(() => () => d.resetWorker(), [d]);
            const H = h ? yu : Ou;
            return (0, ht.jsxs)("div", {
              className: "AUc0W",
              children: [
                (0, ht.jsxs)("div", {
                  className: "rjodX",
                  children: [
                    (0, ht.jsx)(hc, {
                      children:
                        !i &&
                        (0, ht.jsx)(oc, {
                          isMatching: E.isMatching,
                          matchNum: u,
                          steps: E.steps,
                          time: E.time,
                          error: l,
                          flavor: s,
                          hasRegex: t.length > 0,
                        }),
                    }),
                    (0, ht.jsx)(Jo, {
                      onRegexChange: V,
                      onRegexPaste: U,
                      onDelimiterChange: F,
                      onFlagsChange: G,
                      regex: t,
                      flavor: s,
                      flags: r,
                      delimiter: n,
                      regexParser: ri.Z,
                    }),
                  ],
                }),
                (0, ht.jsx)("div", {
                  className: "f9BbV",
                  children: i
                    ? (0, ht.jsx)(mo, {})
                    : (0, ht.jsxs)("div", {
                        className: "F69Q6",
                        children: [
                          (0, ht.jsx)(Zc, {
                            onInput: B,
                            matchMap: P.matchMap,
                            waiting: I,
                          }),
                          (p || h) &&
                            (0, ht.jsx)("div", {
                              className: "kPafO",
                              children: (0, ht.jsx)(H, {
                                matchResult: P.matchResult,
                                testString: f,
                                regex: y.regex,
                                regexParserStatus: y.status,
                                captureGroupMap: y.captureGroupMap,
                                subpatterns: y.subpatterns,
                                captureGroupCount: y.captureGroupCount,
                              }),
                            }),
                        ],
                      }),
                }),
              ],
            });
          };
        var Cu = r(8342);
        const Eu = () => {
            const e = (0, ze.useState)(!1),
              t = (0, st.Z)(e, 2),
              r = t[0],
              s = t[1],
              n = [
                {
                  description: (0, et.Z)("Switch to regex matching"),
                  shortcuts: [Ht.SWITCH_TO_MATCH],
                },
                {
                  description: (0, et.Z)("Switch to regex substitution"),
                  shortcuts: [Ht.SWITCH_TO_SUBST],
                },
                {
                  description: (0, et.Z)("Switch to regex list substitution"),
                  shortcuts: [Ht.SWITCH_TO_LIST],
                },
                {
                  description: (0, et.Z)("Switch to unit tests"),
                  shortcuts: [Ht.SWITCH_TO_UNIT_TESTS],
                },
                {
                  description: (0, et.Z)("Open regex debugger"),
                  shortcuts: [Ht.SHOW_DEBUGGER],
                },
                {
                  description: (0, et.Z)("Open code generator"),
                  shortcuts: [Ht.SHOW_CODE_GEN],
                },
                {
                  description: (0, et.Z)("Run unit tests (when view is open)"),
                  shortcuts: [Ht.RUN_UNIT_TESTS],
                },
              ];
            return (
              (0, ze.useEffect)(() => {
                const e = () => s(!0);
                return (
                  tt.ZP.on("key:question", e),
                  () => tt.ZP.off("key:question", e)
                );
              }, []),
              (0, ht.jsx)(Cu.Z, {
                onModalClose: () => s(!1),
                isOpen: r,
                shortcuts: n,
              })
            );
          },
          Zu = (0, ze.memo)(Eu),
          Su = () => {
            const e = (0, Ke.UO)(),
              t = e.permalinkFragment,
              r = e.version,
              s = (0, Qe.$5)("getRegex"),
              n = (0, st.Z)(s, 3),
              a = n[1],
              i = n[2];
            if (
              ((0, Qe.DB)(
                (e) => {
                  e && null != t && !isNaN(r) && i((0, je.Of)(t, r));
                },
                [i, t, r]
              ),
              null != t && (a || isNaN(r)))
            )
              return "1" !== r
                ? (0, ht.jsx)(rt.l_, { to: `/r/${t}/1` })
                : (0, ht.jsx)(rt.l_, { to: "/" });
            const o = t ? `${t}-${r}` : "plain";
            return (0, ht.jsxs)("div", {
              className: "bkz2q",
              children: [
                (0, ht.jsx)(Ui, {}),
                (0, ht.jsx)(wu, {}),
                (0, ht.jsx)(
                  ra,
                  {
                    path: "/codegen",
                    title: (0, et.Z)("Code Generator"),
                    children: (0, ht.jsx)(Hn, {}),
                  },
                  `code-gen-${o}`
                ),
                (0, ht.jsx)(
                  ra,
                  {
                    path: "/debugger",
                    title: (0, et.Z)("Regex Debugger"),
                    children: (0, ht.jsx)(zn, {}),
                  },
                  `debugger-${o}`
                ),
                (0, ht.jsxs)(Ke.Z5, {
                  children: [
                    (0, ht.jsx)(Ke.AW, {
                      path: "/codegen",
                      element: (0, ht.jsx)(ht.Fragment, {}),
                    }),
                    (0, ht.jsx)(Ke.AW, {
                      path: "/debugger",
                      element: (0, ht.jsx)(ht.Fragment, {}),
                    }),
                    (0, ht.jsx)(Ke.AW, {
                      path: "/",
                      element: (0, ht.jsx)(ht.Fragment, {}),
                    }),
                    (0, ht.jsx)(Ke.AW, {
                      path: "*",
                      element: (0, ht.jsx)(rt.l_, {
                        to: null != t ? `/r/${t}/${r}` : "/",
                      }),
                    }),
                  ],
                }),
                (0, ht.jsx)(Zu, {}),
              ],
            });
          },
          ku = ({ isVisible: e }) =>
            e
              ? (0, ht.jsx)("div", {
                  className: "wMRs6",
                  children: (0, ht.jsx)(rt.$j, { size: gt.J7.HC }),
                })
              : null,
          Pu = (0, ze.memo)(ku),
          Nu = ({ isLoading: e, children: t }) =>
            (0, ht.jsxs)(ht.Fragment, {
              children: [!e && t, (0, ht.jsx)(Pu, { isVisible: e })],
            });
        function _u(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Tu(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? _u(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : _u(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Au = ({ active: e, page: t }) => {
            const r = (0, Ke.TH)(),
              s = Tu(
                Tu({}, r),
                {},
                {
                  search: sr.stringify(
                    Tu(Tu({}, sr.parse(r.search)), {}, { page: t })
                  ),
                }
              );
            return (0, ht.jsx)(rt.rU, {
              to: s,
              className: Xe()("PMAGi", e && "J4QnP"),
              noTheme: !0,
              children: t,
            });
          },
          Iu = "RnWnK";
        function Ru(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Du(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? Ru(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : Ru(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Lu = ({
            left: e,
            right: t,
            nextPage: r,
            className: s,
            visible: n,
          }) => {
            const a = (0, Ke.TH)(),
              i = Du(
                Du({}, a),
                {},
                {
                  search: sr.stringify(
                    Du(Du({}, sr.parse(a.search)), {}, { page: r })
                  ),
                }
              );
            return (0, ht.jsxs)(rt.rU, {
              to: i,
              className: Xe()("Fa5Yt", !n && "qE_eB", s),
              noTheme: !0,
              "aria-label": e
                ? (0, et.Z)("Previous page")
                : (0, et.Z)("Next page"),
              children: [
                e && (0, ht.jsx)(nt.jW7, { size: 20, className: Iu }),
                t && (0, ht.jsx)(nt.jfD, { size: 20, className: Iu }),
              ],
            });
          },
          Mu = (0, ze.memo)(Lu);
        function Uu(e, t) {
          const r = [];
          for (let s = e; s <= t; s++) r.push(s);
          return r;
        }
        const Fu = ({ pages: e, className: t, currentPage: r }) => {
            if (e < 2) return null;
            const s = Math.min(e, r),
              n = (0, Y.Z)(
                [].concat(Uu(Math.max(1, s - 3), s), Uu(s, Math.min(e, s + 3)))
              ).filter((t) => 1 !== t && t !== e);
            return (0, ht.jsxs)("div", {
              className: Xe()("lt5O_", t),
              children: [
                (0, ht.jsx)(Mu, { nextPage: s - 1, visible: s > 1, left: !0 }),
                (0, ht.jsx)(Au, { page: 1, active: 1 === s }),
                n[0] > 2 && "...",
                n.map((e) =>
                  (0, ht.jsx)(Au, { page: e, active: s === e }, `page-${e}`)
                ),
                n[n.length - 1] + 1 < e && "...",
                (0, ht.jsx)(Au, { page: e, active: e === s }),
                (0, ht.jsx)(Mu, { nextPage: s + 1, visible: s < e, right: !0 }),
              ],
            });
          },
          Gu = (0, ze.memo)(Fu),
          Vu = "EIMPZ",
          Bu = "tMvcj",
          qu = ({
            upvotes: e,
            downvotes: t,
            userVote: r,
            permalinkFragment: s,
            className: n,
          }) => {
            const a = (0, We.I0)(),
              i = (0, We.v9)((e) => e.general.userId),
              o = (0, ze.useState)(e),
              c = (0, st.Z)(o, 2),
              l = c[0],
              u = c[1],
              h = (0, ze.useState)(t),
              p = (0, st.Z)(h, 2),
              d = p[0],
              g = p[1],
              m = (0, ze.useState)(r),
              f = (0, st.Z)(m, 2),
              x = f[0],
              b = f[1];
            (0, ze.useEffect)(() => {
              u(e), g(t), b(r);
            }, [e, t, r]);
            const v = (e, t) => {
                e.preventDefault(), x === t && (t = 0);
                let r = x > 0 ? l - 1 : l,
                  n = x < 0 ? d - 1 : d;
                t > 0 ? r++ : t < 0 && n++,
                  u(r),
                  g(n),
                  b(t),
                  a((0, je._v)(s, t));
              },
              j = null != i,
              y = Math.round(l - d),
              O = Math.max(0, Math.round((l / Math.max(1, l + d)) * 100)),
              w =
                (0, et.Z)(
                  "{1} upvotes, {2} downvotes ({3}% like it)",
                  Math.round(l),
                  Math.round(d),
                  O
                ) +
                (j
                  ? ""
                  : "\n(" + (0, et.Z)("You must be signed in to vote") + ")");
            let C = null;
            return (
              (0 === l && 0 === d) ||
                (C = `hsl(${((O / 100) * 120).toString(10)}, 100%, 25%)`),
              (0, ht.jsx)(rt.lx, {
                direction: gt.qF.E,
                text: w,
                children: (0, ht.jsxs)("div", {
                  className: Xe()("rQI68", n),
                  children: [
                    (0, ht.jsx)(rt.Yd, {
                      className: Xe()(Vu, "IBxjT", x > 0 && Bu),
                      onClick: (e) => v(e, 1),
                      disabled: !j,
                      "aria-label": (0, et.Z)("Upvote"),
                      children: (0, ht.jsx)(kr.s$2, { size: 16 }),
                    }),
                    (0, ht.jsx)("div", {
                      className: "OK2mW",
                      style: { color: C },
                      children: y,
                    }),
                    (0, ht.jsx)(rt.Yd, {
                      className: Xe()(Vu, "QSQhw", x < 0 && Bu),
                      onClick: (e) => v(e, -1),
                      disabled: !j,
                      "aria-label": (0, et.Z)("Downvote"),
                      children: (0, ht.jsx)(kr.RiI, { size: 16 }),
                    }),
                  ],
                }),
              })
            );
          },
          Hu = (0, ze.memo)(qu),
          $u = ({
            delimiter: e,
            flags: t,
            regex: r,
            flavor: s,
            permalinkFragment: n,
            version: a,
          }) => {
            const i = (0, ze.useRef)(new Re.ZP()).current.parse(r, {
              delimiter: e,
              flags: t,
              flavor: s,
            });
            return (0, ht.jsxs)(ht.Fragment, {
              children: [
                (0, ht.jsx)(rt.Po, {
                  text: (0, et.Z)("Regular Expression"),
                  children: (0, ht.jsx)("div", {
                    className: "tKAH6",
                    children: s,
                  }),
                }),
                (0, ht.jsxs)(Bn.Z, {
                  className: "fHgtW",
                  children: [
                    (0, ht.jsx)(Ha, { tokens: i, delimiter: e, flags: t }),
                    (0, ht.jsx)("div", {
                      className: "LOiuh",
                      children: (0, ht.jsxs)(rt.rU, {
                        to: rr(n, a),
                        absolute: !0,
                        children: [
                          (0, et.Z)("Open regex in editor"),
                          (0, ht.jsx)(Js.xXr, { className: "L3Eaj" }),
                        ],
                      }),
                    }),
                  ],
                }),
              ],
            });
          },
          zu = (0, ze.memo)($u);
        var Wu = r(27484),
          Yu = r.n(Wu),
          Ku = r(70178),
          Ju = r.n(Ku),
          Xu = r(84110),
          Qu = r.n(Xu);
        Yu().extend(Qu()), Yu().extend(Ju());
        const eh = Yu(),
          th = ({ date: e, author: t, description: r }) =>
            (0, ht.jsxs)("div", {
              className: "XL8nr",
              children: [
                (0, ht.jsx)(rt.__, { text: (0, et.Z)("Description") }),
                (0, ht.jsxs)(Bn.Z, {
                  children: [
                    (0, ht.jsx)(Zt, {
                      className: Xe()("EcsU0", !r && "afYTT"),
                      children: r || (0, et.Z)("no description available"),
                    }),
                    (0, ht.jsxs)("div", {
                      className: "KPMvl",
                      children: [
                        (0, et.Z)("Submitted by"),
                        " ",
                        (0, ht.jsx)("span", {
                          className: "UblEx",
                          children: t || (0, et.Z)("anonymous"),
                        }),
                        " - ",
                        eh.utc(e).fromNow(),
                      ],
                    }),
                  ],
                }),
              ],
            }),
          rh = (0, ze.memo)(th),
          sh = () => {
            const e = (0, We.I0)(),
              t = (0, We.v9)((e) => e.regexLibrary.details),
              r = (0, Ke.UO)().libraryId,
              s = (0, Qe.$5)("libraryDetails"),
              n = (0, st.Z)(s, 3),
              a = n[0],
              i = n[1],
              o = n[2];
            var c;
            if (
              ((0, Qe.DB)(() => {
                null == t && o((0, je.xv)(r));
              }, [o, r, t]),
              (0, Qe.kF)(
                (null == t ? void 0 : t.title) || "Regex Library",
                q.LIBRARY_META_DESCRIPTION
              ),
              (0, ze.useEffect)(() => () => e((0, je.bL)(null)), [e]),
              i)
            )
              return 404 ===
                (null === (c = i.response) || void 0 === c ? void 0 : c.status)
                ? (0, ht.jsx)(rt.l_, { to: "/library" })
                : (0, ht.jsx)(rt.qX, {
                    type: gt.gr.pn,
                    children: (0, et.Z)(
                      "There was a problem when trying to fetch the details for this entry. Please try again later."
                    ),
                  });
            if (a || null == t) return (0, ht.jsx)(Pu, { isVisible: !0 });
            const l = t.regex,
              u = t.flags,
              h = t.flavor,
              p = t.delimiter,
              d = t.permalinkFragment,
              g = t.version,
              m = t.dateModified,
              f = t.description,
              x = t.author,
              b = t.upvotes,
              v = t.downvotes,
              j = t.userVote;
            return (0, ht.jsxs)("div", {
              className: "Cq6xD",
              children: [
                (0, ht.jsxs)("div", {
                  className: "FDqYn",
                  children: [
                    (0, ht.jsx)(rt.__, {
                      text: (0, et.Z)("Vote"),
                      className: "ULHf7",
                    }),
                    (0, ht.jsx)(Hu, {
                      upvotes: b,
                      downvotes: v,
                      userVote: j,
                      permalinkFragment: d,
                    }),
                  ],
                }),
                (0, ht.jsxs)("div", {
                  className: "INRCS",
                  children: [
                    (0, ht.jsx)(zu, {
                      regex: l,
                      flags: u,
                      flavor: h,
                      delimiter: p,
                      permalinkFragment: d,
                      version: g,
                    }),
                    (0, ht.jsx)(rh, {
                      date: m,
                      description: f || void 0,
                      author: x || void 0,
                    }),
                  ],
                }),
              ],
            });
          };
        var nh = r(26525),
          ah = r.n(nh);
        function ih(e) {
          let t = e;
          return (
            e && e.length > 303 && (t = e.slice(0, 300) + "..."),
            t.split("\n").length > 6 &&
              (t = t.split("\n").slice(0, 6).join("\n") + "..."),
            t
          );
        }
        const oh = ({
            title: e,
            flavor: t,
            date: r,
            upvotes: s,
            downvotes: n,
            canvote: a = !1,
            author: i = (0, et.Z)("anonymous"),
            userVote: o,
            description: c,
            permalinkFragment: l,
          }) => {
            const u = (0, Ke.TH)().search;
            return (0, ht.jsxs)("div", {
              className: "fiYVe",
              children: [
                (0, ht.jsx)(Hu, {
                  canvote: a,
                  upvotes: s,
                  downvotes: n,
                  userVote: o,
                  permalinkFragment: l,
                  className: "BKJlR",
                }),
                (0, ht.jsx)(rt.rU, {
                  noTheme: !0,
                  to: `${l}${u}`,
                  className: "wqwfW",
                  children: (0, ht.jsxs)("div", {
                    children: [
                      (0, ht.jsxs)("div", {
                        className: "aqvFS",
                        children: [
                          (0, ht.jsx)("div", {
                            className: "UYk6r",
                            children: t,
                          }),
                          (0, ht.jsx)("h3", {
                            className: "elKva",
                            children: e,
                          }),
                        ],
                      }),
                      (0, ht.jsx)("div", {
                        className: Xe()("xZqXR", !c && "LHJqG"),
                        children: ih(
                          ah()(c || (0, et.Z)("no description available"))
                        ),
                      }),
                      (0, ht.jsxs)("div", {
                        className: "RryPT",
                        children: [
                          (0, et.Z)("Submitted by"),
                          " ",
                          (0, ht.jsx)("span", {
                            className: "iNeUZ",
                            children: i,
                          }),
                          " - ",
                          (0, ht.jsx)("span", {
                            children: eh.utc(r).fromNow(),
                          }),
                        ],
                      }),
                    ],
                  }),
                }),
              ],
            });
          },
          ch = (0, ze.memo)(oh),
          lh = "m7Th9",
          uh = ({ libraryData: e, fetchError: t, didSearch: r }) =>
            t
              ? (0, ht.jsx)(rt.qX, {
                  type: gt.gr.pn,
                  children: (0, et.Z)(
                    "There was a problem trying to fetch the library data. Please try again later."
                  ),
                })
              : 0 === e.length
              ? (0, ht.jsx)(rt.qX, {
                  noMargin: !0,
                  children: r
                    ? (0, et.Z)("Your search did not match anything")
                    : (0, et.Z)("There does not seem to be anything here"),
                })
              : e.map((e, t) =>
                  (0, ht.jsx)(
                    ch,
                    {
                      title: e.title,
                      description: e.description || void 0,
                      flavor: e.flavor,
                      date: e.dateModified,
                      upvotes: e.upvotes,
                      downvotes: e.downvotes,
                      permalinkFragment: e.permalinkFragment,
                      author: e.author || void 0,
                      userVote: e.userVote || void 0,
                    },
                    `library-entry-${t}`
                  )
                ),
          hh = () => {
            const e = (0, We.I0)(),
              t = (0, We.v9)((e) => e.regexLibrary.libraryData),
              r = (0, We.v9)((e) => e.regexLibrary.pages),
              s = (0, We.v9)((e) => {
                var t;
                return null === (t = e.regexLibrary.details) || void 0 === t
                  ? void 0
                  : t.title;
              }),
              n = (0, Ye.lr)(),
              a = (0, st.Z)(n, 2),
              i = a[0],
              o = a[1],
              c = i.getAll("filterFlavors"),
              l = i.get("orderBy") || qs().MOST_RECENT,
              u = i.get("search") || "",
              h = i.get("page") || 1,
              p = (0, Qe.$5)("regexLibrary"),
              d = (0, st.Z)(p, 3),
              g = d[0],
              m = d[1],
              f = d[2];
            (0, Qe.vI)(() => {
              f((0, je.v0)(h, u, l, c));
            }, [f, c.join(""), l, u, h]),
              (0, Qe.DB)(() => {
                0 === t.length && f((0, je.v0)(h, u, l, c));
              }, [f, c.join(""), l, u, h, t.length]);
            const x = (0, Qe.Sf)(o, 500, "cancel"),
              b = (0, ze.useCallback)(
                (e = "") => {
                  let t;
                  (t =
                    0 === u.length && 0 !== e.length
                      ? qs().RELEVANCE
                      : 0 === e.length && l === qs().RELEVANCE
                      ? qs().MOST_RECENT
                      : l),
                    x({ filterFlavors: c, orderBy: t, search: e });
                },
                [x, c, l, u.length]
              );
            return (
              (0, ze.useEffect)(() => () => e((0, je.tP)([])), [e]),
              (0, Qe.kF)("Regex Library", q.LIBRARY_META_DESCRIPTION),
              (0, ht.jsxs)(ht.Fragment, {
                children: [
                  (0, ht.jsxs)("div", {
                    className: "Mn1lS",
                    children: [
                      (0, ht.jsx)(rt.__, {
                        text: (0, et.Z)("Library entries"),
                        className: lh,
                      }),
                      (0, ht.jsxs)("label", {
                        className: "SS2G3",
                        children: [
                          (0, ht.jsx)("span", {
                            className: lh,
                            children: (0, et.Z)("Search library"),
                          }),
                          (0, ht.jsx)(rt.oi, {
                            defaultValue: u || "",
                            onChange: b,
                            placeholder: (0, et.Z)("Search library"),
                            focusOnMount: !0,
                            clearButton: !0,
                          }),
                        ],
                      }),
                      (0, ht.jsx)(Bn.Z, {
                        className: "kyeKv",
                        children: (0, ht.jsx)(Nu, {
                          isLoading: g,
                          children: (0, ht.jsx)(uh, {
                            libraryData: t,
                            fetchError: !!m,
                            didSearch: "" !== u || c.length > 0,
                          }),
                        }),
                      }),
                      (null == t ? void 0 : t.length) > 0 &&
                        !m &&
                        (0, ht.jsx)(Gu, {
                          pages: r,
                          currentPage: parseInt(h, 10),
                          className: "TkFqs",
                        }),
                    ],
                  }),
                  (0, ht.jsx)(Ke.Z5, {
                    children: (0, ht.jsx)(Ke.AW, {
                      path: ":foo/:bar/*",
                      element: (0, ht.jsx)(rt.l_, { to: "/library" }),
                    }),
                  }),
                  (0, ht.jsx)(ra, {
                    title: s || (0, et.Z)("Library Entry"),
                    preserveLocation: !0,
                    path: ":libraryId/*",
                    children: (0, ht.jsx)(sh, {}),
                  }),
                ],
              })
            );
          };
        var ph = r(48211);
        const dh = ({ title: e, children: t }) =>
            (0, ht.jsxs)("div", {
              className: "qaldp",
              children: [
                (0, ht.jsx)(rt.__, { text: e }),
                (0, ht.jsx)(Bn.Z, { children: t }),
              ],
            }),
          gh = (0, ze.memo)(dh),
          mh = "UClnn",
          fh = "Ln7r5",
          xh = [
            50, 100, 200, 400, 600, 800, 1e3, 1500, 2e3, 3e3, 4e3, 5e3, 7500,
            1e4, 15e3, 2e4, 3e4, 4e4, 5e4, 75e3, 1e5,
          ],
          bh = { exit: "Cr18H", exitActive: "YmXqP" },
          vh = (0, At.Z)(It.JL),
          jh = () => {
            const e = (0, We.I0)(),
              t = (0, We.v9)((e) => e.settings.maxExecutionTime),
              r = (0, We.v9)((e) => e.settings.theme),
              s = (0, We.v9)((e) => e.settings.nonParticipatingGroups),
              n = (0, We.v9)((e) => e.settings.colorizeSyntax),
              a = (0, We.v9)((e) => e.settings.autoComplete),
              i = (0, We.v9)((e) => e.settings.wrapLines),
              o = (0, We.v9)((e) => e.settings.regexAreaLineNumbers),
              c = (0, We.v9)((e) => e.settings.testAreaLineNumbers),
              l = (0, We.v9)((e) => e.settings.language),
              u = (0, We.v9)((e) => e.settings.editorTooltips),
              h = (0, We.v9)((e) => e.settings.displayWhitespace),
              p = (0, We.v9)((e) => e.settings.alwaysCollapseLeftSidebar),
              d = (0, We.v9)((e) => e.settings.alwaysCollapseRightSidebar),
              g = (0, We.v9)((e) => e.settings.defaultFlavor),
              m = (0, We.v9)((e) => e.settings.showWarningUnsavedProgress),
              f = (0, We.v9)((e) => e.settings.defaultCodeGenLanguage),
              x = (0, We.v9)((e) => e.settings.calculateRegexSteps),
              b = (0, We.v9)((e) => e.settings.defaultTabBehavior),
              j = (0, We.v9)((e) => e.settings.disableKeyboardShortcuts),
              y = (0, ze.useState)(!1),
              O = (0, st.Z)(y, 2),
              w = O[0],
              C = O[1],
              E = (0, ze.useRef)(),
              Z = (v, y) => {
                let O;
                null == v.target.checked
                  ? ((O = v.target.value),
                    /^\d+$/.test(O) && (O = parseInt(O, 10)))
                  : (O = v.target.checked);
                const w = {
                  maxExecutionTime: t,
                  theme: r,
                  nonParticipatingGroups: s,
                  colorizeSyntax: n,
                  autoComplete: a,
                  wrapLines: i,
                  regexAreaLineNumbers: o,
                  testAreaLineNumbers: c,
                  language: l,
                  editorTooltips: u,
                  displayWhitespace: h,
                  alwaysCollapseLeftSidebar: p,
                  alwaysCollapseRightSidebar: d,
                  defaultFlavor: g,
                  showWarningUnsavedProgress: m,
                  defaultCodeGenLanguage: f,
                  calculateRegexSteps: x,
                  defaultTabBehavior: b,
                  disableKeyboardShortcuts: j,
                  [y]: O,
                };
                C(!0),
                  e((0, je.I2)(w)),
                  e((0, je.Ot)()),
                  l !== w.language && e((0, je.BF)(w.language)),
                  clearTimeout(E.current),
                  (E.current = setTimeout(() => C(!1), 2e3));
              };
            return (
              (0, ze.useEffect)(
                () => () => {
                  clearTimeout(E.current);
                },
                []
              ),
              (0, ht.jsxs)("div", {
                className: "EGx_u",
                children: [
                  (0, ht.jsx)(rt.uT, {
                    className: "mCG29",
                    classNames: bh,
                    timeout: vh,
                    appear: !1,
                    enter: !1,
                    in: w,
                    children: (0, ht.jsxs)("div", {
                      className: "aQbMN",
                      children: [
                        (0, et.Z)("Saving settings..."),
                        (0, ht.jsx)(rt.$j, {
                          size: gt.J7.TC,
                          className: "Y06gr",
                        }),
                      ],
                    }),
                  }),
                  (0, ht.jsxs)(gh, {
                    title: (0, et.Z)("General"),
                    children: [
                      (0, ht.jsxs)(pi, {
                        className: mh,
                        children: [
                          (0, et.Z)("Language"),
                          (0, ht.jsx)("select", {
                            defaultValue: l,
                            onChange: (e) => Z(e, "language"),
                            children: Object.keys(ph)
                              .sort()
                              .map((e) =>
                                (0, ht.jsx)(
                                  "option",
                                  { value: e, children: ph[e].text },
                                  `language-${e}`
                                )
                              ),
                          }),
                          (0, ht.jsxs)(rt.qX, {
                            className: fh,
                            noMargin: !0,
                            children: [
                              (0, et.Z)(
                                "You can help with translations by visiting the following url:"
                              ),
                              " ",
                              (0, ht.jsx)(rt.rU, {
                                to: "https://r101.cf",
                                absolute: !0,
                                children: "https://r101.cf",
                              }),
                            ],
                          }),
                        ],
                      }),
                      (0, ht.jsxs)(pi, {
                        children: [
                          (0, ht.jsx)("input", {
                            type: "checkbox",
                            checked: p,
                            onChange: (e) => Z(e, "alwaysCollapseLeftSidebar"),
                          }),
                          (0, et.Z)("Always collapse left sidebar"),
                        ],
                      }),
                      (0, ht.jsxs)(pi, {
                        children: [
                          (0, ht.jsx)("input", {
                            type: "checkbox",
                            checked: d,
                            onChange: (e) => Z(e, "alwaysCollapseRightSidebar"),
                          }),
                          (0, et.Z)("Always collapse right sidebar"),
                        ],
                      }),
                      (0, ht.jsxs)(pi, {
                        children: [
                          (0, ht.jsx)("input", {
                            type: "checkbox",
                            checked: m,
                            onChange: (e) => Z(e, "showWarningUnsavedProgress"),
                          }),
                          (0, et.Z)(
                            "Show warning popup when trying to leave site with unsaved data"
                          ),
                        ],
                      }),
                      (0, ht.jsxs)(pi, {
                        className: mh,
                        children: [
                          (0, ht.jsx)("input", {
                            type: "checkbox",
                            checked: b,
                            onChange: (e) => Z(e, "defaultTabBehavior"),
                          }),
                          (0, et.Z)("Use the default behavior for the tab key"),
                          (0, ht.jsx)(rt.qX, {
                            className: fh,
                            noMargin: !0,
                            children: (0, et.Z)(
                              "The tab key will by default switch to the next field in the tabbing order. If this option is disabled, input areas for regex, substitution and test string will instead consume the tab key."
                            ),
                          }),
                        ],
                      }),
                      (0, ht.jsxs)(pi, {
                        children: [
                          (0, ht.jsx)("input", {
                            type: "checkbox",
                            checked: j,
                            onChange: (e) => Z(e, "disableKeyboardShortcuts"),
                          }),
                          (0, et.Z)("Disable all keyboard shortcuts"),
                        ],
                      }),
                    ],
                  }),
                  (0, ht.jsx)(gh, {
                    title: (0, et.Z)("Theme"),
                    children: (0, ht.jsxs)(pi, {
                      children: [
                        (0, et.Z)("Style"),
                        (0, ht.jsxs)("select", {
                          defaultValue: r,
                          onChange: (e) => Z(e, "theme"),
                          children: [
                            (0, ht.jsx)("option", {
                              value: S.B7,
                              children: (0, et.Z)("Automatic"),
                            }),
                            (0, ht.jsx)("option", {
                              value: S.rp,
                              children: (0, et.Z)("Light"),
                            }),
                            (0, ht.jsx)("option", {
                              value: S.Py,
                              children: (0, et.Z)("Dark"),
                            }),
                          ],
                        }),
                      ],
                    }),
                  }),
                  (0, ht.jsxs)(gh, {
                    title: (0, et.Z)("Editor"),
                    children: [
                      (0, ht.jsxs)(pi, {
                        className: mh,
                        children: [
                          (0, et.Z)("Max Execution Time"),
                          (0, ht.jsx)("select", {
                            defaultValue: t,
                            onChange: (e) => Z(e, "maxExecutionTime"),
                            children: xh.map((e) =>
                              (0, ht.jsx)(
                                "option",
                                {
                                  value: e,
                                  children: e > 1e3 ? e / 1e3 + "s" : `${e}ms`,
                                },
                                `max-time-${e}`
                              )
                            ),
                          }),
                          (0, ht.jsx)(rt.qX, {
                            className: fh,
                            noMargin: !0,
                            children: (0, et.Z)(
                              "This setting affects how long the matcher will try to match your regex before it decides to give up"
                            ),
                          }),
                          t < 1500 &&
                            (0, ht.jsx)(rt.qX, {
                              className: fh,
                              noMargin: !0,
                              type: gt.gr.u_,
                              children: (0, et.Z)(
                                "Values below {1} are not recommended. Use at your own discretion",
                                "1.5s"
                              ),
                            }),
                        ],
                      }),
                      (0, ht.jsxs)(pi, {
                        className: mh,
                        children: [
                          (0, et.Z)("Default flavor"),
                          (0, ht.jsx)("select", {
                            defaultValue: g,
                            onChange: (e) => Z(e, "defaultFlavor"),
                            children: v.all.map((e) =>
                              (0, ht.jsx)(
                                "option",
                                { value: e, children: e },
                                `flavor-${e}`
                              )
                            ),
                          }),
                          (0, ht.jsx)(rt.qX, {
                            className: fh,
                            noMargin: !0,
                            children: (0, et.Z)(
                              "Select the flavor you want to use when the site loads. Note: a saved entry's flavor will override this"
                            ),
                          }),
                        ],
                      }),
                      (0, ht.jsxs)(pi, {
                        className: mh,
                        children: [
                          (0, et.Z)("Default code generator language"),
                          (0, ht.jsxs)("select", {
                            defaultValue: f,
                            onChange: (e) => Z(e, "defaultCodeGenLanguage"),
                            children: [
                              (0, ht.jsx)(
                                "option",
                                {
                                  value: "auto",
                                  children: (0, et.Z)("Automatic"),
                                },
                                "code-gen-language-auto"
                              ),
                              As.vI.map((e) =>
                                (0, ht.jsx)(
                                  "option",
                                  { value: e.value, children: e.string },
                                  `code-gen-language-${e.value}`
                                )
                              ),
                            ],
                          }),
                          (0, ht.jsx)(rt.qX, {
                            className: fh,
                            noMargin: !0,
                            children: (0, et.Z)(
                              "If left to automatic, the code generator will mirror the currently selected flavor in the editor"
                            ),
                          }),
                        ],
                      }),
                      (0, ht.jsxs)(pi, {
                        className: mh,
                        children: [
                          (0, ht.jsx)("input", {
                            type: "checkbox",
                            checked: n,
                            onChange: (e) => Z(e, "colorizeSyntax"),
                          }),
                          (0, et.Z)("Highlight Syntax"),
                          (0, ht.jsx)(rt.qX, {
                            className: fh,
                            noMargin: !0,
                            children: (0, et.Z)(
                              "Enable or disable the syntax highlighting of your regular expression in the editor"
                            ),
                          }),
                        ],
                      }),
                      (0, ht.jsxs)(pi, {
                        children: [
                          (0, ht.jsx)("input", {
                            type: "checkbox",
                            checked: a,
                            onChange: (e) => Z(e, "autoComplete"),
                          }),
                          (0, et.Z)("Auto-complete Brackets"),
                        ],
                      }),
                      (0, ht.jsxs)(pi, {
                        children: [
                          (0, ht.jsx)("input", {
                            type: "checkbox",
                            checked: i,
                            onChange: (e) => Z(e, "wrapLines"),
                          }),
                          (0, et.Z)("Wrap Long Lines"),
                        ],
                      }),
                      (0, ht.jsxs)(pi, {
                        children: [
                          (0, ht.jsx)("input", {
                            type: "checkbox",
                            checked: o,
                            onChange: (e) => Z(e, "regexAreaLineNumbers"),
                          }),
                          (0, et.Z)("Show Line Numbers in Regex Editor"),
                        ],
                      }),
                      (0, ht.jsxs)(pi, {
                        children: [
                          (0, ht.jsx)("input", {
                            type: "checkbox",
                            checked: c,
                            onChange: (e) => Z(e, "testAreaLineNumbers"),
                          }),
                          (0, et.Z)(
                            "Show Line Numbers in Test String Editor and Substitution Result"
                          ),
                        ],
                      }),
                      (0, ht.jsxs)(pi, {
                        className: mh,
                        children: [
                          (0, ht.jsx)("input", {
                            type: "checkbox",
                            checked: u,
                            onChange: (e) => Z(e, "editorTooltips"),
                          }),
                          (0, et.Z)("Show tooltips"),
                          (0, ht.jsx)(rt.qX, {
                            className: fh,
                            noMargin: !0,
                            children: (0, et.Z)(
                              "Show informative and helpful tooltips when hovering tokens in the regex editor"
                            ),
                          }),
                        ],
                      }),
                      (0, ht.jsxs)(pi, {
                        children: [
                          (0, ht.jsx)("input", {
                            type: "checkbox",
                            checked: h,
                            onChange: (e) => Z(e, "displayWhitespace"),
                          }),
                          (0, et.Z)(
                            "Visualize whitespace and other special characters"
                          ),
                        ],
                      }),
                      (0, ht.jsxs)(pi, {
                        className: mh,
                        children: [
                          (0, ht.jsx)("input", {
                            type: "checkbox",
                            checked: x,
                            onChange: (e) => Z(e, "calculateRegexSteps"),
                          }),
                          (0, et.Z)(
                            "Show how many steps a regular expression takes to evaluate"
                          ),
                          (0, ht.jsx)(rt.qX, {
                            className: fh,
                            noMargin: !0,
                            children: (0, et.Z)(
                              "If you are working on very large and complex expressions, turning this option off will yield improved performance"
                            ),
                          }),
                        ],
                      }),
                      (0, ht.jsxs)(pi, {
                        className: mh,
                        children: [
                          (0, ht.jsx)("input", {
                            type: "checkbox",
                            checked: s,
                            onChange: (e) => Z(e, "nonParticipatingGroups"),
                          }),
                          (0, et.Z)(
                            "Include non-participating groups in match result"
                          ),
                          (0, ht.jsx)(rt.qX, {
                            className: fh,
                            noMargin: !0,
                            children: (0, et.Z)(
                              "This setting determines whether groups in your regex, which did not match anything in the subject string, should be included in the results or not"
                            ),
                          }),
                        ],
                      }),
                    ],
                  }),
                ],
              })
            );
          },
          yh = () => (
            (0, Qe.kF)("Settings", q.SETTINGS_META_DESCRIPTION),
            (0, ht.jsxs)(Ke.Z5, {
              children: [
                (0, ht.jsx)(Ke.AW, { path: "/", element: (0, ht.jsx)(jh, {}) }),
                (0, ht.jsx)(Ke.AW, {
                  path: "*",
                  element: (0, ht.jsx)(rt.l_, { to: "/settings" }),
                }),
              ],
            })
          ),
          Oh = ({ title: e, permalinkFragment: t, version: r, flavor: s }) => {
            let n;
            return (
              (n =
                null != e && e.length > 0
                  ? (0, ht.jsxs)("span", {
                      children: [
                        (0, ht.jsx)("strong", {
                          className: "fQJFj",
                          children: e,
                        }),
                        " (",
                        t,
                        "/",
                        r,
                        ")",
                      ],
                    })
                  : `${t}/${r}`),
              (0, ht.jsxs)("div", {
                className: "ultvh",
                children: [
                  (0, ht.jsx)(rt.rU, {
                    to: rr(t, r),
                    absolute: !0,
                    children: n,
                  }),
                  (0, ht.jsx)("div", { className: "Qz9r3", children: s }),
                ],
              })
            );
          },
          wh = (0, ze.memo)(Oh),
          Ch = ({
            onModalClose: e,
            isOpen: t,
            title: r = "",
            tags: s = [],
            historyItemIndex: n,
            permalinkFragment: a,
          }) => {
            const i = (0, We.I0)(),
              o = (0, ze.useState)(!1),
              l = (0, st.Z)(o, 2),
              u = l[0],
              h = l[1],
              p = (0, ze.useState)(r),
              d = (0, st.Z)(p, 2),
              g = d[0],
              m = d[1],
              f = (0, ze.useState)(s),
              x = (0, st.Z)(f, 2),
              b = x[0],
              v = x[1],
              j = (0, ze.useState)({ isLoading: !1, hasError: !1 }),
              y = (0, st.Z)(j, 2),
              O = y[0],
              w = y[1],
              C = (0, ze.useCallback)((e) => {
                v(e), h(!0);
              }, []),
              E = (0, ze.useCallback)((e) => {
                m(e), h(!0);
              }, []);
            return (
              (0, ze.useEffect)(() => {
                t && (m(r), v(s));
              }, [t, s, r]),
              (0, ht.jsxs)(bt.Z, {
                onModalClose: e,
                isOpen: t,
                isLoading: O.isLoading,
                children: [
                  (0, ht.jsx)(vt.Z, {
                    children: (0, et.Z)("Edit account entry"),
                  }),
                  (0, ht.jsx)(jt.Z, {
                    children: (0, ht.jsx)(gr, {
                      title: g,
                      tags: b,
                      onTagsChange: C,
                      onTitleChange: E,
                      disabled: O.isLoading,
                    }),
                  }),
                  (0, ht.jsxs)(yt.Z, {
                    children: [
                      O.isLoading &&
                        (0, ht.jsx)(rt.$j, {
                          className: "gTWw0",
                          size: gt.J7.TC,
                        }),
                      O.hasError &&
                        (0, ht.jsx)(rt.lx, {
                          text: (0, et.Z)(
                            "Unable to save changes, please try again"
                          ),
                          direction: gt.qF.N,
                          children: (0, ht.jsx)("div", {
                            className: "wzCa1",
                            role: "alert",
                            children: (0, ht.jsx)(nt.j6O, { size: 20 }),
                          }),
                        }),
                      (0, ht.jsx)(rt.zx, {
                        text: (0, et.Z)("Save"),
                        onClick: async () => {
                          w({ isLoading: !0, hasError: !1 });
                          try {
                            await Promise.all([
                              i((0, je.ML)(b, n, a)),
                              i((0, je._1)(g, n, a)),
                              new Promise((e) => setTimeout(e, 500)),
                            ]),
                              w({ isLoading: !1, hasError: !1 }),
                              e();
                          } catch (e) {
                            c.Z.error("Unable to save account details", e),
                              w({ isLoading: !1, hasError: !0 });
                          }
                        },
                        className: "cTD4v",
                        disabled: O.isLoading || !u,
                      }),
                      (0, ht.jsx)(rt.zx, {
                        text: (0, et.Z)("Close"),
                        onClick: e,
                        type: gt.V5.n1,
                        disabled: O.isLoading,
                      }),
                    ],
                  }),
                ],
              })
            );
          },
          Eh = {
            root: "W2Ezh",
            icons: "J1eYs",
            date: "ULefS",
            icon: "YTN_p",
            fill: "QYMY8",
            delete: "nbKtJ",
            isFavorite: "wEJsJ",
            isLocked: "lEtvT",
            title: "xO8vv",
          },
          Zh = ({
            refreshData: e,
            permalinkFragment: t,
            historyItemIndex: r,
            isOwner: s,
            dateAdded: n,
            isFavorite: a,
            isPrivate: i,
            isLocked: o,
            deleteCode: c,
            isLibraryEntry: l,
            title: u,
            tags: h,
          }) => {
            const p = (0, We.I0)(),
              d = (0, We.v9)((e) => e.general.permalinkFragment),
              g = (0, ze.useState)(!1),
              m = (0, st.Z)(g, 2),
              f = m[0],
              x = m[1],
              b = (0, ze.useState)(!1),
              v = (0, st.Z)(b, 2),
              j = v[0],
              y = v[1],
              O = (0, ze.useCallback)(async () => {
                await p(je.Ez(t, r, !a)), null != d && d === t && p(je.jb(!a));
              }, [p, t, a, r, d]),
              w = (0, ze.useCallback)(async () => {
                await p(je.JO(t, r, !i));
              }, [p, t, r, i]),
              C = (0, ze.useCallback)(async () => {
                await p(je.fU(t, r, !o));
              }, [p, t, r, o]),
              E = (0, ze.useCallback)(() => x(!0), []),
              Z = (0, ze.useCallback)(() => x(!1), []),
              S = (0, ze.useCallback)(() => y(!0), []),
              k = (0, ze.useCallback)(() => y(!1), []),
              P = (0, ze.useCallback)(async () => {
                y(!1),
                  await p(je.MX(t, c)),
                  d === t && p(je.Bq(null, null, null)),
                  e();
              }, [p, t, c, e, d]);
            return (0, ht.jsxs)("div", {
              className: Eh.root,
              children: [
                (0, ht.jsxs)("div", {
                  className: Eh.icons,
                  children: [
                    (0, ht.jsx)(rt.lx, {
                      text: a
                        ? (0, et.Z)("Remove from favorites")
                        : (0, et.Z)("Add to favorites"),
                      direction: gt.qF.NE,
                      children: (0, ht.jsx)(rt.Yd, {
                        onClick: O,
                        children: (0, ht.jsx)(nt.iB2, {
                          className: Xe()(Eh.icon, Eh.isFavorite, a && Eh.fill),
                          size: 16,
                        }),
                      }),
                    }),
                    (0, ht.jsx)(rt.lx, {
                      text: (0, et.Z)("Edit title and tags"),
                      direction: gt.qF.N,
                      children: (0, ht.jsx)(rt.Yd, {
                        onClick: E,
                        children: (0, ht.jsx)(nt.cpK, {
                          className: Xe()(Eh.icon, Eh.title),
                          size: 16,
                        }),
                      }),
                    }),
                    s &&
                      !l &&
                      (0, ht.jsx)(rt.lx, {
                        text: i
                          ? (0, et.Z)("Make permalink public")
                          : (0, et.Z)("Make permalink private"),
                        direction: gt.qF.N,
                        children: (0, ht.jsx)(rt.Yd, {
                          onClick: w,
                          children: (0, ht.jsx)(nt.NuV, {
                            className: Xe()(
                              Eh.icon,
                              Eh.isPrivate,
                              i && Eh.fill
                            ),
                            size: 16,
                          }),
                        }),
                      }),
                    s &&
                      !l &&
                      (0, ht.jsx)(rt.lx, {
                        text: o
                          ? (0, et.Z)("Allow others to edit permalink")
                          : (0, et.Z)("Disallow others to edit permalink"),
                        direction: gt.qF.N,
                        children: (0, ht.jsx)(rt.Yd, {
                          onClick: C,
                          children: (0, ht.jsx)(nt.Dx2, {
                            className: Xe()(Eh.icon, Eh.isLocked, o && Eh.fill),
                            size: 16,
                          }),
                        }),
                      }),
                    !!c &&
                      (0, ht.jsx)(rt.lx, {
                        text: l
                          ? (0, et.Z)("Delete library entry")
                          : (0, et.Z)("Delete permalink"),
                        direction: gt.qF.N,
                        children: (0, ht.jsx)(rt.Yd, {
                          onClick: S,
                          children: (0, ht.jsx)(nt.M$4, {
                            className: Xe()(Eh.icon, Eh.delete),
                            size: 16,
                          }),
                        }),
                      }),
                  ],
                }),
                (0, ht.jsx)("div", {
                  className: Eh.date,
                  children: eh(n).format("YYYY-MM-DD HH:mm"),
                }),
                (0, ht.jsx)(Ch, {
                  isOpen: f,
                  onModalClose: Z,
                  title: u,
                  tags: h,
                  historyItemIndex: r,
                  permalinkFragment: t,
                }),
                (0, ht.jsx)(Ss, {
                  isOpen: j,
                  onModalClose: k,
                  onConfirmClick: P,
                }),
              ],
            });
          },
          Sh = "ZZ5Pq";
        function kh(e, t) {
          var r = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var s = Object.getOwnPropertySymbols(e);
            t &&
              (s = s.filter(function (t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
              })),
              r.push.apply(r, s);
          }
          return r;
        }
        function Ph(e) {
          for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2
              ? kh(Object(r), !0).forEach(function (t) {
                  (0, a.Z)(e, t, r[t]);
                })
              : Object.getOwnPropertyDescriptors
              ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
              : kh(Object(r)).forEach(function (t) {
                  Object.defineProperty(
                    e,
                    t,
                    Object.getOwnPropertyDescriptor(r, t)
                  );
                });
          }
          return e;
        }
        const Nh = ({ item: e, historyItemIndex: t, refreshData: r }) => {
            const s = e.permalinkFragment,
              n = e.version,
              a = e.title,
              i = e.flavor,
              o = e.tags,
              c = e.regex,
              l = e.delimiter,
              u = e.flags;
            return (0, ht.jsxs)("div", {
              className: "yHCCV",
              children: [
                (0, ht.jsx)(Zh, Ph({ refreshData: r, historyItemIndex: t }, e)),
                (0, ht.jsx)(wh, {
                  permalinkFragment: s,
                  version: n,
                  title: a,
                  flavor: i,
                }),
                (0, ht.jsxs)("div", {
                  className: "o699z",
                  children: [
                    (0, ht.jsx)("div", { className: Sh, children: l }),
                    (0, ht.jsx)("div", { className: "cp1os", children: c }),
                    (0, ht.jsx)("div", { className: Sh, children: l }),
                    (0, ht.jsx)("div", { className: "J2B0P", children: u }),
                  ],
                }),
                (0, ht.jsx)(pr, {
                  className: "fyIbf",
                  tags: o,
                  size: gt.J7.HC,
                  ignoreEmpty: !0,
                }),
              ],
            });
          },
          _h = (0, ze.memo)(Nh),
          Th = ({ returnTo: e }) => {
            const t = (0, ze.useState)(!1),
              r = (0, st.Z)(t, 2),
              s = r[0],
              n = r[1],
              a = (0, ze.useCallback)(() => n(!1), []);
            return (0, ht.jsxs)(ht.Fragment, {
              children: [
                (0, ht.jsxs)(rt.qX, {
                  className: "WdG4k",
                  type: gt.gr.u_,
                  children: [
                    (0, ht.jsx)(rt.vV, {
                      tag: "strong",
                      text: "Please {1} by clicking the link or the button in the left sidebar.",
                      ph1: (0, ht.jsx)(rt.Yd, {
                        className: "dQeBH",
                        onClick: () => n(!0),
                        children: (0, et.Z)("sign in"),
                      }),
                    }),
                    (0, ht.jsxs)("p", {
                      children: [
                        (0, et.Z)(
                          "You do not have to create an account, just select an existing account from one of the supported service providers."
                        ),
                        " ",
                        (0, et.Z)(
                          "Only the bare minimum information is retrieved and saved in order to identify your account."
                        ),
                      ],
                    }),
                  ],
                }),
                (0, ht.jsx)(sn, { onModalClose: a, isOpen: s, returnTo: e }),
              ],
            });
          },
          Ah = "bl5fq",
          Ih = ({ scope: e, page: t, emptyMessage: r }) => {
            const s = (0, Ye.lr)(),
              n = (0, st.Z)(s, 1)[0].getAll("filterTags"),
              a = n.join(""),
              i = (0, We.v9)((e) => e.account.staleData),
              o = (0, We.v9)((e) => e.account.data),
              c = (0, Qe.$5)("getUserData"),
              l = (0, st.Z)(c, 3),
              u = l[0],
              h = l[1],
              p = l[2],
              d = (0, ze.useCallback)(
                () => p((0, je.s1)(e, t, n)),
                [p, a, t, e]
              );
            return (
              (0, Qe.DB)(() => {
                i && p((0, je.s1)(e, t, n));
              }, [p, i, a, t, e]),
              (0, Qe.vI)(() => {
                p((0, je.s1)(e, t, n));
              }, [p, a, t, e]),
              h
                ? (0, ht.jsx)(rt.qX, {
                    type: gt.gr.pn,
                    children: (0, et.Z)(
                      "There was an error while fetching your account data. Please try again later."
                    ),
                  })
                : u || 0 !== o.length
                ? (0, ht.jsx)(Nu, {
                    isLoading: u,
                    children: o.map((t, r) =>
                      (0, ht.jsx)(
                        _h,
                        {
                          item: t,
                          filterTags: n,
                          historyItemIndex: r,
                          refreshData: d,
                        },
                        `${e}-user-data-item-${r}`
                      )
                    ),
                  })
                : (0, ht.jsx)(rt.qX, {
                    noMargin: !0,
                    children:
                      n.length > 0
                        ? (0, et.Z)("Your tag filtration returned no results.")
                        : r,
                  })
            );
          },
          Rh = ({ title: e, scope: t, emptyMessage: r }) => {
            const s = (0, Ye.lr)(),
              n = (0, st.Z)(s, 1)[0],
              a = parseInt(n.get("page"), 10) || 1,
              i = (0, We.v9)((e) => e.account.pages),
              o = (0, We.v9)((e) => e.general.userId),
              c = null != o ? e : (0, et.Z)("Account Page");
            return (
              (0, Qe.kF)(c, q.ACCOUNT_META_DESCRIPTION),
              (0, ht.jsxs)("div", {
                className: "Pw4UW",
                children: [
                  (0, ht.jsx)(rt.__, { text: c, className: "rtGnE" }),
                  (0, ht.jsx)(Bn.Z, {
                    className: "mdzfm",
                    children:
                      null == o
                        ? (0, ht.jsxs)(ht.Fragment, {
                            children: [
                              (0, ht.jsx)(Th, {}),
                              (0, ht.jsxs)("p", {
                                className: Ah,
                                children: [
                                  (0, et.Z)(
                                    "By signing in, all your expressions will be automatically saved to your account, where you have ability to organize and manage them."
                                  ),
                                  " ",
                                  (0, et.Z)(
                                    "You can add titles and tags to organize your entries, as well as favorite any expressions."
                                  ),
                                ],
                              }),
                              (0, ht.jsxs)("p", {
                                className: Ah,
                                children: [
                                  (0, et.Z)(
                                    "You also get a valuable feature set with regards to your data privacy, where you are given the ability to restrict who can view and edit the information you save."
                                  ),
                                  " ",
                                  (0, et.Z)(
                                    "If you want to permanently remove the saved data, you can easily do so from here. The delete link will be automatically tied to your account, so you never have to worry about losing it."
                                  ),
                                ],
                              }),
                              (0, ht.jsx)(rt.vV, {
                                tag: "p",
                                text: "By signing in you also get the ability to enhance your skills and participate in the {1} along with thousands of other regex connoisseurs!",
                                ph1: (0, ht.jsx)(rt.rU, {
                                  to: "/quiz",
                                  children: (0, et.Z)("regex quiz"),
                                }),
                              }),
                            ],
                          })
                        : (0, ht.jsx)(Ih, {
                            scope: t,
                            emptyMessage: r,
                            page: a,
                          }),
                  }),
                  (0, ht.jsx)(Gu, {
                    className: "StUEG",
                    currentPage: a,
                    pages: i,
                  }),
                ],
              })
            );
          },
          Dh = () => {
            const e = (0, We.I0)();
            return (
              (0, ze.useEffect)(() => () => e((0, je.xz)()), [e]),
              (0, ht.jsx)("div", {
                className: "cX9NU",
                children: (0, ht.jsxs)(Ke.Z5, {
                  children: [
                    (0, ht.jsx)(Ke.AW, {
                      path: Qs().MINE,
                      element: (0, ht.jsx)(Rh, {
                        title: (0, et.Z)("My Regular Expressions"),
                        scope: Qs().MINE,
                        emptyMessage: (0, et.Z)(
                          "You have not created anything yourself yet."
                        ),
                      }),
                    }),
                    (0, ht.jsx)(Ke.AW, {
                      path: Qs().FAVORITES,
                      element: (0, ht.jsx)(Rh, {
                        title: (0, et.Z)("My Favorites"),
                        scope: Qs().FAVORITES,
                        emptyMessage: (0, et.Z)(
                          "You have not added anything to your favorites yet."
                        ),
                      }),
                    }),
                    (0, ht.jsx)(Ke.AW, {
                      path: Qs().LIBRARY,
                      element: (0, ht.jsx)(Rh, {
                        title: (0, et.Z)("My Library Entries"),
                        scope: Qs().LIBRARY,
                        emptyMessage: (0, et.Z)(
                          "You have not submitted anything to the library yet."
                        ),
                      }),
                    }),
                    (0, ht.jsx)(Ke.AW, {
                      path: "*",
                      element: (0, ht.jsx)(rt.l_, {
                        to: `/account/${Qs().MINE}`,
                      }),
                    }),
                  ],
                }),
              })
            );
          };
        var Lh = r(61898);
        const Mh = ({ title: e, children: t }) =>
            (0, ht.jsxs)("div", {
              className: "bSN9D",
              children: [
                (0, ht.jsx)(rt.__, { text: e, className: "WnWGc" }),
                t,
              ],
            }),
          Uh = Ce()
            ? (0, ze.lazy)(() =>
                Promise.all([r.e(87), r.e(781)]).then(r.bind(r, 90372))
              )
            : () => {},
          Fh = ({
            regex: e,
            flags: t,
            delimiter: r,
            substitution: s,
            isSubstitutionTask: n,
            shortestSolution: a,
            className: i,
            taskIdx: o,
            taskNumber: c,
            hasSolved: l,
          }) => {
            const u = ("" + e + t + r + r + s).length,
              h = n ? "s" + r + e + r + s + r + t : r + e + r + t;
            return (0, ht.jsxs)("div", {
              className: i,
              children: [
                (0, ht.jsx)(rt.__, { text: (0, et.Z)("Task Statistics") }),
                (0, ht.jsxs)(Bn.Z, {
                  children: [
                    (0, ht.jsx)(rt.vV, {
                      text: "Your shortest solution thus far is {1} characters long. The overall shortest solution is {2} characters long.",
                      ph1: (0, ht.jsx)("strong", { children: u }),
                      ph2: (0, ht.jsx)("strong", { children: a }),
                    }),
                    (0, ht.jsx)("div", { className: "uoWfq", children: h }),
                    !l &&
                      (0, ht.jsx)(rt.qX, {
                        type: gt.gr.pn,
                        className: "oJnCW",
                        children: (0, et.Z)(
                          "Your previous best entry has been invalidated and this task is no longer marked as completed for you."
                        ),
                      }),
                    l &&
                      (0, ht.jsx)(rt.I2, {
                        errorClassName: "xEiQv",
                        fallback: (0, ht.jsx)(rt.$j, {
                          size: gt.J7.TC,
                          className: "Z2tPY",
                        }),
                        children: (0, ht.jsx)(Uh, {
                          taskIdx: o,
                          taskNumber: c,
                          bestSolution: u,
                        }),
                      }),
                  ],
                }),
              ],
            });
          },
          Gh = parseFloat(ct.D6),
          Vh = ({ regex: e, flags: t, delimiter: r, flavor: s }) => {
            const n = (0, We.v9)((e) => e.rightSidebar.activeSubsection);
            switch (n) {
              case h:
                return (0, ht.jsx)(Ri, {
                  title: (0, et.Z)("Explanation"),
                  children: (0, ht.jsx)(ei, {
                    regex: e,
                    flags: t,
                    delimiter: r,
                    flavor: s,
                  }),
                });
              case d:
                return (0, ht.jsx)(Ri, {
                  title: (0, et.Z)("Quick Reference"),
                  id: "quickrefParent",
                  children: (0, ht.jsx)(Ei, {}),
                });
              default:
                throw new Error(`Unknown subsection '${n}'`);
            }
          },
          Bh = ({ regex: e, flags: t, delimiter: r, flavor: s }) => {
            const n = (0, Qe.Sj)(Gh);
            if (
              (0, We.v9)((e) => e.settings.alwaysCollapseRightSidebar) ||
              n.width < Gh
            ) {
              const n = [
                {
                  tooltip: (0, et.Z)("View Explanation"),
                  icon: qt.UCm,
                  key: h,
                },
                {
                  tooltip: (0, et.Z)("View Regex Quick Reference"),
                  icon: nt.CA9,
                  key: d,
                },
              ];
              return (0, ht.jsxs)(_i, {
                children: [
                  (0, ht.jsx)(Di, { subsections: n }),
                  (0, ht.jsx)(Vh, {
                    regex: e,
                    flags: t,
                    delimiter: r,
                    flavor: s,
                  }),
                ],
              });
            }
            return (0, ht.jsxs)(oa, {
              children: [
                (0, ht.jsx)(Zi, {
                  title: (0, et.Z)("Explanation"),
                  subsection: h,
                  resizable: !0,
                  children: (0, ht.jsx)(ei, {
                    regex: e,
                    flags: t,
                    delimiter: r,
                    flavor: s,
                  }),
                }),
                (0, ht.jsx)(Zi, {
                  title: (0, et.Z)("Quick Reference"),
                  subsection: d,
                  id: "quickrefParent",
                  children: (0, ht.jsx)(Ei, {}),
                }),
              ],
            });
          },
          qh =
            (Cr().shape({
              taskNumber: Cr().number.isRequired,
              title: Cr().string.isRequired,
              description: Cr().string.isRequired,
              taskType: Cr().string.isRequired,
              errorMessage: Cr().string,
              successMessage: Cr().string,
              totalTests: Cr().number,
              failingTestNumber: Cr().number,
              hasSolved: Cr().bool.isRequired,
              canSolve: Cr().bool.isRequired,
              shortestSolution: Cr().number,
            }),
            Cr().shape({
              regex: Cr().string.isRequired,
              flags: Cr().string.isRequired,
              delimiter: Cr().string.isRequired,
              substitution: Cr().string.isRequired,
            }),
            Cr().shape({
              regex: Cr().string,
              flags: Cr().string,
              delimiter: Cr().string,
              substitution: Cr().string,
            }),
            ({ entry: e, className: t }) => {
              const r = e.regex,
                s = e.flags,
                n = e.delimiter,
                a = e.substitution;
              if ("" === r || null == r) return null;
              const i = ("" + r + s + n + n + a).length;
              return (0, ht.jsx)("div", {
                className: t,
                children: (0, et.Z)("Current score: {1}", i),
              });
            }),
          Hh = (0, ze.memo)(qh),
          $h = "H513J",
          zh = "ZVVpX",
          Wh = "vMhEV",
          Yh = ({ task: e, error: t, loading: r, totalTasks: s, taskIdx: n }) =>
            t
              ? (0, ht.jsxs)(rt.qX, {
                  type: gt.gr.pn,
                  children: [
                    (0, et.Z)(
                      "There was an error querying the server, please try again later:"
                    ),
                    " ",
                    t.message,
                  ],
                })
              : r
              ? (0, ht.jsx)(rt.$j, { size: gt.J7.HC, className: "Npsea" })
              : e.errorMessage
              ? (0, ht.jsx)(Zt, {
                  className: "c7Tes",
                  children: `**Test ${e.failingTestNumber}/${e.totalTests}:** ${e.errorMessage}`,
                })
              : e.successMessage
              ? (0, ht.jsxs)(ht.Fragment, {
                  children: [
                    (0, ht.jsx)(Zt, {
                      className: zh,
                      children: e.successMessage,
                    }),
                    n + 1 < s &&
                      (0, ht.jsxs)(rt.rU, {
                        className: "ityDl",
                        to: `/quiz/${n + 1}`,
                        children: [(0, et.Z)("Next question"), " \u2192"],
                      }),
                  ],
                })
              : (0, et.Z)("Enter your regex and hit submit to see the result."),
          Kh = ["latest", "best"],
          Jh = ({ taskIdx: e }) => {
            const t = (0, ze.useRef)(new Re.ZP()).current,
              r = (0, ze.useRef)(new du()).current,
              s = (0, We.I0)(),
              n = (0, We.v9)((e) => e.quiz.allTasks.length),
              a = (0, We.v9)((t) => t.quiz.allTasks[e - 1]) || {
                latest: {},
                best: {},
                task: null,
              },
              i = a.latest,
              o = a.best,
              c = (0, T.Z)(a, Kh),
              l = i.regex,
              u = i.flags,
              h = i.delimiter,
              p = i.substitution,
              d = o.regex,
              g = o.flags,
              m = o.delimiter,
              f = o.substitution;
            (0, Qe.kF)(`Task ${e} - ${c.title}`, q.QUIZ_META_DESCRIPTION);
            const x = (0, Qe.Sf)(
                (e, t) => s((0, je.$9)(e, { regex: t })),
                q.UPDATE_RESULT_DELAY
              ),
              b = (0, Qe.Sf)(
                (e, t) => s((0, je.$9)(e, { substitution: t })),
                q.UPDATE_RESULT_DELAY
              ),
              v = (0, ze.useCallback)(
                (t) => {
                  const r = (0, Lh.e)(t, j().PCRE2);
                  s((0, je.$9)(e - 1, { flags: r }));
                },
                [s, e]
              ),
              y = (0, ze.useCallback)(
                (t) => s((0, je.$9)(e - 1, { delimiter: t })),
                [s, e]
              ),
              O = (0, ze.useCallback)((t) => x(e - 1, t), [x, e]),
              w = (0, ze.useCallback)((t) => b(e - 1, t), [b, e]),
              C = (0, Qe.$5)("submitQuizSolution"),
              E = (0, st.Z)(C, 3),
              Z = E[0],
              S = E[1],
              k = E[2],
              P = () => {
                Z ||
                  0 === l.length ||
                  null != r.getStatus() ||
                  null != t.getStatus() ||
                  (x.flush(), b.flush(), k((0, je.NS)(c.taskNumber, i)));
              };
            let N = `${(0, et.Z)("Task {1}", e)}: ${c.title}`;
            c.isOptional && (N += ` (${(0, et.Z)("optional")})`);
            const _ = "SUB" === c.taskType;
            return (0, ht.jsxs)(ht.Fragment, {
              children: [
                (0, ht.jsx)(Bh, {
                  regex: l,
                  flavor: j().PCRE2,
                  flags: u,
                  delimiter: h,
                }),
                (0, ht.jsxs)(Mh, {
                  title: N,
                  children: [
                    (0, ht.jsx)(Bn.Z, {
                      className: "k3Ut5",
                      children: (0, ht.jsx)(Zt, {
                        className: zh,
                        children: c.description,
                      }),
                    }),
                    (0, ht.jsxs)("div", {
                      className: "tYBLb",
                      children: [
                        (0, ht.jsx)(rt.__, {
                          text: (0, et.Z)("Regular Expression"),
                        }),
                        (0, ht.jsx)(Jo, {
                          onRegexChange: O,
                          onFlagsChange: v,
                          onDelimiterChange: y,
                          onEnterClick: P,
                          delimiter: h,
                          regex: l,
                          flags: u,
                          regexParser: t,
                          flavor: j().PCRE2,
                        }),
                      ],
                    }),
                    _ &&
                      (0, ht.jsxs)("div", {
                        className: "qdCR1",
                        children: [
                          (0, ht.jsx)(rt.__, {
                            text: (0, et.Z)("Substitution"),
                          }),
                          (0, ht.jsx)(gu, {
                            flavor: j().PCRE2,
                            substParser: r,
                            captureGroupCount: t.captureGroupCount,
                            subpatterns: t.subpatterns,
                            defaultValue: p,
                            onEnterClick: P,
                            onChange: w,
                            className: "ICHlo",
                          }),
                        ],
                      }),
                    (0, ht.jsxs)("div", {
                      className: "O_glM",
                      children: [
                        (0, ht.jsx)(Hh, { className: "asiz9", entry: i }),
                        (0, ht.jsx)(rt.zx, {
                          text: (0, et.Z)("Submit"),
                          onClick: P,
                          disabled:
                            Z ||
                            0 === l.length ||
                            null != r.getStatus() ||
                            null != t.getStatus(),
                          className: "nfzMY",
                        }),
                      ],
                    }),
                    (0, ht.jsxs)("div", {
                      className: "chvbW",
                      children: [
                        (0, ht.jsx)(rt.__, { text: (0, et.Z)("Result") }),
                        (0, ht.jsx)(Bn.Z, {
                          children: (0, ht.jsx)(Yh, {
                            task: c,
                            error: S,
                            loading: Z,
                            totalTasks: n,
                            taskIdx: e,
                          }),
                        }),
                      ],
                    }),
                    null != d &&
                      (0, ht.jsx)("div", {
                        className: $h,
                        children: (0, ht.jsx)(Fh, {
                          regex: d,
                          flags: g,
                          delimiter: m,
                          substitution: f,
                          isSubstitutionTask: _,
                          shortestSolution: c.shortestSolution,
                          className: $h,
                          taskNumber: c.taskNumber,
                          hasSolved: c.hasSolved,
                          taskIdx: e,
                        }),
                      }),
                  ],
                }),
              ],
            });
          },
          Xh = () => {
            const e = (0, Ke.UO)().taskIdx,
              t = (0, We.v9)((t) => t.quiz.allTasks[e - 1]);
            return null != t && t.canSolve
              ? (0, ht.jsx)(Jh, { taskIdx: parseInt(e, 10) }, `quiz-task-${e}`)
              : (0, ht.jsx)(rt.l_, { to: "/quiz" });
          },
          Qh = [
            "DrRegex",
            "Andreas Zetterlund",
            "Timvde",
            "Zarthus",
            "Davidebyzero",
          ],
          ep = ({ notSignedIn: e }) =>
            (0, ht.jsx)(Mh, {
              title: (0, et.Z)("Regex Quiz"),
              children: (0, ht.jsxs)(Bn.Z, {
                className: "d9Wg4",
                children: [
                  e && (0, ht.jsx)(Th, { returnTo: "/quiz" }),
                  (0, ht.jsx)("strong", {
                    children: (0, et.Z)("Welcome to the regex101 regex quiz!"),
                  }),
                  (0, ht.jsxs)("p", {
                    className: Wh,
                    children: [
                      (0, et.Z)(
                        "This is an interactive learning tool you can use to improve your understanding of regular expressions, and their different applications."
                      ),
                      " ",
                      (0, et.Z)(
                        "The quiz is divided into a number of different tasks, which each have a short description of the problem for you to solve."
                      ),
                      " ",
                      (0, et.Z)(
                        "Once you have solved each task, you will be presented with statistics over how well others have done in that task, and the next task will be made available to you."
                      ),
                      " ",
                      (0, et.Z)(
                        "After you have finished a task you can continue improving upon your solution, making it shorter, and climb higher into the leader boards."
                      ),
                    ],
                  }),
                  (0, ht.jsxs)("p", {
                    className: Wh,
                    children: [
                      (0, et.Z)(
                        "Do note that these tasks do not necessarily promote best practices in real life scenarios, but rather aim to teach you the fundamentals of writing powerful regular expressions."
                      ),
                      " ",
                      (0, et.Z)(
                        "Parsing HTML with regex is seldom a good idea, despite there being a task in the quiz to do just that."
                      ),
                      " ",
                      (0, et.Z)(
                        "The quiz is evaluated using the PCRE2 engine, which is also available in the main editor if you would like to do some testing."
                      ),
                      " ",
                      (0, et.Z)(
                        "The tasks will get progressively harder, and you will receive less and less hand-holding the further you progress."
                      ),
                    ],
                  }),
                  (0, ht.jsxs)("p", {
                    className: Wh,
                    children: [
                      (0, et.Z)(
                        "If you encounter any issues, quirky behavior or bugs, please open up an issue on github with all the relevant details"
                      ),
                      ":",
                      " ",
                      (0, ht.jsx)(rt.rU, {
                        to: "https://github.com/firasdib/Regex101/issues",
                        absolute: !0,
                        children: "https://github.com/firasdib/Regex101/issues",
                      }),
                    ],
                  }),
                  (0, ht.jsxs)("div", {
                    className: Wh,
                    children: [
                      (0, et.Z)(
                        "A special thanks goes out to the following individuals for their hard work and contributions to the quiz:"
                      ),
                      (0, ht.jsx)("ul", {
                        className: "Qx04x",
                        children: Qh.map((e) =>
                          (0, ht.jsx)("li", { children: e }, `credit-quiz-${e}`)
                        ),
                      }),
                    ],
                  }),
                  (0, ht.jsx)("p", {
                    className: Wh,
                    children: (0, ht.jsx)("strong", {
                      children: (0, et.Z)("Enjoy!"),
                    }),
                  }),
                ],
              }),
            }),
          tp = () => {
            const e = (0, We.I0)(),
              t = (0, We.v9)((e) => e.general.userId);
            return (
              (0, ze.useEffect)(() => {
                e((0, je.hK)(h));
              }, [e]),
              (0, Qe.kF)("Regex Quiz", q.QUIZ_META_DESCRIPTION),
              null == t
                ? (0, ht.jsx)(ep, { notSignedIn: !0 })
                : (0, ht.jsx)("div", {
                    className: "jGEqA",
                    children: (0, ht.jsxs)(Ke.Z5, {
                      children: [
                        (0, ht.jsx)(Ke.AW, {
                          path: ":taskIdx/*",
                          element: (0, ht.jsx)(Xh, {}),
                        }),
                        (0, ht.jsx)(Ke.AW, {
                          path: "/",
                          element: (0, ht.jsx)(ep, {}),
                        }),
                      ],
                    }),
                  })
            );
          },
          rp = () => {
            const e = (0, Ke.UO)().permalinkFragment,
              t = (0, We.v9)((e) => e.regexEditor.regexVersions),
              r = (0, Qe.$5)("getRegexVersions"),
              s = (0, st.Z)(r, 3),
              n = s[0],
              a = s[1],
              i = s[2];
            return (
              (0, Qe.DB)(() => {
                i((0, je.zp)(e));
              }, [e]),
              n
                ? null
                : a
                ? (0, ht.jsx)(rt.l_, { to: "/" })
                : (0, ht.jsx)(rt.l_, { to: `/r/${e}/${t}` })
            );
          },
          sp = () =>
            (0, ht.jsxs)("div", {
              className: "DmUSm",
              children: [
                (0, ht.jsx)("h1", {
                  children: "A critical error has occurred",
                }),
                (0, ht.jsxs)("p", {
                  children: [
                    "If possible, open up an issue with as many details as you can here:",
                    " ",
                    (0, ht.jsx)("a", {
                      href: "https://github.com/firasdib/Regex101/issues",
                      children: "https://github.com/firasdib/Regex101/issues",
                    }),
                    ".",
                  ],
                }),
                (0, ht.jsx)("p", {
                  children:
                    "It might be a good idea to take a screen shot of your dev console window, if you know how to open it.",
                }),
              ],
            }),
          np = () => {
            (0, Qe.OL)(), (0, Qe.YX)(), (0, Qe.aL)();
            const e = (0, We.v9)((e) => e.settings.alwaysCollapseLeftSidebar),
              t = (0, We.v9)((e) => e.settings.alwaysCollapseRightSidebar),
              r = (0, We.v9)((e) => e.regexEditor.hasUnsavedData),
              s = (0, We.v9)((e) => e.settings.showWarningUnsavedProgress);
            return (
              (0, ze.useEffect)(() => {
                window.requestAnimationFrame(() => tt.ZP.emit(tt.En));
              }, []),
              (0, ze.useEffect)(() => {
                window.onbeforeunload = (e) => {
                  if (s && r) {
                    const t = (0, et.Z)(
                      "You have made changes since you last saved, leaving the website will result in a permanent loss of the data."
                    );
                    return (e.returnValue = t), t;
                  }
                };
              }, [r, s]),
              (0, ht.jsxs)(rt.SV, {
                fallback: (0, ht.jsx)(sp, {}),
                children: [
                  (0, ht.jsx)(Mt, {}),
                  (0, ht.jsxs)("div", {
                    className: "HPRlT",
                    children: [
                      (0, ht.jsx)(Tt, {
                        alwaysCollapseLeftSidebar: e,
                        alwaysCollapseRightSidebar: t,
                      }),
                      (0, ht.jsx)(Vn, { alwaysCollapseLeftSidebar: e }),
                      (0, ht.jsx)("div", {
                        className: Xe()("QtZzw", e && "rxgkz"),
                        children: (0, ht.jsxs)(Ke.Z5, {
                          children: [
                            (0, ht.jsx)(Ke.AW, {
                              path: "/library/*",
                              element: (0, ht.jsx)(hh, {}),
                            }),
                            (0, ht.jsx)(Ke.AW, {
                              path: "/settings/*",
                              element: (0, ht.jsx)(yh, {}),
                            }),
                            (0, ht.jsx)(Ke.AW, {
                              path: "/account/*",
                              element: (0, ht.jsx)(Dh, {}),
                            }),
                            (0, ht.jsx)(Ke.AW, {
                              path: "/quiz/*",
                              element: (0, ht.jsx)(tp, {}),
                            }),
                            (0, ht.jsx)(Ke.AW, {
                              path: "/r/:permalinkFragment/latest",
                              element: (0, ht.jsx)(rp, {}),
                            }),
                            (0, ht.jsx)(Ke.AW, {
                              path: "/r/:permalinkFragment/:version/*",
                              element: (0, ht.jsx)(Su, {}),
                            }),
                            (0, ht.jsx)(Ke.AW, {
                              path: "/r/:permalinkFragment/*",
                              element: (0, ht.jsx)(Su, {}),
                            }),
                            (0, ht.jsx)(Ke.AW, {
                              path: "/*",
                              element: (0, ht.jsx)(Su, {}),
                            }),
                          ],
                        }),
                      }),
                    ],
                  }),
                ],
              })
            );
          },
          ap = ({ store: e, promises: t = [] }) =>
            (0, ht.jsx)(ze.StrictMode, {
              children: (0, ht.jsx)(We.zt, {
                store: e,
                children: (0, ht.jsx)(Ye.VK, { children: (0, ht.jsx)(np, {}) }),
              }),
            });
        let ip,
          op = null;
        async function cp() {
          $e.S1(),
            await (String.fromCodePoint &&
            window.fetch &&
            Object.assign &&
            Object.values &&
            String.prototype.repeat &&
            String.prototype.includes &&
            String.prototype.codePointAt &&
            String.prototype.trim &&
            Array.prototype.includes &&
            Array.prototype.find &&
            Array.prototype.fill &&
            Array.prototype.findIndex &&
            "undefined" != typeof AbortController
              ? (null == window.performance && (window.performance = {}),
                null == window.performance.now &&
                  (window.performance.now = () => Date.now()),
                Promise.resolve())
              : Promise.all([r.e(889), r.e(429)]).then(r.t.bind(r, 95010, 23))),
            (function () {
              const e = window.fetch;
              window.fetch = function (t, r = {}) {
                const s = new AbortController(),
                  n = s.signal,
                  c = s.abort.bind(s),
                  l = e(
                    t,
                    (function (e) {
                      for (var t = 1; t < arguments.length; t++) {
                        var r = null != arguments[t] ? arguments[t] : {};
                        t % 2
                          ? o(Object(r), !0).forEach(function (t) {
                              (0, a.Z)(e, t, r[t]);
                            })
                          : Object.getOwnPropertyDescriptors
                          ? Object.defineProperties(
                              e,
                              Object.getOwnPropertyDescriptors(r)
                            )
                          : o(Object(r)).forEach(function (t) {
                              Object.defineProperty(
                                e,
                                t,
                                Object.getOwnPropertyDescriptor(r, t)
                              );
                            });
                      }
                      return e;
                    })({ signal: n }, r)
                  );
                return (function e(t) {
                  if (t instanceof Promise) {
                    const r = t;
                    (r.then = function (t, r) {
                      const s = Object.getPrototypeOf(this).then.call(
                        this,
                        t,
                        r
                      );
                      return e(s);
                    }),
                      (r.cancel = c);
                  }
                  return t;
                })(l).then(i);
              };
            })();
          const e = await (function () {
            let e;
            Pe().setDefaultLevel("info"),
              c.Z.info("App initialized - version %s", "7.1.4"),
              (window.regex101 = window.regex101 || {});
            try {
              (e = JSON.parse(decodeURIComponent(window.__INITIAL_STATE__))),
                c.Z.info("Loaded initial state");
            } catch (e) {
              return void c.Z.error(
                new Error("Unable to parse initial state from server"),
                { state: window.__INITIAL_STATE__ }
              );
            }
            const t = [_e, Ie, De, Me, Ue, Ve, Be, V, qe, He],
              r = (function (e) {
                const t = (function (e) {
                    return (t, r) => e(r.type === g.sk ? Ee(t, r.value) : t, r);
                  })((0, l.UY)(s)),
                  r = (function (e) {
                    return ({ dispatch: t, getState: r }) =>
                      (s) =>
                      (n) => {
                        const a = s(n),
                          i = e[n.type];
                        if (!i) return a;
                        const o = ye(r(), i.reducersToSave);
                        return Oe.Z.save(i.key, o), t((0, je.UF)()), a;
                      };
                  })(Se),
                  n =
                    ("undefined" != typeof window &&
                      window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__) ||
                    l.qC,
                  a = (0, l.MT)(t, e, n((0, l.md)(u.Z, r)));
                return (
                  (function (e, t) {
                    Ce() &&
                      Object.values(e).forEach((e) => {
                        const r = Oe.Z.get(e.key) || {};
                        t.dispatch((0, je.dM)(r));
                      });
                  })(Se, a),
                  c.Z.info("Store configured"),
                  a
                );
              })(e);
            return Promise.all(t.map((e) => e(r)))
              .catch((e) => {
                throw e;
              })
              .catch((e) => c.Z.error("Unable to initialize app", e))
              .then(() => r);
          })();
          $e.fo(e), lp(e), await $e.PC();
        }
        function lp(e) {
          op || (op = e);
          const t = document.querySelector(q.ROOT_ELEMENT);
          (t.innerHTML = ""), (0, n.render)((0, ht.jsx)(ap, { store: e }), t);
        }
        function up() {
          const e = document.querySelector(q.ROOT_ELEMENT);
          (0, n.unmountComponentAtNode)(e), lp(op);
        }
        "interactive" === document.readyState
          ? cp()
          : document.addEventListener(
              "readystatechange",
              (ip = async () => {
                "interactive" === document.readyState &&
                  (document.removeEventListener("readystatechange", ip),
                  await cp());
              })
            );
      },
      70657: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => s });
        const s = {
          iconButton: "PRs2u",
          disabled: "SC8TZ",
          spinner: "ndNuf",
          icon: "nstWU",
        };
      },
      39912: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => s });
        const s = {
          specialChar: "sej3F",
          whitespace: "qjDbF",
          tab: "YHF8J",
          addBeforeElement: "Ue7my",
          removeNewlines: "iHZok",
        };
      },
      1947: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => s });
        const s = {
          tokenSample: "T0laQ",
          plainText: "xq9Cm",
          keyword: "GedSw",
          flag: "d_MyJ",
          info: "hZ6T9",
          zeroWidth: "KzUpc",
          token: "KrSXE",
          flagDisabled: "Vsdwm",
          tooltip: "fOhwT",
          icon: "W6jS6",
          flags: "aBAKk",
        };
      },
      4458: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => s });
        const s = {
          "group-0": "Ptqb6",
          "group-1": "MnwcL",
          "group-2": "bSq9j",
          "group-3": "WDFFo",
          "group-4": "BuckL",
          alternator: "DsO3D",
          quote: "aZNG2",
          charclass: "QZoeQ",
          meta: "yyE4U",
          quantifier: "LEd3h",
          escaped_string: "HR7qQ",
          inline_modifiers: "Bzxfi",
          verb: "BKf2X",
          subpattern_reference: "xj8ZQ",
          backreference: "r2GH2",
          error: "w_XEF",
          inCharClass: "PQ94p",
          comment: "yU1q9",
          cursorover: "OFUcl",
          mouseoverRelated: "Hkx_o",
          mouseoverRelatedLeft: "kUV2_",
          mouseoverRelatedRight: "qlnVF",
          mouseover: "PqJSq",
          mouseoverLeft: "kG5eN",
          mouseoverRight: "u8QII",
        };
      },
    },
    c = {};
  function l(e) {
    var t = c[e];
    if (void 0 !== t) return t.exports;
    var r = (c[e] = { id: e, loaded: !1, exports: {} });
    return o[e].call(r.exports, r, r.exports, l), (r.loaded = !0), r.exports;
  }
  (l.m = o),
    (e = []),
    (l.O = (t, r, s, n) => {
      if (!r) {
        var a = 1 / 0;
        for (u = 0; u < e.length; u++) {
          for (var [r, s, n] = e[u], i = !0, o = 0; o < r.length; o++)
            (!1 & n || a >= n) && Object.keys(l.O).every((e) => l.O[e](r[o]))
              ? r.splice(o--, 1)
              : ((i = !1), n < a && (a = n));
          if (i) {
            e.splice(u--, 1);
            var c = s();
            void 0 !== c && (t = c);
          }
        }
        return t;
      }
      n = n || 0;
      for (var u = e.length; u > 0 && e[u - 1][2] > n; u--) e[u] = e[u - 1];
      e[u] = [r, s, n];
    }),
    (l.n = (e) => {
      var t = e && e.__esModule ? () => e.default : () => e;
      return l.d(t, { a: t }), t;
    }),
    (r = Object.getPrototypeOf
      ? (e) => Object.getPrototypeOf(e)
      : (e) => e.__proto__),
    (l.t = function (e, s) {
      if ((1 & s && (e = this(e)), 8 & s)) return e;
      if ("object" == typeof e && e) {
        if (4 & s && e.__esModule) return e;
        if (16 & s && "function" == typeof e.then) return e;
      }
      var n = Object.create(null);
      l.r(n);
      var a = {};
      t = t || [null, r({}), r([]), r(r)];
      for (var i = 2 & s && e; "object" == typeof i && !~t.indexOf(i); i = r(i))
        Object.getOwnPropertyNames(i).forEach((t) => (a[t] = () => e[t]));
      return (a.default = () => e), l.d(n, a), n;
    }),
    (l.d = (e, t) => {
      for (var r in t)
        l.o(t, r) &&
          !l.o(e, r) &&
          Object.defineProperty(e, r, { enumerable: !0, get: t[r] });
    }),
    (l.f = {}),
    (l.e = (e) =>
      Promise.all(Object.keys(l.f).reduce((t, r) => (l.f[r](e, t), t), []))),
    (l.u = (e) =>
      ({
        87: "vendors-quizStats",
        101: "markdownContainer",
        153: "regexDebugger",
        215: "vendors-markdownContainer",
        429: "polyfills",
        483: "vendors-quickref",
        530: "vendors-sentry",
        648: "vendors-codeSample",
        653: "quickref",
        781: "quizStats",
        889: "vendors-polyfills",
        961: "codeSample",
      }[e] +
      "." +
      {
        87: "cbb2b4ab004a16c6dfb3",
        101: "53bcfb8ce943c87d72b3",
        153: "8dd93963184542dad02a",
        215: "855c4bc0980030e39b26",
        429: "484bb4c75e1df1f8ff8c",
        483: "d9c9f6ab1098dcb7569d",
        530: "1e5809e6707955dc3a99",
        648: "638d74d40e9ce2aa96ca",
        653: "4550147817191958ffd7",
        781: "e6c2fce6d541b388e478",
        889: "397f21875efb62ebd692",
        961: "595af44a459ca2a141fe",
      }[e] +
      ".chunk.js")),
    (l.miniCssF = (e) =>
      e +
      "." +
      {
        101: "9e42c91353d3f6d3baea",
        153: "3a0abb9ae317a441dd88",
        653: "db58d84198d6592a633e",
        781: "7ba3836d8ae25f7bb111",
        961: "3f4e47b936fafeb707f0",
      }[e] +
      ".css"),
    (l.g = (function () {
      if ("object" == typeof globalThis) return globalThis;
      try {
        return this || new Function("return this")();
      } catch (e) {
        if ("object" == typeof window) return window;
      }
    })()),
    (l.hmd = (e) => (
      (e = Object.create(e)).children || (e.children = []),
      Object.defineProperty(e, "exports", {
        enumerable: !0,
        set: () => {
          throw new Error(
            "ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: " +
              e.id
          );
        },
      }),
      e
    )),
    (l.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t)),
    (s = {}),
    (n = "regex101:"),
    (l.l = (e, t, r, a) => {
      if (s[e]) s[e].push(t);
      else {
        var i, o;
        if (void 0 !== r)
          for (
            var c = document.getElementsByTagName("script"), u = 0;
            u < c.length;
            u++
          ) {
            var h = c[u];
            if (
              h.getAttribute("src") == e ||
              h.getAttribute("data-webpack") == n + r
            ) {
              i = h;
              break;
            }
          }
        i ||
          ((o = !0),
          ((i = document.createElement("script")).charset = "utf-8"),
          (i.timeout = 120),
          l.nc && i.setAttribute("nonce", l.nc),
          i.setAttribute("data-webpack", n + r),
          (i.src = e)),
          (s[e] = [t]);
        var p = (t, r) => {
            (i.onerror = i.onload = null), clearTimeout(d);
            var n = s[e];
            if (
              (delete s[e],
              i.parentNode && i.parentNode.removeChild(i),
              n && n.forEach((e) => e(r)),
              t)
            )
              return t(r);
          },
          d = setTimeout(
            p.bind(null, void 0, { type: "timeout", target: i }),
            12e4
          );
        (i.onerror = p.bind(null, i.onerror)),
          (i.onload = p.bind(null, i.onload)),
          o && document.head.appendChild(i);
      }
    }),
    (l.r = (e) => {
      "undefined" != typeof Symbol &&
        Symbol.toStringTag &&
        Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
        Object.defineProperty(e, "__esModule", { value: !0 });
    }),
    (l.nmd = (e) => ((e.paths = []), e.children || (e.children = []), e)),
    (l.p = "/static/"),
    (a = (e) =>
      new Promise((t, r) => {
        var s = l.miniCssF(e),
          n = l.p + s;
        if (
          ((e, t) => {
            for (
              var r = document.getElementsByTagName("link"), s = 0;
              s < r.length;
              s++
            ) {
              var n =
                (i = r[s]).getAttribute("data-href") || i.getAttribute("href");
              if ("stylesheet" === i.rel && (n === e || n === t)) return i;
            }
            var a = document.getElementsByTagName("style");
            for (s = 0; s < a.length; s++) {
              var i;
              if ((n = (i = a[s]).getAttribute("data-href")) === e || n === t)
                return i;
            }
          })(s, n)
        )
          return t();
        ((e, t, r, s) => {
          var n = document.createElement("link");
          (n.rel = "stylesheet"),
            (n.type = "text/css"),
            (n.onerror = n.onload =
              (a) => {
                if (((n.onerror = n.onload = null), "load" === a.type)) r();
                else {
                  var i = a && ("load" === a.type ? "missing" : a.type),
                    o = (a && a.target && a.target.href) || t,
                    c = new Error(
                      "Loading CSS chunk " + e + " failed.\n(" + o + ")"
                    );
                  (c.code = "CSS_CHUNK_LOAD_FAILED"),
                    (c.type = i),
                    (c.request = o),
                    n.parentNode.removeChild(n),
                    s(c);
                }
              }),
            (n.href = t),
            document.head.appendChild(n);
        })(e, n, t, r);
      })),
    (i = { 296: 0 }),
    (l.f.miniCss = (e, t) => {
      i[e]
        ? t.push(i[e])
        : 0 !== i[e] &&
          { 101: 1, 153: 1, 653: 1, 781: 1, 961: 1 }[e] &&
          t.push(
            (i[e] = a(e).then(
              () => {
                i[e] = 0;
              },
              (t) => {
                throw (delete i[e], t);
              }
            ))
          );
    }),
    (() => {
      var e = { 296: 0 };
      (l.f.j = (t, r) => {
        var s = l.o(e, t) ? e[t] : void 0;
        if (0 !== s)
          if (s) r.push(s[2]);
          else {
            var n = new Promise((r, n) => (s = e[t] = [r, n]));
            r.push((s[2] = n));
            var a = l.p + l.u(t),
              i = new Error();
            l.l(
              a,
              (r) => {
                if (l.o(e, t) && (0 !== (s = e[t]) && (e[t] = void 0), s)) {
                  var n = r && ("load" === r.type ? "missing" : r.type),
                    a = r && r.target && r.target.src;
                  (i.message =
                    "Loading chunk " + t + " failed.\n(" + n + ": " + a + ")"),
                    (i.name = "ChunkLoadError"),
                    (i.type = n),
                    (i.request = a),
                    s[1](i);
                }
              },
              "chunk-" + t,
              t
            );
          }
      }),
        (l.O.j = (t) => 0 === e[t]);
      var t = (t, r) => {
          var s,
            n,
            [a, i, o] = r,
            c = 0;
          if (a.some((t) => 0 !== e[t])) {
            for (s in i) l.o(i, s) && (l.m[s] = i[s]);
            if (o) var u = o(l);
          }
          for (t && t(r); c < a.length; c++)
            (n = a[c]), l.o(e, n) && e[n] && e[n][0](), (e[n] = 0);
          return l.O(u);
        },
        r = (("undefined" != typeof self ? self : this).webpackChunkregex101 =
          ("undefined" != typeof self ? self : this).webpackChunkregex101 ||
          []);
      r.forEach(t.bind(null, 0)), (r.push = t.bind(null, r.push.bind(r)));
    })();
  var u = l.O(void 0, [598], () => l(6817));
  u = l.O(u);
})();
